# mirim — a friendly guide

This is a gentle, start-to-finish walkthrough of **mirim**: a tiny embedded
SQL database that is *encrypted at rest by default* and can hand your data to
someone else as a *post-quantum sealed export*. No prior mirim knowledge is
assumed. If you just want the reference, the [README](../README.md) is
denser; this guide is the on-ramp.

**Contents**

1. [What mirim is (and isn't)](#1-what-mirim-is-and-isnt)
2. [Install it](#2-install-it)
3. [Your first encrypted database](#3-your-first-encrypted-database)
4. [The SQL you can use — a cheat sheet](#4-the-sql-you-can-use--a-cheat-sheet)
5. [Load a ready-made sample](#5-load-a-ready-made-sample)
6. [Keeping data safe: passphrases, rotation, checkpoints](#6-keeping-data-safe-passphrases-rotation-checkpoints)
7. [Send a database to someone: post-quantum sealed exports](#7-send-a-database-to-someone-post-quantum-sealed-exports)
8. [Sign and verify files with mirim-sign](#8-sign-and-verify-files-with-mirim-sign)
9. [Use mirim from Rust](#9-use-mirim-from-rust)
10. [Use mirim from C](#10-use-mirim-from-c)
11. [Troubleshooting & FAQ](#11-troubleshooting--faq)

---

## 1. What mirim is (and isn't)

mirim keeps a small dataset **entirely in memory** and persists it as one
**encrypted file** (`.mrm`). Every change you make is written to an
encrypted, fsynced write-ahead log *before* mirim tells you it succeeded, so
an acknowledged write survives a crash or a power cut.

Reach for mirim when your data is **small, sensitive, and wants to be
durable and portable** — a credential store, an audit trail, a personal
vault, a fleet inventory. It is *not* a general-purpose SQL engine: there are
no joins, no transactions spanning statements, no secondary indexes beyond
the built-in PRIMARY KEY / UNIQUE ones, and the working set must fit in RAM.
If your data outgrows memory, use SQLite. What SQLite does not give you is
an at-rest format with **zero classical asymmetric cryptography** and
**post-quantum sealed exports** — that is mirim's niche.

## 2. Install it

### Option A — a prebuilt package (recommended)

Grab the artifact for your OS from the
[Releases page](https://github.com/cristiancmoises/mirim/releases):

| OS | File |
|----|------|
| Debian / Ubuntu | `mirim_<version>_amd64.deb` — `sudo apt install ./mirim_*.deb` |
| Fedora / RHEL / openSUSE | `mirim-<version>.x86_64.rpm` — `sudo dnf install ./mirim-*.rpm` |
| Any Linux | `mirim-<version>-x86_64.AppImage` — `chmod +x` then run, or the `.tar.gz` |
| macOS | `mirim-<version>-<arch>-macos.dmg` or `.pkg` |
| Windows | `mirim-<version>-x86_64-windows.zip` (contains `mirim.exe`) |

Every artifact is listed in `SHA256SUMS`; verify before installing:

```sh
sha256sum -c SHA256SUMS --ignore-missing
```

### Option B — build from source

mirim is pinned to Rust 1.96.0 (via `rust-toolchain.toml`). With
[rustup](https://rustup.rs) installed:

```sh
git clone https://github.com/cristiancmoises/mirim
cd mirim
cargo build --release
# binary at target/release/mirim  (and mirim-sign with: --features sign)
```

Per-distro prerequisites:

```sh
# Debian/Ubuntu
sudo apt install curl build-essential && curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
# Fedora
sudo dnf install rustup gcc && rustup-init -y
# Arch
sudo pacman -S rustup base-devel && rustup default stable
```

## 3. Your first encrypted database

Run `mirim` with a filename. If the file doesn't exist, mirim creates it and
asks you to set a passphrase:

```text
$ mirim notes.mrm
creating new vault: notes.mrm
new passphrase:
repeat passphrase:
mirim 1.1.0 — .help for commands
mirim> create table notes (id integer primary key, body text);
ok
mirim> insert into notes values (1, 'buy milk');
1 row(s)
mirim> insert into notes values (2, 'call dentist');
1 row(s)
mirim> select * from notes;
id | body
-----------------
1  | buy milk
2  | call dentist
mirim> .quit
```

That's it — `notes.mrm` on disk is XChaCha20-Poly1305 ciphertext keyed by
your passphrase through Argon2id. There is nothing to "turn on"; encryption
is the default and the only mode.

A few things worth knowing immediately:

- **Statements end with `;`.** You can spread one across several lines.
- **Every `ok` is already durable.** You don't need to "save" to survive a
  crash. `.quit` just folds the log into a fresh snapshot on the way out.
- **Dot-commands** start with `.` — type `.help` to see them:

```text
.tables       list tables
.schema       show CREATE TABLE statements
.read <path>  run the SQL statements in a file
.save         checkpoint: fold the log into the vault
.rotate       re-encrypt under a new passphrase
.quit         exit (every Ok statement is already durable)
```

## 4. The SQL you can use — a cheat sheet

mirim speaks a small, predictable dialect. Two types, `INTEGER` (64-bit) and
`TEXT` (UTF-8). No type coercion, ever. `NULL` never matches a comparison.

```sql
-- Comments: -- to end of line, and /* block */ (new in 1.1.0)

CREATE TABLE users (
  id    INTEGER PRIMARY KEY,   -- single-column PK, implies NOT NULL + unique
  email TEXT UNIQUE,           -- UNIQUE allows any number of NULLs
  age   INTEGER
);

-- One row per INSERT. Unlisted columns become NULL.
INSERT INTO users VALUES (1, 'ana@x.io', 30);
INSERT INTO users (id, email) VALUES (2, 'bia@x.io');   -- age is NULL

-- SELECT: projection, WHERE (AND-chained), IS [NOT] NULL,
--         ORDER BY, LIMIT/OFFSET, COUNT(*)   (last three new in 1.1.0)
SELECT email, age FROM users WHERE age >= 18 AND email IS NOT NULL;
SELECT * FROM users ORDER BY age DESC;                 -- NULLs sort last on DESC
SELECT id FROM users ORDER BY id LIMIT 10 OFFSET 20;   -- paging
SELECT COUNT(*) FROM users WHERE age IS NULL;          -- how many unknown ages

UPDATE users SET age = 31 WHERE id = 1;   -- atomic: a violation changes nothing
DELETE FROM users WHERE id = 2;
```

**Carrying untrusted input safely.** Never paste user input into SQL text.
Use `?` placeholders — in the REPL that's less relevant, but from a program
it is the rule (see [§9](#9-use-mirim-from-rust)). Bound values are always
data, never SQL.

What's intentionally *not* here: joins, sub-queries, `GROUP BY`, aggregate
functions other than `COUNT(*)`, `OR` in `WHERE`, expressions/arithmetic,
`FOREIGN KEY`, `DEFAULT`, `CHECK`, multi-row `VALUES`, and any type other
than `INTEGER`/`TEXT`. Model relationships by storing a parent's id or name
as a plain column and joining in your application.

## 5. Load a ready-made sample

The repo ships five realistic sample databases under
[`samples/`](../samples/). Load one into a live vault with `.read`:

```text
$ mirim demo.mrm
new passphrase: ****
repeat passphrase: ****
mirim> .read samples/secrets_vault.sql
ok: ran 30 statement(s) from samples/secrets_vault.sql
mirim> .tables
access_log
secrets
services
mirim> SELECT name, endpoint FROM services ORDER BY name LIMIT 3;
mirim> SELECT COUNT(*) FROM access_log WHERE allowed = 0;
```

Or materialize encrypted vaults for all five at once (and see a post-quantum
sealed export happen):

```sh
cargo run --example gen_samples ./out
```

## 6. Keeping data safe: passphrases, rotation, checkpoints

- **Choose a real passphrase.** mirim stretches it with Argon2id (64 MiB,
  3 passes), which makes brute force expensive — but a weak passphrase is
  still weak. A wrong passphrase, or *any* tampering with the file, fails
  with a single indistinguishable error; mirim never tells an attacker which.
- **Rotate it** without dumping plaintext: `.rotate` re-encrypts the vault
  and rebinds the log under a new passphrase in one atomic step. The old
  passphrase stops working immediately.
- **Checkpoint** with `.save` to fold the write-ahead log into a fresh
  snapshot (smaller file, faster open). You rarely *need* to — your writes
  are already durable — but it tidies up.
- **Back up** by copying the `.mrm` file (and its `.mrm.wal` if present).
  The ciphertext is safe to store anywhere; it reveals nothing without the
  key. For long-term archival that must resist future quantum attackers, use
  a sealed export instead (next section) — a plain vault's confidentiality
  rests on your passphrase, while a sealed export needs no shared secret at
  all.
- **One writer at a time.** On Unix, mirim takes an advisory lock per
  database; a second `mirim <same file>` fails fast rather than corrupting
  the log. The lock dies with the process, so a crash never leaves it stuck.

## 7. Send a database to someone: post-quantum sealed exports

A *sealed export* encrypts a whole database to a recipient's **public key**
using ML-KEM-768 (FIPS 203) — a post-quantum key-encapsulation mechanism.
There is no classical RSA/ECC anywhere, so a copy captured today cannot be
unlocked by a future quantum computer ("harvest-now-decrypt-later").

The flow (shown from Rust; a CLI recipient keeps their secret key safe):

1. The recipient generates a keypair and shares only the **public** half.
2. You seal your database to that public key and send the sealed blob.
3. Only the holder of the matching secret key can open it.

```rust
use mirim::{pq, Db};

let (secret, public) = pq::keygen();        // recipient side
let sealed: Vec<u8> = pq::seal(&db, &public)?;   // your side
let received: Db = pq::open(&sealed, &secret)?;  // recipient reopens
# Ok::<(), mirim::Error>(())
```

You can seal to **several** recipients at once with `pq::seal_multi` — the
snapshot is encrypted once and the key wrapped to each recipient, so any one
of them can open it.

## 8. Sign and verify files with mirim-sign

`mirim-sign` (build with `--features sign`) makes a detached **ML-DSA-87
(FIPS 204)** post-quantum signature over any file:

```sh
# One-time: create a signing seed (keep it secret!) and a public key.
mirim-sign keygen release.seed release.pub

# Sign a file. Argument order is: sign <file> <seed> [-o <manifest>].
mirim-sign sign mirim release.seed              # writes mirim.mf next to it
mirim-sign sign mirim release.seed -o mirim.mf  # or name the manifest explicitly

# Verify anywhere, offline, with just the public key.
mirim-sign verify mirim mirim.mf release.pub && echo OK
```

Add `--enforce <trustfile>` to `verify` to get **rollback protection**: the
manifest carries a monotonic counter, and the trust file remembers the
highest one accepted, so a replayed older signature is rejected. mirim signs
its own release binaries this way; each release ships the binary, its `.mf`
manifest, and the maintainer public key.

## 9. Use mirim from Rust

Add it to `Cargo.toml` (`mirim = "1.1"`), then:

```rust
use mirim::vault::{self, Secret};
use mirim::{Db, Output, Value};

let mut db = Db::new();
db.execute("CREATE TABLE k (id INTEGER PRIMARY KEY, v TEXT)")?;

// Untrusted input is BOUND, never spliced into SQL text.
db.execute_params(
    "INSERT INTO k VALUES (?, ?)",
    &[Value::Int(1), Value::Text("from user".into())],
)?;

// Read it back.
if let Output::Rows { rows, .. } =
    db.execute("SELECT v FROM k ORDER BY id LIMIT 1")?
{
    assert_eq!(rows[0][0], Value::Text("from user".into()));
}

// Load a whole SQL script (e.g. a sample) in one call.
db.execute_script(include_str!("../samples/audit_trail.sql"))?;

// Persist, encrypted at rest.
vault::save(&db, "data.mrm".as_ref(), &Secret::Passphrase("correct horse"))?;
let db = vault::load("data.mrm".as_ref(), &Secret::Passphrase("correct horse"))?;
# Ok::<(), mirim::Error>(())
```

For crash-durable sessions use `DurableDb` instead of `Db`: it keeps the
encrypted write-ahead log, so every acknowledged `execute` is fsynced before
it returns. See the [`quickstart`](../examples/quickstart.rs) example.

## 10. Use mirim from C

The `ffi/` crate builds `libmirim_ffi` (a `cdylib` + `staticlib`) against
[`ffi/include/mirim.h`](../ffi/include/mirim.h): open (raw key or
passphrase), parameterized execute, result accessors, checkpoint, per-handle
errors. Statements that return `MIRIM_OK` are durable before the call
returns. One handle, one thread.

```c
#include "mirim.h"
uint8_t key[32] = { /* 32 bytes from your KMS/HSM */ };
char err[128] = {0};
MirimDb *db = mirim_open("data.mrm", key, err, sizeof err);
MirimResult *r = mirim_execute(db, "create table t (id integer primary key)");
mirim_result_free(r);
mirim_checkpoint(db);
mirim_close(db);
```

## 11. Troubleshooting & FAQ

**"error: …" when opening a file.** A wrong passphrase and a tampered file
produce the *same* error on purpose. Double-check the passphrase; if it's
right, the file may be corrupt or truncated.

**mirim won't open my database — "Locked".** Another `mirim` process holds
the writer lock on that file. Close it; the lock releases when the process
exits (even on a crash).

**"trailing tokens after statement".** mirim runs *one* statement per REPL
line-group. Put each statement on its own `;`-terminated entry, or use
`.read` for a multi-statement file.

**Can I store dates / floats / booleans?** There is no dedicated type. Store
timestamps as Unix epoch `INTEGER`, booleans as `0`/`1`, and format/parse
floats yourself as `TEXT` if you truly need them (mirim never coerces types).

**Is my data safe if someone steals the `.mrm` file?** The file is
authenticated ciphertext; without the passphrase (or key) it reveals
nothing, and any edit is detected. Read [`SECURITY.md`](../SECURITY.md) for
exactly what mirim does and does not defend against before relying on it.

**How big can it get?** The working set lives in RAM. mirim targets small,
sensitive datasets; past a few hundred MB you want a real out-of-core engine.

---

Questions or gaps in this guide? The source of truth is the code and
[`SECURITY.md`](../SECURITY.md); this document aims to get you productive
before you need either.
