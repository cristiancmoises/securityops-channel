-- ============================================================================
-- Sample database: ctf_scoreboard
-- ----------------------------------------------------------------------------
-- A capture-the-flag competition scoreboard: teams, challenges across the
-- usual categories, and the solves that connect them. A good fit for a
-- portable, tamper-evident file you can seal and hand to organizers.
--
-- Timestamps are Unix epoch seconds (INTEGER). A team's score is the sum of
-- the points of the challenges it has solved — mirim has no SUM(), so compute
-- rankings in your app; the raw solves live here.
--
-- Load:  mirim ctf.mrm   then   .read samples/ctf_scoreboard.sql
--
-- Things to try:
--   SELECT name, country FROM teams ORDER BY name;
--   SELECT title, points FROM challenges WHERE category = 'pwn' ORDER BY points DESC;
--   SELECT COUNT(*) FROM solves;                                  -- total solves
--   SELECT title FROM challenges WHERE solved_first_by IS NULL;   -- still unsolved
--   SELECT team, challenge FROM solves ORDER BY ts LIMIT 5;       -- first blood race
-- ============================================================================

CREATE TABLE teams (
  id       INTEGER PRIMARY KEY,
  name     TEXT UNIQUE,
  country  TEXT,       -- ISO-3166 alpha-2
  hidden   INTEGER     -- 1 if excluded from the public board (e.g. staff)
);

CREATE TABLE challenges (
  id               INTEGER PRIMARY KEY,
  slug             TEXT UNIQUE,
  title            TEXT,
  category         TEXT,     -- pwn | web | crypto | rev | forensics | misc
  points           INTEGER,
  solved_first_by  INTEGER   -- teams.id of first blood, NULL if unsolved
);

CREATE TABLE solves (
  id        INTEGER PRIMARY KEY,
  team      TEXT,      -- teams.name
  challenge TEXT,      -- challenges.slug
  ts        INTEGER,   -- epoch s
  points    INTEGER    -- points awarded (snapshot at solve time)
);

INSERT INTO teams VALUES (1, 'null_deref',    'US', 0);
INSERT INTO teams VALUES (2, 'segfault_sultans','DE', 0);
INSERT INTO teams VALUES (3, 'off_by_one',    'JP', 0);
INSERT INTO teams VALUES (4, 'heap_spray',    'BR', 0);
INSERT INTO teams VALUES (5, 'rot13_wizards', 'FR', 0);
INSERT INTO teams VALUES (6, 'staff_internal','US', 1);

INSERT INTO challenges VALUES (1, 'baby-rop',    'Baby ROP',           'pwn',       100, 3);
INSERT INTO challenges VALUES (2, 'heap-note',   'Heap Note',          'pwn',       300, 1);
INSERT INTO challenges VALUES (3, 'jwt-mess',    'JWT Mess',           'web',       150, 4);
INSERT INTO challenges VALUES (4, 'ssti-101',    'SSTI 101',           'web',       200, 2);
INSERT INTO challenges VALUES (5, 'weak-rsa',    'Weak RSA',           'crypto',    250, 5);
INSERT INTO challenges VALUES (6, 'ecb-oracle',  'ECB Oracle',         'crypto',    350, NULL);
INSERT INTO challenges VALUES (7, 'unpack-me',   'Unpack Me',          'rev',       200, 3);
INSERT INTO challenges VALUES (8, 'pcap-hunt',   'PCAP Hunt',          'forensics', 150, 4);
INSERT INTO challenges VALUES (9, 'sanity',      'Sanity Check',       'misc',       10, 1);
INSERT INTO challenges VALUES (10,'quantum-seal','Post-Quantum Seal',  'crypto',    500, NULL);

INSERT INTO solves VALUES (1,  'null_deref',       'sanity',    1717000000, 10);
INSERT INTO solves VALUES (2,  'segfault_sultans', 'sanity',    1717000060, 10);
INSERT INTO solves VALUES (3,  'off_by_one',       'sanity',    1717000120, 10);
INSERT INTO solves VALUES (4,  'off_by_one',       'baby-rop',  1717001000, 100);
INSERT INTO solves VALUES (5,  'null_deref',       'baby-rop',  1717001500, 100);
INSERT INTO solves VALUES (6,  'segfault_sultans', 'ssti-101',  1717002000, 200);
INSERT INTO solves VALUES (7,  'null_deref',       'heap-note', 1717003000, 300);
INSERT INTO solves VALUES (8,  'heap_spray',       'jwt-mess',  1717003500, 150);
INSERT INTO solves VALUES (9,  'rot13_wizards',    'weak-rsa',  1717004000, 250);
INSERT INTO solves VALUES (10, 'off_by_one',       'unpack-me', 1717004500, 200);
INSERT INTO solves VALUES (11, 'heap_spray',       'pcap-hunt', 1717005000, 150);
INSERT INTO solves VALUES (12, 'null_deref',       'ssti-101',  1717005500, 200);
INSERT INTO solves VALUES (13, 'segfault_sultans', 'baby-rop',  1717006000, 100);
