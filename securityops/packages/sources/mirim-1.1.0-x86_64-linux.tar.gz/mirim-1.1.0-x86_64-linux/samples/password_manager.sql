-- ============================================================================
-- Sample database: password_manager
-- ----------------------------------------------------------------------------
-- A personal password manager: named vaults, the login entries inside them,
-- and free-form tags. This is the archetypal reason to want an embedded
-- database that is encrypted at rest by default and can be sealed to a
-- recovery key you keep offline — exactly what mirim is for.
--
-- Note what is NOT stored here: no plaintext passwords. In a real deployment
-- the secret itself lives only inside the encrypted vault payload; a sample
-- file printed to your terminal keeps only non-secret metadata (usernames,
-- URLs, strength, timestamps).
--
-- Timestamps are Unix epoch seconds (INTEGER); booleans are 0 / 1.
--
-- Load:  mirim pw.mrm   then   .read samples/password_manager.sql
--
-- Things to try:
--   SELECT title, username FROM entries ORDER BY title;
--   SELECT title FROM entries WHERE reused = 1;                    -- reused passwords
--   SELECT title, strength FROM entries WHERE strength < 3 ORDER BY strength;
--   SELECT COUNT(*) FROM entries WHERE totp = 1;                   -- have 2FA
--   SELECT title, changed_at FROM entries ORDER BY changed_at ASC LIMIT 5;  -- stalest
-- ============================================================================

CREATE TABLE vaults (
  id         INTEGER PRIMARY KEY,
  name       TEXT UNIQUE,
  purpose    TEXT,      -- personal | work | shared
  created_at INTEGER
);

CREATE TABLE entries (
  id         INTEGER PRIMARY KEY,
  vault      TEXT,       -- vaults.name
  title      TEXT,       -- human label, e.g. "GitHub"
  username   TEXT,
  url        TEXT,
  strength   INTEGER,    -- 0 (weak) .. 4 (strong)
  reused     INTEGER,    -- 1 if the password is reused elsewhere
  totp       INTEGER,    -- 1 if a TOTP 2FA secret is attached
  changed_at INTEGER,    -- last time the password changed (epoch s)
  notes      TEXT        -- NULL if none
);

CREATE TABLE tags (
  id    INTEGER PRIMARY KEY,
  entry INTEGER,   -- entries.id
  tag   TEXT       -- e.g. finance, work, legacy
);

INSERT INTO vaults VALUES (1, 'personal', 'personal', 1690000000);
INSERT INTO vaults VALUES (2, 'work',     'work',     1690000000);
INSERT INTO vaults VALUES (3, 'family',   'shared',   1700000000);

INSERT INTO entries VALUES (1,  'personal', 'GitHub',        'octo-cat',        'https://github.com',        4, 0, 1, 1715000000, NULL);
INSERT INTO entries VALUES (2,  'personal', 'Email',         'me@example.com',  'https://mail.example.com',  3, 0, 1, 1712000000, NULL);
INSERT INTO entries VALUES (3,  'personal', 'Bank',          '4021-****',       'https://bank.example.com',  4, 0, 1, 1716000000, 'primary checking');
INSERT INTO entries VALUES (4,  'personal', 'Streaming',     'me@example.com',  'https://stream.example',    1, 1, 0, 1680000000, 'reused with Forum');
INSERT INTO entries VALUES (5,  'personal', 'Forum',         'octo-cat',        'https://forum.example',     1, 1, 0, 1670000000, 'reused with Streaming');
INSERT INTO entries VALUES (6,  'work',     'AWS Console',   'ops+aws',         'https://console.aws',       4, 0, 1, 1717000000, NULL);
INSERT INTO entries VALUES (7,  'work',     'Jira',          'a.ng',            'https://jira.corp',         2, 0, 0, 1705000000, NULL);
INSERT INTO entries VALUES (8,  'work',     'VPN',           'a.ng',            'vpn.corp',                  3, 0, 1, 1714000000, NULL);
INSERT INTO entries VALUES (9,  'work',     'Legacy CRM',    'admin',           'https://crm.legacy.corp',   0, 1, 0, 1650000000, 'shared admin, rotate!');
INSERT INTO entries VALUES (10, 'family',   'Router',        'admin',           '192.168.1.1',               2, 0, 0, 1700000000, NULL);
INSERT INTO entries VALUES (11, 'family',   'Streaming Kids','family',          'https://kids.stream',       2, 0, 0, 1702000000, NULL);

INSERT INTO tags VALUES (1, 1, 'dev');
INSERT INTO tags VALUES (2, 3, 'finance');
INSERT INTO tags VALUES (3, 4, 'legacy');
INSERT INTO tags VALUES (4, 5, 'legacy');
INSERT INTO tags VALUES (5, 6, 'work');
INSERT INTO tags VALUES (6, 9, 'legacy');
INSERT INTO tags VALUES (7, 9, 'urgent');
INSERT INTO tags VALUES (8, 10, 'home');
