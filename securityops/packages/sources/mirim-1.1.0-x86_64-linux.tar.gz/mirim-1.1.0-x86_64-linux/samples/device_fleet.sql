-- ============================================================================
-- Sample database: device_fleet
-- ----------------------------------------------------------------------------
-- An endpoint / IoT fleet inventory: the devices you manage, their current
-- firmware, and the most recent health check-in for each. The kind of
-- operational data that is sensitive enough to encrypt but small enough to
-- keep entirely in memory.
--
-- Timestamps are Unix epoch seconds (INTEGER); booleans are 0 / 1.
--
-- Load:  mirim fleet.mrm   then   .read samples/device_fleet.sql
--
-- Things to try:
--   SELECT hostname, model FROM devices ORDER BY hostname;
--   SELECT hostname FROM devices WHERE decommissioned_at IS NOT NULL;   -- retired
--   SELECT COUNT(*) FROM checkins WHERE healthy = 0;                    -- unhealthy
--   SELECT device, battery FROM checkins WHERE battery IS NOT NULL
--     ORDER BY battery ASC LIMIT 5;   -- lowest batteries (NULL = mains-powered, excluded)
--   SELECT version, channel FROM firmware ORDER BY released_at DESC LIMIT 3;
-- ============================================================================

CREATE TABLE devices (
  id                INTEGER PRIMARY KEY,
  hostname          TEXT UNIQUE,
  serial            TEXT UNIQUE,
  model             TEXT,
  site              TEXT,       -- physical location code
  firmware          TEXT,       -- firmware.version currently installed
  enrolled_at       INTEGER,    -- epoch s
  decommissioned_at INTEGER     -- epoch s, NULL if still in service
);

CREATE TABLE firmware (
  id          INTEGER PRIMARY KEY,
  version     TEXT UNIQUE,   -- semantic version string
  channel     TEXT,          -- stable | beta | canary
  released_at INTEGER,       -- epoch s
  critical    INTEGER        -- 1 if it closes a security advisory
);

CREATE TABLE checkins (
  id       INTEGER PRIMARY KEY,
  device   TEXT,      -- devices.hostname
  ts       INTEGER,   -- epoch s
  battery  INTEGER,   -- percent 0..100, NULL if mains-powered
  healthy  INTEGER,   -- 1 ok, 0 reported a fault
  note     TEXT       -- free text, NULL if none
);

INSERT INTO firmware VALUES (1, '2.1.0', 'stable', 1704067200, 0);
INSERT INTO firmware VALUES (2, '2.2.0', 'stable', 1709251200, 0);
INSERT INTO firmware VALUES (3, '2.2.1', 'stable', 1711929600, 1);
INSERT INTO firmware VALUES (4, '2.3.0', 'beta',   1714521600, 0);
INSERT INTO firmware VALUES (5, '2.4.0', 'canary', 1717200000, 0);

INSERT INTO devices VALUES (1, 'gw-lobby-01',  'SN-A1001', 'EdgeGW-100', 'HQ',   '2.2.1', 1704067200, NULL);
INSERT INTO devices VALUES (2, 'gw-lobby-02',  'SN-A1002', 'EdgeGW-100', 'HQ',   '2.2.1', 1704067200, NULL);
INSERT INTO devices VALUES (3, 'sensor-cold-1','SN-B2001', 'TempProbe',  'WH1',  '2.1.0', 1706745600, NULL);
INSERT INTO devices VALUES (4, 'sensor-cold-2','SN-B2002', 'TempProbe',  'WH1',  '2.2.0', 1706745600, NULL);
INSERT INTO devices VALUES (5, 'kiosk-east-1', 'SN-C3001', 'Kiosk-7',    'ST-E', '2.3.0', 1709251200, NULL);
INSERT INTO devices VALUES (6, 'kiosk-west-1', 'SN-C3002', 'Kiosk-7',    'ST-W', '2.2.0', 1709251200, 1715000000);
INSERT INTO devices VALUES (7, 'cam-dock-1',   'SN-D4001', 'CamNode',    'WH1',  '2.4.0', 1712000000, NULL);
INSERT INTO devices VALUES (8, 'cam-dock-2',   'SN-D4002', 'CamNode',    'WH1',  '2.2.1', 1712000000, NULL);

INSERT INTO checkins VALUES (1,  'gw-lobby-01',   1717300000, NULL, 1, NULL);
INSERT INTO checkins VALUES (2,  'gw-lobby-02',   1717300060, NULL, 1, NULL);
INSERT INTO checkins VALUES (3,  'sensor-cold-1', 1717300120, 84,   1, NULL);
INSERT INTO checkins VALUES (4,  'sensor-cold-2', 1717300180, 12,   0, 'battery critical');
INSERT INTO checkins VALUES (5,  'kiosk-east-1',  1717300240, NULL, 1, NULL);
INSERT INTO checkins VALUES (6,  'cam-dock-1',    1717300300, 61,   1, NULL);
INSERT INTO checkins VALUES (7,  'cam-dock-2',    1717300360, 7,    0, 'lens obstructed');
INSERT INTO checkins VALUES (8,  'sensor-cold-1', 1717386400, 83,   1, NULL);
INSERT INTO checkins VALUES (9,  'sensor-cold-2', 1717386460, 9,    0, 'battery critical');
INSERT INTO checkins VALUES (10, 'gw-lobby-01',   1717386520, NULL, 0, 'wan link flapping');
