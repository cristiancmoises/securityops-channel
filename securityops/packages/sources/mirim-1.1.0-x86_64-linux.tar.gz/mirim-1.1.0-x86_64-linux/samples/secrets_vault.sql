-- ============================================================================
-- Sample database: secrets_vault
-- ----------------------------------------------------------------------------
-- A self-hosted service-credential store: which services exist, the secrets
-- held for each, when they were last rotated, and an append-only access log.
-- This is mirim's home turf — a small, sensitive dataset that wants to live
-- encrypted at rest and travel as a post-quantum sealed export.
--
-- Conventions used throughout the samples:
--   * timestamps are Unix epoch seconds, stored as INTEGER;
--   * booleans are 0 / 1 INTEGER (mirim has no BOOLEAN type);
--   * relationships are by convention (a name or id column) — mirim has no
--     FOREIGN KEY, so joins live in your application, not the engine.
--
-- Load it into a fresh encrypted vault:
--   mirim secrets.mrm
--   mirim> .read samples/secrets_vault.sql
--
-- Things to try once loaded:
--   SELECT name, endpoint FROM services ORDER BY name;
--   SELECT label FROM secrets WHERE rotated_at IS NULL;          -- never rotated
--   SELECT COUNT(*) FROM access_log WHERE allowed = 0;           -- denied attempts
--   SELECT actor, ts FROM access_log WHERE allowed = 0 ORDER BY ts DESC LIMIT 5;
--   SELECT service, label FROM secrets ORDER BY rotated_at DESC LIMIT 3;
-- ============================================================================

CREATE TABLE services (
  id       INTEGER PRIMARY KEY,
  name     TEXT UNIQUE,   -- stable slug, e.g. postgres-prod
  endpoint TEXT,          -- host:port
  env      TEXT,          -- prod | staging | dev
  owner    TEXT           -- responsible team
);

CREATE TABLE secrets (
  id         INTEGER PRIMARY KEY,
  service    TEXT,          -- services.name
  label      TEXT UNIQUE,   -- unique handle for this secret
  kind       TEXT,          -- password | api_key | token | certificate
  rotated_at INTEGER        -- last rotation (epoch s), NULL = never rotated
);

CREATE TABLE access_log (
  id      INTEGER PRIMARY KEY,
  service TEXT,       -- services.name
  actor   TEXT,       -- who asked
  ts      INTEGER,    -- when (epoch s)
  allowed INTEGER     -- 1 granted, 0 denied
);

INSERT INTO services VALUES (1, 'postgres-prod',  'db.internal:5432',    'prod',    'platform');
INSERT INTO services VALUES (2, 'redis-cache',    'cache.internal:6379', 'prod',    'platform');
INSERT INTO services VALUES (3, 'smtp-relay',     'mail.internal:587',   'prod',    'comms');
INSERT INTO services VALUES (4, 'postgres-stage', 'db.stage:5432',       'staging', 'platform');
INSERT INTO services VALUES (5, 'object-store',   's3.internal:9000',    'prod',    'data');
INSERT INTO services VALUES (6, 'grafana',        'obs.internal:3000',   'prod',    'sre');

INSERT INTO secrets VALUES (1, 'postgres-prod',  'pg_app_password',     'password',    1717200000);
INSERT INTO secrets VALUES (2, 'postgres-prod',  'pg_replica_password', 'password',    NULL);
INSERT INTO secrets VALUES (3, 'redis-cache',    'redis_auth',          'password',    1715000000);
INSERT INTO secrets VALUES (4, 'smtp-relay',     'smtp_api_key',        'api_key',     NULL);
INSERT INTO secrets VALUES (5, 'object-store',   's3_access_key',       'api_key',     1716400000);
INSERT INTO secrets VALUES (6, 'object-store',   's3_secret_key',       'api_key',     1716400000);
INSERT INTO secrets VALUES (7, 'grafana',        'grafana_admin_token', 'token',       1712000000);
INSERT INTO secrets VALUES (8, 'postgres-stage', 'pg_stage_password',   'password',    1710000000);
INSERT INTO secrets VALUES (9, 'smtp-relay',     'smtp_dkim_cert',      'certificate', NULL);

INSERT INTO access_log VALUES (1,  'postgres-prod', 'svc-web',      1717300000, 1);
INSERT INTO access_log VALUES (2,  'postgres-prod', 'svc-web',      1717300100, 1);
INSERT INTO access_log VALUES (3,  'redis-cache',   'svc-worker',   1717300200, 1);
INSERT INTO access_log VALUES (4,  'postgres-prod', 'unknown-host', 1717300300, 0);
INSERT INTO access_log VALUES (5,  'smtp-relay',    'svc-mailer',   1717300400, 1);
INSERT INTO access_log VALUES (6,  'redis-cache',   'svc-web',      1717300500, 0);
INSERT INTO access_log VALUES (7,  'object-store',  'svc-etl',      1717300600, 1);
INSERT INTO access_log VALUES (8,  'grafana',       'oncall-sre',   1717300700, 1);
INSERT INTO access_log VALUES (9,  'postgres-prod', 'ex-employee',  1717300800, 0);
INSERT INTO access_log VALUES (10, 'object-store',  'svc-etl',      1717300900, 1);
INSERT INTO access_log VALUES (11, 'smtp-relay',    'unknown-host', 1717301000, 0);
INSERT INTO access_log VALUES (12, 'redis-cache',   'svc-worker',   1717301100, 1);
