-- ============================================================================
-- Sample database: audit_trail
-- ----------------------------------------------------------------------------
-- A compliance-grade audit trail: the principals acting in a system, the
-- policies in force, and an append-only stream of events (who did what to
-- which resource, allowed or denied, under which policy). Pairs naturally
-- with mirim's durable write-ahead log — every appended event is fsynced
-- before it is acknowledged, so an acknowledged audit record survives a
-- crash — and with signed manifests for tamper-evidence of the exported file.
--
-- Timestamps are Unix epoch seconds (INTEGER); booleans are 0 / 1.
--
-- Load:  mirim audit.mrm   then   .read samples/audit_trail.sql
--
-- Things to try:
--   SELECT COUNT(*) FROM events WHERE allowed = 0;                 -- denied actions
--   SELECT actor, action, resource FROM events WHERE allowed = 0 ORDER BY ts DESC;
--   SELECT display_name FROM principals WHERE disabled_at IS NOT NULL;   -- offboarded
--   SELECT name FROM policies WHERE effect = 'deny' ORDER BY name;
--   SELECT actor, ts FROM events ORDER BY ts DESC LIMIT 10;        -- latest activity
-- ============================================================================

CREATE TABLE principals (
  id           INTEGER PRIMARY KEY,
  subject      TEXT UNIQUE,   -- stable subject id (e.g. user:alice, svc:etl)
  display_name TEXT,
  role         TEXT,          -- admin | operator | auditor | service
  disabled_at  INTEGER        -- epoch s, NULL if active
);

CREATE TABLE policies (
  id        INTEGER PRIMARY KEY,
  name      TEXT UNIQUE,
  resource  TEXT,      -- glob the policy governs, e.g. secrets/*
  effect    TEXT,      -- allow | deny
  priority  INTEGER    -- higher wins on conflict
);

CREATE TABLE events (
  id        INTEGER PRIMARY KEY,
  ts        INTEGER,   -- epoch s
  actor     TEXT,      -- principals.subject
  action    TEXT,      -- read | write | delete | login | rotate | export
  resource  TEXT,      -- what was touched
  allowed   INTEGER,   -- 1 permitted, 0 denied
  policy    TEXT       -- policies.name that decided it, NULL if default-deny
);

INSERT INTO principals VALUES (1, 'user:alice',  'Alice Ng',      'admin',    NULL);
INSERT INTO principals VALUES (2, 'user:bob',    'Bob Reyes',     'operator', NULL);
INSERT INTO principals VALUES (3, 'user:carol',  'Carol Danvers', 'auditor',  NULL);
INSERT INTO principals VALUES (4, 'user:dave',   'Dave Lin',      'operator', 1715600000);
INSERT INTO principals VALUES (5, 'svc:etl',     'ETL Service',   'service',  NULL);
INSERT INTO principals VALUES (6, 'svc:backup',  'Backup Service','service',  NULL);

INSERT INTO policies VALUES (1, 'admins-all',     'secrets/*', 'allow', 100);
INSERT INTO policies VALUES (2, 'auditors-read',  'events/*',  'allow', 50);
INSERT INTO policies VALUES (3, 'deny-offboard',  'secrets/*', 'deny',  200);
INSERT INTO policies VALUES (4, 'etl-read-data',  'data/*',    'allow', 40);
INSERT INTO policies VALUES (5, 'deny-export-pii','pii/*',     'deny',  150);

INSERT INTO events VALUES (1,  1717300000, 'user:alice', 'login',  'console',            1, 'admins-all');
INSERT INTO events VALUES (2,  1717300100, 'user:alice', 'rotate', 'secrets/pg_app',     1, 'admins-all');
INSERT INTO events VALUES (3,  1717300200, 'svc:etl',    'read',   'data/orders',        1, 'etl-read-data');
INSERT INTO events VALUES (4,  1717300300, 'user:dave',  'read',   'secrets/redis_auth', 0, 'deny-offboard');
INSERT INTO events VALUES (5,  1717300400, 'user:carol', 'read',   'events/2026-06',     1, 'auditors-read');
INSERT INTO events VALUES (6,  1717300500, 'svc:backup', 'export', 'pii/customers',      0, 'deny-export-pii');
INSERT INTO events VALUES (7,  1717300600, 'user:bob',   'write',  'data/inventory',     1, 'etl-read-data');
INSERT INTO events VALUES (8,  1717300700, 'user:dave',  'login',  'console',            0, NULL);
INSERT INTO events VALUES (9,  1717300800, 'user:alice', 'delete', 'secrets/old_token',  1, 'admins-all');
INSERT INTO events VALUES (10, 1717300900, 'svc:etl',    'read',   'secrets/s3_key',     0, NULL);
INSERT INTO events VALUES (11, 1717301000, 'user:carol', 'export', 'events/2026-06',     1, 'auditors-read');
INSERT INTO events VALUES (12, 1717301100, 'svc:backup', 'read',   'data/orders',        1, 'etl-read-data');
