# Security model — mirim 1.0

Plain-English threat model. Read the non-goals; they are the half that
matters.

## Durability

`DurableDb` appends every mutating statement to an encrypted write-ahead
log and fsyncs before acknowledging. The crash contract, enforced by a
SIGKILL harness in the test suite: after any crash, the reopened database
contains every acknowledged commit, and recovery never invents state. The
log inherits the vault's confidentiality and integrity: records are
individually AEAD-sealed under a key bound (via HKDF salt and AAD) to the
SHA-256 of the exact snapshot they extend, with authenticated consecutive
sequence numbers. Cross-vault replay, reordering, and splicing fail
closed.

## Constant-time posture

Reviewed site by site; this section is the record. mirim's own code
contains no branch, comparison, or table index that depends on secret
key material. Wrong keys and tampered data are detected exclusively by
AEAD tag verification inside `chacha20poly1305` (constant-time via
`subtle`); ML-KEM decapsulation failure is handled by the scheme's
implicit rejection inside `ml-kem`, and mirim maps success and failure
onto one uniform code path and one uniform error. The KDF-id check, the
trust-file comparison, and all wire-format checks operate on public
bytes. Two deliberate, documented timing signals remain: which wrap slot
matched during multi-recipient open (recipient-set privacy is a stated
non-goal of seal v2), and the CLI's interactive passphrase-confirmation
equality check, where both operands come from the same keyboard and no
attacker-controlled oracle exists. Consequence: there is no
mirim-owned secret-dependent path for dudect to measure; constant-time
obligations live in the dependencies named above. A dudect harness
becomes due the moment mirim grows its own comparison over secret bytes.

## Testing posture

Five libFuzzer targets under `fuzz/` cover every attacker-reachable
decoder: snapshot wire decode, sealed-export open (both versions),
manifest verification, SQL text, and the full WAL open/replay/repair
path. Seed corpora regenerate via
`cargo run --example gen_fuzz_corpus --features fuzzing,sign`. A
deterministic randomized smoke harness (`tests/fuzz_smoke.rs`) exercises
the same surfaces on stable on every `cargo test`. The logic-bearing
suites run under Miri (`-Zmiri-disable-isolation`): the SQL suite (29
tests, including the PRIMARY KEY / UNIQUE index paths and the decode →
index-rebuild path through save/load) and the unit invariants are
re-verified clean for the 0.14.0 index work; the durable/WAL suite runs
clean too but is slow under Miri, and its only index code is the same
decode-rebuild path the SQL suite covers.

## FFI boundary

The core crate forbids unsafe code; `mirim-ffi` is the one deliberate
unsafe surface. Its rules: every `extern "C"` body is wrapped in
`catch_unwind` (a panic becomes `MIRIM_E_PANIC`, never UB across the
boundary); NULL handles and pointers are reported, never dereferenced;
out-of-range result indices return defined values. What the FFI cannot
defend: double-free of a handle or result, use-after-close, and sharing
a handle across threads — these are stated as undefined behaviour in the
header, which is the authoritative contract. The conformance harness
runs the documented misuse paths under ASan/UBSan on both sides of the
boundary.

## What mirim protects

**Offline disk theft and backup exposure.** An adversary who obtains the
`.mrm` file — stolen laptop, leaked backup, seized drive — and does not
hold the passphrase or raw key learns nothing about the contents beyond
the file's size and that it is a mirim vault. Confidentiality and
integrity come from XChaCha20-Poly1305 over the whole snapshot.

**Tampering, including header tampering.** The 50-byte vault header
(magic, version, KDF id, salt, nonce) is bound as AEAD associated data.
Any bit flip in header or body fails authentication. There is no partial
or "best effort" decode of a tampered file.

**Passphrase brute force, within passphrase quality.** Keys are derived
with Argon2id at 64 MiB memory, 3 passes, 4 lanes (RFC 9106 family). This
raises the per-guess cost; it does not rescue a weak passphrase.

**Harvest-now-decrypt-later on sealed exports.** Sealed exports use
ML-KEM-768 (FIPS 203) and a 256-bit symmetric layer. No RSA, no elliptic
curves, no classical Diffie-Hellman exists anywhere in either format. An
adversary recording sealed exports today, betting on a future quantum
computer, gains nothing a quantum computer is currently believed to
deliver against ML-KEM-768 or 256-bit symmetric cryptography.

**Decryption-failure oracles.** Wrong key, wrong recipient, and tampered
data all surface as the same `Error::Crypto` with no detail. ML-KEM
decapsulation is implicit-rejection, so a mismatched KEM ciphertext is
indistinguishable from a tampered body.

**Hostile vault files.** The snapshot decoder treats its input as
attacker-controlled even though it runs only after authentication: every
length is bounds-checked before allocation, collections grow by `push`,
and every structural violation fails closed.

## What mirim does NOT protect against

- **A compromised host.** Malware, a hostile root user, or a debugger on
  the machine while the vault is open sees plaintext and can capture the
  passphrase. Key material is zeroized on drop (`zeroize`), but safe Rust
  cannot scrub transient stack copies, and the decrypted database lives
  in ordinary heap memory while in use. Swap and core dumps are not
  mitigated.
- **Rollback, partially.** `verify_manifest_enforcing` persists the
  highest accepted (counter, target hash) in a 49-byte trust file and
  rejects anything older as `Error::Rollback`. This moves rollback from
  "undetectable" to "detectable given intact local trust state" — an
  adversary who can rewrite the trust file itself can still reset it. The
  trust file is the local trust root; protect it like one (e.g. keep it
  on storage the adversary in your model cannot write). The non-enforcing
  `verify_manifest` still proves origin only, never freshness. The WAL
  remains unprotected against truncation regardless (below).
- **Log truncation.** Deleting the WAL, or tampering with its *final*
  record, is equivalent to rolling back to the last checkpoint plus a
  prefix of the log. Detected tampering anywhere before the final record
  fails closed as corruption. Same adversary class as rollback above.
- **WAL metadata.** Record count and record sizes are visible on disk and
  leak the number of mutations and the approximate size of each statement
  (text plus parameters). Records are not padded.
- **Concurrent writers, on non-Unix.** On Unix, an advisory `flock` on
  `<vault>.lock` makes a second live opener fail with `Error::Locked`,
  and the kernel drops the lock on process death (crash recovery is never
  wedged). This is advisory: a process that ignores mirim and writes the
  files directly is not stopped. Non-Unix builds currently have no
  locking at all — one process, one writer, enforced by you.
- **Ciphertext remanence after rotation.** `rotate_secret` re-encrypts
  under the new secret and atomically replaces the files; it does not
  shred the old ciphertext from unallocated blocks, journals, or backups.
  If the old secret must die, the medium is your problem (FDE, discard,
  or physical destruction).
- **Metadata.** File size, existence, modification times, and access
  patterns are visible. Padding is not implemented.
- **Concurrent writers.** No locking. Two processes saving the same path
  race; the atomic rename means you get one consistent file, but one
  writer's changes are silently lost.
- **Denial of service beyond decode bounds.** A validly decrypted,
  structurally valid snapshot can still describe a database large enough
  to exhaust memory.
- **Side channels beyond upstream guarantees.** Constant-time behaviour
  of ML-KEM, ChaCha20-Poly1305, and Argon2 is inherited from the
  RustCrypto implementations. mirim adds no secret-dependent branches or
  indexing of its own, but no dudect verification of the emitted binary
  has been performed yet.
- **SQL string composition.** `?` binding (`execute_params`, prepared
  `Statement`s) is the supported path for untrusted input; bound values
  are data and cannot alter statement structure. A caller who instead
  concatenates untrusted input into SQL text still owns the
  consequences — binding removes the need, not the possibility.
- **Loss of the secret.** No recovery. A forgotten passphrase or a lost
  recipient key is permanent data loss, by design.

## Properties stated explicitly

- **No forward secrecy at rest.** One passphrase (or raw key) protects
  every save of a vault. Compromise of that secret exposes all past and
  future snapshots encrypted under it. Sealed exports are one-shot: each
  `seal()` encapsulates a fresh shared secret, but the recipient's
  long-term decapsulation key decrypts every export sealed to it.
- **Identity binding is the caller's job.** A sealed export proves
  nothing about who sealed it. Anyone with the recipient's public key can
  produce one. With the `sign` feature, a manifest signed by the sender's
  ML-DSA-87 key gives offline origin authentication for the file it
  covers; distributing and pinning the verifying key is the caller's
  problem, as is checking the manifest before trusting the file.
- **Nonces.** 192-bit XChaCha20-Poly1305 nonces are drawn fresh from the
  OS CSPRNG per encryption; the collision bound is negligible without
  nonce bookkeeping. No counter state exists to misuse.

## Reporting

Security contact: via https://securityops.co. Reports of vulnerabilities
in the format, the parser, or the crypto plumbing are welcome; "the
threat model excludes my attack" is documented above, not a bug.
