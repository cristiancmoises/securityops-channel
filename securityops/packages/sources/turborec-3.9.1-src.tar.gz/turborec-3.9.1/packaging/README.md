# Packaging for Turbo Recorder

This directory builds every distributable: the Debian `.deb`, the RPM, the
AppImage, a portable tarball for **any Unix (including the BSDs)**, and a native
**FreeBSD `.pkg`**.

Every release also publishes `turborec-<version>-source.tar.gz`: an immutable,
reproducible archive of the complete tracked source tree, including tests. Use
it for distribution packaging; `turborec-<version>.tar.gz` is the portable
end-user installer.

`turborec.py`'s `VERSION` is the release source of truth. The tarball and
FreeBSD builders derive it automatically; package formats that require literal
metadata are checked against it by `tests/test_release_metadata.py`. The GitHub
Actions release workflow builds the Linux artifacts on
`ubuntu-latest` and the FreeBSD `.pkg` in a real FreeBSD VM
(`vmactions/freebsd-vm`), then attaches all of them to the tagged release.

## Windows builder

- **`build-windows.sh`** → `dist/Turbo_Recorder-<version>-windows-x64-setup.exe`.
  Downloads and SHA-256-verifies two pinned artifacts: the gyan.dev static
  FFmpeg build and the **python.org Python 3.12 installer**, then runs `makensis`.
  The resulting installer ships `turborec.py`, FFmpeg **and** the Python 3.12
  installer; during install it runs Python silently per-user (with Tk and the
  `py` launcher) only when no Python 3.8+ with Tk is already present — so the
  target machine needs **no prerequisites**. The uninstaller removes the app but
  never uninstalls the shared Python.

## BSD / portable builders

- **`build-tarball.sh`** → `dist/turborec-<version>.tar.gz`. Strict POSIX `sh`
  (no bashisms) so it runs under base `/bin/sh` on FreeBSD/OpenBSD/NetBSD as well
  as Linux/macOS. Unpacks to a self-contained tree with `install.sh` /
  `uninstall.sh` honouring `PREFIX` (default `/usr/local`) and `DESTDIR`:

  ```sh
  tar xzf turborec-3.9.1.tar.gz && cd turborec-3.9.1
  sudo ./install.sh                  # → /usr/local
  PREFIX="$HOME/.local" ./install.sh # per-user
  ```

- **`build-freebsd-pkg.sh`** → `dist/turborec-<version>.pkg`. Must run on FreeBSD
  (uses `pkg create`). Stages the tree under `${PREFIX}`, generates a plist +
  `+MANIFEST`, and emits a package installable with
  `pkg add ./turborec-3.9.1.pkg`. Runtime prerequisites (`python3`, `ffmpeg`,
  and Tk for the GUI) are documented in the package description rather than
  declared as hard deps, so the file installs cleanly on any FreeBSD release
  (`pkg install python3 ffmpeg`).

- **`build-source-tarball.sh`** → `dist/turborec-<version>-source.tar.gz`.
  Archives exactly `HEAD` with `git archive` and deterministic gzip metadata;
  it refuses staged or tracked working-tree edits so a release cannot omit
  uncommitted source accidentally.

## Publishing release binaries to Forgejo + Codeberg

Forgejo (`git.securityops.com.br`) is the primary repo; GitHub and Codeberg are
independent Git remotes synchronized deliberately during a release. Git pushes
replicate branches and tags but **not** release objects or their binaries.
GitHub builds its binaries via `release.yml`; to attach that same verified set
to the Forgejo and Codeberg releases, run:

```sh
# downloads the tag's assets from the GitHub release, then attaches them to the
# matching Forgejo + Codeberg releases (creating the release if needed)
FJTOKEN=<forgejo-token> CBTOKEN=<codeberg-token> \
    packaging/publish-release.sh v3.9.1

# or attach files from a local directory instead of downloading
FJTOKEN=… CBTOKEN=… packaging/publish-release.sh v3.9.1 dist/
```

Tokens are read only from the environment. The script requires all **nine
platform payloads** (including both Windows executables and both RPMs), the
complete source archive, and `SHA256SUMS`: **11 release assets in total**. It
mirrors the checksum file, verifies remote byte sizes, and fails on an
incomplete upload. It is idempotent when re-run.

## Debian `.deb` layout

```
packaging/
├── build-deb.sh            # portable builder (dpkg-deb OR ar+tar+gzip+xz)
├── assets/
│   └── turborec.svg        # source icon (256x256 viewBox, scalable)
└── debian/
    ├── control             # package metadata + Depends
    ├── postinst            # refresh icon/desktop caches on install
    ├── postrm              # refresh icon/desktop caches on removal
    └── turborec.desktop    # desktop entry (Exec=turborec gui)
```

This package ships **no** configuration files, so there is no `conffiles`
member (the builder adds one only if `debian/conffiles` exists).

## Build

```bash
./packaging/build-deb.sh
```

The script:

1. Stages the install layout from the repo:
   - `turborec.py`   -> `/usr/bin/turborec`            (0755)
   - `turborecorder` -> `/usr/bin/turborecorder`       (0755)
   - `debian/turborec.desktop` -> `/usr/share/applications/turborec.desktop`
   - `assets/turborec.svg`     -> `/usr/share/icons/hicolor/scalable/apps/turborec.svg`
   - rasterized 256x256 PNG    -> `/usr/share/icons/hicolor/256x256/apps/turborec.png`
   - `README.md`               -> `/usr/share/doc/turborec/README.md`
2. Builds the control tree (`control` with computed `Installed-Size`,
   `md5sums`, `postinst`, `postrm`).
3. Emits `dist/turborec_3.9.1_all.deb`.

### dpkg-deb vs. portable mode

- If `dpkg-deb` is on `PATH`, it is used (`dpkg-deb --root-owner-group --build`).
- Otherwise the script assembles the `.deb` by hand using only `ar`, `tar`,
  `gzip` and `xz`, producing the three `ar` members in the required order:
  `debian-binary`, `control.tar.gz`, `data.tar.xz`.

### Icon rasterization

The PNG is generated from the SVG using the first available of
`rsvg-convert`, `inkscape`, or ImageMagick `convert`. If none is present but a
pre-rendered `assets/turborec.png` exists, that is used instead.

## Runtime dependencies

All non-self-contained builds need `ffmpeg`, Python 3.8+, and Tk for the GUI.
On Debian/Ubuntu Tk comes from `python3-tk`; the `.deb` also installs
`pulseaudio-utils` for Linux Pulse/PipeWire discovery. On RPM distributions Tk
is normally `python3-tkinter`; the RPM accepts any provider of
`/usr/bin/ffmpeg`, including Fedora's `ffmpeg-free`. When `libx264` is absent,
Turbo Recorder can use `libopenh264` only after its one-frame probe succeeds;
the `noopenh264` shim is rejected. With `fedora-cisco-openh264` enabled, repair
a stub installation with `sudo dnf swap noopenh264 openh264`.

BSD microphone discovery does not require PulseAudio: OpenBSD prefers an
FFmpeg sndio input, while FreeBSD, NetBSD and DragonFly prefer OSS. Each source
must be backed by a real character-device node. `pactl` is optional on BSD and
is needed only for available Pulse sources, including the monitor source
required for desktop/system audio. BSD screen capture uses X11/XWayland.

The Guix definition includes Python's `tk` output and validates `_tkinter`
during the build. This validates the intended CLI/GUI runtime composition in a
headless environment; it does not claim a visual GUI test.

## Verify a built package

```bash
# inspect members and metadata without installing
ar t dist/turborec_3.9.1_all.deb
mkdir -p /tmp/deb && ar x dist/turborec_3.9.1_all.deb --output /tmp/deb
tar -tvf /tmp/deb/data.tar.xz
tar -xOf /tmp/deb/control.tar.gz ./control
```
