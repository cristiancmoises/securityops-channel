# Changelog

All notable changes to Turbo Recorder are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [3.9.1] — 2026-09-06

### Fixed
- **BSD is detected as BSD.** FreeBSD, OpenBSD, NetBSD and DragonFly now retain
  distinct operating-system identities instead of falling through to Linux.
  Their supported screen path uses FFmpeg `x11grab`: X11 retains screen,
  monitor, visible-window and signed-region targets, while XWayland can capture
  the screen/region visible through the compatibility server.
- **Capability-first BSD audio.** Turbo Recorder reads the actual FFmpeg input
  devices before choosing Pulse, sndio or OSS. Pulse is used only when its
  FFmpeg input, `pactl` connection and real sources work; OpenBSD otherwise
  prefers sndio, and FreeBSD/NetBSD/DragonFly prefer OSS. Native candidates
  must resolve to character-device nodes, and sndio/OSS inputs are never
  invented as desktop-audio monitors.
- **Capability-aware BSD cameras.** `/dev/video*` devices are offered only when
  FFmpeg contains V4L2 and the path resolves to a real, capturable device.
- **Fedora H.264 fallback.** If `libx264` is absent from a stock `ffmpeg-free`
  build, automatic recording, explicit H.264, CPU mode and RTMP streaming can
  use `libopenh264` only after a real one-frame initialization succeeds. An
  advertised but unusable Fedora `noopenh264` shim is rejected even when the
  general encoder-probe opt-out is set; OpenH264 uses its supported
  quality/bitrate controls rather than x264 CRF or preset options.

### Packaging and validation
- Added `turborec-3.9.1-source.tar.gz`, a deterministic archive of the complete
  tracked source tree including tests, for BSD ports and other downstream
  packagers. It is distinct from the portable end-user tarball.
- The release gate now requires nine platform payloads, the complete source
  archive and `SHA256SUMS` — 11 assets total — before publication/mirroring.
- The RPM accepts any provider of `/usr/bin/ffmpeg`, including Fedora's
  `ffmpeg-free`. The Guix definition includes Python's `tk` output and validates
  that `_tkinter` imports.
- Added mocked coverage for all four BSD identities, realistic FFmpeg input
  listings, audio preference/fallback, device-node filtering, X11 arguments and
  targets, camera safeguards, and automatic mode. The FreeBSD release job also
  smoke-tests stock FFmpeg, OS detection and a video dry run in a VM. These are
  automated capability/package checks, not physical BSD or Windows capture
  hardware tests.

### Compatibility and documentation
- The v3.9.0 quality-first defaults remain unchanged: **Best**, **Auto**, the
  literal integer **23 fps**, and **4K (3840×2160)**. Recent Windows Unicode
  DirectShow IDs, native HWND and signed multi-monitor fixes are retained.
- Updated the English guide, Brazilian Portuguese documentation, packaging
  notes and website for the BSD audio model, Fedora fallback, Guix GUI runtime,
  new source archive and v3.9.1 downloads.

## [3.9.0] — 2026-09-06

### Changed
- **Quality-first defaults everywhere.** A new GUI or CLI session now starts at
  `best` quality, **23 fps**, and **4K (3840×2160)** output. The same defaults
  apply to `RecordSpec`, command-line parsing, the GUI controls, previews, and
  configuration fallback behavior; explicit user settings still win.
- **Automatic best-codec selection.** `-c auto` is now the default. Turbo
  Recorder runtime-probes candidates and prefers usable hardware **AV1**, then
  hardware **HEVC**, then hardware **H.264**, with software H.264 as the safe,
  real-time-compatible fallback. `-c h264|hevc|av1` remains available for an
  explicit choice, and RTMP/RTMPS streaming continues to force H.264.

### Documentation
- Updated the English README, complete user guide, packaging guide, and the
  full Brazilian Portuguese documentation for the 3.9.0 profile and artifact
  names.
- Clarified that the default is the literal integer **23 fps**, not 23.976 fps,
  and documented when to choose native resolution, 30/60 fps, or an explicit
  compatibility codec.
- Added the production website source, refreshed its release/download content,
  and added a same-origin favicon, screenshot, sitemap, and prominent PT-BR
  documentation route while retaining a zero-JavaScript, tracker-free design.
- Updated GitHub Actions to the current `actions/setup-python@v6` runtime.

### Removed
- Removed the stale, version-specific `docs/RELEASE_NOTES.md`; the changelog and
  automatically generated forge release notes remain the release-history
  sources of truth.

## [3.8.1] — 2026-08-31

### Fixed
- **Same-second recordings no longer overwrite each other.** `ffmpeg` runs
  with `-y` and the output timestamp is second-granularity, so a second
  recording started within the same second as the previous one silently
  replaced the first file. Output names now get a `_1`, `_2`, … suffix when a
  file with the timestamped name already exists (both the FFmpeg and the
  Wayland/wf-recorder paths).
- **Release publishing is guarded against stale mirrors.** `publish-release.sh`
  now verifies that each forge's git tag ref exists and matches the local tag
  before creating/reusing a release, and refuses to publish on a mismatch —
  the same failure mode observed when a stale force-mirror deleted the
  v3.7.1/v3.8.0 tags and reverted `main` on GitHub (and Codeberg's
  pull-mirror) after both releases.

### Changed
- GitHub Actions upgraded off the deprecated Node-20 runtimes:
  `actions/checkout@v4` → `@v6`, `actions/upload-artifact@v4` → `@v5`,
  `actions/download-artifact@v4` → `@v5` (v4/v5 artifact formats are
  incompatible, so upload and download move together).

## [3.8.0] — 2026-08-31

### Added
- **Self-contained Windows installer.** `Turbo_Recorder-…-windows-x64-setup.exe`
  now bundles the pinned **Python 3.12 installer (with Tk)** alongside FFmpeg and
  the app. During install it silently installs Python per-user (Tk, pip, `py`
  launcher, PATH prepended) **only when** no Python 3.8+ with Tk is already
  present, so the target machine needs **no prerequisites** — matching the
  zero-install `.exe`. The uninstaller removes the app but never uninstalls the
  shared Python. The Python installer is pinned (python.org 3.12.10, SHA-256
  verified, matches the published MD5) and cached/verified the same way as the
  pinned FFmpeg build.

### Fixed
- `packaging/build-windows.sh`: fixed the shellcheck SC2015 `A && B || C`
  pattern flagged by the lint gate.
- `--duration` keeps the v3.7.1 behavior: `1h30` is 1 hour 30 minutes; bare
  trailing numbers still mean seconds.

## [3.7.1] — 2026-08-31

### Fixed
- `--duration` now parses `1h30` as the natural shorthand for 1 hour 30
  minutes instead of 1 hour + 30 seconds. Bare trailing numbers still mean
  seconds (`90`, `1m30`, `1h30s`), and all documented forms (`90`, `90s`,
  `5m`, `1h30m`, `HH:MM:SS`) are unchanged.

## [3.7.0] — 2026-07-24

### Added
- **4K default resolution for maximum quality platforms.** Turbo Recorder now
  defaults to 4K output (3840×2160) which is ideal for YouTube's 4K tier and
  other high-quality streaming platforms. The resolution can still be scaled
  down to 720p/1080p/1440p for smaller files or bandwidth constraints.
- **23 fps default frame rate.** The default is the literal integer 23 fps for
  high quality per frame and lower encoding load. Higher fps modes remain
  available via CLI for sports/gaming use cases.
- **Lossless FLAC audio remains default.** Audio quality is maximized with
  FLAC compression, preserving the full 48kHz stereo audio from your sources.

### Changed
- **Enhanced 4K encoder quality across all hardware.** NVENC, QSV, VAAPI,
  AMF, VideoToolbox, and software encoders (x264/x265/AV1) now use lower
  CRF/qp values for 4K output, delivering significantly better quality at
  4K resolution. CRF thresholds reduced by 1-3 points for all encoders.
- **Increased 4K bitrate recommendations.** Live streaming bitrate for 4K
  is now 40Mbps (up from 23Mbps) to match YouTube's premium quality
  recommendations and reduce compression artifacts.
- **Improved encoder presets for 4K.** Quality tiers now favor slower,
  higher-quality presets at 4K resolution. The speed tier thresholds were
  adjusted to better balance quality and real-time performance.
- Recording mode now defaults to **`auto`**: screen + mic + system audio when
  both exist, screen + whichever audio source is available, or video-only.
  Explicit modes remain strict. This makes first-run recording work on ordinary
  Windows/macOS installations where no loopback device is enabled.
- Windows loopback recognition includes Brazilian Portuguese **Mixagem
  estéreo** and other strong localized/virtual-cable names. The GUI also permits
  an explicit system-audio selection from every DirectShow audio source without
  misclassifying every virtual microphone as loopback.
- Duplicate friendly names remain independently selectable in the GUI; the
  stable device ID, window handle, or display ID is retained behind each label.
- Advertised hardware encoders are validated with a cached one-frame probe.
  Auto mode skips NVENC/QSV/VAAPI/AMF/VideoToolbox entries that the installed
  GPU or driver cannot actually initialize and falls back to software.
- Linux audio detection supports older PulseAudio (`pactl info`) and no longer
  invents default devices when the Pulse/PipeWire server is unreachable.
  Turbo Recorder now consumes FFmpeg 5–8's structured DirectShow source list
  and retains a parser for older `-list_devices` output. Friendly names are
  paired with their stable `@device_…` identifiers instead of treating
  `Alternative name` lines as duplicate devices.
- **Unicode Windows device names remain usable.** FFmpeg emits DirectShow names
  as UTF-8; subprocess output is now decoded as UTF-8 before falling back to the
  native code page, fixing names containing accents, `®`, Japanese characters,
  and other non-ASCII text.
- Slow DirectShow drivers no longer make every device disappear: enumeration
  has a hardware-appropriate timeout and preserves output produced before a
  timeout. Audio and camera discovery also share a short-lived cache instead of
  freezing startup with repeated probes.
- **Windows multi-monitor and window capture now matches the documentation.**
  Native `EnumDisplayMonitors` / `EnumWindows` discovery supplies physical-pixel
  geometry and stable `hwnd=0x…` targets. Signed offsets now work for monitors
  positioned left of or above the primary display.
- **macOS screen capture uses the correct AVFoundation display index.** Screen
  pseudo-devices are enumerated explicitly instead of assuming index `1`
  (which can be a webcam), multiple displays appear in the source picker, and
  explicit regions are cropped from the selected real display.
- Invalid capture regions now fail closed instead of silently recording the
  full desktop. Signed X11/Wayland/Windows monitor coordinates are preserved.
- FFmpeg streams stop cleanly on Windows through FFmpeg's `q` command instead of
  an unsupported `SIGINT` call. The CLI now actually watches for `q` as its
  on-screen instructions promise.

### Changed
- Recording mode now defaults to **`auto`**: screen + mic + system audio when
  both exist, screen + whichever audio source is available, or video-only.
  Explicit modes remain strict. This makes first-run recording work on ordinary
  Windows/macOS installations where no loopback device is enabled.
- Windows loopback recognition includes Brazilian Portuguese **Mixagem
  estéreo** and other strong localized/virtual-cable names. The GUI also permits
  an explicit system-audio selection from every DirectShow audio source without
  misclassifying every virtual microphone as loopback.
- Duplicate friendly names remain independently selectable in the GUI; the
  stable device ID, window handle, or display ID is retained behind each label.
- Advertised hardware encoders are validated with a cached one-frame probe.
  Auto mode skips NVENC/QSV/VAAPI/AMF/VideoToolbox entries that the installed
  GPU or driver cannot actually initialize and falls back to software.
- Linux audio detection supports older PulseAudio (`pactl info`) and no longer
  invents default devices when the Pulse/PipeWire server is unreachable.

### Documentation and testing
- Added a complete Brazilian Portuguese guide:
  [`docs/README.pt-BR.md`](docs/README.pt-BR.md).
- Added regression coverage for current/legacy DirectShow output, Unicode names,
  stable IDs, signed geometry, HWND capture, macOS display indices, automatic
  modes, encoder fallback, and graceful shutdown.
- Push/PR tests now run on Linux, Windows, and macOS with Python 3.9 and 3.13.
  Release builds are gated by the same three-OS test suite, and the Windows
  package verifies `dshow`, `gdigrab`, JSON device probes, and a real H.264
  encode before it is published.
- Release jobs now converge on one atomic publishing gate. All eight platform
  artifacts must exist and be non-empty; `SHA256SUMS` is generated, GitHub is
  verified, and Forgejo/Codeberg uploads verify remote byte sizes.

## [3.6.0] — 2026-07-13

### Fixed
- **`turborecorder` now records on Wayland.** The Bash recorder was X11-only
  (`x11grab`), so on a Wayland/wlroots session it captured nothing and **saved no
  file**. It now auto-detects the session and captures with **`wf-recorder`** on
  Wayland — video-only, video + system, video + mic, and video + **mixed
  mic&system** (via a PipeWire combined source, cleaned up on exit) — with clean
  Ctrl-C stop (signal forwarded to wf-recorder so the file is finalized).
- **Static-screen recordings no longer hang on stop.** Both recorders now pass
  `-D` (no-damage / constant framerate) to `wf-recorder`, so it always polls its
  stop flag and finalizes cleanly even when the screen isn't changing (previously
  a still screen could stall the stop until a `SIGKILL` truncated the file).

### Changed
- `turborecorder` prints the detected session and capture backend, and selects a
  `wf-recorder`-compatible encoder on Wayland (VAAPI on Intel/AMD, else software).

## [3.5.0] — 2026-07-13

### Added
- **Webcam overlay (picture-in-picture), OBS-style.** Overlay your camera on the
  recording *or* the live stream: pick the device (`--camera`, or the GUI
  **Webcam** dropdown), the **size** (`small`/`medium`/`large`, an explicit `WxH`,
  or `N%` of the output width) and the **position** (any corner or center). Works
  on every backend — ffmpeg (X11/macOS/Windows) and Wayland (`wf-recorder` →
  ffmpeg overlay pipeline) — and for both file recording and RTMP streaming. The
  camera is hardware-encoded into the output with the rest of the frame. New
  `turborec cameras` lists available devices.
- **Built-in microphone noise suppression (`--denoise`), NoiseTorch-style.** A
  one-switch `off`/`light`/`medium`/`strong` noise reducer (ffmpeg `afftdn` with
  adaptive noise tracking + a high-pass), applied **to the microphone only** —
  never to clean system audio. No external NoiseTorch daemon, model file, or
  virtual device required; it's all in the tool and works in recordings and
  streams, in the CLI and the GUI (**Denoise** dropdown).

### Fixed
- **Webcam/stream FIFO frame loss.** On the Wayland compose pipeline the screen
  FIFO is now opened as ffmpeg's *last* input, after the slow-to-start camera and
  microphone, so ffmpeg drains it immediately and `wf-recorder` never blocks on
  the pipe buffer — eliminating the dropped-frames / short-recording bug when a
  webcam or audio was added.

### Changed
- The detection summary now flags an active webcam (`· CAM`) and denoise level.

## [3.4.0] — 2026-07-13

### Added
- **Zero-install, self-contained Windows app.** The Windows `.exe` now bundles
  **FFmpeg** (plus Python and Tk) inside it, so users just download and run —
  no Python, no separate FFmpeg, no `PATH` setup, no admin install. When frozen,
  Turbo Recorder finds its bundled `ffmpeg.exe` automatically (a system FFmpeg on
  `PATH`, or `--ffmpeg`, still overrides it). The bundling is wired into both the
  release workflow and the on-demand `windows-asset` workflow.

### Changed
- Turbo Recorder is now developed **primary on Forgejo**
  (`git.securityops.co/cristiancmoises/turborec`), with **GitHub** and
  **Codeberg** as push-mirrors. Releases (with all binaries) are published on
  Forgejo as well as GitHub.

### Security
Full adversarial security audit of the codebase and CI/release supply chain, with
all confirmed findings fixed:
- **Windows PATH hardening.** The self-contained build now exposes **only** the
  bundle's own extracted directory (`sys._MEIPASS`) on `PATH`, and only if it
  actually contains the bundled `ffmpeg` — never the folder the portable `.exe`
  was launched from (e.g. Downloads). This closes a binary-planting vector where a
  co-located `nvidia-smi.exe` could have been executed.
- **Stream key no longer leaks via ffmpeg stderr.** ffmpeg prints the output RTMP
  URL (which contains the key) at info/error level; that child stderr is now piped
  through the same redaction as everything else, so the key never reaches the
  terminal, scrollback, or a redirected log.
- **Supply-chain pinning.** The bundled FFmpeg is a pinned, immutable gyan.dev
  build verified by SHA-256 in CI; PyInstaller and appimagetool are likewise
  pinned (appimagetool moved off the rolling `continuous` tag to a checksummed
  versioned release).
- **Filesystem hardening.** Wayland mux scratch files moved from the user-chosen
  output directory into a private `0700` temp dir (removing a symlink-overwrite
  vector on shared output dirs), and the config loader now tolerates pathologically
  deep JSON instead of crashing.

## [3.3.0] — 2026-07-13

### Added
- **YouTube live streaming (OBS-style)** — go live straight from Turbo Recorder
  with your YouTube **stream key**, no third-party software. CLI: `--stream KEY`
  (optionally `--stream-url` for a custom RTMP/RTMPS ingest; defaults to YouTube's
  `rtmps://a.rtmps.youtube.com:443/live2`); GUI: a masked **Stream key** field.
  The engine forces a streaming-correct pipeline — H.264 (CBR at YouTube's
  recommended bitrate for the frame size), AAC audio, a 2-second keyframe interval
  (GOP = 2×fps) and FLV — while still mixing mic + system audio. On Wayland,
  `wf-recorder` encodes into an mpegts FIFO that ffmpeg stream-copies and pushes,
  so live streaming works on wlroots compositors too. Video-only streams get a
  silent audio track so YouTube always sees audio.
- **Adaptive, resolution-aware encoder tuning** — the encoder presets now scale
  with the actual pixel throughput (megapixels/sec). At 1080p there is spare
  encode time, so Turbo Recorder uses much slower/higher-quality presets
  (NVENC `p7` + temporal-AQ + look-ahead, x264 `slow` CRF 17, x265, SVT-AV1),
  and it steps down toward faster presets only at 4K / high-fps to keep capture
  real-time. Result: visibly better quality at the resolutions most people record,
  with no dropped frames at the demanding ones.

### Security
- **Stream keys are treated as credentials.** They are redacted (`••••`) from every
  printed command, the `--dry-run` output, the GUI command preview, and the
  end-of-stream status line — including whitespace-padded keys. The live preview /
  dry-run no longer creates a temporary stream pipe on disk. A note is shown when
  going live that, as with any ffmpeg RTMP push, the key is visible to other local
  users via the process list on a shared machine. `--stream-url` is restricted to
  `rtmp://` / `rtmps://` ingests.

### Packaging
- **BSD / portable binary release.** A new architecture-independent tarball
  (`turborec-<version>.tar.gz`, with `install.sh` / `uninstall.sh`) installs on any
  Unix with Python 3 — FreeBSD, OpenBSD, NetBSD, DragonFly, illumos, Linux, macOS —
  and a native **FreeBSD package** (`turborec-<version>.pkg`, `pkg add`) is now
  built and smoke-tested in CI alongside the `.deb`, `.rpm`, and AppImage.

## [3.2.0] — 2026-07-12

### Added
- **Selectable output resolution (`-R/--resolution`)** — `native` (default),
  `720p`, `1080p`, `1440p`, `4k`. The recording is scaled with high-quality
  lanczos (aspect preserved, padded to the exact standard frame), so you can
  **record true 4K videos** even from a 1080p/1200p screen. This matters for
  YouTube: it picks its quality tier (and bitrate budget) from the uploaded
  resolution — a native 1920×1200 capture can land at a low tier, while a 4K
  upload gets the high-bitrate 4K pipeline. Works on every backend: ffmpeg
  (X11/macOS/Windows; scaling runs before any NVENC/VAAPI/QSV hwupload) and
  Wayland (`wf-recorder -F`). Available in the CLI, the GUI (**Output** dropdown),
  and the JSON config (`"resolution": "4k"`).

### Notes
- On Wayland, choosing a scaled resolution with a VAAPI encoder falls back to the
  software encoder (the software scale chain can't feed VAAPI hardware frames).

## [3.1.0] — 2026-07-08

### Added
- **Audio channel handling (`--audio-channels`)** — fixes recordings that only
  play on one side. `left`/`right` clone that channel to **both** outputs at full
  level (ideal for a mono mic wired to one input, e.g. a Focusrite where only one
  channel is live); `mono` averages both channels (clip-safe); `stereo` (default)
  keeps the source. Applies to every audio path — the ffmpeg backend (X11/macOS/
  Windows, audio-only modes) and Wayland (a non-`stereo` choice routes audio
  through ffmpeg + mux so the channel remap always applies). Available in the CLI
  and as a **Channels** dropdown in the GUI.
- **23 fps** added to the GUI frame-rate presets — a great quality/CPU sweet spot
  (~2.6× less encoding work than 60 fps), which meaningfully lowers CPU load
  during software (Wayland/CPU) capture. Any FPS is still settable via `-f`.

## [3.0.0] — 2026-06-28

### Added
- **Wayland (wlroots) screen capture** via `wf-recorder` — sway, Hyprland, river,
  etc. `x11grab` only ever saw XWayland, so on a Wayland session video was
  black/empty; turborec now auto-detects Wayland and records the real desktop.
  Per-output (`--monitor`), region (`--region`, mapped to the right output), and
  sway **window** capture are supported; outputs/windows are read from
  `swaymsg`/`wlr-randr`.
- **Perfectly A/V-synced mic+system on Wayland.** For `video_both`, turborec
  creates a temporary PipeWire combined source (null sink + two loopbacks) so a
  single `wf-recorder` process captures video and mixed audio under one clock —
  no lip-sync drift — then tears the modules down. Falls back to a two-process
  capture + mux if the combined source can't be created. The chosen audio codec
  (FLAC/AAC/Opus) is honored via `wf-recorder -C`.

### Fixed (from an adversarial security + performance review)
- **AV1 software no longer uses the non-real-time `libaom-av1`** for live capture:
  prefers `libsvtav1` (real-time presets), else falls back to `libx264` — matching
  behavior across the ffmpeg and Wayland paths.
- **No orphaned processes / leaked temp files** when the capture crashes: the GUI
  and CLI now tear down every process, unload PipeWire modules, and clean up.
- Processes are reaped after kill/terminate (no zombies); a `None` exit code is
  treated as failure, not success.
- wf-recorder is always given a valid `-o <output>` (no interactive prompt hang);
  duration timing uses a monotonic deadline; region is clamped to the output;
  `--region WxH` (offset-less) is accepted on Wayland; the `wlr-randr` fallback
  reads each output's `Position:`.
- Window/output titles from `swaymsg` are sanitized before display (no terminal
  escape-sequence injection). Preview no longer emits encoder warnings to stderr.

### Notes
- On NVIDIA + Wayland, `wf-recorder` encodes in software (`libx264`/`libx265`);
  NVENC is not reachable through it. At 1080p/1200p this is comfortably real-time.
- Requires **`wf-recorder`** on Wayland (`guix install wf-recorder` ·
  `sudo apt install wf-recorder` · `sudo dnf install wf-recorder`).

## [2.2.0] — 2026-06-13

### Fixed
- **Slow / "≈2× slow-motion" recordings.** Live screen capture must encode in
  real time or frames pile up and the video plays back slowed and choppy. The
  old NVENC `p7` (+ lookahead) and software `slow`/`film` presets fell far below
  real-time at high resolution/fps. Encoders now use real-time-capable presets
  (NVENC `p4`–`p6`, QSV medium/fast, VAAPI cqp, AMF balanced/speed, VideoToolbox
  `realtime=1`, x264/x265 `veryfast`/`ultrafast`) **and** the output is forced to
  constant frame rate (`-fps_mode cfr -r FPS`), so playback speed is always
  correct. A 6 s capture now yields exactly 6.000 s / 60 fps / 360 frames.
- **GUI timer frozen at `00:00:00`.** A dangling reference to the removed
  software-encoding switch raised a `NameError` in `do_start()` just before the
  elapsed-timer tick was scheduled, so the clock and REC pulse never started.

### Added
- **Encoder backend selection** — `--backend auto|gpu|cpu` (with `--gpu` / `--cpu`
  shorthands) on the CLI, and an **Encoder: Auto / GPU / CPU** control in the GUI.
- **OBS-style capture targets** — the new `targets` subcommand lists the full
  screen, each monitor and capturable windows; `--monitor NAME`, `--window TITLE`
  and `--region WxH+X+Y` select what to grab. The GUI gains a **Source** picker
  with a refresh button. Screen capture now supports an X/Y offset.

## [2.1.0] — 2026-06-13

### Added
- **Redesigned dark GUI** (near-black background, cyan accents): segmented capture
  mode selector, hardware status header, mic/system pickers with presence dots,
  live FFmpeg command preview, output folder + live filename preview, and a footer
  with a prominent Start/Stop, live elapsed timer, pulsing REC indicator and
  running output-file size.
- **Packaging**: `.deb`, `.rpm` and AppImage build scripts under `packaging/`
  (the `.deb` builds with `dpkg-deb`, or portably with `ar`/`tar`/`xz`), a desktop
  entry, a scalable cyan-on-black icon, and a GitHub Actions release workflow that
  builds and publishes all three formats on `v*` tags.
- **CLI**: `devices` and `encoders` subcommands; `detect --json`; `-t/--duration`
  (accepts `90`, `5m`, `1m30s`, `2h`, `HH:MM:SS`); `--countdown`; `--open`;
  `--version`; and JSON config via `--config`, `$TURBOREC_CONFIG` or
  `~/.config/turborec/config.json`.

### Fixed
- GUI startup crash from a custom `Vert.TScrollbar` ttk style with no layout.

## [2.0.0] — 2026-06-13

### Added
- **Cross-platform `turborec.py`** (Linux/macOS/Windows, Python stdlib + FFmpeg):
  auto-detects OS, display server, CPU vendor (Intel/AMD/Apple), GPU and the best
  hardware encoder (NVENC/QSV/VAAPI/AMF/VideoToolbox, software fallback), screen
  resolution, microphone and system-audio sources. Ships an argparse CLI and a
  Tkinter GUI.
- Quality-first presets, BT.709 color metadata, lossless FLAC audio (AAC/Opus
  optional) with soxr resampling.

### Changed
- **`turborecorder`** (Linux/X11 bash) upgraded: auto-detects CPU/GPU vendor and
  the best encoder (NVENC > VAAPI > software), auto-detects default mic + system
  audio (no more hardcoded device names), full-screen capture by default, and adds
  HEVC / codec / quality / audio-codec options.

[3.7.0]: https://github.com/cristiancmoises/turborec/releases/tag/v3.7.0
[3.6.0]: https://github.com/cristiancmoises/turborec/releases/tag/v3.6.0
[3.5.0]: https://github.com/cristiancmoises/turborec/releases/tag/v3.5.0
[3.4.0]: https://github.com/cristiancmoises/turborec/releases/tag/v3.4.0
[3.3.0]: https://github.com/cristiancmoises/turborec/releases/tag/v3.3.0
[3.2.0]: https://github.com/cristiancmoises/turborec/releases/tag/v3.2.0
[3.1.0]: https://github.com/cristiancmoises/turborec/releases/tag/v3.1.0
[3.0.0]: https://github.com/cristiancmoises/turborec/releases/tag/v3.0.0
[2.2.0]: https://github.com/cristiancmoises/turborec/releases/tag/v2.2.0
[2.1.0]: https://github.com/cristiancmoises/turborec/releases/tag/v2.1.0
[2.0.0]: https://github.com/cristiancmoises/turborec/releases/tag/v2.0.0
