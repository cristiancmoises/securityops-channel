# Evelin v4.1.0 — Formal Audit Report (deep review)

> Sprint 7: a deep review of the v4.0.0 GA tree that became a
> correction-and-completion release. Reviewer: SecurityOps.
> Date: 2026-06-10.

## 1. Provenance — what this review actually reviewed

The sprint began as a routine deep review of the GA codebase. It
immediately found that the working tree contained **~740 changed
lines across 15 files that match no recorded development step**:
the development transcript has no mention of them, and the shipped
v4.0.0 source tarball (the release baseline) does not contain them.
The shipped v4.0.0 artifacts were verified unaffected by extracting
the GA tarball and confirming the old code (single-argument offer
builders, `bool`-returning `set`, no `max_frame_kib`).

The only plausible origin is an unrecorded, interrupted working
session whose file-system side effects persisted. Provenance being
unestablishable, the delta was treated as an **untrusted patch**:
every hunk was diffed against the GA baseline and reviewed line by
line — dependency changes first (none external; one dev
self-dependency), then crypto-adjacent code (record, handshake),
then the rest — before any of it was adopted. The patch itself was
unfinished: it did not pass `clippy -D warnings` and carried dead
code (§ F-8/F-9). Everything below that is marked *adopted* passed
that review; everything marked *added* is new in this sprint.

## 2. Scope

| Area | Change | Status |
|---|---|---|
| evelin-negotiation | strict offer validation, `set*` → `Result`, `MAX_ENCODED_LEN`, `MIN_MAX_FRAME_LOG2`, `log2_for_kib`, +5 tests | adopted |
| evelin-handshake | `negotiate` Result plumbing (coherent abort), framing canonical-max bound, tests use the real `framing` module (dev self-dep, `io`), framing negative/boundary tests, +`nonconforming_offer_aborts_handshake` | adopted |
| evelin-channel | mux live frame budget (`send_data` chunking, `send_request` pre-flight, `RequestTooLarge`), `DATA_OVERHEAD`/`request_encoded_len` locked to `encode()`, e2e regression | adopted (one lint fix added) |
| evelin-record | `max_plaintext_len()` accessor | adopted |
| evelin-config | `max_frame_kib` field + defaults (both configs) | adopted |
| evelin-client / evelin-server | `max_frame_kib` threading, startup validation (client `validate_protocol_settings`, server `run_check`), config-driven offers | adopted |
| evelin-session tests/benches | 5 files fixed to the 3-argument handshake API | **added** |
| both binaries | startup warning when `max_frame_kib ≠ 1024` under v1 | **added** |
| integration_tcp_v2.rs | dead `read_caps_into` + unused imports removed | **added** |
| evelin-channel mux | `manual_clamp` lint fix (`.clamp(1, MAX_DATA_LEN)`) | **added** |
| docs | CHANGELOG, ERRATA, this report, SECURITY.md, man pages, README, SPRINT_PROMPT discipline | **added** |

No change to: KEX, signatures, AEAD, KDF, transcript construction,
record crypto, ticket sealing, libevelin C ABI (20 symbols).

## 3. Findings

| ID | Severity | Finding | Disposition |
|---|---|---|---|
| **F-1** | MEDIUM | `negotiate` accepted `MAX_FRAME_LOG2` < 14. The record layer clamps **up** to 16 KiB, so the advertisement could not be honoured — the local side would send frames larger than the peer declared it accepts. | Fixed (adopted): floor at `MIN_MAX_FRAME_LOG2 = 14` (constant locked to `evelin_core::protocol::MAX_FRAME_LEN` by test); abort, both argument orders tested, boundary (=14) accepted. |
| **F-2** | LOW | Lenient parse of known capability values: trailing bytes on `MAX_FRAME_LOG2` silently ignored; `REKEY` value ignored. | Fixed (adopted): exact-shape validation; unknown ids stay opaque (forward-compat). **ERRATUM E-4.** |
| **F-3** | MEDIUM (latent at GA) | Mux chunked `send_data` at the static `MAX_DATA_LEN` and never pre-flighted Requests; any v2 connection negotiating a frame < 1 MiB died on bulk transfer (reachable by any peer offering log2 < 20). | Fixed (adopted): live frame budget captured at spawn; `RequestTooLarge` per-call error; overhead constants locked to `encode()`; e2e regression at negotiated 16 KiB incl. connection-survives assertion. **ERRATUM E-2.** |
| **F-4** | LOW | `Capabilities::{set,set_flag,set_u8}` returned an ignorable `bool`; a silently dropped capability could ship an offer not matching operator intent. | Fixed (adopted): `Result` (`#[must_use]` via `Result`); ignoring is now a `-D warnings` failure. |
| **F-5** | LOW | The v2 caps-block stream bound was a vacuous `u16::MAX`. | Fixed (adopted): bound at the canonical maximum `MAX_ENCODED_LEN = 16 642` (locked reachable-not-slack by test), rejected before allocation; boundary-exact framing tests. |
| **F-6** | MEDIUM (claims accuracy) | The GA audit/CHANGELOG claim "the binaries use the same framing module these tests exercise" was false: the tests carried a private duplicate of the readers (the `io` feature was not enabled for dev-deps). | Fixed (adopted): dev self-dependency with `io`; tests import `evelin_handshake::framing`. **ERRATUM E-1.** |
| **F-7** | HIGH (release process) | Five evelin-session test/bench files did not compile (stale 2-arg handshake API since dev.2); the GA source tarball fails `cargo test --workspace`. Per-crate testing never selected the crate after v3.9. | Fixed (**added**): all call sites updated; suite green (44 tests, twice). Process correction in `docs/SPRINT_PROMPT.md`: full-workspace compile gate every release. **ERRATUM E-3.** |
| **F-8** | NIT | The unrecorded patch failed `clippy -D warnings` (`manual_clamp` in the mux chunk sizing). | Fixed (**added**): `.clamp(1, MAX_DATA_LEN)`. |
| **F-9** | NIT | Dead code in the patch: unused `read_caps_into` + four unused imports left from the deleted private readers; one stale fuzz comment. | Fixed (**added**). |
| **F-10** | LOW (usability) | A valid `max_frame_kib ≠ 1024` under `max_protocol_version = 1` was a silent no-op. | Fixed (**added**): startup warning on both binaries. |

Reviewed-OK (no change): the `(client, server)` argument order of
`negotiate` is identical on both peers (client.rs `finish`,
server.rs `respond`) — the coherent-abort argument holds; the
client's zero-key `Aead` placeholder in `mem::replace` remains
sound (the dummy is never used; the struct cannot be partially
moved); `log2_for_kib` is single-sourced in evelin-negotiation and
re-exported — no duplicated arithmetic; serde defaults keep the
default v2 offer byte-identical to v4.0.0.

## 4. Behaviour changes (intentional, v2 only)

1. **Strictness:** a nonconforming v2 offer (frame log2 < 14;
   malformed known-value shape) aborts the handshake on both ends
   instead of being silently clamped/reinterpreted. Rationale: at a
   protocol boundary, silent reinterpretation of an authenticated
   but invalid offer is worse than a clean abort, and the floor
   case was not merely cosmetic (F-1: the sender would exceed the
   peer's declared limit). Both peers compute the identical error
   from the same transcript-bound inputs — desynchronisation is
   impossible by construction.
2. **Operator-tunable frame size:** `max_frame_kib` ∈ {16 … 1024}
   (powers of two), default 1024 ⇒ default offers byte-identical to
   v4.0.0. Honest framing: on a single core this does not change
   measured throughput (v3.7); its value is operational (memory
   bound per connection, latency/overhead trade-off) on real
   deployments.

## 5. Interop matrix

| Pair | Result |
|---|---|
| v4.1 default ↔ v4.0 / v3.9 / v1.4 | byte-identical (v1 unchanged; default v2 offer unchanged) |
| v4.1 (kib < 1024) ↔ v4.1 (any) | negotiated min; mux fragments correctly (regression-tested) |
| v4.1 (kib < 1024) ↔ v4.0 | handshake succeeds; **the v4.0 side drops on bulk transfer (E-2)** — documented: both peers must be ≥ 4.1.0 before lowering `max_frame_kib` |
| malformed/low offer ↔ v4.1 | coherent abort (new strictness) |
| v1 client ↔ v4.1 v2 server | byte-identical v1 fallback (unchanged) |

## 6. Tests / gates

- **233 passed, 0 failed** across 11 crates (negotiation 23,
  handshake 30, channel 32, record 21, config + core 14, session
  44, crypto 41 incl. the RFC 8439 KAT suite, ticket/agent/hsm 28);
  changed crates run twice with identical results.
- Clippy clean (`-D warnings`, `--all-targets --all-features`) on
  all touched crates + both binaries.
- `cargo audit --no-fetch` 0 vulnerabilities (2 expected
  unmaintained INFO: `number_prefix`, `paste`); `cargo deny check
  bans licenses sources` PASS. No new external dependency.

## 7. Verdict

**Cleared for tagging as v4.1.0.**

- The unrecorded delta was reviewed in full as an untrusted patch,
  finished (lint, dead code, missing warning), and adopted; nothing
  unreviewed ships.
- Four v4.0.0 defects are published as errata and corrected —
  including one inaccurate coverage claim in the GA audit itself,
  acknowledged per the same standard applied to every other claim
  in this project.
- The v4.0 R-1 follow-up (`max_frame_kib`) ships with the mux made
  safe for it first; defaults remain byte-identical end to end.

— SecurityOps, v4.1.0, June 2026
