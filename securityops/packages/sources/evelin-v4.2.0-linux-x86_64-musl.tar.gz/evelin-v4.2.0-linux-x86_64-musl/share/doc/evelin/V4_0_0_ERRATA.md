# Evelin v4.0.0 — ERRATA

> Published with v4.1.0 (2026-06-10). The v4.1 deep review
> (`docs/V4_1_AUDIT_REPORT.md`) found the following defects in the
> v4.0.0 release. Each is corrected in v4.1.0. The shipped v4.0.0
> artifacts and their SHA256SUMS are unchanged — errata are
> published forward, not by rewriting released artifacts.

## E-1 — Inaccurate audit claim: v2 integration tests did not exercise the shipped framing module

**Claimed** (dev.3 audit §4, dev.4/GA carried forward): "The
binaries use the same `framing` module these tests exercise (not a
private copy)." **Actual:** the test file
`crates/evelin-handshake/tests/integration_tcp_v2.rs` defined its
own private `read_hello_client` / `read_hello_server` because the
dev-dependencies did not enable the `io` feature that gates the
real module. The duplicated logic happened to match, so the tests
were not wrong — but the *coverage claim* was: the shipped framing
code had no direct test execution. Severity: documentation
accuracy (the exact class the v3.5 correction targets).
**Fixed in v4.1.0:** a dev self-dependency enables `io`; the tests
import `evelin_handshake::framing` directly, plus new
framing-level negative/boundary tests.

## E-2 — Mux chunked at the static build-default frame; negotiated smaller frames dropped connections on bulk transfer

`Mux::send_data` split payloads at the static `MAX_DATA_LEN`
(sized to the 1 MiB build-default frame). On a v2 connection that
negotiated a smaller frame, a full-size chunk exceeded the record
layer's clamped maximum; the writer task's send failed and the
connection died mid-transfer. Likewise an over-budget Request
killed the connection instead of failing its own call.

Reachability at v4.0.0: the local config could not select a
smaller frame (offers were hardcoded to log2 = 20), but **any v2
peer offering log2 < 20** drove the negotiated minimum below the
default and triggered the defect on the v4.0.0 side's next bulk
send. Impact: availability only (self-drop), post-authentication,
opt-in v2; no confidentiality/integrity effect. Severity: MEDIUM.

**Fixed in v4.1.0:** the mux sizes data chunks and pre-flights
requests against the live frame budget captured at spawn;
oversized requests return `MuxError::RequestTooLarge` without
harming the connection. Regression-tested end-to-end at a
negotiated 16 KiB.

**Operator guidance:** keep `max_frame_kib = 1024` (the default)
until both peers run ≥ 4.1.0.

## E-3 — Shipped source tree failed `cargo test --workspace`

Five evelin-session test/bench files
(`filecopy_e2e`, `filecopy_4mib_throughput`, `agent_forward_e2e`,
`reverse_forward_e2e`, `benches/filecopy_throughput`) still called
the pre-dev.2 two-argument handshake API and did not compile. The
dev.2 note "all call sites updated" missed them, and no sprint
after v3.9 selected the session crate, so per-crate testing never
caught it. Runtime binaries were unaffected; the defect is
release-quality (the v4.0.0 source tarball fails its own full test
build). Severity: release process.

**Fixed in v4.1.0:** all call sites updated; the session suite
passes (44 tests, run twice). The release discipline in
`docs/SPRINT_PROMPT.md` now requires a full-workspace compile gate
so unselected crates cannot rot silently.

## E-4 — Lenient parsing of known capability values

`negotiate` read the first byte of `MAX_FRAME_LOG2` and silently
ignored trailing bytes, and ignored any value on `REKEY`
(presence-only check). A conforming-looking but malformed offer
was silently reinterpreted instead of rejected. No exploit path
identified (the block is authenticated and the reinterpretation is
deterministic on both ends), but lenient parsing at a protocol
boundary is a defect. Severity: LOW.

**Fixed in v4.1.0:** strict shape validation of known capability
values; malformed offers abort the handshake coherently on both
ends. Unknown ids remain opaque.

— SecurityOps, published with v4.1.0, 2026-06-10
