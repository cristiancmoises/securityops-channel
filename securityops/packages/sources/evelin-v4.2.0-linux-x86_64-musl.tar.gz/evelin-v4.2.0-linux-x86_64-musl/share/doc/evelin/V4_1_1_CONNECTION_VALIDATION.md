# v4.1.1 — Full-binary connection validation

> First live end-to-end validation of the shipped binaries in this
> build environment (previously: protocol paths were proven by
> crate-level real-TCP tests; the binaries themselves were not run —
> tracked since dev.3 R-1, now closed). Binaries: the shipped
> v4.1.0 x86_64-musl set. Host: 1-core container, loopback.
> Date: 2026-06-10.

## Setup

- `evelin-keygen` produced server and client identities
  (unencrypted v1 format); fingerprints from keygen output.
- `authorized_keys`: `# evelin-authorized-keys v1` header + the
  line emitted by `evelin-client print-auth-line`.
- Server config: `bind 127.0.0.1:7222`, `max_protocol_version = 2`,
  `max_frame_kib = 64`, `[exec] allow = ["/bin/echo", ...]`,
  `[filecopy] roots = [...] allow_upload/download = true`.
  `evelin-server --check` passed.
- Client configs: v2 (`max_protocol_version = 2`,
  `max_frame_kib = 64`), v1 (default), and one with a deliberately
  wrong `server_fingerprint`.

## Results

| # | Test | Result |
|---|---|---|
| T1 | v2 exec (`/bin/echo`) | exit 0; client log: `handshake complete` + **`v2 negotiated frame size applied, max_frame_len = 65536`** — min(64 KiB, 64 KiB) live on a real connection |
| T2 | 1 MiB upload over negotiated 64 KiB frames | exit 0; server: `filecopy upload complete, bytes_sent = 1048576, 46 ms, 21.6 MB/s` |
| T3 | download back + `cmp` | exit 0; `21 ms, 45.8 MB/s`; **roundtrip byte-identical** (sha256 equal) — the v4.0.0 E-2 mux fix proven at full-binary level: 1 MiB fragments correctly through 64 KiB frames |
| T4 | v1 client ↔ v2 server | exit 0; **zero** `v2 negotiated` lines — clean v1 fallback, mixed-version interop confirmed |
| T5 | wrong server fingerprint | client aborts, `Unauthorized`, exit 1 — server-auth pinning works |
| T6 | handshake + exec wall time, 5 runs | 45.4 (cold), 11.7, 11.4, 11.7, 11.6 ms → **median 11.7 ms, min 11.4 ms** for connect + full ML-KEM-1024/ML-DSA-87 handshake + exec + teardown. Loopback, 1 core; not a network latency claim |
| T7 | non-allow-listed command (`/bin/ls`) | refused, exit 126 — exec allow-list enforced |

## Honest scope

Loopback on one core validates correctness and gives a handshake
CPU-cost floor; it says nothing about WAN latency or multi-core
throughput (standing blocker: real two-host hardware). Throughput
figures are single runs at a deliberately small 64 KiB frame and are
below the v3.7 contention-bound bulk numbers — expected, not
optimized, reported as measured.

— SecurityOps, 2026-06-10
