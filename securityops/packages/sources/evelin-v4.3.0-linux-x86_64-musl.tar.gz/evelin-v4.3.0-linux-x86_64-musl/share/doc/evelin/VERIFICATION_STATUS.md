<!-- SPDX-License-Identifier: AGPL-3.0-or-later OR LicenseRef-Evelin-Commercial -->

# Formal Verification Status

This file is the **single source of truth** for the state of
Evelin's formal models. It is reconciled against the actual model
files in `verification/tamarin/` and `verification/proverif/`, and
its counts are checked by the test
`formal_status_manifest_matches_model_files` (in `evelin-core`).

**Honesty note (v3.5):** prior to v3.5 the top-level `README.md`
claimed "Tamarin formal model: 5/5 lemmas verified" and "ProVerif
formal model: 10/10 queries proved", and `verification/README.md`
listed lemma/query names and counts that did not match the model
files. Those claims were inaccurate on three axes: the **counts**
were wrong (the primary Tamarin model has 8 lemmas, not 5), the
**names** were wrong (e.g. `mutual_authentication` /
`session_key_secrecy` are not lemmas in the model; the actual
names are `secret_session_key`, `agreement_server`,
`agreement_client`, …), and the **proof status** was overstated
(per `verification/runs/v0.2.1-formal-status.md`, only the 5 v0.1
lemmas were machine-checked; the 3 v0.2 lemmas and the extension
models were added but not yet proven). This file states the real
status. No protocol or code behaviour changed in v3.5.

## What "status" means here

- **PROVEN** — `tamarin-prover --prove` / `proverif` was run to
  completion on this lemma/query in a release CI ceremony and
  reported success. The run log is referenced.
- **STATED** — the lemma/query is written and the model parses,
  but it has **not** been machine-checked in this repository's CI
  (often because a full run is 90+ min and is deferred, or because
  no prover is available in the current build environment). A
  STATED lemma is a claim about intended design, **not** a
  verified property of the code.
- **ASPIRATIONAL-MODEL** — additionally, the lemma lives in a
  model that abstracts a protocol Evelin does **not** currently
  implement (e.g. a hybrid X25519 KEX, or on-wire extension
  negotiation). Even if proven, it would describe a different
  protocol than the shipping code. See the v3.3 and v3.4
  corrections.

## Primary handshake model — `verification/tamarin/evelin.spthy`

Models the shipping three-message AKE with ML-KEM-1024 as a
generic IND-CCA KEM (`aenc`/`adec`) and ML-DSA-87 as a generic
UF-CMA signature (`builtins: signing`). **No diffie-hellman / no
X25519** — this model matches the shipped construction (single
ML-KEM-1024 + single ML-DSA-87).

| # | Lemma | Status | Notes |
|---|---|---|---|
| 1 | `exec` | PROVEN (v0.1 ceremony) | sanity: protocol completes |
| 2 | `secret_session_key` | PROVEN (v0.1 ceremony) | key secret from network adversary |
| 3 | `agreement_server` | PROVEN (v0.1 ceremony) | server agreement ⇒ client started |
| 4 | `agreement_client` | PROVEN (v0.1 ceremony) | client agreement ⇒ server started |
| 5 | `perfect_forward_secrecy` | PROVEN (v0.1 ceremony) | past keys survive LTK compromise |
| 6 | `v02_ratchet_forward_secrecy` | **STATED** | added v0.2.1; not yet machine-checked |
| 7 | `v02_agent_binding` | **STATED** | added v0.2.1; not yet machine-checked |
| 8 | `v02_filecopy_content_integrity` | **STATED** | added v0.2.1; not yet machine-checked |

**Primary Tamarin: 8 lemmas total — 5 PROVEN, 3 STATED.**

## Primary handshake model — `verification/proverif/evelin.pv`

Same protocol, ProVerif formulation. KEM as abstract CCA KEM with
`kem_decap(kem_encap(m,ek),dk)=m`; signatures = ProVerif builtin;
KDF = one-way function.

| # | Query | Status |
|---|---|---|
| 1–8 | session-key secrecy (both views), s2c/c2s auth (non-injective), injective server/client auth, same-key agreement | PROVEN (v0.1 ceremony) |
| 9–10 | v0.2 deltas (ratchet pre-key secrecy, agent-binding) appended to the model | **STATED** (new-channel modeling deferred per `runs/v0.2.1-formal-status.md`) |

**Primary ProVerif: 10 queries total — 8 PROVEN, 2 STATED.**

## Extension models — REMOVED in v3.8

Earlier revisions carried four additional model files for features
that are **not wired into the live connection path** (see the v3.4
correction: the shipping client/server do not negotiate extensions
on the wire) and/or that assumed a **hybrid X25519 KEX** the
transport does not implement and the project's design explicitly
rules out (pure post-quantum KEX; see the v3.3 correction):

- `verification/tamarin/evelin-v1.5-extensions.spthy` (10 lemmas)
- `verification/tamarin/evelin-v1.8-extensions.spthy` (3 lemmas)
- `verification/proverif/evelin-v1.5-extensions.pv` (10 queries)
- `verification/proverif/evelin-v1.8-extensions.pv` (3 queries)

These were **deleted in v3.8**. They modeled a protocol Evelin does
not ship, so keeping them in-tree was a standing source of
confusion (a reader who ran them and saw "verified" might wrongly
believe those properties hold of the shipping code). The v3.3–v3.5
corrections had already removed the false *claims* about them; v3.8
removes the *artifacts*. If transcript-bound extension negotiation
is implemented in a future protocol version, new models that match
that code should be added then — not carried ahead of it. The
`formal_status` test asserts these files stay absent.

## v2 capability-negotiation models — added in v4.0 (STATED)

v4.0 introduces an **opt-in protocol v2** that negotiates a
transcript-bound capability block (shipped and live over the socket
in `v4.0.0-dev.2 .. dev.4`; the binaries offer/accept it when
configured with `max_protocol_version = 2`). Two models describe it:

- `verification/tamarin/evelin-v2-negotiation.spthy` (4 lemmas)
- `verification/proverif/evelin-v2-negotiation.pv` (3 queries)

**These are NOT the deleted aspirational models.** The crucial
difference from the v3.8-removed files: those modeled a protocol the
code did **not** ship (hybrid X25519 KEX / unwired extensions). The
v2 negotiation, by contrast, **is implemented and reachable over the
wire** — there is a real-TCP integration test
(`tcp_v2_handshake_over_socket_negotiates`,
`tcp_v2_negotiated_frame_size_gates_record_layer`) and a data-level
downgrade test (`any_byte_flip_changes_or_breaks_decode`). So a
model of it describes shipping code, which is exactly the condition
the v3.8 note set for adding new models ("if transcript-bound
extension negotiation is implemented in a future protocol version,
new models that match that code should be added then").

**They are STATED, not PROVEN.** No prover binary is available in
this build environment, so neither model has been machine-checked
here. The lemmas/queries are written to parse and to match the
implementation, but a STATED claim is about intended design, not a
verified property. **Do not describe v2 as "formally verified"**
until a release ceremony runs the provers to completion and the run
logs are referenced here.

| Model | Lemma / query | Status |
|---|---|---|
| tamarin v2 | `v2_exec` | **STATED** |
| tamarin v2 | `v2_caps_agreement` (downgrade resistance) | **STATED** |
| tamarin v2 | `v2_server_sees_client_caps` | **STATED** |
| tamarin v2 | `v2_key_binds_caps` | **STATED** |
| proverif v2 | `ClientAccepted ⇒ ServerAccepted` (downgrade) | **STATED** |
| proverif v2 | `ServerAccepted ⇒ ClientOffered` | **STATED** |
| proverif v2 | `attacker(secretMsg)` (secrecy carries over) | **STATED** |

**v2 negotiation: 4 Tamarin lemmas + 3 ProVerif queries, all
STATED.** The symbolic downgrade-resistance property
(`v2_caps_agreement`) is the formal analogue of the executable
downgrade/tamper tests; both are evidence, neither is a substitute
for a machine-checked proof, and this file says so.

## Honest one-line summary

> **Primary handshake (the shipping single-ML-KEM-1024 +
> single-ML-DSA-87 protocol): 5 Tamarin lemmas and 8 ProVerif
> queries machine-checked in the v0.1 ceremony; 3 Tamarin lemmas
> and 2 ProVerif queries added since are STATED-but-unproven. The
> opt-in v2 capability negotiation (v4.0) adds 4 Tamarin lemmas and
> 3 ProVerif queries, all STATED-but-unproven, in models that DO
> match shipping code (unlike the aspirational extension models
> removed in v3.8).**

Do not summarize this as "fully formally verified." The honest
phrasing is: *"core handshake secrecy, authentication, and forward
secrecy are machine-checked (5 Tamarin lemmas / 8 ProVerif
queries); the ratchet/agent/filecopy lemmas are stated but not yet
machine-checked."*

## How to actually run the proofs

```bash
# Tamarin (≥ 1.10):
cd verification/tamarin
tamarin-prover --prove evelin.spthy 2>&1 | tee ../runs/tamarin-$(date +%F).log

# ProVerif (≥ 2.05):
proverif verification/proverif/evelin.pv 2>&1 | tee verification/runs/proverif-$(date +%F).log
```

The `.forgejo/workflows/formal-models.yaml` CI job installs both
provers and is the intended place to turn STATED lemmas into
PROVEN ones. When a STATED lemma is machine-checked, move it to
PROVEN here and reference the run log; the manifest test will keep
the counts honest.
