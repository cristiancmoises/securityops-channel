# Evelin vs OpenSSH — an honest comparison

> Method note. Every Evelin number below is measured (hardware and
> method stated) or derived from protocol constants; every OpenSSH
> protocol fact was verified against openssh.org and release notes
> as of June 2026. Where the two tools were not benchmarked on the
> same hardware, **no comparative performance claim is made**.
> Where OpenSSH is better, that is stated in the same format as
> where Evelin is better. Last reviewed: 2026-06-10
> (Evelin 4.1.0, OpenSSH 10.2).

## Summary

OpenSSH is the right default for general-purpose remote access: ~30
years of deployment, multiple interoperating implementations, an
enormous tooling ecosystem, and (since 10.0) hybrid post-quantum key
exchange by default. Evelin is a small, single-implementation,
pure-post-quantum transport for operators who specifically want
PQ authentication (not just PQ key exchange), a memory-safe
implementation, and a codebase small enough to actually read —
and who accept the maturity trade-offs listed plainly below.

## Cryptography

| | Evelin 4.1.0 | OpenSSH 10.2 (defaults) |
|---|---|---|
| Key exchange | **ML-KEM-1024** (FIPS 203), pure PQ | **mlkem768x25519-sha256** — hybrid ML-KEM-768 + X25519 (default since 10.0, Apr 2025; PQ KEX default since 9.0 via sntrup761x25519) |
| Host/user authentication | **ML-DSA-87** (FIPS 204), post-quantum | Ed25519 / ECDSA / RSA — **classical**; no PQ signatures ship as of 10.2 |
| AEAD | ChaCha20-Poly1305 | chacha20-poly1305@openssh.com or AES-GCM (negotiated) |
| KDF | HKDF-SHA-512 | KEX-hash-based KDF (SHA-256/512 per algorithm) |
| Negotiation integrity | capability block inside the **signed transcript** (v2, opt-in) | algorithm negotiation bound by the exchange hash — **equivalent property**; this is not an Evelin advantage |

Two design differences worth stating without spin:

- **Hybrid vs pure PQ.** OpenSSH's hybrid KEX keeps an X25519
  backstop: if ML-KEM falls to cryptanalysis, sessions still rest on
  a classical hard problem. Evelin's pure ML-KEM-1024 has **no
  classical backstop** — a deliberate design position (and at a
  higher category than OpenSSH's ML-KEM-768), but a real
  single-point-of-failure trade-off, not a strict win.
- **PQ authentication.** OpenSSH's authentication is classical;
  that is a defensible stance, because "harvest now, decrypt later"
  threatens recorded *confidentiality*, while signatures cannot be
  attacked retroactively — they only matter once a quantum
  adversary exists at connection time. Evelin signs with ML-DSA-87
  today; the cost is wire size (below).

## Handshake wire cost (derived from protocol constants)

| Message | Evelin v1 | Notes |
|---|---|---|
| HelloClient | 4 200 B | ML-KEM-1024 ek 1568 + ML-DSA-87 pk 2592 + nonce + header |
| HelloServer | 8 827 B | pk 2592 + ct 1568 + nonce + **sig 4 627** + header |
| Finish | 4 635 B | sig 4 627 + header |
| **Total** | **17 662 B** | 3 messages, 1.5 RTT |

An OpenSSH 10.2 default handshake (mlkem768x25519 + Ed25519 host
key) carries roughly: ML-KEM-768 material 1 184/1 088 B + X25519
64 B + Ed25519 key/sig ≈ 100 B, plus KEXINIT lists — **on the
order of 3–4 KB total** `[ESTIMATED from algorithm object sizes;
not packet-captured]`. **Evelin's handshake is roughly 4–5× larger
on the wire.** That is the price of PQ signatures at category 5;
on any link where 17 KB matters (high-latency, constrained), SSH
wins this dimension outright.

## Performance

Measured Evelin numbers (this project's hardware: 1-core container,
loopback, methods in `docs/BENCHMARKS.md`):

- AEAD ceiling: seal 1.13 GiB/s, open 924 MiB/s (1 MiB blocks,
  single core, AVX2) — v3.7 measurement.
- Bulk filecopy: ~50–75 MiB/s single-core (core-contention-bound,
  ±50% cross-session variance) — v3.7.
- Live v4.1.0 binaries (this release's validation, single runs):
  1 MiB upload 21.6 MB/s / download 45.8 MB/s over negotiated
  64 KiB frames; full connect + ML-KEM-1024/ML-DSA-87 handshake +
  exec + teardown: **median 11.7 ms** (5 runs, loopback, 1 core).

**OpenSSH was not benchmarked on this hardware. No comparative
throughput or latency claim is made.** OpenSSH is a mature, heavily
optimized C codebase; absent a same-host, multi-core benchmark
(pending hardware — a standing project blocker), assuming Evelin is
faster would be exactly the kind of claim this project refuses.

## Features

| | Evelin 4.1.0 | OpenSSH 10.2 |
|---|---|---|
| exec / interactive PTY shell | ✓ | ✓ |
| File transfer | ✓ `cp` (own protocol, policy-rooted) | ✓ scp/SFTP (universal ecosystem) |
| Port forward (-L), reverse (-R), SOCKS (-D) | ✓ | ✓ |
| Agent + agent forwarding | ✓ | ✓ |
| ProxyJump | ✓ | ✓ |
| Session resumption tickets (0-RTT-style reconnect) | ✓ | ✗ |
| Transcript-bound capability negotiation | ✓ (v2, opt-in) | ✓ equivalent via exchange hash |
| SFTP protocol compatibility | ✗ | ✓ |
| X11 forwarding | ✗ | ✓ |
| Certificates (CA-signed user/host keys) | ✗ | ✓ |
| PAM / GSSAPI / Kerberos | ✗ | ✓ |
| ssh_config ecosystem, ControlMaster sharing | ✗ | ✓ |
| Multiple interoperating implementations | ✗ (one) | ✓ (many) |
| Prometheus metrics exporter | ✓ | ✗ (external tooling) |
| fail2ban integration docs, rate/CIDR policy | ✓ | ✓ (mature) |

The right-hand ✗ column is short; the left-hand ✗ column is the
ecosystem of three decades. Anyone whose workflow depends on SFTP,
certificates, PAM, or third-party SSH clients should use OpenSSH.

## Implementation & assurance

| | Evelin 4.1.0 | OpenSSH 10.2 |
|---|---|---|
| Language / memory safety | Rust, `#![forbid(unsafe_code)]` (one documented FFI exception in `evelin-capi`) | C (memory-unsafe language; decades of hardening, privilege separation) |
| Size | 30 902 lines of Rust (measured, `wc -l` over `crates/`) | far larger; not measured here |
| Sandboxing | Landlock + seccomp-bpf | privsep + seccomp (mature, OpenBSD-pledge upstream) |
| Formal models | 5 Tamarin lemmas + 8 ProVerif queries **machine-checked** (v0.1 ceremony); 7 Tamarin + 5 ProVerif **STATED, not machine-checked** — exact status in `verification/VERIFICATION_STATUS.md` | implementation not formally verified; the SSH *protocol* has substantial academic analysis |
| Third-party audit | **none completed** | continuous scrutiny: ~30 years of public deployment, CVE history, and independent review |
| Track record | first release 2026; CVE process self-managed | the strongest argument for OpenSSH in this table |
| License | AGPL-3.0-or-later OR commercial | BSD |

This table is where OpenSSH wins most decisively, and it should be
read before any of the others. A young single-implementation
transport with no completed external audit carries risk that no
feature list offsets. Evelin's mitigations — small auditable
codebase, memory safety, machine-checked core lemmas, per-release
reproducible artifacts with SHA256SUMS — reduce that risk; they do
not eliminate it.

## Validated interop & behaviour (this release)

Full-binary end-to-end on 4.1.0 (loopback): v2 handshake with
negotiated 64 KiB frames applied on both ends; 1 MiB file roundtrip
byte-identical over those frames; v1-client ↔ v2-server fallback
with zero negotiation; wrong server fingerprint → `Unauthorized`,
exit 1; non-allow-listed command → refused, exit 126. Evidence:
`docs/V4_1_1_CONNECTION_VALIDATION.md`.

## When to use which

- **Use OpenSSH** for general-purpose access, anything needing the
  SSH ecosystem (SFTP, certificates, PAM, third-party clients), or
  any environment where a hybrid-PQ posture and 30 years of
  scrutiny outweigh pure-PQ authentication. This is most users.
- **Use Evelin** when the requirement is specifically
  post-quantum *authentication and* key exchange today, a
  memory-safe implementation, a codebase one person can read in a
  sitting, session-resumption tickets, or AGPL/self-hosted
  licensing — and the maturity trade-offs above are acceptable.
- Running both (Evelin on its own port alongside sshd) is a
  reasonable migration posture; nothing in Evelin conflicts with a
  resident sshd.

— SecurityOps, 2026-06-10. Corrections welcome: facts in this file
are held to the same claims policy as the rest of the project.
