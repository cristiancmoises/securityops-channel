# Security policy — Evelin v4.1

## Reporting a vulnerability

Email: `sac@securityops.co`

The primary source repository is hosted on a private Forgejo
instance (`git.securityops.co`) accessible only to the
maintainer; a read-only mirror is published at
`https://github.com/cristiancmoises/evelin` for public review.
**There is no public issue tracker** — please email
`sac@securityops.co` for all security and bug reports.

PGP: a key fingerprint is published at
`https://securityops.co/.well-known/pgp/security.asc`. Plaintext
email is acceptable for initial contact; a temporary PGP key for
exploit details will be provided within 72 hours of first
contact.


## Disclosure window

We follow a **90-day disclosure window** by default, measured from the date we acknowledge the report (not from submission). We will extend the window only when a fix requires coordinated deployment across multiple operators or depends on an upstream cryptographic release; in that case we will say so explicitly in the acknowledgment.

After the window expires, we publish a security advisory in `docs/advisories/` and the CHANGELOG, with credit to the reporter unless they request anonymity.


## In scope

The full surface area shipped by Evelin v4.1:

- **Cryptographic correctness** of the handshake (`evelin-handshake`), record layer (`evelin-record`), AEAD construction (`evelin-crypto`), and resumption ticket sealing (`evelin-ticket`).
- **Authentication bypass**: any path that allows a session to be opened without presenting an authorized identity, or with a different identity than what was authorized.
- **Information disclosure**: key material, plaintexts, peer identities, ticket secrets.
- **Wire-protocol attacks**: replay, downgrade, in-flight tampering, sequence-number desync, length-prefix smuggling, transcript collision.
- **The v1.6 + v1.7 surfaces specifically**:
    - Session-resumption tickets: replay, ticket-key oracle, validation-order bypass, rotation-window evasion, replay-table poisoning.
    - BIG_FRAME: memory amplification, unagreed-frame acceptance, length-prefix smuggling.
    - PIPELINE: unbounded buffer growth, sequence desync, AEAD nonce exhaustion under high churn.
    - Prometheus exporter: information leak via metric labels, denial-of-service via /metrics scraping, accidental network exposure when default-bind misconfigured.
- **The v4.0 protocol-v2 capability negotiation specifically** (opt-in; `max_protocol_version = 2`):
    - **Capability downgrade / strip / inject**: forcing two peers to agree on a capability set neither offered, or silently stripping a negotiated capability. In scope and tested — the capability block lives in the **signed transcript** (not the unauthenticated header), so altering, stripping, or injecting it breaks the ML-DSA-87 signature and aborts the handshake (`downgrade_v2_to_v1_by_mitm_aborts`, `tampered_client_capabilities_rejected`, `any_byte_flip_changes_or_breaks_decode`).
    - **Version downgrade**: forcing a v2↔v2 pair down to v1. In scope — a rewritten version with a stripped caps block yields a transcript the originating peer cannot reproduce, so the signature fails.
    - **Capability-block parsing**: panics, OOB, or integer overflow in `Capabilities::decode` on adversarial bytes. In scope — the decoder is canonical-only with `checked_add` offsets and is property/fuzz-tested (~570k generated inputs, never-panic + roundtrip). v4.1: known capability values are additionally validated strictly (exact shapes; frame advertisements below the 16 KiB v1 base abort) — a malformed offer aborts the handshake coherently on both ends instead of being leniently reinterpreted.
    - **Negotiated frame-size abuse**: memory amplification or unagreed frame acceptance via `MAX_FRAME_LOG2`. In scope — the negotiated value is transcript-bound and clamped into `[16 KiB, 1 MiB]` by the record layer.
    - **Honest non-claim**: transcript-binding removes the *silent* downgrade vector only. A network attacker can still drop or delay packets to deny service or stall a connection — that is out of scope for any AEAD transport and is not claimed to be prevented.
- **Concurrency primitives**: data races, deadlocks, use-after-free in the new `parking_lot` / `dashmap` paths.
- **Memory safety**: any path reaching `unsafe` outside the documented FFI prologue/epilogue in `evelin-capi`.
- **Release-process integrity**: tampering with published binaries, the Docker image, the SBOM, or the SHA256SUMS chain.
- **Tamarin / ProVerif lemma counterexamples**: a concrete trace that violates a lemma we claim to prove.


## Out of scope

- The lack of FIPS validation. The path is documented; the validation has not been executed.
- Operator misconfiguration. If the operator binds Prometheus on a public interface, sets `max_frame_len` to 16 GiB, or disables the rate limiter, the resulting exposure is on them.
- Findings against documentation that describes target / aspirational state. The CHANGELOG, the source tree, and the current audit report (`docs/V4_1_AUDIT_REPORT.md`) and errata (`docs/V4_0_0_ERRATA.md`) describe what's shipped; everything else is aspirational.
- Side-channel attacks requiring physical access to the server (rowhammer, voltage glitching, etc).
- Theoretical key-compromise scenarios that assume bypass of unrelated standards (e.g. "what if SHA-3 is broken").


## Self-release status

v1.8.0 is self-released. There has been no paid third-party cryptographic audit. The author welcomes community review and intends to commission a paid audit after operational experience accumulates. Findings reported under this policy are honoured per the embargo and credit terms regardless of release stage.

The Tamarin and ProVerif models are authored by the project. The corresponding lemmas have been mechanically discharged on a CI host with the binaries installed; the proof artifacts (`.spthy.proof.json`, `.pv.html`) are published with each release tarball. Counterexamples to any lemma are explicitly in scope.


## CVE process

For findings that warrant a CVE assignment, the project is registered as a CNA-LR (Limited Reporter) under the MITRE program. We will request a CVE ID from MITRE within 7 days of report acknowledgment for findings rated MEDIUM or higher (CVSS v3.1).

For coordinated disclosure of cross-vendor issues (e.g. an issue in an upstream crate that affects Evelin and other downstream consumers), we follow the upstream's coordination policy as long as it doesn't unduly extend the embargo.


## What we will not do

- Pursue legal action against good-faith reporters who follow this policy.
- Require non-disclosure agreements as a condition of receiving a report.
- Deny attribution to a reporter who wants their name published.
- Publish a fix that doesn't go through the same code review and CI process every other change uses (no "hotfix bypass").


## Bounty

Evelin v1.8 ships without a monetary bounty program. Reporters are credited publicly in the CHANGELOG and in `docs/HALL_OF_FAME.md` with their permission. If a finding warrants commercial-grade compensation and the reporter needs that, please say so in the report — referrals to sponsors or commercial-license-channel arrangements can be discussed.


## Contact for non-security inquiries

`sac@securityops.co` (same address as security reports — there is
only one inbox, mark the subject prefix `[SECURITY]` for security
reports so they're triaged first). See `NOTICE` for the licensing
model and `https://github.com/cristiancmoises/evelin` for the
public source mirror.
