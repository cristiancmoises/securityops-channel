# Evelin Benchmarks

> Reproducible filecopy throughput + handshake measurements via
> `cargo bench`. Numbers come from the Criterion harness at
> `crates/evelin-session/benches/filecopy_throughput.rs`.

## v3.6.0 — parser overflow-safety hardening (no perf change)

v3.6 made `Parser::take` overflow-safe (`checked_add`) to close a
latent 32-bit (armv7) panic path on malformed decrypted frames. The
extra check is one `checked_add` per field parse — negligible, off
the bulk data path (the record layer's AEAD + framing dominate; the
channel-message parser handles small control/header structures).
The benchmark numbers below are unchanged and still valid; no
throughput characteristic changes.

## v3.5.0 — formal-verification claim correction (no perf change)

v3.5 changed **no code behaviour** — it corrected the project's
headline formal-verification claim (the README said "5/5 Tamarin
lemmas verified / 10/10 ProVerif queries proved"; the real status
is 5 Tamarin lemmas + 8 ProVerif queries machine-checked, 3 + 2
stated-but-unproven, and the extension models stated + aspirational
— see `verification/VERIFICATION_STATUS.md`). There is no
performance dimension. The benchmark numbers below are unchanged
and still valid.

## v3.4.0 — extension-negotiation claim correction (no perf change)

v3.4 changed **no code behaviour** — it corrected documentation
that described the `EVLN-EXT-1.5` extension mechanism as an active,
transcript-bound, on-wire negotiation. In the shipping code there
is no extension flight: the record layer uses fixed build-time
defaults (1 MiB frames since v2.5), identical on both ends. The
benchmark numbers below are unchanged and still valid.

There is no performance dimension to this release: frame size was
already a fixed 1 MiB default, not a negotiated value, so no
throughput characteristic changes. The correction is purely to the
documentation and a regression test pinning the fixed-default
behaviour.

## v3.3.0 — cryptographic-construction correction (no perf change)

v3.3 changed **no code behaviour** — it corrected documentation
that overstated the handshake construction. The benchmark numbers
below (v3.2 and earlier sections) are unchanged and still valid.

**The handshake construction, stated accurately:**
- **KEX**: a single ML-KEM-1024 encapsulation (FIPS 203, NIST
  category 5). Not triple-KEM. No X25519.
- **Auth**: a single ML-DSA-87 signature per side (FIPS 204, NIST
  category 5). No Ed25519. No SPHINCS+.

Prior revisions of this file claimed "ML-KEM-1024 ×3" and
"Ed25519 + SPHINCS+"; those primitives are not in the transport.
The measured ~5 ms handshake latency was always the real
single-primitive handshake. The construction is now pinned by the
test `handshake_construction_is_single_mlkem1024_single_mldsa87`.

## v3.9.0 — overflow-safety bug fixes (no perf change)

v3.9 is a bug-fix release: it made the file-copy, reverse-forward,
and agent wire decoders overflow-safe on 32-bit targets (the v3.6
`Parser::take` class). The added checks are a few `checked_add`/
`checked_mul` per decode — negligible, off the bulk data path. **No
performance change**; the numbers below (incl. the v3.7 measured
AEAD ceiling) are unchanged and still valid.

## v3.8.0 — parser property/fuzz coverage + model cleanup (no perf change)

v3.8 changed **no code behaviour** and has **no** performance
dimension. It added CI-integrated property/fuzz tests for the
channel wire parser (a security-*assurance* improvement, not a
speed change) and removed aspirational formal models for an
unshipped protocol. The benchmark numbers below — including the
v3.7 measured AEAD ceiling — are unchanged and still valid.

## v3.7.0 — measured AEAD ceiling; "AEAD-bound" claim corrected

**Correction (v3.7):** earlier revisions of this file (and the
v3.1/v3.2 notes) explained the flat ~50–75 MiB/s bulk-filecopy
loopback number by saying the path was "AEAD-compute-bound". That
was asserted **without** an isolating measurement, and it is
**wrong**. Measuring ChaCha20-Poly1305 in isolation (new committed
bench, `cargo bench -p evelin-crypto --bench aead_throughput`):

| Operation (1 MiB record) | Throughput |
|---|---|
| `seal` (allocating) | **1.132 GiB/s** |
| `seal_in_place` (v3.2) | **1.133 GiB/s** |
| `open` (decrypt) | **924 MiB/s** |

Backend: SIMD (x86_64 **AVX2** detected; `cpufeatures` runtime
detection is active even with `chacha20poly1305`
`default-features = false, features = ["alloc"]`). The cipher is
already vectorized — **no SIMD speed-up is available** (checked and
ruled out by measurement, not assumption).

The AEAD ceiling (~1.1 GiB/s per direction) is **~16–24× faster**
than the ~50–75 MiB/s end-to-end loopback filecopy, so the bulk
path is **not** AEAD-bound. On the single-core test box the real
limiter is **core contention**: the client task, the server task,
the loopback duplex, the mux mpsc hops, and disk I/O all share one
CPU. That is a benchmark-topology artifact — real deployments
(separate hosts/cores) are bounded by min(AEAD, NIC, disk), not by
the cipher on a shared core. A faithful end-to-end throughput
number requires a two-host or pinned multi-core setup; the
single-core loopback bench is for regression detection, and its
absolute MiB/s understates real-deployment throughput.

## How to reproduce

```bash
cargo bench -p evelin-session --bench filecopy_throughput
cargo bench -p evelin-session --bench filecopy_throughput -- handshake
cargo bench -p evelin-session --bench filecopy_throughput -- filecopy_upload
cargo bench -p evelin-session --bench filecopy_throughput -- filecopy_download

# v3.2 zero-extra-allocation proof (deterministic, not wall-clock):
cargo test -p evelin-crypto seal_in_place_does_not_reallocate_when_tag_reserved
```

## v3.2.0 baseline — loopback, single-core box

v3.2 removes redundant **allocations and copies** from the send
path: `Aead::seal_in_place` encrypts the caller's buffer in place
(no fresh full-frame ciphertext Vec), the mux hands owned buffers
straight to it, and `ChannelMsg::encode` pre-sizes bulk Data
frames. **This is an allocation/copy reduction, proven
deterministically — NOT a measured bulk-throughput win on this
1-core box** (where the limiter is single-core contention between
the client/server tasks, loopback, mux, and disk — NOT the cipher;
the AEAD alone runs ~16–24× faster than the bulk number, see the
v3.7 "measured AEAD ceiling" section above).

### The metric that deterministically moved: allocations

| Property | Before v3.2 | After v3.2 |
|---|---|---|
| Full-frame ciphertext alloc per record | 1 (seal allocates) | **0** (in-place; proven no-realloc) |
| `encode` reallocs per 1 MiB Data chunk | ~15 (64 B base doubling) | **1** (pre-sized) |
| Send-path full-frame copies per record | 3 | **2** |

Proven by `seal_in_place_does_not_reallocate_when_tag_reserved`
(buffer pointer + capacity unchanged after encryption) and
`send_owned_matches_flushed_stream` (byte-identical wire output).

### Bulk filecopy: flat (within variance, as expected)

| Size | v3.1 upload | v3.2 upload | Verdict |
|---|---|---|---|
| 1 MiB | 45.4 MiB/s | 47.5 MiB/s | flat (±50% variance) |
| 16 MiB | — | 62.5 MiB/s | — |
| 64 MiB | 51.4 MiB/s | 60.1 MiB/s | flat (±50% variance) |

### Handshake latency

| Operation | Median | Range |
|---|---|---|
| ClientHandshake → ServerHandshake round trip | 5.28 ms | 5.03–5.49 ms |

**Honest summary**: v3.2 removes one full-frame copy + the
per-record ciphertext allocation + bulk-encode realloc churn,
proven deterministically. On a 1-core loopback microbench this is
correctly invisible — not because the path is "AEAD-bound" (it is
not; the AEAD ceiling is ~16–24× the bulk number, see v3.7), but
because the single shared core is saturated by client+server task
scheduling, the loopback duplex, and disk I/O. The saving is
expected
to matter on multi-core servers (allocator contention),
long-running processes (fragmentation/RSS), and
memory-bandwidth-bound targets — those are **[ESTIMATED]**, not
measured here.

## v3.1.0 baseline — loopback, single-core box

v3.1 is a **small-frame syscall-reduction** release. `RecordSender`
now buffers through a 64 KiB `BufWriter`, and the mux writer loop
coalesces queued records into one flush. **This targets small-frame
streaming (interactive PTY, port-forward small writes, pipelined
channel control, high-channel-count muxing) — NOT bulk filecopy.**

### The metric that actually moved: write syscalls

Wall-clock throughput on this shared 1-core container varies ±50%
between sessions — far too noisy to show a syscall change. The v3.1
benefit is therefore measured **deterministically** by a
counting-mock unit test:

| Workload | Writes BEFORE v3.1 | Writes AFTER v3.1 |
|---|---|---|
| 100 small records (24 B each) | 200 (len+ct per record, flush each) | **1** (buffered, single flush) |

Large frames (> 64 KiB) bypass the buffer and write through
directly — verified by `bufwriter_passes_large_frames_through` —
so bulk transfer incurs no extra copy and is unaffected.

### Bulk filecopy: flat (by design)

| Size | v3.0 upload | v3.1 upload | Verdict |
|---|---|---|---|
| 1 MiB | 48.5 MiB/s | 45.4 MiB/s | flat (within ±50% variance) |
| 64 MiB | 61.7 MiB/s | 51.4 MiB/s | flat (within ±50% variance) |

### Handshake latency

| Operation | Median | Range |
|---|---|---|
| ClientHandshake → ServerHandshake round trip | 5.55 ms | 5.43–5.69 ms |

Consistent with v3.0's 5.07 ms within container variance. v3.1
does not touch the handshake.

**Honest summary**: v3.1 reduces per-record syscall/segment
overhead for small-frame workloads (proven exactly: 200 → 1) and
leaves bulk throughput unchanged (large frames bypass the buffer).
We do **not** claim a bulk-filecopy speedup. The bulk path's real
bottleneck is per-chunk memory copies (`send_data` →
`ChannelMsg::encode` → `Aead::seal`), tracked for a future sprint.

## v3.0.0 baseline — loopback, single-core box

v3.0 is a memory-hygiene release: the source delta is a handful
of `zeroize` calls on key-derivation stack buffers (executed once
per handshake) plus two `#![forbid(unsafe_code)]` lint attributes.
**Nothing on the data path changed.**

Benchmarks were **not re-run** for v3.0 because the delta provably
cannot affect throughput: the added wipes are ~3 × 32-byte
volatile writes per handshake — tens of nanoseconds against a
~5 ms post-quantum handshake — and the filecopy data path is
byte-identical to v2.9. The v2.9 baseline therefore applies
unchanged:

### Handshake latency

| Operation | Median | Range |
|---|---|---|
| ClientHandshake → ServerHandshake round trip | 5.07 ms | 4.62–6.08 ms |

Per-handshake zeroize cost is unmeasurable: the three new
`[u8; 32]` volatile wipes (two session keys + one shared-secret
copy, plus one signing-seed wipe at key generation, which is not
even on the handshake path) sum to well under 100 ns.

### Filecopy upload (client → server)

| Payload | Throughput (median) | Range |
|---|---|---|
| 1 KiB | 636 KiB/s | 578–683 KiB/s |
| 64 KiB | 25.0 MiB/s | 24.0–25.5 MiB/s |
| 1 MiB | 48.5 MiB/s | 47.0–50.0 MiB/s |
| 16 MiB | 64.7 MiB/s | 64.1–65.3 MiB/s |
| 64 MiB | 61.7 MiB/s | 60.9–62.4 MiB/s |

### Filecopy download (server → client)

| Payload | Throughput (median) | Range |
|---|---|---|
| 1 KiB | 4.02 MiB/s | 3.97–4.05 MiB/s |
| 64 KiB | 60.6 MiB/s | 60.4–60.9 MiB/s |
| 1 MiB | 62.9 MiB/s | 62.4–63.3 MiB/s |
| 16 MiB | 74.7 MiB/s | 74.2–75.0 MiB/s |
| 64 MiB | 73.5 MiB/s | 72.6–74.2 MiB/s |

Cross-session container-IO variance (±50% between fresh container
sessions) still applies; treat these as that-baseline numbers,
not a delta from v2.9. See the v2.9 section below for the full
methodology note.

## v2.9.0 baseline — loopback, single-core box

**Hardware**: 1× CPU core, 3.9 GiB RAM, ext4 on tmpfs-backed
loop device. Linux 5.15 / glibc 2.39 / rustc 1.96.0. TCP loopback
(`127.0.0.1`), no real network. `release` profile. Container
uptime 15 min at bench start.

### Handshake latency

| Operation | Median | Range |
|---|---|---|
| ClientHandshake → ServerHandshake round trip | 5.07 ms | 4.62–6.08 ms |

### Filecopy upload (client → server)

| Payload | Throughput (median) | Range |
|---|---|---|
| 1 KiB | 636 KiB/s | 578–683 KiB/s |
| 64 KiB | 25.0 MiB/s | 24.0–25.5 MiB/s |
| 1 MiB | 48.5 MiB/s | 47.0–50.0 MiB/s |
| 16 MiB | 64.7 MiB/s | 64.1–65.3 MiB/s |
| 64 MiB | 61.7 MiB/s | 60.9–62.4 MiB/s |

### Filecopy download (server → client)

| Payload | Throughput (median) | Range |
|---|---|---|
| 1 KiB | 4.02 MiB/s | 3.97–4.05 MiB/s |
| 64 KiB | 60.6 MiB/s | 60.4–60.9 MiB/s |
| 1 MiB | 62.9 MiB/s | 62.4–63.3 MiB/s |
| 16 MiB | 74.7 MiB/s | 74.2–75.0 MiB/s |
| 64 MiB | 73.5 MiB/s | 72.6–74.2 MiB/s |

### v2.9 CT auth-path cost

v2.9 made `AuthorizedKeys::contains` (server, per-connection)
and `KnownHosts::matches` (client) constant-time. These run
**once per handshake**, not per data byte, so filecopy
throughput is unaffected by design and the numbers above match
v2.8 within container variance.

The CT cost is `O(authorized-list length)` per handshake: a
1000-key allow-list adds ~1000 32-byte constant-time compares
≈ a few microseconds, negligible against the ~5 ms PQ handshake.
The benchmark's single-key configuration makes the addition
unmeasurable.

## v2.8.0 baseline — loopback, single-core box

**Hardware**: 1× CPU core, 3.9 GiB RAM, ext4 on tmpfs-backed
loop device. Linux 5.15 / glibc 2.39 / rustc 1.96.0. TCP loopback
(`127.0.0.1`), no real network. `release` profile.

**Sample size**: 10 iterations per parameter (50 cap for
handshake), 15-second measurement window. Container uptime at
bench start: 1 minute.

### Handshake latency

| Operation | Median | Range |
|---|---|---|
| ClientHandshake → ServerHandshake round trip | **4.66 ms** | 4.54–4.73 ms |

The full post-quantum handshake: **one** ML-KEM-1024
encapsulation + **one** ML-DSA-87 signature on the client;
reciprocal decapsulation + sign + verify on the server. Loopback
TCP, no network RTT.

> **Correction (v3.3):** earlier revisions of this document
> described the handshake as "ML-KEM-1024 ×3" encapsulation plus
> "Ed25519 + SPHINCS+" signatures. That was never the
> implementation. The transport performs a **single** ML-KEM-1024
> encapsulation and a **single** ML-DSA-87 signature per side —
> no triple-KEM, no X25519, no Ed25519, no SPHINCS+. (`ed25519-dalek`
> appears only in `evelin-hsm`, the offline release-manifest
> signing crate, never in the transport.) The construction is
> pinned by the test
> `handshake_construction_is_single_mlkem1024_single_mldsa87`.

### Filecopy upload (client → server)

| Payload | Median time | Throughput | Range |
|---|---|---|---|
| 1 KiB | 1.44 ms | **692 KiB/s** | 685–699 KiB/s |
| 64 KiB | 2.54 ms | 24.6 MiB/s | 24.1–25.4 MiB/s |
| 1 MiB | 19.06 ms | 52.5 MiB/s | 51.6–53.4 MiB/s |
| 16 MiB | 236 ms | 67.8 MiB/s | 67.0–68.5 MiB/s |
| 64 MiB | 1.04 s | 61.4 MiB/s | 60.9–62.0 MiB/s |

### Filecopy download (server → client)

| Payload | Median time | Throughput | Range |
|---|---|---|---|
| 1 KiB | 253 µs | 3.86 MiB/s | 3.81–3.91 MiB/s |
| 64 KiB | 1.07 ms | 58.2 MiB/s | 57.0–59.8 MiB/s |
| 1 MiB | 13.10 ms | 76.4 MiB/s | 75.9–76.8 MiB/s |
| 16 MiB | 213 ms | 75.3 MiB/s | 74.7–75.8 MiB/s |
| 64 MiB | 875 ms | 73.2 MiB/s | 72.5–73.8 MiB/s |

### Nonce-defense overhead

v2.8 adds a per-seal nonce-reuse check (one u64 comparison +
one assignment, both cache-line-local on the existing `Aead`
struct). Estimated overhead per seal: ~2 ns. At sustained
~70 MiB/s = ~700k seals/sec, total overhead is ~1.4 µs/sec —
unmeasurable in throughput. v2.8 small-file numbers actually
improved vs v2.7 (1 KiB upload: 428 → 692 KiB/s) but this is
within container-IO variance, not attributable to the
nonce-defense code path.

### Honest note on cross-version comparison

v2.6 → v2.7 → v2.8 each measured on a different fresh
container session. Numbers swing widely in non-attributable
directions because the build host's IO scheduling, page cache,
and kernel scheduling pressure vary between sessions. The
v2.x source delta between consecutive releases is small enough
that any throughput delta >10% is almost certainly
container-IO variance, not a real performance change.

**Conclusion**: treat each version's published numbers as
**that version's baseline on that hardware**, not as a delta
from the previous version. The numbers are reproducible
**within a single session** (run-to-run variance <2%) but not
**across sessions** (run-to-run variance can be ±50%).

v2.9 priority: run all of v2.6/v2.7/v2.8 benches **paired on
the same container** to produce a clean cross-version
comparison.

## v2.7.0 archive — loopback, single-core box

**Hardware**: 1× CPU core, 3.9 GiB RAM, ext4 on tmpfs-backed
loop device. Linux 5.15 / glibc 2.39 / rustc 1.96.0. TCP loopback
(`127.0.0.1`), no real network. `release` profile.

**Sample size**: 10 iterations per parameter (50 for handshake),
15-second measurement window.

### Handshake latency (new in v2.7)

| Operation | Median | Range |
|---|---|---|
| ClientHandshake → ServerHandshake round trip | **4.89 ms** | 4.80–4.99 ms |

This is the **full post-quantum handshake**: a single ML-KEM-1024
encapsulation + a single ML-DSA-87 signature on the client side;
reciprocal decapsulation + sign + verify on the server. Loopback
TCP, no network RTT. The ~5 ms cost is dominated by:
- ML-KEM-1024 keygen + encapsulation (~1.5 ms)
- ML-DSA-87 keygen + signature (the bulk of the remaining cost;
  ML-DSA-87 signing is the single most expensive step)

> **Correction (v3.3):** this archived section previously claimed
> "ML-KEM-1024 ×3" and "Ed25519 + SPHINCS+ (negligible)". Those
> primitives are not in the transport — the handshake is a single
> ML-KEM-1024 + single ML-DSA-87 per side. The measured latency
> numbers in this section are unchanged (they were always
> measuring the real single-primitive handshake); only the
> inaccurate prose describing the construction is corrected.

Comparison framing (rough, not benched here):
- OpenSSH 9.x w/ Curve25519 + Ed25519 on same hardware: ~0.5 ms
- PQ overhead: ~5–10x classical for the handshake. This is the
  unavoidable cost of post-quantum key exchange.

### Filecopy upload (client → server)

| Payload | Median time | Throughput (median) | Range |
|---|---|---|---|
| 1 KiB | 2.34 ms | 428 KiB/s | 410–447 KiB/s |
| 64 KiB | 2.91 ms | 21.5 MiB/s | 20.8–22.9 MiB/s |
| 1 MiB | 10.3 ms | 97.4 MiB/s | 96.1–99.3 MiB/s |
| 16 MiB | 112 ms | 142.7 MiB/s | 141.1–143.5 MiB/s |
| 64 MiB | 436 ms | **146.9 MiB/s** | 144.8–148.3 MiB/s |

### Filecopy download (server → client)

| Payload | Median time | Throughput (median) | Range |
|---|---|---|---|
| 1 KiB | 349 µs | 2.80 MiB/s | 2.74–2.86 MiB/s |
| 64 KiB | 1.27 ms | 49.1 MiB/s | 48.4–49.4 MiB/s |
| 1 MiB | 18.2 ms | 54.8 MiB/s | 54.3–55.5 MiB/s |
| 16 MiB | 247 ms | 64.9 MiB/s | 63.8–65.7 MiB/s |
| 64 MiB | 1.08 s | **59.1 MiB/s** | 57.0–61.0 MiB/s |

### Honest note on v2.6 → v2.7 comparison

The v2.6 and v2.7 numbers below come from two different fresh
container runs, not paired back-to-back on the same host:

| Size | Upload v2.6 → v2.7 | Download v2.6 → v2.7 |
|---|---|---|
| 1 KiB | 365 → 428 KiB/s (+17%) | 3.9 → 2.8 MiB/s (−28%) |
| 1 MiB | 81 → 97 MiB/s (+19%) | 134 → 55 MiB/s (−59%) |
| 16 MiB | 111 → 143 MiB/s (+29%) | 167 → 65 MiB/s (−61%) |

The upload improved consistently. The download dropped
consistently. **This is almost certainly container-IO variance**,
not a v2.7 regression — the v2.7 source delta is entirely in
the rate-limiter prune code (which doesn't fire during
single-connection bench runs) and the bench harness (which
just adds a new handshake group; the upload + download
functions are byte-identical to v2.6).

Container hosts differ in IO scheduling, page cache state,
kernel scheduling pressure from neighboring tenants, etc.
v2.8 should run v2.6 and v2.7 benches **paired on the same
container** to get a clean delta. Until that data exists, treat
the v2.7 throughput numbers as **the v2.7.0 baseline** rather
than a delta from v2.6.

## v2.6.0 archive — loopback, single-core box

**Hardware**: 1× CPU core, 3.9 GiB RAM, ext4 on tmpfs-backed
loop device. Linux 5.15 / glibc 2.39 / rustc 1.96.0. TCP loopback
(`127.0.0.1`), no real network. `release` profile (LTO off,
opt-level 3).

**Sample size**: 10 iterations per parameter, 15-second
measurement window. Median ± dispersion shown.

### Filecopy upload (client → server)

| Payload | Median time | Throughput (median) | Range |
|---|---|---|---|
| 1 KiB | 2.74 ms | 365 KiB/s | 329–390 KiB/s |
| 64 KiB | 3.52 ms | 17.8 MiB/s | 17.0–19.0 MiB/s |
| 1 MiB | 12.3 ms | 81.3 MiB/s | 79.8–84.1 MiB/s |
| 16 MiB | 144 ms | 111 MiB/s | 101–124 MiB/s |
| 64 MiB | 493 ms | **130 MiB/s** | 125–134 MiB/s |

### Filecopy download (server → client)

| Payload | Median time | Throughput (median) | Range |
|---|---|---|---|
| 1 KiB | 250 µs | 3.9 MiB/s | 3.8–4.1 MiB/s |
| 64 KiB | 567 µs | 110 MiB/s | 107–114 MiB/s |
| 1 MiB | 7.47 ms | 134 MiB/s | 133–136 MiB/s |
| 16 MiB | 96 ms | 167 MiB/s | 160–174 MiB/s |
| 64 MiB | 414 ms | **155 MiB/s** | 133–167 MiB/s |

## Reading the numbers

- **1 KiB is handshake-dominated.** Each iteration opens a fresh
  filecopy channel which carries ~2 ms of mux/channel-open
  overhead. The "365 KiB/s" figure is that overhead expressed
  as throughput; it's not a transfer-rate ceiling for small
  files but the cost of a round-trip channel.
- **64 KiB+ is throughput-bound.** At 1 MiB and up, the cost of
  AEAD seal + TCP write per chunk dominates and throughput
  scales linearly.
- **Download outpaces upload at large sizes** because:
  1. Receiver-side SHA-256 verification happens after
     `write_all` (write is async, hash can overlap with the
     next chunk's recv via v2.4 async-hash).
  2. Upload pays an extra disk-read step that download doesn't.
- **Peak loopback: ~167 MiB/s.** This is the cap on this
  hardware for v2.6's frame-by-frame AEAD + mux pipeline. Real
  networks (Gbit Ethernet) typically cap at ~120 MiB/s due to
  per-packet processing.

## Comparison to prior versions

The v2.5 audit cited "4 MiB upload in 112 ms, download in 59 ms"
from a one-off test timing. Restated as throughput:
- v2.5 audit: 4 MiB upload @ ~35 MiB/s, download @ ~70 MiB/s
- v2.6 bench:  16 MiB upload @ 111 MiB/s, download @ 167 MiB/s

The improvement is partly real (v2.6 keeps the 1 MiB record-cap
default from v2.5 plus the v2.4 async-hash pipeline) and partly
**measurement-method change**: v2.5's "112 ms for 4 MiB" included
the mux build + handshake setup time; v2.6's `iter_custom`
excludes setup and measures only the transfer.

## Comparison to `scp -c chacha20-poly1305@openssh.com`

> Not yet measured. v2.7 candidate: add a comparative benchmark
> against OpenSSH 9.x with `chacha20-poly1305@openssh.com` cipher
> on the same loopback to quantify the post-quantum overhead.
> Expected: evelin within 30% of OpenSSH small files (handshake
> heavier due to ML-KEM-1024 + ML-DSA-87 message sizes); within
> 10% large files (same AEAD primitive).

## What's NOT measured here

- **Real-network throughput**: numbers above are loopback only.
  On a 1 Gbit LAN, expect ~80% of these numbers due to NIC
  overhead. On a 100 Mbit ISP link, the link itself is the
  bottleneck.
- **Handshake latency**: not yet a separate bench group.
  v2.7 candidate.
- **Many-channel concurrent throughput**: single-channel only.
  Multiplexing 16 channels through one mux is the v2.7 case.
- **Memory footprint per active transfer**: documented in the
  v2.4 audit as ~6 MiB per active filecopy (4 MiB read-ahead
  buffer + 2 MiB chunk pipeline). Not benchmarked as a
  throughput number.

## Regression detection in CI

The bench is fast enough (~3 min for all 10 parameters on this
hardware) to run on every release. Suggested CI step:

```bash
cargo bench -p evelin-session --bench filecopy_throughput -- \
    --save-baseline release-$VERSION
cargo bench -p evelin-session --bench filecopy_throughput -- \
    --baseline release-$PREVIOUS_VERSION
```

A throughput regression of >10% in the median would flag a
release blocker.

— SecurityOps, v2.6.0
