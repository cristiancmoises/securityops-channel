> Tradução para pt-BR de `README.md`. Em caso de divergência, a versão em inglês prevalece.

# Evelin

Túnel seguro pós-quântico. Conjunto de ferramentas no molde do SSH, Rust, ML-KEM-1024 + ML-DSA-87 + ChaCha20-Poly1305.

**Versão:** 4.3.0
**Licença:** AGPL-3.0-or-later ou comercial (veja `NOTICE`)
**Status:** autolançado; validado em produção contra 1× host Debian 12 exposto à internet desde a v2.0
**Autor:** Cristian Cezar Moisés / SecurityOps · `sac@securityops.co`

**In English:** [`README.md`](README.md) · full docs at [`docs/en/`](docs/en/)
**Projeto:** [`GOVERNANCE.md`](GOVERNANCE.md) · [`CONTRIBUTING.md`](CONTRIBUTING.md) · [`ROADMAP.md`](ROADMAP.md) · [`CODE_OF_CONDUCT.md`](CODE_OF_CONDUCT.md) — traduções em [`docs/pt-br/`](docs/pt-br/)
**Guias:** [primeiros passos](docs/pt-br/getting-started.md) · [arquitetura](docs/pt-br/architecture.md) · [extensões](docs/pt-br/extensions.md) · [exemplos](docs/pt-br/examples.md) · [FAQ](docs/pt-br/faq.md)

## Novidades da v4.3.0 (2026-07-24) — cliente silencioso por padrão, cópia estilo scp

- **O cliente agora é silencioso por padrão, como o `ssh`.** Uma conexão bem-sucedida não imprime nada além da sessão remota; o antigo ruído `{"timestamp":…,"message":"handshake complete",…}` acabou. Use `-v`/`-vv`/`-vvv` para detalhes da conexão (INFO/DEBUG/TRACE, como `ssh -v`) ou `-q` para apenas erros. `RUST_LOG` ainda tem prioridade.
- **Logs não vão mais para o stdout** (texto *e* json vão para o stderr), então a saída de `exec`/`pipe` e os dados de `cp` no stdout ficam limpos e encadeáveis. O formato de log padrão do cliente agora é `text` (legível); o **daemon servidor continua com `json` por padrão**.
- **`cp` familiar ao scp:** `-q` silencia a barra de progresso/resumo, `-v` adiciona detalhe por arquivo, e a barra agora mostra uma porcentagem explícita (`[■■■…] 42% · 1.26 MiB/3.00 MiB · 118 MiB/s · ETA 0s`). As transferências continuam byte a byte idênticas e verificadas por BLAKE3 (`… BLAKE3 verified · Quantum-secured!`).
- Apenas console/UX do lado do cliente — **nenhuma mudança de fio, formato, chave ou ticket; servidor intocado.** 440 testes / 0 falhas (executados duas vezes); clippy `-D warnings` limpo; verificado ao vivo com os binários de release.

## Novidades da v4.2.0 (2026-07-20) — documentação, desempenho, avisos de segurança

- **Documentação, EN + pt-BR:** conjunto de governança do projeto (`CONTRIBUTING.md`, `GOVERNANCE.md`, `ROADMAP.md`, `CODE_OF_CONDUCT.md`) e cinco guias de usuário em `docs/en/` (primeiros passos, arquitetura, extensões, exemplos, FAQ), cada um checado contra o código-fonte; espelho completo em português do Brasil em `docs/pt-br/` mais o `README.pt-BR.md`.
- **Redução de alocações/cópias nos caminhos quentes** (escopo honesto: alocações e cópias removidas; **nenhuma alegação de throughput** — a transferência em massa continua limitada por contenção de núcleo, conforme `docs/BENCHMARKS.md`): descriptografia in-place no recebimento (`Aead::open_in_place`, espelho no recv do `seal_in_place` da v3.2, travado por novos testes de equivalência); frames Data de saída pré-reservam a tag AEAD para o seal não realocar; o dispatch do mux libera o lock de estado antes de envios sob backpressure (correção de head-of-line); o filecopy elimina uma cópia profunda por chunk nos três caminhos de massa e não relê nada no resume (estado SHA-256 bifurcado). Bytes no fio inalterados.
- **Avisos de dependência resolvidos:** `crossbeam-epoch` 0.9.20 (RUSTSEC-2026-0204; alcance apenas em dev-dependency) e `anyhow` 1.0.104 (RUSTSEC-2026-0190); `cargo audit` verde.
- **Robustez da suíte de testes:** corrigida uma corrida de exit-status perdido no e2e de exec; removido o `/bin/echo` fixo (hosts Guix/NixOS); folga de pilha no perfil debug para os frames grandes de handshake ML-KEM/ML-DSA via `.cargo/config.toml`.
- 439 testes / 0 falhas (executados duas vezes); clippy `-D warnings` limpo; gate de auditoria PASS. Lançamento em nível de código-fonte — os pacotes binários não são reconstruídos por este commit.

## Novidades da v4.1.1 (2026-06-10) — documentação + validação ao vivo

- **`COMPARISON.md`**: comparação honesta Evelin↔OpenSSH (fatos pós-quânticos do OpenSSH 10.x verificados; desvantagens declaradas com clareza; nenhuma alegação de desempenho sem benchmark).
- **Validação de conexão com os binários completos** (`docs/V4_1_1_CONNECTION_VALIDATION.md`): handshake v2 ao vivo com frames de 64 KiB negociados, ida e volta de filecopy de 1 MiB byte a byte idêntica, fallback para v1, casos negativos de autenticação, mediana de handshake+exec de 11,7 ms (loopback, 1 núcleo). Encerra o R-1 do dev.3.
- **44 arquivos .md narrativos obsoletos removidos** (manifesto no CHANGELOG); zero referências pendentes. Nenhuma mudança de código.

## Novidades da v4.1.0 (2026-06-10) — lançamento de revisão profunda

- **Tamanho de frame ajustável pelo operador:** `max_frame_kib` (potência de dois em [16, 1024] KiB; padrão 1024 = byte a byte idêntico à v4.0.0) é anunciado na oferta v2; o mínimo negociado limita a camada de registro. Defina abaixo de 1024 somente quando ambos os pares forem ≥ 4.1.0 (veja ERRATA E-2). Nota honesta: isso não altera o throughput medido em núcleo único (v3.7); seu valor é operacional.
- **Validação estrita da oferta v2:** uma oferta fora de conformidade (anúncio de frame abaixo da base de 16 KiB do v1; formatos malformados de valores conhecidos) agora aborta o handshake de forma coerente em ambas as pontas, em vez de ser silenciosamente ajustada ao limite. Mudança de comportamento intencional, travada por testes.
- **Mux dimensionado ao orçamento de frame ativo:** os dados são fragmentados conforme o frame negociado e Requests grandes demais falham apenas na própria chamada (`RequestTooLarge`), em vez de derrubar a conexão — corrige o ERRATUM E-2 da v4.0.0.
- **Quatro erratas da v4.0.0 publicadas e corrigidas** (`docs/V4_0_0_ERRATA.md`): uma alegação imprecisa de cobertura de testes na auditoria do GA (E-1), o defeito de frame do mux (E-2), uma suíte de testes de sessão que não compilava no código-fonte distribuído (E-3), análise leniente de valores de capacidade (E-4).
- 233 testes / 0 falhas em 11 crates (crates alterados executados duas vezes); clippy limpo; audit com 0 vulnerabilidades; deny PASS. Registro completo da revisão, incl. proveniência: `docs/V4_1_AUDIT_REPORT.md`.

## Novidades da v4.0.0 (2026-06-09) — GA

**O protocolo v2 chega ao GA: negociação de capacidades opt-in, vinculada ao transcript e resistente a downgrade.** Implantações padrão permanecem byte a byte idênticas à v1.4 — o v2 é estritamente opt-in (defina `max_protocol_version = 2` em ambas as pontas).

- **Resistência a downgrade por construção:** o bloco de capacidades vive no corpo assinado do handshake (nunca no cabeçalho); removê-lo/alterá-lo/injetá-lo — ou reescrever a versão — quebra a assinatura ML-DSA-87 e aborta o handshake. Respaldado por testes executáveis e um teste de integração sobre TCP real.
- **Tamanho de frame de registro negociado** (`MAX_FRAME_LOG2`) limita a camada de registro (comprovado: um frame de 128 KiB faz ida e volta por um socket v2, impossível sob o teto de 16 KiB do v1). `REKEY` é negociado/exposto, mas reservado para um futuro rekey assimétrico com ML-KEM (não ligado ao ratchet sempre ativo — isso seria mera cerimônia).
- **Hardening:** `Capabilities::decode` ganha cobertura de propriedade/fuzz com ~570 mil entradas; `SECURITY.md` ganha uma seção de modelo de ameaças do v2; modelos Tamarin + ProVerif da negociação v2 distribuída são adicionados como **STATED** (não verificados por máquina — não há binário de provador aqui).
- **Limitações honestas levadas ao GA:** os modelos formais do v2 são STATED, não PROVEN; o throughput permanece o mesmo da v3.7 (teto do AEAD medido; a transferência em massa é limitada por contenção de núcleo único) — o tamanho de frame negociado muda o que a camada de registro aceita, não o throughput medido em núcleo único.
- Migração: nenhuma mudança de chave/identidade/ticket; atualize primeiro os servidores (um servidor v2 continua aceitando clientes v1 de forma byte a byte idêntica), depois os clientes. Todos os gates verdes; empacotamento multiplataforma completo. Veja `docs/V4_0_0_AUDIT_REPORT.md`.

## Notas de versões anteriores

O histórico completo por versão (v0.1 → v4.0.0-dev.5) está em [`CHANGELOG.md`](CHANGELOG.md); os relatórios de auditoria de cada versão são distribuídos, com checksum, junto aos artefatos de cada lançamento.

## Versões mais antigas (v3.4 e anteriores)

Condensado por brevidade — veja `CHANGELOG.md` para o histórico completo por versão (correção da alegação de negociação de extensões na v3.4, correção de alegação criptográfica na v3.3, redução de alocações/cópias na v3.2, coalescência de escritas na v3.1, zeroização na v3.0 e o arco de hardening de segurança da série v2.x).

## O que é

O Evelin é o que o SSH seria se você o reprojetasse em 2026 sabendo que a criptografia clássica tem prazo de validade. O handshake usa ML-KEM-1024 (FIPS 203, encapsulamento de chave pós-quântico) e ML-DSA-87 (FIPS 204, assinaturas pós-quânticas), ambos na categoria de segurança 5 do NIST. A camada de registro é ChaCha20-Poly1305 com KDF HKDF-SHA-512. As chaves de identidade podem ser protegidas por frase secreta com Argon2id (m=64 MiB, t=3, p=1).

O formato do conjunto de ferramentas voltado ao usuário é emprestado do OpenSSH de propósito, para que operadores não precisem reaprender nada. O protocolo de rede **não** é compatível com SSH e nunca será.

Se você grava tráfego hoje e precisa que ele permaneça confidencial daqui a dez ou vinte anos, os padrões clássicos do SSH não bastam. O Evelin existe exatamente para esse caso.


## O que há no conjunto de ferramentas

| Binário | Análogo no OpenSSH | O que faz |
|---|---|---|
| `evelin-server` | `sshd` | daemon do servidor |
| `evelin-client` | `ssh` | cliente (exec, shell, cópia de arquivos, encaminhamento de porta, SOCKS, jump, proxy-command) |
| `evelin-keygen` | `ssh-keygen` | gera chaves de identidade |
| `evelin-agent` | `ssh-agent` | mantém chaves desbloqueadas na memória |
| `evelin-keyscan` | `ssh-keyscan` | descobre fingerprints de servidores |
| `evelin-multisig-verify` | — | verifica as assinaturas dos lançamentos |
| `evelin-sandbox-probe` | — | verifica o suporte a landlock neste host |
| `evelin-seccomp-probe` | — | verifica o suporte a seccomp neste host |


## Lado do servidor — instalação e primeira execução

```sh
# 1. Install. Pick your platform:
sudo dpkg -i evelin_1.1.0_amd64.deb              # Debian/Ubuntu
sudo rpm -i  evelin-1.1.0-1.x86_64.rpm           # Fedora/RHEL/Alma/Rocky
# OR drop the static tarball anywhere on $PATH:
tar xzf evelin-v1.1.0-x86_64-unknown-linux-musl.tar.gz
sudo install -m 0755 evelin-v1.1.0-*/bin/* /usr/local/bin/

# 2. Generate the server identity key.
sudo mkdir -p /etc/evelin
sudo evelin-keygen --out /etc/evelin/identity.key
sudo chmod 600 /etc/evelin/identity.key
sudo chown evelin:evelin /etc/evelin/identity.key 2>/dev/null || true

# 3. Set up the authorized_keys file (required header on first line).
sudo tee /etc/evelin/authorized_keys > /dev/null <<'EOF'
# evelin-authorized-keys v1
EOF

# 4. Set up the server config.
sudo tee /etc/evelin/server.toml > /dev/null <<EOF
bind = "0.0.0.0:7222"
identity_key = "/etc/evelin/identity.key"
authorized_keys = "/etc/evelin/authorized_keys"
log_format = "json"
log_level = "info"

[limits]
max_connections = 100

[exec]
allow = []                    # exact-match command allow-list

[forward]
allow = []
wildcards = false

[reverse_forward]
allow = []
EOF

# 5. Sanity-check the config without binding the network:
sudo evelin-server --config /etc/evelin/server.toml --check

# 6. Note the server fingerprint — you'll need it on the client side.
sudo evelin-server --config /etc/evelin/server.toml --check | grep identity_key

# 7. Run as a systemd service (unit file is shipped in the .deb / .rpm):
sudo systemctl enable --now evelin-server
sudo systemctl status evelin-server
```

Se você não está em uma distribuição com pacote, a unit do systemd fica em `packaging/systemd/evelin-server.service` na árvore do código-fonte.


## Lado do cliente — primeira conexão

```sh
# 1. Install (same package, both halves).
sudo dpkg -i evelin_1.1.0_amd64.deb              # or
tar xzf evelin-v1.1.0-x86_64-unknown-linux-musl.tar.gz
sudo install -m 0755 evelin-v1.1.0-*/bin/* /usr/local/bin/

# 2. Generate your client identity key.
mkdir -p ~/.evelin
evelin-keygen --out ~/.evelin/identity.key
chmod 600 ~/.evelin/identity.key

# 3. Print the line to paste into the server's authorized_keys:
evelin-client --config ~/.evelin/client.toml print-auth-line --comment "$(whoami)@$(hostname)"
# → copy that hex fingerprint + comment into /etc/evelin/authorized_keys
#   on the server (the line goes UNDER the v1 header).

# 4. Get the server's fingerprint out-of-band — phone, paper, signed
#    email — and add it to your local trust file:
evelin-client --config ~/.evelin/client.toml \
    trust --addr server.example.com:7222 \
          --fingerprint <64-hex-from-server-out-of-band>

# 5. Connect:
cat > ~/.evelin/client.toml <<EOF
server_addr = "server.example.com:7222"
identity_key = "$HOME/.evelin/identity.key"
EOF

# Run a single command:
evelin-client --config ~/.evelin/client.toml exec uname -a

# Interactive shell:
evelin-client --config ~/.evelin/client.toml shell

# Copy a file:
evelin-client --config ~/.evelin/client.toml cp ./local.txt remote:/tmp/

# Local port forward (-L):
evelin-client --config ~/.evelin/client.toml forward -L 8080:internal.example:80

# Reverse port forward (-R):
evelin-client --config ~/.evelin/client.toml reverse-forward -R 9090:127.0.0.1:9090

# SOCKS5 dynamic forward (-D):
evelin-client --config ~/.evelin/client.toml socks -D 1080

# Through a jump host:
evelin-client --config ~/.evelin/client.toml --jump bastion.example:7222 exec hostname

# Through a corporate HTTP CONNECT proxy:
evelin-client --config ~/.evelin/client.toml \
    --proxy-command 'corkscrew proxy.corp 8080 $EVELIN_HOST $EVELIN_PORT' \
    exec hostname
```


## Verificando assinaturas

Todo tarball de lançamento é acompanhado de um arquivo `SHA256SUMS`:

```sh
sha256sum -c SHA256SUMS
```

Os lançamentos produzidos pela CI do Forgejo também são assinados com PGP pela chave de lançamento do projeto. O fingerprint está em `SECURITY.md`.


## Compilando a partir do código-fonte

```sh
git clone https://github.com/cristiancmoises/evelin
cd evelin
cargo build --release --workspace
ls target/release/evelin-*
```

Requisitos: Rust 1.85+ (o `rust-toolchain.toml` fixa essa versão).
Para builds estáticos com musl, veja os comandos de compilação cruzada em `BUILD.md`.


## Criptografia

| Camada | Algoritmo | Fonte |
|---|---|---|
| Encapsulamento de chave | ML-KEM-1024 (FIPS 203) | `ml-kem` 0.3 |
| Assinaturas | ML-DSA-87 (FIPS 204) | `ml-dsa` 0.1.0-rc.9 |
| AEAD | ChaCha20-Poly1305 | `chacha20poly1305` 0.10 |
| KDF | HKDF-SHA-512 | `hkdf` 0.12 + `sha2` 0.10 |
| Proteção por frase secreta | Argon2id (m=64 MiB, t=3, p=1) | `argon2` 0.5 |
| Hash | SHA-512, BLAKE2b | `sha2`, `blake2` |

Os fingerprints de chave de identidade são SHA-512 truncado a 256 bits, exibidos como 64 caracteres hexadecimais.


## Notas de implantação

Estas são lições reais de executar a v1.1.0 em produção. Leia isto antes da sua primeira instalação.

**Use o binário estático musl em qualquer VPS Linux.** O binário glibc (e os pacotes `.deb` / `.rpm`, que embrulham o binário glibc) foi compilado contra a glibc 2.39. Ele não roda no Debian 12 (glibc 2.36), no Ubuntu 22.04 (glibc 2.35) nem em nada mais antigo. O binário estático musl em `evelin-v1.1.0-x86_64-unknown-linux-musl.tar.gz` tem zero dependência de glibc e roda em qualquer lugar. Prefira o musl como padrão em VPSes; use o binário glibc apenas se você souber especificamente que seu host é recente o bastante.

**`[shell]` exige a feature `pty-shell` do Cargo em tempo de compilação.** O tarball musl distribuído é compilado sem ela. Se você quer sessões interativas de shell com PTY (`evelin-client shell`), recompile o servidor com `cargo build --release --features pty-shell -p evelin-server` (ou use o binário publicado como `evelin-server-v1.1.0-pty-shell-*`). O campo de configuração `[shell] enable = true` é aceito pelo parser de qualquer forma, mas o servidor recusará `pty-req` em tempo de execução se a feature não estiver compilada.

**Os caminhos em `client.toml` e `server.toml` não passam por expansão de shell.** TOML não avalia `$HOME` nem `~`. Use apenas caminhos absolutos. Errado: `identity_key = "$HOME/.evelin/identity.key"`. Certo: `identity_key = "/home/cristian/.evelin/identity.key"`.

**O esquema de `[filecopy]` é `roots` + `allow_upload` + `allow_download`.** Uma única lista compartilhada de prefixos de caminho governa as duas direções. A distinção entre leitura e escrita é imposta pelo modo dos arquivos e pelo usuário sob o qual o `evelin-server` roda, não por campos de configuração separados.

**O esquema de `[shell]` é `enable` + `command` + `args`.** O caminho do binário do shell é `command`, não `program`.

**O usuário da unit do systemd deve ser dono dos arquivos de chave.** `User=evelin` na unit significa que o usuário `evelin` precisa conseguir ler `/etc/evelin/identity.key`. O empacotamento padrão deixa o arquivo com dono root, o que derruba o serviço com um `Permission denied` genérico. Correção:

```sh
sudo chown -R evelin:evelin /etc/evelin
sudo chmod 755 /etc/evelin
sudo chmod 600 /etc/evelin/identity.key
sudo chmod 644 /etc/evelin/authorized_keys /etc/evelin/server.toml
```

**O caminho de `ExecStart` na unit do systemd deve corresponder a onde o binário realmente está.** Se você instalou pelo tarball musl, o binário está em `/usr/local/bin/evelin-server`. O arquivo de unit padrão vem com `/usr/sbin/evelin-server`. Edite a unit (`sudo systemctl edit --full evelin-server`) para que os caminhos coincidam, ou crie um link simbólico. Se você instalou via `.deb` / `.rpm` e usou o binário glibc, o caminho é `/usr/bin/evelin-server`.

**O `ReadWritePaths` da unit do systemd deve incluir todo caminho declarado em `[filecopy] roots`.** Se `roots = ["/srv/uploads/"]`, então `ReadWritePaths=/srv/uploads`. Caso contrário, as tentativas de escrita do servidor no sistema de arquivos são bloqueadas por `ProtectSystem=strict`, mesmo que o usuário tenha as permissões corretas.

**O cliente não tem flag `--log-level`.** A verbosidade é controlada por `log_level` no `client.toml`, ou definindo `RUST_LOG=debug` no ambiente. O mesmo vale para o servidor.

**`authorized_keys` deve começar com o cabeçalho `# evelin-authorized-keys v1`.** Um arquivo sem ele é rejeitado na análise, com um erro de número de linha de aparência confusa. O subcomando `print-auth-line` emite uma linha de comentário acima do fingerprint — cole apenas a linha do fingerprint, não o comentário.


## Status

A v1.1.0 é **autolançada**. O mantenedor a implantou na própria infraestrutura e a considera pronta para implantação autônoma por terceiros. A v1.1.0 NÃO reflete uma auditoria criptográfica paga de terceiros; isso ainda é um evento futuro que o projeto acolhe. Veja `SECURITY.md` para a disposição completa dos riscos residuais.


## Histórico do projeto

- **2026-05-08** — primeiro uso em produção de ponta a ponta:
  - Primeira transferência de arquivo pelo túnel pós-quântico: `love.txt → remote:/tmp/life.txt`, do laptop para o VPS.
  - Primeira sessão interativa de shell com PTY através do Evelin, do laptop para o shell do VPS.
  - Build: v1.1.0 musl estático + feature `pty-shell`, VPS Debian 12, gerenciado pelo systemd com sandbox completo (Landlock totalmente aplicado).


## Licença

Licenciamento duplo:

- **AGPL-3.0-or-later** — software livre, com copyleft forte para uso em rede. Fonte: `LICENSE-AGPL-3.0`.
- **Licença comercial** — para usos incompatíveis com a AGPL (incorporação em código fechado, serviço modificado sem divulgação do código-fonte, organizações que não podem aceitar a AGPL). Contato: `sac@securityops.co`.

Veja `NOTICE` para a explicação completa em linguagem simples. A licença comercial existe porque o autor escreveu este código e quer ser pago quando empresas construírem negócios em cima dele. Uso individual / hobbista / de pesquisa / sem fins lucrativos / corporativo interno é totalmente coberto pela AGPL — nenhum pagamento é exigido.


## Relatando problemas de segurança

Não abra issues públicas para vulnerabilidades de segurança. Veja `SECURITY.md` para o fluxo de relato por canal criptografado.


## Fatos do projeto

- 12 crates, 78 arquivos Rust, ~16.400 linhas de Rust
- Zero código `unsafe` (lint imposto no workspace)
- Limpo sob Clippy `-D warnings`
- 134+ testes nos crates criptográficos e de protocolo
- 6 alvos de fuzz, 50,4 milhões de iterações acumuladas, 0 travamentos (herdado da v0.3.0)
- Modelos formais (handshake principal): **5 lemas Tamarin + 8 consultas ProVerif verificados por máquina** na cerimônia de prova da v0.1 (sigilo do núcleo, autenticação mútua, perfect forward secrecy). Outros 3 lemas Tamarin + 2 consultas ProVerif (ratchet / vinculação ao agente / integridade do filecopy) estão **declarados, mas ainda não verificados por máquina**, e os modelos das extensões v1.5/v1.8 são **declarados + aspiracionais** (modelam recursos não ligados ao código distribuído). Status completo por lema: `verification/VERIFICATION_STATUS.md`. **Não** é "totalmente verificado formalmente" — veja esse arquivo para o detalhamento honesto.
- Builds reproduzíveis verificados em dois hosts independentes (herdado da v0.3.0)
