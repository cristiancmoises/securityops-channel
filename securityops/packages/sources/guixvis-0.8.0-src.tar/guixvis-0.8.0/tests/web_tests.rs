//! Web API handler tests (only built with the `web` feature).
//!
//! Driven through `tower::ServiceExt::oneshot` — no sockets, no runtime
//! blocking, deterministic fixture data.

#![cfg(feature = "web")]

mod common;

use std::net::SocketAddr;

use axum::body::Body;
use axum::extract::ConnectInfo;
use axum::http::{Request, StatusCode};
use http_body_util::BodyExt;
use tower::ServiceExt;

use common::load_fixture;
use guixvis::web::{router, AppState};

fn state() -> std::sync::Arc<AppState> {
    AppState::with_index(load_fixture())
}

fn get(path: &str) -> Request<Body> {
    Request::get(path)
        .header("host", "127.0.0.1:8787")
        .extension(ConnectInfo(SocketAddr::from(([127, 0, 0, 1], 50000))))
        .body(Body::empty())
        .expect("request builds")
}

async fn json_of(res: axum::response::Response) -> serde_json::Value {
    let bytes = res.into_body().collect().await.expect("body").to_bytes();
    serde_json::from_slice(&bytes).expect("json body")
}

#[tokio::test]
async fn exact_identity_and_stale_snapshot() {
    let index = common::identity_fixture();
    let token = index.snapshot_id().to_string();
    let api = router(AppState::with_index(index));
    let health = json_of(api.clone().oneshot(get("/api/v1/health")).await.unwrap()).await;
    assert!(health["origin"]["channels"].is_array());
    for id in [3, 4] {
        let res = api
            .clone()
            .oneshot(get(&format!(
                "/api/v1/package/variant?id={id}&snapshot={token}"
            )))
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        assert_eq!(json_of(res).await["id"], id);
    }
    let res = api
        .oneshot(get(&format!(
            "/api/v1/package/root?id=0&snapshot={}",
            "0".repeat(64)
        )))
        .await
        .unwrap();
    assert_eq!(res.status(), StatusCode::CONFLICT);
}

#[tokio::test]
async fn exact_api_validates_pairs_and_preserves_zero_and_relation_kinds() {
    let index = common::identity_fixture();
    let token = index.snapshot_id().to_string();
    let api = router(AppState::with_index(index));
    for route in ["package", "graph"] {
        for query in [
            "id=0".to_string(),
            format!("snapshot={token}"),
            format!("id=-1&snapshot={token}"),
            format!("id=4294967296&snapshot={token}"),
            "id=0&snapshot=bad".into(),
        ] {
            let res = api
                .clone()
                .oneshot(get(&format!("/api/v1/{route}/root?{query}")))
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::BAD_REQUEST, "{route}?{query}");
            assert!(json_of(res).await["error"].is_string());
        }
        let res = api
            .clone()
            .oneshot(get(&format!(
                "/api/v1/{route}/root?id=999&snapshot={token}"
            )))
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::NOT_FOUND);
        let res = api
            .clone()
            .oneshot(get(&format!("/api/v1/{route}/wrong?id=0&snapshot={token}")))
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::BAD_REQUEST);
        let res = api
            .clone()
            .oneshot(get(&format!(
                "/api/v1/{route}/root?id=999&snapshot={}",
                "0".repeat(64)
            )))
            .await
            .unwrap();
        assert_eq!(
            res.status(),
            StatusCode::CONFLICT,
            "stale token checked before ID"
        );
    }
    let res = api
        .clone()
        .oneshot(get(&format!("/api/v1/package/root?id=0&snapshot={token}")))
        .await
        .unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let body = json_of(res).await;
    assert_eq!(body["id"], 0);
    assert_eq!(body["snapshot"], token);
    assert_eq!(body["deps"].as_array().unwrap().len(), 5);
    assert_eq!(
        body["deps"][0]["kinds"],
        serde_json::json!(["input", "propagated", "native"])
    );
    let res = api
        .clone()
        .oneshot(get(&format!("/api/v1/graph/root?id=0&snapshot={token}")))
        .await
        .unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let body = json_of(res).await;
    assert_eq!(body["root_id"], 0);
    assert_eq!(body["depth"], 2);
    assert_eq!(
        body["nodes"]
            .as_array()
            .unwrap()
            .iter()
            .filter(|n| n["name"] == "variant")
            .count(),
        2
    );
    let edge = body["edges"]
        .as_array()
        .unwrap()
        .iter()
        .find(|e| e["from_id"] == 0 && e["to_id"] == 1)
        .unwrap();
    assert_eq!(edge["kinds"].as_array().unwrap().len(), 3);
    let res = api
        .clone()
        .oneshot(get("/api/v1/search?q=variant"))
        .await
        .unwrap();
    let body = json_of(res).await;
    assert_eq!(body["snapshot"], token);
    let ids: Vec<_> = body["items"]
        .as_array()
        .unwrap()
        .iter()
        .map(|i| i["id"].as_u64().unwrap())
        .collect();
    assert!(ids.contains(&3) && ids.contains(&4));
    let body = json_of(
        api.oneshot(get(&format!(
            "/api/v1/package/variant?id=4&snapshot={token}"
        )))
        .await
        .unwrap(),
    )
    .await;
    assert_eq!(body["catalog"], false);
    assert_eq!(body["command_safe"], false);
}

#[tokio::test]
async fn snapshot_survives_cache_restart_but_not_changed_content_at_generation_one() {
    let old = common::identity_fixture();
    let token = old.snapshot_id().to_string();
    let loaded = guixvis::blob::decode(&guixvis::blob::encode(&old), 999).unwrap();
    let path = format!("/api/v1/package/root?id=0&snapshot={token}");
    let res = router(AppState::with_index(loaded))
        .oneshot(get(&path))
        .await
        .unwrap();
    assert_eq!(res.status(), StatusCode::OK);
    let mut doc: guixvis::model::IndexDoc =
        serde_json::from_str(include_str!("fixtures/identity.json")).unwrap();
    doc.packages[0].native_inputs.clear();
    let replacement = guixvis::index::Index::from_doc(doc, 0).unwrap();
    let api = router(AppState::with_index(replacement));
    let health = json_of(api.clone().oneshot(get("/api/v1/health")).await.unwrap()).await;
    assert_eq!(health["generation"], 1);
    assert_ne!(health["snapshot"], token);
    assert_eq!(
        api.oneshot(get(&path)).await.unwrap().status(),
        StatusCode::CONFLICT
    );
}

#[tokio::test]
async fn health_reports_generation_and_packages() {
    let res = router(state())
        .oneshot(get("/api/v1/health"))
        .await
        .expect("call");
    assert_eq!(res.status(), StatusCode::OK);
    let body = json_of(res).await;
    assert_eq!(body["ok"], true);
    assert_eq!(body["packages"], 10);
    assert_eq!(body["generation"], 1);
    assert_eq!(body["phase"], "ready");
}

#[tokio::test]
async fn search_ranks_emacs_first() {
    let res = router(state())
        .oneshot(get("/api/v1/search?q=emac&limit=10"))
        .await
        .expect("call");
    assert_eq!(res.status(), StatusCode::OK);
    let body = json_of(res).await;
    let items = body["items"].as_array().expect("items");
    assert_eq!(items[0]["name"], "emacs");
    assert!(!items[0]["name_spans"].as_array().unwrap().is_empty());
    // Fuzzy highlight spans lie within the 5-char name.
    for span in items[0]["name_spans"].as_array().unwrap() {
        let end = span[1].as_u64().unwrap();
        assert!(end <= 5, "span must stay within \"emacs\"");
    }
}

#[tokio::test]
async fn search_bounds() {
    let app = router(state());

    let res = app
        .clone()
        .oneshot(get("/api/v1/search?q=emac&limit=abc"))
        .await
        .expect("call");
    assert_eq!(res.status(), StatusCode::BAD_REQUEST, "limit=abc must 400");

    let res = app
        .clone()
        .oneshot(get("/api/v1/search?q=emac&limit=1"))
        .await
        .expect("call");
    let body = json_of(res).await;
    assert_eq!(body["items"].as_array().unwrap().len(), 1);
    assert_eq!(body["capped"], true);

    let res = app
        .clone()
        .oneshot(get("/api/v1/search?limit=10"))
        .await
        .expect("call");
    let body = json_of(res).await;
    assert_eq!(body["items"].as_array().unwrap().len(), 10);
    assert_eq!(body["capped"], false, "an exact fit is not truncated");

    let res = app
        .clone()
        .oneshot(get("/api/v1/search?q=emac&limit=600"))
        .await
        .expect("call");
    let body = json_of(res).await;
    assert!(body["items"].as_array().unwrap().len() <= 500);

    // Over-long query rejected.
    let long_q = "x".repeat(201);
    let res = app
        .oneshot(get(&format!("/api/v1/search?q={long_q}")))
        .await
        .expect("call");
    assert_eq!(res.status(), StatusCode::BAD_REQUEST);
}

#[tokio::test]
async fn package_detail_and_404() {
    let app = router(state());

    let res = app
        .clone()
        .oneshot(get("/api/v1/package/emacs"))
        .await
        .expect("call");
    assert_eq!(res.status(), StatusCode::OK);
    let body = json_of(res).await;
    assert_eq!(body["name"], "emacs");
    assert_eq!(body["deps"].as_array().unwrap().len(), 4);
    assert_eq!(body["generation"], 1);

    let res = app
        .oneshot(get("/api/v1/package/does-not-exist"))
        .await
        .expect("call");
    assert_eq!(res.status(), StatusCode::NOT_FOUND);
}

#[tokio::test]
async fn graph_deps_and_reverse() {
    let app = router(state());

    let res = app
        .clone()
        .oneshot(get("/api/v1/graph/emacs?dir=deps&depth=1"))
        .await
        .expect("call");
    let body = json_of(res).await;
    assert_eq!(body["root"], "emacs");
    assert_eq!(body["nodes"].as_array().unwrap().len(), 5, "root + 4 deps");
    // 4 edges from emacs + the transitive gtk+ -> zlib edge.
    assert_eq!(body["edges"].as_array().unwrap().len(), 5);
    assert_eq!(body["truncated"], 0);

    // Reverse of zlib: 4 direct dependents.
    let res = app
        .clone()
        .oneshot(get("/api/v1/graph/zlib?dir=reverse&depth=1"))
        .await
        .expect("call");
    let body = json_of(res).await;
    assert_eq!(body["dir"], "reverse");
    let names: Vec<&str> = body["nodes"]
        .as_array()
        .unwrap()
        .iter()
        .map(|n| n["name"].as_str().unwrap())
        .collect();
    assert!(names.contains(&"zlib"));
    assert!(names.contains(&"emacs"));
    assert_eq!(names.len(), 5);

    // Bad params.
    let res = app
        .clone()
        .oneshot(get("/api/v1/graph/emacs?depth=9"))
        .await
        .expect("call");
    assert_eq!(res.status(), StatusCode::BAD_REQUEST);
    let res = app
        .oneshot(get("/api/v1/graph/emacs?dir=sideways"))
        .await
        .expect("call");
    assert_eq!(res.status(), StatusCode::BAD_REQUEST);
}

#[tokio::test]
async fn host_allowlist_rejects_foreign_hosts() {
    let req = Request::get("/api/v1/health")
        .header("host", "evil.example.com")
        .extension(ConnectInfo(SocketAddr::from(([127, 0, 0, 1], 50000))))
        .body(Body::empty())
        .expect("request builds");
    let res = router(state()).oneshot(req).await.expect("call");
    assert_eq!(res.status(), StatusCode::FORBIDDEN);
}

#[tokio::test]
async fn static_assets_and_traversal() {
    let app = router(state());

    let res = app.clone().oneshot(get("/")).await.expect("call");
    assert_eq!(res.status(), StatusCode::OK);
    let csp = res.headers().get("content-security-policy").expect("csp");
    assert!(csp.to_str().unwrap().contains("default-src 'self'"));

    let res = app.clone().oneshot(get("/app.js")).await.expect("call");
    assert_eq!(res.status(), StatusCode::OK);
    assert!(res
        .headers()
        .get("content-type")
        .unwrap()
        .to_str()
        .unwrap()
        .starts_with("text/javascript"));

    // Traversal and unknown paths are plain 404s (no filesystem access).
    for path in [
        "/../Cargo.toml",
        "/%2e%2e/Cargo.toml",
        "/etc/passwd",
        "/api/v1/nope",
    ] {
        let res = app.clone().oneshot(get(path)).await.expect("call");
        assert_eq!(res.status(), StatusCode::NOT_FOUND, "{path}");
    }
}

#[tokio::test]
async fn live_bind_loopback_and_fetch() {
    // Real socket smoke: bind an ephemeral port, fetch health over TCP.
    use tokio::io::{AsyncReadExt, AsyncWriteExt};

    let state = state();
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let addr = listener.local_addr().unwrap();
    let server = axum::serve(
        listener,
        router(state).into_make_service_with_connect_info::<SocketAddr>(),
    );
    let (tx, rx) = tokio::sync::oneshot::channel::<()>();
    let handle = tokio::spawn(async move {
        server
            .with_graceful_shutdown(async move {
                let _ = rx.await;
            })
            .await
            .unwrap();
    });

    let mut stream = tokio::net::TcpStream::connect(addr).await.unwrap();
    let request = "GET /api/v1/health HTTP/1.1\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n";
    stream.write_all(request.as_bytes()).await.unwrap();
    let mut response = String::new();
    stream.read_to_string(&mut response).await.unwrap();
    assert!(response.starts_with("HTTP/1.1 200 OK"), "got: {response}");
    assert!(response.contains("\"generation\":1"));

    let _ = tx.send(());
    handle.await.unwrap();
}

#[tokio::test]
async fn responses_carry_hardening_headers() {
    let res = router(state())
        .oneshot(get("/api/v1/health"))
        .await
        .expect("call");
    let headers = res.headers();
    assert_eq!(headers.get("x-content-type-options").unwrap(), "nosniff");
    assert_eq!(headers.get("x-frame-options").unwrap(), "DENY");
    assert_eq!(headers.get("referrer-policy").unwrap(), "no-referrer");
    assert_eq!(
        headers.get("cross-origin-resource-policy").unwrap(),
        "same-origin"
    );
    assert_eq!(headers.get("cache-control").unwrap(), "no-store");
}

#[tokio::test]
async fn cross_site_requests_are_refused() {
    // A browser on another origin sends Origin/Sec-Fetch-Site; loopback alone
    // is not proof that the caller is friendly.
    let res = router(state())
        .oneshot(
            Request::get("/api/v1/health")
                .header("host", "127.0.0.1:8787")
                .header("origin", "http://evil.example")
                .header("sec-fetch-site", "cross-site")
                .extension(ConnectInfo(SocketAddr::from(([127, 0, 0, 1], 50000))))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .expect("call");
    assert_eq!(res.status(), StatusCode::FORBIDDEN);

    // Our own origin still works.
    let res = router(state())
        .oneshot(
            Request::get("/api/v1/health")
                .header("host", "127.0.0.1:8787")
                .header("origin", "http://127.0.0.1:8787")
                .header("sec-fetch-site", "same-origin")
                .extension(ConnectInfo(SocketAddr::from(([127, 0, 0, 1], 50000))))
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .expect("call");
    assert_eq!(res.status(), StatusCode::OK);
}

#[tokio::test]
async fn malformed_and_other_local_origins_are_refused() {
    let app = router(state());
    for origin in [
        "127.0.0.1:8787",
        "http://127.0.0.1:9000",
        "https://127.0.0.1:8787",
        "http://localhost:8787",
        "http://127.0.0.1:8787/",
        "http://127.0.0.1:8787@evil.example",
        "http://[::1]junk",
        "null",
    ] {
        let mut req = get("/api/v1/health");
        req.headers_mut().insert("origin", origin.parse().unwrap());
        let res = app.clone().oneshot(req).await.unwrap();
        assert_eq!(res.status(), StatusCode::FORBIDDEN, "origin {origin:?}");
        assert_eq!(res.headers()["x-content-type-options"], "nosniff");
    }
    let mut req = get("/api/v1/health");
    req.headers_mut().insert(
        "origin",
        axum::http::HeaderValue::from_bytes(&[0xff]).unwrap(),
    );
    assert_eq!(
        app.oneshot(req).await.unwrap().status(),
        StatusCode::FORBIDDEN
    );
}

#[tokio::test]
async fn host_authority_must_be_complete_and_unambiguous() {
    let app = router(state());
    for host in [
        "127.0.0.1:",
        "127.0.0.1:bad",
        "127.0.0.1:65536",
        "127.0.0.1:80@evil.example",
        "[::1]junk",
        "[::1",
        "[::1]:80/path",
    ] {
        let mut req = get("/api/v1/health");
        req.headers_mut().insert("host", host.parse().unwrap());
        let res = app.clone().oneshot(req).await.unwrap();
        assert_eq!(res.status(), StatusCode::FORBIDDEN, "host {host:?}");
    }
    for host in ["localhost:8787", "LOCALHOST", "[::1]:8787", "127.0.0.1"] {
        let mut req = get("/api/v1/health");
        req.headers_mut().insert("host", host.parse().unwrap());
        assert_eq!(
            app.clone().oneshot(req).await.unwrap().status(),
            StatusCode::OK,
            "{host}"
        );
    }
    for header in ["host", "origin", "sec-fetch-site"] {
        let mut req = get("/api/v1/health");
        let value = match header {
            "host" => "127.0.0.1:8787",
            "origin" => "http://127.0.0.1:8787",
            _ => "same-origin",
        };
        req.headers_mut().insert(header, value.parse().unwrap());
        req.headers_mut().append(header, value.parse().unwrap());
        assert_eq!(
            app.clone().oneshot(req).await.unwrap().status(),
            StatusCode::FORBIDDEN,
            "duplicate {header}"
        );
    }
}

#[tokio::test]
async fn exotic_package_names_are_rejected() {
    for name in ["has%20space", "dot.dot", "a".repeat(200).as_str()] {
        let res = router(state())
            .oneshot(get(&format!("/api/v1/package/{name}")))
            .await
            .expect("call");
        assert!(
            res.status() == StatusCode::BAD_REQUEST || res.status() == StatusCode::NOT_FOUND,
            "{name} produced {}",
            res.status()
        );
    }
    // A normal name still resolves (and gtk+ keeps its plus sign).
    for name in ["emacs", "gtk%2B", "pkg-config"] {
        let res = router(state())
            .oneshot(get(&format!("/api/v1/package/{name}")))
            .await
            .expect("call");
        assert_eq!(res.status(), StatusCode::OK, "{name} was refused");
    }
}

#[tokio::test]
async fn static_assets_carry_the_policy_too() {
    // The CSP used to be added only by the HTML handler; it belongs on every
    // response, because scripts and styles are exactly what it constrains.
    for path in ["/", "/app.js", "/graph.js", "/style.css"] {
        let res = router(state()).oneshot(get(path)).await.expect("call");
        assert_eq!(res.status(), StatusCode::OK, "{path}");
        let csp = res
            .headers()
            .get("content-security-policy")
            .unwrap_or_else(|| panic!("{path} has no CSP"));
        assert!(
            csp.to_str().unwrap().contains("default-src 'self'"),
            "{path}"
        );
    }
}

#[tokio::test]
async fn compression_respects_encoding_tokens_and_quality() {
    let mut index = load_fixture();
    index.packages[0].description = std::sync::Arc::from("x".repeat(2048));
    let app = router(AppState::with_index(index));
    for (encoding, compressed) in [
        ("gzip", true),
        ("GZIP;Q=1.000", true),
        ("gzip;q=0.001", true),
        ("br, *;q=0.5", true),
        ("gzip;q=0", false),
        ("gzip;q=0.000", false),
        ("gzipgarbage", false),
        ("gzip;q=invalid", false),
        ("gzip;q=1.1", false),
        ("gzip;q=0.0001", false),
        ("gzip;q=1;q=0", false),
        ("gzip;q=0, *;q=1", false),
        ("*;q=1, gzip;q=0", false),
        ("*;q=0", false),
    ] {
        let mut req = get("/api/v1/package/emacs");
        req.headers_mut()
            .insert("accept-encoding", encoding.parse().unwrap());
        let res = app.clone().oneshot(req).await.unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        assert_eq!(
            res.headers().contains_key("content-encoding"),
            compressed,
            "{encoding}"
        );
        let body = res.into_body().collect().await.unwrap().to_bytes();
        let json = if compressed {
            let mut decoder = flate2::read::GzDecoder::new(body.as_ref());
            let mut plain = String::new();
            std::io::Read::read_to_string(&mut decoder, &mut plain).unwrap();
            serde_json::from_str::<serde_json::Value>(&plain).unwrap()
        } else {
            serde_json::from_slice::<serde_json::Value>(&body).unwrap()
        };
        assert_eq!(json["description"].as_str().unwrap().len(), 2048);
    }
}

#[tokio::test]
async fn oversized_compression_response_is_an_explicit_error() {
    let mut index = load_fixture();
    index.packages[0].description = std::sync::Arc::from("x".repeat(8 * 1024 * 1024));
    let mut req = get("/api/v1/package/emacs");
    req.headers_mut()
        .insert("accept-encoding", "gzip".parse().unwrap());
    let res = router(AppState::with_index(index))
        .oneshot(req)
        .await
        .unwrap();
    assert_eq!(res.status(), StatusCode::INTERNAL_SERVER_ERROR);
    assert_eq!(res.headers()["x-content-type-options"], "nosniff");
    assert_eq!(res.headers()["cache-control"], "no-store");
    assert!(!res.headers().contains_key("content-encoding"));
    let content_length = res
        .headers()
        .get("content-length")
        .map(|h| h.to_str().unwrap().parse::<usize>().unwrap());
    let body = res.into_body().collect().await.unwrap().to_bytes();
    if let Some(length) = content_length {
        assert_eq!(length, body.len());
    }
    let json: serde_json::Value = serde_json::from_slice(&body).unwrap();
    assert!(json["error"].is_string());
}
