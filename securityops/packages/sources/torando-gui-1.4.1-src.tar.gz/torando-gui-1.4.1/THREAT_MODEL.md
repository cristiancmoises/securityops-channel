# Threat model

Torando-Gui is the GUI for [Torando](https://github.com/cristiancmoises/torando).
Its own privileged daemon manages routing, firewall, DNS and proxy settings.
This document describes what those controls check and where they stop.

## Intended protection

Torando-Gui aims to reduce accidental direct connections by routing supported
traffic through Tor and blocking other traffic within the selected account's
firewall scope. That depends on the operating system, existing rules, settings
and applications. A connected status is not a guarantee of anonymity.

| Platform | Controls installed | Boundaries |
|---|---|---|
| Linux | Per-UID TCP and UDP/53 redirects, IPv4 drop rules, default IPv6 drop rules | Other users and privileged traffic are outside the selected UID; existing rules and local services need review |
| macOS | Per-UID `pf` rules, system SOCKS proxy, per-service DNS settings | Apps must use SOCKS; UID rules cover TCP/UDP, not ICMP |
| FreeBSD / OpenBSD | Per-UID `pf` rules and resolver pinning | Apps need SOCKS or `torsocks`; no system proxy is configured |
| Windows | Machine-wide outbound-default changes, Tor/loopback allow rules, current account's WinINET proxy and IPv4 DNS settings | Existing allow rules remain; app proxy support and firewall profile state need review |

On Linux, IPv6 is blocked rather than transparently redirected. If the kernel
supports IPv6 and `ip6tables` is missing, connection is refused while
`ipv6_killswitch` is enabled. Disabling that option leaves IPv6 outside these
rules. On macOS/BSD, the IPv6 option controls TCP/UDP rules; it does not add
ICMP coverage. Windows status checks configured policy defaults and the proxy,
not every effective rule or application path.

Loopback remains available for the GUI, Tor and local services. A local service
running as another account can make outbound connections on an application's
behalf, outside a per-UID ruleset. Windows also allows DHCP by default and can
allow the local subnet through `allow_lan`.

## Trust assumptions

- The kernel, firewall tools, Python runtime and Tor process are trusted.
- Root/Administrator is trusted. The daemon has enough privilege to change
  networking and system configuration.
- The host's other local users are trusted with access to the loopback UI.
- Torando and Torando-Gui are used one at a time. They have separate state and
  should not compete over the same firewall and resolver settings.
- Existing firewall rules are understood and tested with the new rules active.

## Firewall and recovery limits

Linux rules are checked before insertion, and failed application attempts a
rollback. Rule updates are separate system commands, not one atomic firewall
transaction. A command failure can also prevent rollback or removal. Check the
reported error and the live rules before assuming the previous state is back.

On macOS/BSD, the daemon validates its `pf.conf` marker block and checks whether
`pf` is enabled and the main ruleset references its anchor. An earlier matching
`pass ... quick` rule can bypass that anchor. The status check does not evaluate
all interactions in the host ruleset. Place the anchor before conflicting quick
rules and test with an application that does not use the proxy.

On Windows, the daemon captures the prior profile policy and proxy settings,
adds named allow rules, then changes outbound defaults. It does not remove
existing application allow rules or verify every effective policy. Confirm the
firewall is enabled for the active profile and inspect existing rules. These
backends remain beta and need validation on the target host.

DNS pinning changes `resolv.conf` on Linux/BSD, network-service settings on
macOS and interface settings on Windows. Saved state supports restoration on
disconnect. Startup recovery attempts to undo an orphaned DNS pin when no
killswitch is detected. Missing backups, changed configuration, command failures
or external network managers can prevent restoration. `--restore-dns` repairs
DNS only; `--disconnect` requests firewall, proxy and DNS teardown. See
[recovery instructions](docs/USAGE.md#recovery).

## What status and exit checks mean

The status endpoint inspects firewall state, Tor's control port and resolver
configuration. A resolver set to `127.0.0.1` with a detected killswitch is
reported as using Tor; this is a configuration check, not an independent DNS
leak test.

The exit check connects to `https://check.torproject.org/api/ip` through Tor's
SOCKS port. It trusts that service and the HTTPS certificate chain for the
verdict. A successful HTTP response must contain a JSON boolean `IsTor` and a
valid IP address. Invalid, incomplete or oversized responses and network errors
leave the result unknown. A custom `check_url` changes who supplies the verdict;
plain HTTP lacks the default endpoint's transport authentication.

A positive result verifies that SOCKS connection's exit. It does not verify the
route taken by every app or rule out other outbound paths. An unknown result
means verification failed; it is not evidence by itself of either a Tor exit or
a direct connection. The UI distinguishes unverified and verified exit status.

## Local control surface

The daemon binds to `127.0.0.1` in live mode and serves the UI there. API requests
require a per-session token. POSTs also check the Origin/Referer, the Host header
is allowlisted, and the server sets a Content Security Policy without CORS
headers. These controls reduce attacks from unrelated websites; they do not
isolate mutually untrusted users on one host.

The token file is written with mode 0600 on POSIX, but the local UI supplies its
session token to anyone who can read the served page. A local user who can reach
that page can control the daemon. Do not expose the server through a forwarding
proxy or treat the token as a multi-user authorization boundary.

Target users are resolved to numeric UIDs on supported POSIX systems. Firewall
commands use argument lists rather than interpolated shell commands. This
reduces command-injection exposure but does not reduce the daemon's privileges.

## Outside this protection

**Application identity.** Torando-Gui does not normalize browser fingerprints,
fonts, language, WebRTC behavior or application identifiers. Named logins still
identify you. Tor Browser provides a different application-level privacy model.

**Compromised hosts.** Root or a compromised kernel can remove the firewall,
read traffic before encryption or replace the daemon.

**Tor's network limits.** Traffic correlation, hostile exits and global passive
observation are outside this routing tool. Use end-to-end encryption: ordinary
HTTP traffic to a non-onion destination can be read after it leaves Tor.

**Unsupported traffic.** Tor does not carry arbitrary UDP traffic. Linux drops
UDP other than redirected DNS, including QUIC, under the installed rules.
Applications using DoH or DoT do not use the resolver pin; their connections
follow the applicable TCP/UDP routing rules. Platform exceptions above still
apply.

## Checking on your host

Inspect the rules, DNS settings and proxy configuration using the commands in
[the usage guide](docs/USAGE.md#verifying). Then, from a local session, stop Tor
while connected and test the selected account's traffic with and without app
proxy settings. Check both IPv4 and IPv6 where available. Traffic within the
expected blocked scope should fail. Restart Tor or disconnect afterward.

Unit tests exercise command construction, parsing and recovery with fake system
runners. They do not establish that a particular host configuration prevents
all direct traffic.
