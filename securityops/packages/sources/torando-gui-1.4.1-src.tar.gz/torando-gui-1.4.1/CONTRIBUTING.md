# Contributing

Torando-Gui is the GUI for [Torando](https://github.com/cristiancmoises/torando),
with a separate Python daemon that uses only the standard library. Before
changing the firewall, DNS or control-surface code, read
[THREAT_MODEL.md](THREAT_MODEL.md).

## Where to send changes

The repo is mirrored on four hosts; use whichever you prefer:

- Forgejo (official): <https://git.securityops.co/cristiancmoises/torando-gui>
- SecurityOps Brazil: <https://git.securityops.com.br/cristiancmoises/torando-gui>
- GitHub: <https://github.com/cristiancmoises/torando-gui>
- Codeberg: <https://codeberg.org/berkeley/torando-gui>

Don't open a public issue for a security bug; see [SECURITY.md](SECURITY.md).

## Setup

The daemon has no third-party Python runtime dependencies. Install Node.js 22+
for frontend tests, then set up the Python development tools:

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install ruff pytest
```

Run the UI with no privileges and no Tor:

```sh
make mock            # backend/ python3 -m torando_gui --mock --open
```

## Tests and lint

`make test` is what CI runs:

```sh
make lint            # ruff check .
make fmt             # ruff format .
make test            # ruff, pytest and Node frontend tests
```

Keep the code stdlib-only. Add or update tests under `tests/` for any behaviour
change. Match the existing style: argv-only subprocess calls (never a shell
string), atomic and durable writes for system files, and explicit failure states.
Describe what a check verifies; an unknown exit result must stay unverified.

The firewall/DNS backends are split by platform: `engine.py` (Linux
iptables/ip6tables), `pf.py` (macOS/BSD), `winfw.py` (Windows) and `dns.py`
(per-OS DNS pinning), selected by `platform.py` and composed in `firewall.py`.
All of them build their commands as pure, side-effect-free functions that take a
`runner` seam, so the whole cross-platform surface is unit-tested on Linux with
fake runners — add tests the same way rather than gating them on the host OS.
Guard POSIX-only imports (`pwd`) so the daemon still imports on Windows.

## Commits

Write focused commits and sign them off to certify the
[DCO](https://developercertificate.org/):

```sh
git commit -s -m "engine: ..."
```

## Packaging

Build scripts live in `packaging/`, driven by the `Makefile`:

- Linux: `make deb rpm tarball appimage` (needs `dpkg-deb`/`rpmbuild`/`zstd`/
  `appimagetool`), plus `packaging/guix.scm` and the securityops channel.
- Cross-platform: `make windows macos freebsd openbsd` stage each platform's
  bundle into `dist/` on Linux. `macos`/`freebsd`/`openbsd` are pure-Python
  payloads (need `zip`/`tar`). `windows` is **all-in-one**: it downloads the
  pinned embeddable Python and Tor Expert Bundle (needs `curl` + network) and
  bundles them, so bump `TORANDO_PYVER`/`TORANDO_TORVER` in `build-windows.sh`
  deliberately — Tor especially, for its security updates.

If you change the installed file layout, update **every** definition (deb, rpm,
PKGBUILD, guix.scm, the securityops channel, AppRun, tarball, and the
`packaging/{windows,macos,freebsd,openbsd}` install scripts) so they stay in
sync. Version strings live in `pyproject.toml`, `backend/torando_gui/__init__.py`,
the spec/PKGBUILD/guix.scm, the macOS `Info.plist`, and
the Homebrew formula template. The formula needs a real archive checksum before
it can be published.
The shared build helper reads its version from `pyproject.toml`.

## Releases

Every new version must have a tag and a release on all four hosts listed above.
Each Torando-Gui release must include the Debian package, RPM, portable Linux
archive, x86-64 AppImage, Windows all-in-one zip, macOS zip, FreeBSD and OpenBSD
archives, Python wheel, complete source archive and `SHA256SUMS`. Publish the
same files to every mirror. A version is not finished until all four releases
and their downloads have been verified.

1. Update the version metadata, existing README and changelog. Run `make test`
   and commit the final source. Keep planning notes and prompts private; don't
   add Markdown files just to describe the work.
2. Install the packaging tools: `dpkg-deb`, `rpmbuild`, `zstd`, `zip`, `curl`,
   `tar`, `unsquashfs`, `sha256sum`, Pillow and Python's `build` package. Offline
   builders can set `APPIMAGETOOL` and `APPIMAGE_RUNTIME` to local files; the
   default tool and runtime downloads are pinned and checked.
   `png2icns` adds the macOS application icon.
3. Run `make release`. It starts from a clean committed checkout, builds all ten
   downloads in a temporary directory and verifies their versions and contents
   before producing `dist/vX.Y.Z/SHA256SUMS`. It fails if any required format
   fails, and refuses to reuse an existing release directory. Use
   `make verify-release` to check a finished set again.
4. Create an annotated `vX.Y.Z` tag for that commit and push the branch and tag
   to all four remotes. The GitHub tag workflow runs the tests and full build,
   synchronizes the branch and tag to the mirrors, then publishes and verifies
   the four releases. A manual workflow run must select the matching version tag.

The workflow needs repository secrets `CODEBERG_TOKEN`, `SECURITYOPS_CO_TOKEN`
and `SECURITYOPS_BR_TOKEN`, each with release-write access to its mirror. GitHub
uses the workflow's `GITHUB_TOKEN`. Never commit credentials or put them in Git
remote URLs. Missing credentials fail the workflow before building.

For a local publication of the verified directory, provide those variables and
`GITHUB_TOKEN` in the environment, then run:

```sh
python3 packaging/publish-release.py --project torando-gui \
  --version 1.4.1 --commit "$(git rev-parse HEAD)" --sync-refs --artifacts dist/v1.4.1
```

The publisher checks the tag commit, asset list and checksums on every host.
If publication is interrupted, reuse the original verified directory or download
it from the workflow's retained artifacts. Rebuilding the same version can
change archive timestamps and checksums. Published assets are not overwritten.
For a local publication, temporarily disable the Release workflow while pushing
the tag, then enable it again after all four releases are verified; this avoids
two publishers uploading different builds of the same version.
Build artifacts belong in release downloads, not in the source branch.

## License

By contributing you agree your work is licensed under AGPL-3.0-only. New files
need the SPDX header:

```
# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (c) <year> <you>
```
