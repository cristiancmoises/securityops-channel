# Security policy

Torando-Gui is the GUI for [Torando](https://github.com/cristiancmoises/torando).
Its daemon manages privileged firewall, DNS and proxy settings; bugs in those
paths can affect network access and privacy.

## Reporting

Don't open a public issue for a security bug. Email it privately to
**cristian@securityops.co**.

Include the version (`torando-guid --version`), your OS and packaging format
(deb/rpm/Arch/Guix/AppImage, macOS `.app`/Homebrew, the FreeBSD/OpenBSD tarball,
or the Windows zip), what you found, and a way to reproduce it. If you want
encryption, say so in a first plaintext mail and we'll exchange a key.

You'll get an acknowledgement within a few days. Once there's a fix it ships
across the official repo and mirrors (Forgejo, GitHub, Codeberg) with an
advisory, and you get credit unless you'd rather not.

## In scope

- Bypasses of the killswitch or DNS pinning that let the torified traffic leave
  in the clear (IPv4 **or** IPv6) in a setup the tool claims to protect, on any
  supported platform.
- A firewall/DNS/proxy teardown that fails to restore the prior state — e.g. a
  disconnect that leaves the host without DNS, or (on Windows) blocking outbound
  with the Tor allow-rule already deleted.
- Auth, CSRF or Host-header bypasses of the loopback control surface.
- Command injection, path traversal, or privilege issues in the daemon
  (including the `pf.conf`/`netsh`/`networksetup` command construction).
- Crashes or unsafe state from malformed input (a crafted GeoIP DB, `torrc`, or
  control-port reply).

## Out of scope

These are documented design boundaries, not bugs (see
[THREAT_MODEL.md](THREAT_MODEL.md)):

- Apps without SOCKS support on macOS/BSD/Windows are not transparently routed.
  Loss of connectivity for those apps is expected within the firewall
  rules' scope; direct egress beyond the documented exceptions remains in scope.
- ICMP/ICMPv6 for the torified user on macOS/BSD (pf's `user` token only tags
  TCP/UDP).
- Fingerprinting and anonymity-set properties; this isn't Tor Browser.
- A compromised root/Administrator or kernel, other local users on a shared
  host, and Tor's own threat model (global passive adversary, traffic
  correlation, hostile exits).

## Supported versions

The latest released minor version gets security fixes. Older versions don't.
