# Usage

**Torando-Gui is the GUI for [Torando](https://github.com/cristiancmoises/torando).**
It has its own routing daemon and does not need Torando's shell scripts installed.
Disconnect Torando before connecting with the GUI, and disconnect the GUI before
switching back. Both manage firewall and DNS state.

There are two programs:

- `torando-guid`, the root/Administrator daemon. It programs the firewall
  (iptables/ip6tables, `pf`, or Windows Firewall), manages DNS, talks to Tor's
  control port, and serves the UI on `127.0.0.1:8088`.
- `torando-gui`, the front end. On Linux it opens a GTK4/WebKitGTK desktop
  window; without that stack (and by default elsewhere) it falls back to your
  browser. It has no privileges and only talks to the daemon over loopback.

Read [THREAT_MODEL.md](../THREAT_MODEL.md) first. This is not Tor Browser: it
routes packets, it does not anonymize application fingerprints.

## Downloads and upgrades

Use the [release links in the README](../README.md#install) to get the package
for your system. Every version ships the complete build set and `SHA256SUMS`
on all four mirrors. Windows includes Python and Tor; macOS and BSD use your
system installations. The Linux AppImage also needs system Python and Tor.

Disconnect before upgrading. Install the new package or extract the new bundle
into a fresh directory and run its installer. macOS and BSD replace application
files while keeping your configuration. On Windows, run the installer elevated
as the same desktop account you used before. Reopen the GUI and check the
installed version with `torando-guid --version` (or `torando-guid.cmd --version`
on Windows).

## Quick start

1. Start the daemon (once, as root via your init system):
   - systemd: `sudo systemctl enable --now torando-gui.service`
   - Guix System: it's started by `torando-gui-service-type`
     (`sudo herd start torando-gui` if needed)
2. Run `torando-gui` to open the app.
3. Pick the user whose traffic should go through Tor. On Windows, select the
   displayed account; the firewall policy still applies to the whole machine.
4. Press **Connect to Tor** and wait for Tor to bootstrap. Check the status details for
   the firewall, DNS and exit-check results.
5. New Tor identity requests a fresh circuit through the control port. It does
   not guarantee a different exit IP.
6. Press Disconnect to remove the session rules and restore saved DNS/proxy
   settings. Closing the window does not disconnect.

The API uses a session token the daemon injects into the page;
you never copy or paste it.

## Recovery

If the interface is available, use Disconnect first. It restores saved DNS and
asks the firewall backend to remove its rules and restore proxy settings.
If the daemon cannot serve the interface, run a one-shot teardown with the same
configuration file used by the service:

```sh
sudo torando-guid --disconnect          # Linux/macOS/BSD
```

```powershell
torando-guid --disconnect               # Windows, elevated as your desktop account
```

For a DNS-only repair, use `--restore-dns` instead. That command does **not**
remove firewall rules or restore the system proxy. On Windows the installed
command is under `%ProgramFiles%\torando-gui\torando-guid.cmd` if it is not
on `PATH`.

The daemon saves prior settings and attempts rollback after a failed connect.
At startup it also checks for a DNS pin left behind without an active
killswitch. These recovery paths can fail if system commands fail, backups are
missing or the configuration has changed. Read the error output and keep the
saved state until recovery succeeds. A stopped daemon may leave active firewall
rules in place; restart it or use the teardown command before uninstalling.

Per-platform last resort, if `--restore-dns` can't run:

- **Linux / BSD** — clear the lock and put back the backup:
  ```sh
  sudo chattr -i /etc/resolv.conf                          # Linux
  sudo chflags noschg /etc/resolv.conf                     # BSD
  sudo cp /etc/resolv.conf.torando.bak /etc/resolv.conf    # if present
  ```
  Check that the backup contains your expected resolver settings before copying
  it, then restore readable permissions with `sudo chmod 0644 /etc/resolv.conf`.
- **macOS** — DNS is set per service, not in `resolv.conf`:
  ```sh
  networksetup -listallnetworkservices
  sudo networksetup -setdnsservers "Wi-Fi" Empty           # back to DHCP
  ```
- **Windows** — if your normal configuration uses DHCP and allows outbound
  traffic, these commands restore those defaults:
  ```powershell
  netsh interface ipv4 set dnsservers name="Wi-Fi" source=dhcp
  netsh advfirewall set allprofiles firewallpolicy blockinbound,allowoutbound
  ```
  These defaults may differ from your saved policy and do not restore the
  WinINET proxy. Prefer `--disconnect`; the bundled `uninstall.ps1` also
  requests full teardown.

## CLI

```
torando-guid [--host H] [--port P] [--config FILE]
             [--mock] [--open] [--no-token-file] [--restore-dns] [--disconnect]
             [--version]
```

| Flag | Meaning |
|---|---|
| `--host` | Bind address; must be `127.0.0.1` unless `--mock`. |
| `--port` | Bind port (default 8088). |
| `--config` | Path to `config.json`; platform defaults are listed below. |
| `--mock` | Preview with simulated state; no root, Tor or real routing. |
| `--open` | Open the UI in a browser on start. |
| `--no-token-file` | Skip writing the session token to the runtime directory. |
| `--restore-dns` | Restore saved DNS settings and exit; leave firewall/proxy settings in place. |
| `--disconnect` | Request firewall, proxy and DNS teardown, then exit. |
| `--version` | Print the installed version and exit. |

`torando-gui [--browser]` is the front end; `--browser` forces the browser path.

Preview the UI with no privileges:

```sh
torando-guid --mock --open
```

## Configuration

The configuration file is `/etc/torando-gui/config.json` on Linux, macOS and
OpenBSD, `/usr/local/etc/torando-gui/config.json` on FreeBSD, and
`%ProgramData%\torando-gui\config.json` on Windows. `--config` selects another
file. Edit common settings in the app, or stop the daemon before editing the
file by hand. Some options are available only in that file:

| Key | Default | Notes |
|---|---|---|
| `host` / `port` | `127.0.0.1` / `8088` | Control surface, loopback only. |
| `trans_port` | `9040` | Tor TransPort (Linux transparent redirect). Must match your Tor. |
| `dns_port` | `53` | Tor DNSPort. Set to match your Tor (often `5353`). |
| `socks_port` | `9050` | Tor SocksPort (exit verification; the system proxy on macOS/Windows). |
| `control_port` | `9051` | Tor ControlPort (bootstrap/NEWNYM, cookie auth). |
| `target_uid` | `null` | UID to route. Set in the app; it does not narrow Windows firewall scope. |
| `manage_torrc` | `true` | Write a managed block into `torrc`. Turn off where Tor is configured elsewhere (Guix, Homebrew, the Expert Bundle). |
| `lock_resolv` | `true` | Pin DNS; Linux/BSD also attempt an immutable-file lock. |
| `ipv6_killswitch` | `true` | Block the UID's IPv6 egress (Linux ip6tables / pf `inet6`). Leave on unless you have no IPv6. |
| `check_url` | `https://check.torproject.org/api/ip` | Exit-check endpoint, reached through SOCKS; keep HTTPS for authenticated replies. |
| `exit_country` | `null` | ISO code (e.g. `de`) to pin the exit country. |
| `use_bridges` / `bridges` | `false` / `[]` | Optional bridge lines. |
| `tor_user` | `null` | Account Tor runs as, for the pf exemption (defaults to `_tor` on macOS/BSD). |
| `tor_path` | `null` | Path to `tor.exe` the Windows firewall whitelists (required on Windows). |
| `pf_anchor` | `torando-gui` | Name of the pf anchor the daemon owns (macOS/BSD). |
| `allow_lan` / `allow_dhcp` | `false` / `true` | Windows: also permit the local subnet / DHCP under the killswitch. |

`target_uid`, `trans_port` and `dns_port` define the live rules, so the app
refuses to change them while connected. Disconnect first.

Torando-Gui connects to a separate Tor service, which must listen on the ports
above. With `manage_torrc=true`, the daemon writes a managed block and requests
a service reload. Otherwise configure and start Tor yourself. On Linux, a
common mismatch is a system Tor with `DNSPort 5353` while `dns_port` is `53`;
set `dns_port` to `5353` to match (the Guix service seeds this for you).
On macOS/BSD/Windows there is no Linux DNS redirect: a resolver pinned to
`127.0.0.1` needs a DNS listener on port 53.

## Verifying

The exit check queries `check.torproject.org/api/ip` through Tor's SOCKS port.
A result requires a successful HTTP response containing a JSON boolean `IsTor`
and a valid IP address. HTTP errors, malformed or incomplete responses,
oversized payloads and connection failures leave the result unknown. Chunked
HTTP responses are supported.

The app shows **Tor exit verified** for a valid positive verdict and
**Exit not verified** when it has no valid verdict for the current connection.
A negative verdict or a DNS configuration check failure shows **Connection
needs attention**. Exit checks refresh once per minute; changing the connection
or configuration invalidates the previous result.

This verifies the SOCKS connection used by the check. It does not prove that a
browser or another app uses the same route, or that the host has no other
outbound path. The DNS status checks local configuration and firewall state;
it is not a separate DNS leak test. Inspect the rules as well:

**Linux**

```sh
iptables  -t nat -S OUTPUT     # REDIRECT + loopback RETURN
iptables  -S OUTPUT            # the ACCEPTs and the final DROP
ip6tables -S OUTPUT            # the IPv6 killswitch (loopback ACCEPT + DROP)
cat /etc/resolv.conf           # nameserver 127.0.0.1 while connected
lsattr /etc/resolv.conf        # the immutable bit while connected
```

**macOS / FreeBSD / OpenBSD**

```sh
pfctl -s info                          # Status: Enabled
pfctl -a torando-gui -sr                # the loopback pass + block-out rules
pfctl -s rules | grep torando-gui       # confirms the anchor is REFERENCED
scutil --dns | grep nameserver          # 127.0.0.1 (macOS)
networksetup -getsocksfirewallproxy Wi-Fi   # macOS: Enabled Yes, 127.0.0.1 9050
```

**Windows** (elevated)

```powershell
netsh advfirewall show allprofiles | findstr "Policy"   # ...,BlockOutbound
netsh advfirewall firewall show rule name=TorandoGUI-Tor-Out
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" /v ProxyServer
netsh interface ipv4 show dnsservers                     # 127.0.0.1 while pinned
```

To test the killswitch, stop Tor while connected and try traffic from the
selected account, including an app with no proxy configured. Check IPv4 and
IPv6 paths supported by the host. Expected traffic should fail until Tor is
restarted or you disconnect. Do this in a local session where you can recover
network access; the firewall can interrupt remote administration.

## Platform notes

Linux redirects the selected user's TCP and UDP DNS traffic. macOS and Windows
set a system SOCKS proxy; whether an application uses it depends on the app.
BSD apps need their own SOCKS settings or `torsocks`. Firewall coverage and
existing host rules differ across systems; see the [threat model](../THREAT_MODEL.md).

### Linux

- Debian/Ubuntu, Fedora/RHEL, Arch: the systemd unit plus polkit rule let an
  active local session start and stop the service without a password.
- The IPv6 killswitch needs `ip6tables`. If the kernel has IPv6 but `ip6tables`
  is missing, connect refuses. Install it before connecting. Turning off
  `ipv6_killswitch` leaves IPv6 outside these rules.
- Guix System: use the Shepherd service. Tor's `/etc/tor/torrc` is a read-only
  store symlink owned by `tor-service-type`, so `manage_torrc` is seeded off and
  `dns_port` to 5353. Manage Tor with `herd`, not the GUI's start/stop.
- Native window: needs GTK4, WebKitGTK and PyGObject. Without them you still get
  the full UI in a browser.

### macOS

- Install Tor with Homebrew (`brew install tor && brew services start tor`). The
  macOS bundle seeds `manage_torrc=false`; configure `SocksPort 9050` and a
  local DNS listener on port 53 in Tor's configuration before connecting.
- Connect sets the **system SOCKS proxy** (`networksetup -setsocksfirewallproxy`)
  on every active network service and loads a per-UID `pf` killswitch anchor,
  hooked into `/etc/pf.conf` via a validated marker block. DNS is pinned with
  `networksetup -setdnsservers "Wi-Fi" 127.0.0.1`, using each service's name.
  Disconnect restores the captured proxy/DNS settings.
- The `.app` is unsigned; first launch needs Right-click → Open, or
  `xattr -dr com.apple.quarantine "/Applications/Torando Control.app"`.
- pf's `user` match only tags TCP/UDP, so ICMP for the user is not blocked — a
  documented limitation.

### FreeBSD / OpenBSD

- Install the `tor` package; it runs as `_tor`. Enable pf
  (`sysrc pf_enable=YES && service pf start` on FreeBSD).
- Connect loads a per-UID `pf` killswitch anchor and pins DNS in
  `/etc/resolv.conf` with `chflags schg`. Route apps through Tor with `torsocks`
  or per-app SOCKS at `127.0.0.1:9050` (there is no system-wide SOCKS setting on
  the BSDs).
- The rc.d service is `torando-gui` (FreeBSD) / `torando_gui` (OpenBSD).

### Windows

- The firewall policy is **machine-wide**. Selecting the displayed account
  in the app does not limit that policy to one user.
  Connect captures the current profile policy, then changes each outbound
  default to block. It allows `tor.exe` (from `tor_path`) and loopback, points
  the WinINET proxy at Tor, and pins interface DNS with `netsh`. Disconnect
  attempts to restore saved settings and delete its named allow rules. It does
  not clear other applications' firewall rules or audit their effect. DHCP is
  allowed by default; `allow_lan` permits local-subnet access when enabled.
- **All-in-one:** the `-windows.zip` bundles its own embedded Python and Tor, so
  there is nothing to install first. `install.ps1` copies the bundle to
  `Program Files`, writes a `torrc` (no `TransPort` — Windows has no transparent
  proxy), and registers two Scheduled Tasks:
  - **`TorandoGUI-Tor`** — the bundled Tor, as **SYSTEM at boot** (needs no user).
  - **`TorandoGUI-Daemon`** — the root daemon, as **your own account, elevated,
    at logon**. This matters: the WinINET system proxy is per-user (`HKCU`), so a
    SYSTEM daemon would set it in the wrong hive and your browser would never see
    it. Run `install.ps1` from the account you'll actually use the desktop with.
- The daemon runs under `pythonw.exe boot\daemon.py` (bundled Python) and logs to
  **`%ProgramData%\torando-gui\logs\daemon.log`** — read it first if the app
  doesn't come up.
- `manage_torrc` is seeded off because the bundled Tor owns its `torrc`; set exit
  country / bridges by editing `%ProgramData%\torando-gui\torrc` and restarting
  the `TorandoGUI-Tor` task. Tor ships frequent security updates — refresh the
  bundled copy by installing a newer release (see `BUNDLED.txt`).

## Troubleshooting

- **The exit check is unverified.** Tor may be unreachable, the check host may
  be blocked, or its HTTP/JSON response may be invalid. Confirm `socks_port`
  matches Tor's configuration and inspect the activity log. An unknown result
  is neither a confirmed Tor exit nor proof of a leak.
- **Linux: DNS fails with a port mismatch.** The daemon routes into an existing
  Tor, so its ports must match. A common case is Tor using `DNSPort 5353` while
  `dns_port` is `53`; set `dns_port` to `5353`.
- **Linux: "refusing to connect… ip6tables is unavailable".** Your kernel has
  IPv6 but `ip6tables` isn't installed, so the v6 killswitch can't be armed. Install
  it (usually the `iptables`/`iptables-nft` package). Disabling
  `ipv6_killswitch` leaves IPv6 outside the rules.
- **macOS/BSD: connected but traffic still isn't through Tor.** The killswitch
  is intended to block direct TCP/UDP, while routing into Tor needs SOCKS. On
  macOS confirm `networksetup -getsocksfirewallproxy` shows it enabled; on BSD use
  `torsocks`. Also verify the anchor is actually evaluated
  (`pfctl -s rules | grep torando-gui`) — if your `pf.conf` has an earlier
  `pass … quick` rule, move the `anchor "torando-gui"` reference ahead of it.
- **macOS: "app is damaged / cannot be opened".** Gatekeeper quarantine on the
  unsigned app. `xattr -dr com.apple.quarantine "/Applications/Torando Control.app"`,
  or approve it in System Settings → Privacy & Security.
- **Windows: everything is blocked, including Tor.** `tor_path` must point at a
  real `tor.exe` so the firewall can whitelist it. If a disconnect was interrupted,
  run `torando-guid --disconnect` to request policy, proxy and DNS restoration.
  `--restore-dns` only repairs DNS.
- **DNS is stuck on 127.0.0.1 after a crash.** Run `torando-guid --restore-dns`,
  or see [Recovery](#recovery) for the per-platform manual steps.
