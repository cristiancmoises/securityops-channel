# Torando-Gui

[![License: AGPL-3.0-only](https://img.shields.io/badge/license-AGPL--3.0--only-blue.svg)](LICENSE)
[![Python 3.11+](https://img.shields.io/badge/python-3.11%2B-blue.svg)](pyproject.toml)
[![stdlib only](https://img.shields.io/badge/dependencies-stdlib%20only-success.svg)](pyproject.toml)
[![platforms](https://img.shields.io/badge/platforms-Linux%20%C2%B7%20macOS%20%C2%B7%20BSD%20%C2%B7%20Windows-blue.svg)](#platform-support)

**Torando-Gui is the GUI for [Torando](https://github.com/cristiancmoises/torando).**
It gives Torando's per-user Tor routing workflow a desktop interface with
connection controls, firewall status, DNS settings and exit checks.

Torando-Gui has its own Python daemon and can be installed on its own. It does
not call Torando's shell scripts or require the Torando package. Choose Torando
for the command line, or Torando-Gui for the desktop; disconnect one before
using the other so they do not compete over firewall and DNS settings.

<p align="center">
  <img src="docs/screenshots/connected.png" alt="Connection view" width="280">
  &nbsp;
  <img src="docs/screenshots/disconnected.png" alt="Disconnected view" width="280">
  &nbsp;
  <img src="docs/screenshots/settings.png" alt="Settings" width="280">
</p>

The screenshots show an earlier version; the connection labels have since changed.

Torando-Gui routes traffic through Tor; it does not provide Tor Browser's
fingerprinting protections. Its firewall rules aim to block traffic that cannot
use Tor, within the platform limits below. Read the
[threat model](THREAT_MODEL.md) before relying on that protection.

[Usage and recovery](docs/USAGE.md) · [Changelog](CHANGELOG.md) ·
[Security policy](SECURITY.md) · [Contributing](CONTRIBUTING.md)

## What's changed in 1.4.1

Every release now includes the full set of packages, a Python wheel, the complete
source archive and SHA-256 checksums on all four mirrors. Builds stop if any
format fails or an old package slips into the release directory. Windows bundles
update Python and Tor and verify both downloads. macOS and BSD upgrades replace
the installed Python package cleanly, keeping your configuration.

The exit-verification improvements from 1.4.0 are included. See the
[changelog](CHANGELOG.md) for details.

## Platform support

| Platform | Routing | Firewall and DNS | Status |
|---|---|---|---|
| Linux | Per-user TCP and UDP DNS redirected to Tor | `iptables`, `ip6tables`, `resolv.conf` | Primary platform |
| macOS | System SOCKS proxy for apps that support it | Per-user `pf` rules, `networksetup` DNS | Beta |
| FreeBSD / OpenBSD | Per-app SOCKS or `torsocks` | Per-user `pf` rules, `resolv.conf` | Beta |
| Windows 10/11 | WinINET SOCKS proxy for apps that support it | Machine-wide Windows Firewall defaults, `netsh` DNS | Beta |

On Linux, TCP and UDP/53 need no per-app proxy setup; other outgoing traffic
from the selected user is blocked by the installed rules. IPv6 is blocked by
default. On macOS and BSD, `pf` user rules cover TCP/UDP, but not ICMP, and
existing rules can take precedence. Windows changes the machine-wide outbound
default and the current account's proxy; existing firewall rules and application
proxy support still matter. The status display does not audit every possible
path through the host. See [platform notes](docs/USAGE.md#platform-notes).

## Requirements

The daemon needs Python 3.11+, Tor and root/Administrator access. Its Python
runtime uses only the standard library. Windows bundles include Python and Tor.

| Platform | Additional requirements |
|---|---|
| Linux | `iptables`, `ip6tables`, `e2fsprogs`; polkit for desktop service control |
| macOS | `pf`, Python 3.11+ and Tor, usually installed through Homebrew |
| FreeBSD / OpenBSD | `pf`, Python 3.11+ and the Tor package |
| Windows | Administrator account for installation and the daemon |

The native Linux window uses GTK4, WebKitGTK and PyGObject. Without those
libraries, the same interface opens in a browser. A browser is the default on
macOS, BSD and Windows.

## Install

Download **v1.4.1** from any of these release pages:

- [SecurityOps](https://git.securityops.co/cristiancmoises/torando-gui/releases/tag/v1.4.1)
- [SecurityOps Brazil](https://git.securityops.com.br/cristiancmoises/torando-gui/releases/tag/v1.4.1)
- [Codeberg](https://codeberg.org/berkeley/torando-gui/releases/tag/v1.4.1)
- [GitHub](https://github.com/cristiancmoises/torando-gui/releases/tag/v1.4.1)

Each page carries the same ten downloads plus `SHA256SUMS`: Debian, RPM,
Linux portable tarball, x86-64 AppImage, Windows x86-64 all-in-one zip, macOS
zip, FreeBSD and OpenBSD tarballs, Python wheel and complete source archive.
macOS and BSD bundles use the Python and Tor installed on your system.

Save the package for your platform and `SHA256SUMS` in the same directory.
On Linux, check downloaded files with `sha256sum --check --ignore-missing SHA256SUMS`.
On macOS use `shasum -a 256 <filename>`; on Windows use
`Get-FileHash <filename> -Algorithm SHA256` and compare with its entry in
`SHA256SUMS`. Then follow the matching instructions below.

### Debian / Ubuntu

```sh
sudo apt install ./torando-gui_1.4.1_all.deb
sudo systemctl enable --now torando-gui.service
torando-gui
```

### Fedora / RHEL

```sh
sudo dnf install ./torando-gui-1.4.1-1.noarch.rpm
sudo systemctl enable --now torando-gui.service
torando-gui
```

### Arch

From a source checkout or the extracted source archive:

```sh
cd packaging
makepkg -si
sudo systemctl enable --now torando-gui.service
torando-gui
```

### GNU Guix

```sh
guix package -f packaging/guix.scm
```

The package uses Python and firewall tools from the Guix store. On Guix System,
use the Shepherd service in [packaging/torando-gui-shepherd.scm](packaging/torando-gui-shepherd.scm)
or the corresponding service from your securityops channel. A systemd unit does
not start a service under Shepherd. That service seeds `manage_torrc=false` and
`dns_port=5353` because Guix's Tor service owns its configuration. See the
[usage guide](docs/USAGE.md#linux).

### AppImage

Download the x86-64 AppImage, then run:

```sh
chmod +x torando-gui-1.4.1-x86_64.AppImage
./torando-gui-1.4.1-x86_64.AppImage
```

The AppImage needs system Python 3.11+ and Tor. It starts its daemon through
`pkexec` for the session. Disconnect before closing it.

### macOS

Install Python 3.11+ and Tor first, then extract the downloaded macOS bundle:

```sh
unzip torando-gui-1.4.1-macos.zip
cd torando-gui-1.4.1
sudo ./install.sh
```

The installer adds the CLI, a LaunchDaemon and `/Applications/Torando Control.app`.
That bundle keeps its existing filename for upgrades. Start Tor and configure
its SOCKS and DNS ports before connecting; see [macOS setup](docs/USAGE.md#macos).
The app is unsigned, so approve its first launch through macOS's Open action.
The Homebrew formula in `packaging/macos/` is a release template; its archive
checksum must be filled in before publishing it to a tap.

### FreeBSD / OpenBSD

Download the archive for your BSD system. Install Python 3.11+ and Tor and
enable `pf` before connecting.

```sh
# FreeBSD
tar xzf torando-gui-1.4.1-freebsd.tar.gz
cd torando-gui-1.4.1
sudo ./install.sh
sudo sysrc torando_gui_enable=YES
sudo service torando-gui start
```

For OpenBSD, extract `torando-gui-1.4.1-openbsd.tar.gz`, run `doas ./install.sh`,
then `doas rcctl enable torando_gui` and `doas rcctl start torando_gui`.
Apps need SOCKS settings or `torsocks` on both systems.

### Windows

Download the Windows x86-64 zip. It includes Python 3.13.15 and the Tor Expert
Bundle 15.0.21; no separate Python or Tor installation is needed.

Open an elevated PowerShell **as the account you use for your desktop**:

```powershell
Expand-Archive torando-gui-1.4.1-windows.zip .
cd torando-gui-1.4.1
powershell -ExecutionPolicy Bypass -File install.ps1
.\torando-gui.cmd
```

The installer creates two Scheduled Tasks: Tor runs as SYSTEM at boot, and the
daemon runs as your elevated account at logon. Using that account matters
because WinINET proxy settings belong to the user, while the firewall policy
applies to the whole machine. Installation and daemon logs are under
`%ProgramData%\torando-gui\logs`. Run the bundled `uninstall.ps1` to remove it.
The bundle's `BUNDLED.txt` records the included Python and Tor versions.

### Portable Linux archive and Python wheel

The `.tar.zst` includes `install.sh` and `uninstall.sh`. Extract it with
`tar --zstd -xf torando-gui-1.4.1.tar.zst`, enter `torando-gui-1.4.1`, and run
`sudo ./install.sh`. Install the Linux requirements above separately.

The wheel installs the Python daemon, launchers and web interface:

```sh
python3 -m pip install torando_gui-1.4.1-py3-none-any.whl
```

It does not install Tor, firewall tools, desktop service files or GTK libraries.
Use your platform's package or bundle for those integration files.

## Usage

1. Start the daemon and open `torando-gui`.
2. Select the user to route. On Windows, select the displayed account; the
   firewall policy still applies to the whole machine.
3. Press **Connect to Tor** and wait for Tor to bootstrap. Open the status details to inspect
   DNS, firewall and exit information.
4. Use **New Tor identity** to request a new circuit when Tor's control port is
   available. This does not guarantee a different exit IP.
5. Disconnect to remove the session's rules and restore saved DNS/proxy settings.
   Closing the window alone does not disconnect.

**Tor exit verified** means the SOCKS probe received a valid positive verdict.
**Exit not verified** means the app has no valid verdict for this connection.
Checks refresh once per minute. They confirm that SOCKS connection's exit, not
the route taken by every application. Country and city information may be
unavailable.

If DNS is stuck, run `sudo torando-guid --restore-dns`. To request full teardown,
use `sudo torando-guid --disconnect`. On Windows, run these commands from an
elevated shell. See [recovery](docs/USAGE.md#recovery) for details.

## Development and builds

Get the source and preview the interface without root or Tor:

```sh
git clone https://github.com/cristiancmoises/torando-gui.git
cd torando-gui
make mock
```

For lint and tests, install Node.js 22+ and set up the Python tools:

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install ruff pytest
make test
```

The tests use temporary files and fake firewall runners. They do not validate
traffic routing on a live host. Before relying on a platform backend, also
check its behavior with Tor stopped as described in the usage guide.

| Target | Output in `dist/` | Build tool |
|---|---|---|
| `make deb` | `torando-gui_1.4.1_all.deb` | `dpkg-deb` |
| `make rpm` | `torando-gui-1.4.1-1.noarch.rpm` | `rpmbuild` |
| `make appimage` | `torando-gui-1.4.1-x86_64.AppImage` | `appimagetool` |
| `make tarball` | `torando-gui-1.4.1.tar.zst` | `zstd` |
| `make windows` | `torando-gui-1.4.1-windows.zip` | `curl`, `zip`, network access |
| `make macos` | `torando-gui-1.4.1-macos.zip` | `zip`; optional `png2icns` |
| `make freebsd openbsd` | `torando-gui-1.4.1-<os>.tar.gz` | GNU `tar` |
| `make source` | `torando-gui-1.4.1-source.tar.gz` | Git, committed checkout |
| `make wheel` | `torando_gui-1.4.1-py3-none-any.whl` | Python `build` |

`make release` (also `make all`) builds every format in a fresh directory,
verifies package versions and contents, and writes `SHA256SUMS`. The finished
set goes to `dist/v1.4.1/`. Missing tools, failed downloads, incomplete bundles
or existing release output stop the build. See [release instructions](CONTRIBUTING.md#releases)
for the tooling and publication steps.

`backend/torando_gui/` contains the daemon and platform backends; `webroot/`
inside it contains the interface, with no build step or remote assets.
Tests live in `tests/`, and package definitions live in `packaging/`.

## Repositories and license

The official repository is [Forgejo](https://git.securityops.co/cristiancmoises/torando-gui),
with mirrors on [SecurityOps Brazil](https://git.securityops.com.br/cristiancmoises/torando-gui),
[GitHub](https://github.com/cristiancmoises/torando-gui) and
[Codeberg](https://codeberg.org/berkeley/torando-gui).

Torando-Gui is licensed under [AGPL-3.0-only](LICENSE). It provides the GUI for
[Torando](https://github.com/cristiancmoises/torando), whose shell implementation
is licensed under GPL-3.0. The GUI's routing backend is implemented separately.
