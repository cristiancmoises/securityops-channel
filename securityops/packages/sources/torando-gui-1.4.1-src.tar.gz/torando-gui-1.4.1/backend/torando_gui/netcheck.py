# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only
"""Verify that egress actually leaves through a Tor exit.

We perform a real HTTPS request to the Tor Project's check endpoint *through*
Tor's SocksPort and report exactly what it says. The verdict is never
fabricated: on any error we return ``is_tor=None`` with the error string so the
UI shows "unknown", not a false "secured".
"""

from __future__ import annotations

import json
import socket
import ssl
from contextlib import ExitStack
from dataclasses import dataclass
from http.client import HTTPResponse
from ipaddress import ip_address
from typing import BinaryIO
from urllib.parse import urlsplit

from .socks import socks5_connect

_MAX_BODY = 1 << 20
_MAX_RESPONSE = 2 << 20  # Include headers, chunk extensions, and trailers.


class _ResponseReader:
    """Bound all wire reads and require complete HTTP framing lines."""

    def __init__(self, stream: BinaryIO):
        self.stream = stream
        self.remaining = _MAX_RESPONSE

    def _take(self, data: bytes) -> bytes:
        self.remaining -= len(data)
        if self.remaining < 0:
            raise ValueError("HTTP response exceeds size limit")
        return data

    def read(self, size: int = -1) -> bytes:
        limit = self.remaining + 1
        return self._take(self.stream.read(min(size, limit) if size >= 0 else limit))

    def readline(self, size: int = -1) -> bytes:
        limit = self.remaining + 1
        line = self._take(self.stream.readline(min(size, limit) if size >= 0 else limit))
        if not line.endswith(b"\r\n"):
            raise ValueError("invalid or truncated HTTP framing")
        return line

    def close(self) -> None:
        self.stream.close()

    def flush(self) -> None:
        self.stream.flush()


class _CheckResponse(HTTPResponse):
    """Use stdlib framing without its tolerance for broken chunk delimiters."""

    def __init__(self, sock: socket.socket):
        super().__init__(sock, method="GET")
        self.fp = _ResponseReader(self.fp)

    def _read_next_chunk_size(self) -> int:
        line = self.fp.readline(65537)
        size = line[:-2].split(b";", 1)[0]
        if not size or any(c not in b"0123456789abcdefABCDEF" for c in size):
            raise ValueError("invalid HTTP chunk size")
        return int(size, 16)

    def _get_chunk_left(self) -> int | None:
        if self.chunk_left == 0:
            if self._safe_read(2) != b"\r\n":
                raise ValueError("invalid HTTP chunk delimiter")
            self.chunk_left = None
        return super()._get_chunk_left()


def _unique_json_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
    doc: dict[str, object] = {}
    for key, value in pairs:
        if key in doc:
            raise ValueError("check response contains duplicate JSON fields")
        doc[key] = value
    return doc


def _invalid_json_constant(value: str) -> None:
    raise ValueError("check response contains an invalid JSON constant")


@dataclass
class ExitInfo:
    is_tor: bool | None
    ip: str | None
    error: str | None = None
    country: str | None = None  # ISO-3166-1 alpha-2, lower-case, if resolvable
    lat: float | None = None
    lon: float | None = None
    city: str | None = None

    def as_dict(self) -> dict[str, object]:
        return {
            "is_tor": self.is_tor,
            "ip": self.ip,
            "error": self.error,
            "country": self.country,
            "lat": self.lat,
            "lon": self.lon,
            "city": self.city,
        }


def _http_get_over(sock: socket.socket, host: str, path: str, timeout: float) -> bytes:
    sock.settimeout(timeout)
    req = (
        f"GET {path} HTTP/1.1\r\n"
        f"Host: {host}\r\n"
        "User-Agent: torando-gui\r\n"
        "Accept: application/json\r\n"
        "Connection: close\r\n\r\n"
    ).encode("ascii")
    sock.sendall(req)
    with _CheckResponse(sock) as response:
        response.begin()
        if not 200 <= response.status < 300:
            raise ValueError(f"check endpoint returned HTTP {response.status}")
        if response.headers.defects:
            raise ValueError("invalid HTTP headers")

        lengths = [value.strip() for value in response.headers.get_all("Content-Length", [])]
        encodings = [value.strip() for value in response.headers.get_all("Transfer-Encoding", [])]
        if len(lengths) > 1 or len(encodings) > 1 or (lengths and encodings):
            raise ValueError("ambiguous HTTP response framing")
        if encodings and encodings[0].lower() != "chunked":
            raise ValueError("unsupported HTTP transfer encoding")
        if lengths and (not lengths[0].isascii() or not lengths[0].isdigit()):
            raise ValueError("invalid HTTP content length")
        if response.getheader("Content-Encoding", "identity").strip().lower() != "identity":
            raise ValueError("unsupported HTTP content encoding")
        if lengths and int(lengths[0]) > _MAX_BODY:
            raise ValueError("check response exceeds size limit")
        if encodings:
            response.chunked = True
            response.chunk_left = None

        expected = response.length
        if expected is not None and expected > _MAX_BODY:
            raise ValueError("check response exceeds size limit")
        body = response.read(_MAX_BODY + 1)
        if len(body) > _MAX_BODY:
            raise ValueError("check response exceeds size limit")
        if expected is not None and len(body) != expected:
            raise ValueError("truncated check response")
        return body


def check_exit(
    socks_host: str,
    socks_port: int,
    url: str,
    timeout: float = 15.0,
) -> ExitInfo:
    try:
        if not isinstance(url, str) or any(ord(c) <= 32 or ord(c) == 127 for c in url):
            raise ValueError("check URL contains invalid characters")
        parts = urlsplit(url)
        if parts.scheme not in {"http", "https"} or not parts.hostname:
            raise ValueError("check URL must be an absolute HTTP or HTTPS URL")
        if parts.username is not None or parts.password is not None:
            raise ValueError("check URL must not contain credentials")
        host = parts.hostname.encode("idna").decode("ascii")
        if any(c in host for c in "\\%"):
            raise ValueError("check URL contains an invalid hostname")
        port = parts.port if parts.port is not None else (443 if parts.scheme == "https" else 80)
        if not 1 <= port <= 65535:
            raise ValueError("check URL port is out of range")
        authority = f"[{host}]" if ":" in host else host
        if parts.port is not None:
            authority = f"{authority}:{port}"
        path = parts.path or "/"
        if parts.query:
            path = f"{path}?{parts.query}"
        path.encode("ascii")  # Reject invalid request targets before opening a tunnel.
    except (ValueError, UnicodeError) as exc:
        return ExitInfo(None, None, f"url: {exc}")

    try:
        tunnel = socks5_connect(socks_host, socks_port, host, port, timeout=timeout)
    except Exception as exc:  # noqa: BLE001 — surfaced to UI as "unknown"
        return ExitInfo(None, None, f"socks: {exc}")
    try:
        with ExitStack() as stack:
            stack.callback(tunnel.close)
            connection = tunnel
            if parts.scheme == "https":
                ctx = ssl.create_default_context()
                connection = ctx.wrap_socket(tunnel, server_hostname=host)
                stack.callback(connection.close)
            body = _http_get_over(connection, authority, path, timeout)
    except Exception as exc:  # noqa: BLE001
        return ExitInfo(None, None, f"http: {exc}")

    try:
        doc = json.loads(
            body.decode("utf-8"),
            object_pairs_hook=_unique_json_object,
            parse_constant=_invalid_json_constant,
        )
        if not isinstance(doc, dict) or type(doc.get("IsTor")) is not bool:
            raise ValueError("check response must contain a boolean IsTor")
        ip = doc.get("IP")
        if not isinstance(ip, str) or "%" in ip:
            raise ValueError("check response must contain an IP address")
        ip_address(ip)
    except (ValueError, UnicodeError, RecursionError) as exc:
        return ExitInfo(None, None, f"invalid check response: {exc}")
    return ExitInfo(doc["IsTor"], ip)
