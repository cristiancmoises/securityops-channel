# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only
"""Torando-Gui — the GUI for Torando, with a standalone routing daemon."""

__version__ = "1.4.1"
