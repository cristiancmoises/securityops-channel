# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (c) 2026 Cristian Cezar Moisés
"""Release gates must reject missing builds, stale payloads and changed bytes."""

import importlib.util
import io
import tarfile
import zipfile
from pathlib import Path

import pytest

SCRIPT = Path(__file__).resolve().parents[1] / "packaging/verify-release.py"
SPEC = importlib.util.spec_from_file_location("verify_release", SCRIPT)
assert SPEC is not None and SPEC.loader is not None
release = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(release)


def populate_assets(directory, version="1.4.1"):
    for name in release.expected_assets(version):
        (directory / name).write_bytes(b"built package")


def test_missing_appimage_blocks_release(tmp_path):
    populate_assets(tmp_path)
    (tmp_path / "torando-gui-1.4.1-x86_64.AppImage").unlink()
    with pytest.raises(ValueError, match="missing=.*AppImage"):
        release.check_file_set(tmp_path, "1.4.1", checksums=False)


def test_old_build_blocks_release_even_when_new_builds_are_complete(tmp_path):
    populate_assets(tmp_path)
    (tmp_path / "torando-gui-1.4.0-windows.zip").write_bytes(b"old build")
    with pytest.raises(ValueError, match="unexpected=.*1.4.0"):
        release.check_file_set(tmp_path, "1.4.1", checksums=False)


def test_empty_download_blocks_release(tmp_path):
    populate_assets(tmp_path)
    (tmp_path / "torando-gui-1.4.1-windows.zip").write_bytes(b"")
    with pytest.raises(ValueError, match="empty or invalid"):
        release.check_file_set(tmp_path, "1.4.1", checksums=False)


def test_checksums_detect_changed_download_bytes(tmp_path):
    populate_assets(tmp_path)
    paths = release.check_file_set(tmp_path, "1.4.1", checksums=False)
    original = release.checksum_text(paths)
    paths[0].write_bytes(b"changed package")
    assert release.checksum_text(paths) != original
    assert len(original.splitlines()) == 10


def test_renamed_source_archive_cannot_hide_old_version(tmp_path):
    path = tmp_path / "torando-gui-1.4.1-source.tar.gz"
    payload = b'[project]\nversion = "1.4.0"\n'
    with tarfile.open(path, "w:gz") as archive:
        member = tarfile.TarInfo("torando-gui-1.4.1/pyproject.toml")
        member.size = len(payload)
        archive.addfile(member, io.BytesIO(payload))
    with pytest.raises(ValueError, match="source archive version mismatch"):
        release.check_asset(path, "1.4.1")


def test_windows_bundle_requires_embedded_python_and_tor(tmp_path):
    path = tmp_path / "torando-gui-1.4.1-windows.zip"
    with zipfile.ZipFile(path, "w") as archive:
        for member in (
            "lib/torando_gui/webroot/app.js",
            "lib/torando_gui/webroot/index.html",
            "README.md",
            "THREAT_MODEL.md",
        ):
            archive.writestr("torando-gui-1.4.1/" + member, "payload")
    with pytest.raises(KeyError, match="python/python.exe"):
        release.check_bundle(path, "1.4.1")


def test_python_module_version_must_match_release():
    with pytest.raises(ValueError, match="packaged Python version"):
        release.check_module(b'__version__ = "1.4.0"\n', "1.4.1")


def test_current_package_metadata_is_consistent():
    release.check_versions(release.ROOT, release.release_version())


def test_rpm_with_unexpanded_service_macros_is_rejected():
    with pytest.raises(ValueError, match="unexpanded systemd macros"):
        release.check_rpm_scripts(b"%systemd_post torando-gui.service\n")
