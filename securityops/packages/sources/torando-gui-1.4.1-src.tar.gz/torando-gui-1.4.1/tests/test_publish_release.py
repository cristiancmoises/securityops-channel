# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only
"""Release publication must reject incomplete inputs before writing to any forge."""

import argparse
import importlib.util
import io
import urllib.error
from pathlib import Path

import pytest

SCRIPT = Path(__file__).resolve().parents[1] / "packaging" / "publish-release.py"
SPEC = importlib.util.spec_from_file_location("publish_release", SCRIPT)
publisher = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(publisher)


def artifacts(directory):
    for name in ["torando-2.0.1-src.tar.gz", "torando-2.0.1-src.zip"]:
        (directory / name).write_bytes(b"source contents")
    (directory / "SHA256SUMS").write_text(
        "".join(f"{publisher.file_hash(p)}  {p.name}\n" for p in sorted(directory.iterdir()))
    )


def test_verified_manifest_includes_its_own_digest(tmp_path):
    artifacts(tmp_path)
    hashes = publisher.artifact_hashes(tmp_path)
    assert len(hashes) == 3
    assert hashes["SHA256SUMS"] == publisher.file_hash(tmp_path / "SHA256SUMS")


@pytest.mark.parametrize("change", ["extra", "corrupt", "duplicate", "traversal", "symlink"])
def test_invalid_artifacts_are_rejected(tmp_path, change):
    artifacts(tmp_path)
    manifest = tmp_path / "SHA256SUMS"
    if change == "extra":
        (tmp_path / "old-version.zip").write_bytes(b"stale")
    elif change == "corrupt":
        (tmp_path / "torando-2.0.1-src.zip").write_bytes(b"changed")
    elif change == "duplicate":
        manifest.write_text(manifest.read_text() * 2)
    elif change == "traversal":
        manifest.write_text("a" * 64 + "  ../key\n")
    else:
        original = tmp_path / "torando-2.0.1-src.zip"
        original.unlink()
        try:
            original.symlink_to(tmp_path / "torando-2.0.1-src.tar.gz")
        except OSError:
            pytest.skip("symlinks unavailable")
    with pytest.raises(ValueError):
        publisher.artifact_hashes(tmp_path)


def test_missing_token_fails_before_network(monkeypatch):
    monkeypatch.delenv("CODEBERG_TOKEN", raising=False)
    with pytest.raises(ValueError, match="CODEBERG_TOKEN"):
        publisher.Forge("codeberg.org", "berkeley", "CODEBERG_TOKEN", "torando")


def test_credentials_never_follow_an_unexpected_upload_host(monkeypatch):
    monkeypatch.setenv("GITHUB_TOKEN", "test-only-token")
    forge = publisher.Forge("github.com", "cristiancmoises", "GITHUB_TOKEN", "torando")
    with pytest.raises(ValueError, match="unexpected host"):
        forge.request("POST", "https://unrelated.example/upload", payload=b"file")


@pytest.mark.parametrize("interrupted", [False, True])
def test_all_uploads_finish_before_any_release_is_published(tmp_path, monkeypatch, interrupted):
    artifacts(tmp_path)
    events = []
    commit = "a" * 40

    class FakeForge:
        def __init__(self, host, owner, variable, project):
            self.host, self.repo = host, "/repo"
            self.uploaded = {}
            self.token = "test-only-token"

        def tagged_commit(self, tag):
            return commit

        def request(self, method, path, document=None):
            events.append((self.host, method, path))
            if method == "GET":
                return {}
            return {"id": 1, "draft": method == "POST", "html_url": self.host}

        def find_release(self, tag):
            return None

        def assets(self, release_id):
            return list(self.uploaded.values())

        def upload(self, release_id, path):
            events.append((self.host, "upload", path.name))
            self.uploaded[path.name] = {
                "name": path.name,
                "size": path.stat().st_size,
                "browser_download_url": path.name,
            }
            if interrupted:
                raise OSError("connection closed after upload was saved")
            return {**self.uploaded[path.name], "browser_download_url": "draft/" + path.name}

    monkeypatch.setattr(publisher, "Forge", FakeForge)
    monkeypatch.setattr(publisher.subprocess, "check_output", lambda *a, **k: commit + "\n")
    monkeypatch.setattr(
        publisher, "download_hash", lambda name, **kwargs: publisher.file_hash(tmp_path / name)
    )
    publisher.publish(
        argparse.Namespace(
            version="2.0.1",
            commit=commit,
            project="torando",
            artifacts=tmp_path,
            notes=None,
            sync_refs=False,
        )
    )
    first_publish = next(i for i, event in enumerate(events) if event[1] == "PATCH")
    uploads = [i for i, event in enumerate(events) if event[1] == "upload"]
    assert len(uploads) == 12
    assert max(uploads) < first_publish
    assert len([event for event in events if event[1] == "PATCH"]) == 4


@pytest.mark.parametrize("field", ["sha", "id"])
def test_forgejo_tag_commit_accepts_current_and_legacy_fields(monkeypatch, field):
    monkeypatch.setenv("CODEBERG_TOKEN", "test-only-token")
    forge = publisher.Forge("codeberg.org", "berkeley", "CODEBERG_TOKEN", "torando")
    monkeypatch.setattr(forge, "request", lambda *args: {"commit": {field: "a" * 40}})
    assert forge.tagged_commit("v2.0.1") == "a" * 40


@pytest.mark.parametrize(
    "destination", ["https://downloads.example/file", "http://unsafe.example/file"]
)
def test_draft_download_tokens_do_not_follow_cross_host_redirects(monkeypatch, destination):
    requests = []

    class Opener:
        def open(self, request, timeout):
            requests.append(request)
            if len(requests) == 1:
                raise urllib.error.HTTPError(
                    request.full_url, 302, "redirect", {"Location": destination}, None
                )
            return io.BytesIO(b"release asset")

    monkeypatch.setattr(publisher.urllib.request, "build_opener", lambda *args: Opener())

    def call():
        return publisher.download_hash(
            "https://codeberg.org/draft", token="test-token", auth_host="codeberg.org"
        )

    if destination.startswith("http:"):
        with pytest.raises(ValueError, match="HTTPS"):
            call()
        assert len(requests) == 1
    else:
        assert call() == publisher.hashlib.sha256(b"release asset").hexdigest()
        assert requests[1].get_header("Authorization") is None
    assert requests[0].get_header("Authorization") == "token test-token"
