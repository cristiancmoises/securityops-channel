# SPDX-License-Identifier: AGPL-3.0-only
"""Exercise release installers in temporary directories without touching the host."""

from __future__ import annotations

import hashlib
import os
import re
import shutil
import subprocess
import sys
import tomllib
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
pytestmark = pytest.mark.skipif(
    sys.platform != "linux", reason="release bundle construction uses Linux packaging tools"
)


@pytest.fixture
def build_repo(tmp_path):
    root = tmp_path / "source"
    root.mkdir()
    shutil.copytree(REPO / "packaging", root / "packaging")
    package = root / "backend" / "torando_gui"
    package.mkdir(parents=True)
    (package / "__init__.py").write_text('VERSION = "new"\n')
    (package / "__main__.py").write_text("from . import VERSION\nprint(VERSION)\n")
    for name in ("pyproject.toml", "README.md", "THREAT_MODEL.md", "LICENSE"):
        shutil.copy2(REPO / name, root / name)
    return root


@pytest.mark.parametrize("platform", ["freebsd", "openbsd", "macos"])
def test_reinstall_replaces_package_and_preserves_config(build_repo, tmp_path, platform):
    if platform == "macos" and shutil.which("zip") is None:
        pytest.skip("zip is needed for the macOS bundle")
    script = "build-macos.sh" if platform == "macos" else "build-bsd.sh"
    args = [] if platform == "macos" else [platform]
    subprocess.run(["sh", str(build_repo / "packaging" / script), *args], check=True)
    metadata = tomllib.loads((build_repo / "pyproject.toml").read_text())
    stage = build_repo / "build" / platform / f"torando-gui-{metadata['project']['version']}"

    # Translate every installer destination into the temporary filesystem. The
    # service manager and privilege check are stubs; no host service is called.
    host = tmp_path / "host"
    installer = (stage / "install.sh").read_text()
    for path in ("/usr/local", "/etc", "/Applications", "/Library/LaunchDaemons"):
        destination = host / path.lstrip("/")
        destination.mkdir(parents=True, exist_ok=True)
    installer = re.sub(
        r"(?<![A-Za-z0-9])/(?:usr/local|etc|Applications|Library/LaunchDaemons)",
        lambda match: str(host) + match[0],
        installer,
    )
    (stage / "install-test.sh").write_text(installer)
    commands = tmp_path / "commands"
    commands.mkdir()
    for name, command in (("id", "echo 0"), ("launchctl", "exit 0")):
        target = commands / name
        target.write_text(f"#!/bin/sh\n{command}\n")
        target.chmod(0o755)
    env = dict(os.environ, PATH=f"{commands}{os.pathsep}{os.environ['PATH']}")
    command = ["sh", str(stage / "install-test.sh")]
    subprocess.run(command, check=True, env=env)
    installed = host / "usr/local/lib/torando-gui/torando_gui"
    (installed / "__init__.py").write_text('VERSION = "old"\n')
    (installed / "removed.py").write_text("stale\n")
    config = host / ("usr/local/etc" if platform == "freebsd" else "etc")
    config = config / "torando-gui/config.json"
    config.write_text('{"port": 9001}\n')

    subprocess.run(command, check=True, env=env)

    assert (installed / "__init__.py").read_text() == 'VERSION = "new"\n'
    assert not (installed / "removed.py").exists()
    assert not (installed / "torando_gui").exists()
    assert config.read_text() == '{"port": 9001}\n'

    if platform == "macos":
        # launchd/Finder may see Apple's older Python in PATH. The installed
        # launcher must still find a supported Homebrew interpreter.
        brew = host / "opt/homebrew/bin/python3"
        brew.parent.mkdir(parents=True)
        brew.symlink_to(sys.executable)
        old_python = commands / "python3"
        old_python.write_text("#!/bin/sh\nexit 2\n")
        old_python.chmod(0o755)
        launcher = host / "usr/local/bin/torando-guid"
        launcher.write_text(
            re.sub(
                r"(?<![A-Za-z0-9])/(?:usr/local|opt/homebrew)",
                lambda match: str(host) + match[0],
                launcher.read_text(),
            )
        )
        result = subprocess.run(
            ["sh", str(launcher)], check=True, capture_output=True, text=True, env=env
        )
        assert result.stdout == "new\n"


@pytest.mark.parametrize("component", ["python", "tor"])
def test_windows_build_rejects_corrupt_cached_runtime(build_repo, component):
    if shutil.which("zip") is None or shutil.which("curl") is None:
        pytest.skip("zip and curl are needed for the Windows builder")
    cache = build_repo / "build/windows-cache"
    cache.mkdir(parents=True)
    expected = b"verified upstream payload"
    env = dict(os.environ)
    env.update(TORANDO_PYVER="test", TORANDO_TORVER="test")
    digest = hashlib.sha256(expected).hexdigest()
    env.update(TORANDO_PY_SHA256=digest, TORANDO_TOR_SHA256=digest)
    for name, filename in (
        ("python", "python-test-embed-amd64.zip"),
        ("tor", "tor-expert-bundle-test.tar.gz"),
    ):
        (cache / filename).write_bytes(b"corrupt" if name == component else expected)

    result = subprocess.run(
        ["sh", str(build_repo / "packaging/build-windows.sh")],
        capture_output=True,
        text=True,
        env=env,
    )

    assert result.returncode != 0
    assert "SHA256 mismatch" in result.stderr
    assert not (build_repo / "build/windows").exists()
