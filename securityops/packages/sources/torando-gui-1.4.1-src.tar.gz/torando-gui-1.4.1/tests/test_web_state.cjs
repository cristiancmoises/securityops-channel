// SPDX-License-Identifier: AGPL-3.0-only
// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');

// Run the actual browser script with a tiny DOM and controlled HTTP responses.
function harness() {
  const nodes = new Map();
  function node(id) {
    if (!nodes.has(id)) nodes.set(id, {
      textContent: '', innerHTML: '', hidden: false, disabled: false,
      dataset: {}, style: {}, elements: {},
      classList: { contains: () => false, toggle() {}, add() {}, remove() {} },
      getAttribute: () => 'test-token', setAttribute() {}, addEventListener() {},
      appendChild() {}, querySelectorAll: () => [],
    });
    return nodes.get(id);
  }
  const requests = [];
  const events = [];
  const context = vm.createContext({
    document: {
      body: node('body'), activeElement: null,
      getElementById: node, querySelector: node, createElement: () => node(Symbol()),
      addEventListener() {},
    },
    window: {}, Date, setInterval: () => 1, clearInterval() {}, setTimeout() {},
    fetch: (url) => new Promise((resolve, reject) => requests.push({ url, resolve, reject })),
    EventSource: function () { events.push(this); },
  });
  const source = fs.readFileSync(path.join(__dirname, '../backend/torando_gui/webroot/app.js'), 'utf8');
  vm.runInContext(source, context); // boot's initial HTTP requests remain pending
  const run = (code) => vm.runInContext(code, context);
  run('var active = {active: true, target_uid: 1000, dns: {via_tor: true}, config: {}}');
  const exits = () => requests.filter((r) => r.url === '/api/exit');
  const respond = async (request, doc) => {
    request.resolve({ ok: true, text: async () => JSON.stringify(doc) });
    await new Promise(setImmediate);
  };
  return { run, node, requests, exits, respond, events };
}

test('active rules alone and malformed verdicts never show a verified exit', () => {
  const h = harness();
  assert.equal(h.run('deriveState(active)'), 'unverified');
  for (const value of ['null', 'false', '"true"', '1']) {
    h.run(`lastExit = {is_tor: ${value}}; exitCheckedAt = Date.now()`);
    assert.notEqual(h.run('deriveState(active)'), 'routed');
  }
  h.run('lastExit = {is_tor: true}; exitCheckedAt = Date.now()');
  assert.equal(h.run('deriveState(active)'), 'routed');
  assert.equal(h.run('deriveState({...active, dns: {via_tor: false}})'), 'leak');
  h.run('exitCheckedAt -= EXIT_MAX_AGE_MS');
  assert.equal(h.run('deriveState(active)'), 'unverified');
});

test('unverified routing keeps the disconnect button available and deduplicates checks', () => {
  const h = harness();
  h.run('render(active); render(active); refreshExit()');
  assert.equal(h.exits().length, 1);
  assert.equal(h.node('body').dataset.state, 'unverified');
  assert.equal(h.node('action-label').textContent, 'Disconnect');
  assert.equal(h.node('action').disabled, false);
});

test('a failed check is unknown and retries after its result expires', async () => {
  const h = harness();
  h.run('render(active)');
  h.exits()[0].reject(new Error('timeout'));
  await new Promise(setImmediate);
  assert.equal(h.node('body').dataset.state, 'unverified');
  assert.equal(h.node('status-where').textContent, 'timeout');
  assert.equal(h.exits().length, 1);
  h.run('exitCheckedAt -= EXIT_MAX_AGE_MS; render(active)');
  assert.equal(h.exits().length, 2);
});

test('a late response from an earlier connection cannot verify a new session', async () => {
  const h = harness();
  h.run('render(active)');
  const old = h.exits()[0];
  h.run('render({...active, active: false}); render(active)');
  assert.equal(h.exits().length, 2);
  await h.respond(old, { is_tor: true, ip: '192.0.2.1' });
  assert.equal(h.run('lastExit'), null);
  assert.equal(h.node('body').dataset.state, 'unverified');
  await h.respond(h.exits()[1], { is_tor: true, ip: '192.0.2.2' });
  assert.equal(h.node('body').dataset.state, 'routed');
  assert.match(h.node('status-where').textContent, /192\.0\.2\.2/);
});

test('changing the target user invalidates an in-flight exit check', async () => {
  const h = harness();
  h.run('render(active)');
  const old = h.exits()[0];
  h.run('render({...active, target_uid: 1001})');
  await h.respond(old, { is_tor: true, ip: '192.0.2.1' });
  assert.equal(h.run('lastExit'), null);
  assert.equal(h.node('body').dataset.state, 'unverified');
});

test('configuration changes from another window discard old exit responses', async () => {
  const h = harness();
  h.run('render({...active, config: {socks_port: 9050, exit_country: "se"}})');
  const old = h.exits()[0];
  h.run('render({...active, config: {exit_country: "se", socks_port: 9050}})');
  assert.equal(h.exits().length, 1); // Object key order is not a configuration change.
  h.run('render({...active, config: {socks_port: 9999, exit_country: "se"}})');
  assert.equal(h.exits().length, 2);
  await h.respond(old, { is_tor: true, ip: '192.0.2.1' });
  assert.equal(h.run('lastExit'), null);
  assert.equal(h.node('body').dataset.state, 'unverified');
  await h.respond(h.exits()[1], { is_tor: true, ip: '192.0.2.2' });
  assert.equal(h.node('body').dataset.state, 'routed');
  h.run('render({...active, config: {socks_port: 9999, exit_country: "de"}})');
  assert.equal(h.node('body').dataset.state, 'unverified');
  assert.equal(h.exits().length, 3);
});

test('exit location is displayed as text, including markup from a data file', async () => {
  const h = harness();
  h.run('render(active)');
  await h.respond(h.exits()[0], {
    is_tor: true, ip: '192.0.2.1', city: '<img src=x onerror=alert(1)>',
  });
  assert.match(h.node('status-where').textContent, /<img/);
  assert.equal(h.node('status-where').innerHTML, '');
});

test('losing the status stream removes verification until the service responds', async () => {
  const h = harness();
  h.run('render(active); connectEvents()');
  const old = h.exits()[0];
  h.events[0].onerror();
  assert.equal(h.node('body').dataset.state, 'unknown');
  assert.equal(h.node('action').disabled, true);
  await h.respond(old, { is_tor: true, ip: '192.0.2.1' });
  assert.equal(h.run('lastStatus'), null);
  assert.equal(h.node('body').dataset.state, 'unknown');
  h.events[0].onmessage({ data: JSON.stringify({
    type: 'status', data: { active: true, target_uid: 1000, dns: { via_tor: true }, config: {} },
  }) });
  assert.equal(h.node('body').dataset.state, 'unverified');
  assert.equal(h.exits().length, 2);
});

test('finishing an action after stream loss keeps controls disabled', async () => {
  const h = harness();
  h.run('render(active); connectEvents()');
  const pending = h.run('withBusy(() => new Promise(resolve => { globalThis.finishBusy = resolve; }))');
  h.events[0].onerror();
  h.run('finishBusy()');
  await pending;
  assert.equal(h.run('lastStatus'), null);
  assert.equal(h.node('action').disabled, true);
  const requestCount = h.requests.length;
  await h.run('toggleAction()');
  assert.equal(h.requests.length, requestCount);
  assert.equal(h.node('body').dataset.state, 'unknown');
});
