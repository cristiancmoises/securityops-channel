# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only
"""Only complete, valid check responses can establish a Tor exit verdict."""

from __future__ import annotations

import io
import json
import ssl

import pytest
from torando_gui import netcheck

_BODY = b'{"IsTor":true,"IP":"185.220.101.47"}'
_URL = "http://check.example/api/ip"


class _Socket:
    def __init__(self, response: bytes):
        self.stream = io.BytesIO(response)
        self.closed = False
        self.sent = b""
        self.timeout = None

    def makefile(self, mode):
        assert mode == "rb"
        return self.stream

    def settimeout(self, timeout):
        self.timeout = timeout

    def sendall(self, data):
        self.sent += data

    def close(self):
        self.closed = True


def _check(monkeypatch, raw: bytes, url: str = _URL):
    sock = _Socket(raw)
    monkeypatch.setattr(netcheck, "socks5_connect", lambda *a, **k: sock)
    result = netcheck.check_exit("127.0.0.1", 9050, url)
    assert sock.closed
    assert sock.stream.closed
    return result, sock


def _response(body: bytes = _BODY, headers: bytes = b"", status: int = 200) -> bytes:
    return f"HTTP/1.1 {status} Test\r\n".encode() + headers + b"\r\n" + body


def _assert_unknown(info):
    assert info.is_tor is None
    assert info.ip is None
    assert info.error


@pytest.mark.parametrize("is_tor", [True, False])
@pytest.mark.parametrize("ip", ["185.220.101.47", "2001:db8::1"])
@pytest.mark.parametrize("with_length", [True, False])
def test_check_exit_parses_verified_verdict(monkeypatch, is_tor, ip, with_length):
    body = json.dumps({"IsTor": is_tor, "IP": ip}).encode()
    headers = f"Content-Length: {len(body)}\r\n".encode() if with_length else b""
    info, _ = _check(monkeypatch, _response(body, headers))
    assert info.is_tor is is_tor
    assert info.ip == ip
    assert info.error is None


def test_chunked_response_with_extensions_and_trailers(monkeypatch):
    first, second = _BODY[:12], _BODY[12:]
    chunks = (
        f"{len(first):x};name=value\r\n".encode()
        + first
        + b"\r\n"
        + f"{len(second):x}\r\n".encode()
        + second
        + b"\r\n"
        + b"0\r\nX-Check: done\r\n\r\n"
    )
    info, _ = _check(monkeypatch, _response(chunks, b"Transfer-Encoding: chunked\r\n"))
    assert info.is_tor is True
    assert info.ip == "185.220.101.47"


@pytest.mark.parametrize("status", [101, 204, 301, 302, 400, 403, 500, 503])
def test_non_success_or_empty_status_cannot_verify_exit(monkeypatch, status):
    info, _ = _check(monkeypatch, _response(status=status))
    _assert_unknown(info)


@pytest.mark.parametrize(
    "body",
    [
        b"not-json",
        b"[]",
        b"null",
        b"true",
        b"42",
        b'"text"',
        b"{}",
        b'{"IP":"185.220.101.47"}',
        b'{"IsTor":"false","IP":"185.220.101.47"}',
        b'{"IsTor":"true","IP":"185.220.101.47"}',
        b'{"IsTor":1,"IP":"185.220.101.47"}',
        b'{"IsTor":0,"IP":"185.220.101.47"}',
        b'{"IsTor":[],"IP":"185.220.101.47"}',
        b'{"IsTor":{},"IP":"185.220.101.47"}',
        b'{"IsTor":null,"IP":"185.220.101.47"}',
        b'{"IsTor":true}',
        b'{"IsTor":true,"IP":null}',
        b'{"IsTor":true,"IP":123}',
        b'{"IsTor":true,"IP":[]}',
        b'{"IsTor":true,"IP":"check.example"}',
        b'{"IsTor":true,"IP":"999.1.2.3"}',
        b'{"IsTor":true,"IP":"fe80::1%eth0"}',
        b'{"IsTor":true,"IP":"185.220.101.47","extra":"\xff"}',
        b'{"IsTor":false,"IsTor":true,"IP":"185.220.101.47"}',
        b'{"IsTor":true,"IP":"185.220.101.47","extra":NaN}',
        b"[" * 2000,
    ],
)
def test_invalid_json_or_verdict_schema_is_unknown(monkeypatch, body):
    info, _ = _check(monkeypatch, _response(body))
    _assert_unknown(info)


@pytest.mark.parametrize(
    "headers",
    [
        b"Content-Length: 999\r\n",
        b"Content-Length: -1\r\n",
        b"Content-Length: invalid\r\n",
        b"Content-Length: +34\r\n",
        b"Content-Length: " + b"9" * 5000 + b"\r\n",
        b"Content-Length: 34, 34\r\n",
        b"Content-Length: 34\r\nContent-Length: 35\r\n",
        b"Content-Length: 34\r\nTransfer-Encoding: chunked\r\n",
        b"Transfer-Encoding: gzip\r\n",
        b"Transfer-Encoding: chunked\r\nTransfer-Encoding: chunked\r\n",
        b"Content-Encoding: gzip\r\n",
        b"Not-a-header\r\n",
    ],
)
def test_invalid_or_truncated_http_framing_is_unknown(monkeypatch, headers):
    info, _ = _check(monkeypatch, _response(headers=headers))
    _assert_unknown(info)


@pytest.mark.parametrize(
    "suffix",
    [b"", b"\r\n", b"\r\n0", b"\r\n0\r\n", b"xx0\r\n\r\n"],
)
def test_truncated_or_malformed_chunk_terminator_is_unknown(monkeypatch, suffix):
    chunks = f"{len(_BODY):x}\r\n".encode() + _BODY + suffix
    info, _ = _check(monkeypatch, _response(chunks, b"Transfer-Encoding: chunked\r\n"))
    _assert_unknown(info)


@pytest.mark.parametrize("size", [b"-1", b"+22", b"nope", b"999"])
def test_invalid_or_incomplete_chunk_is_unknown(monkeypatch, size):
    chunks = size + b"\r\n" + _BODY + b"\r\n0\r\n\r\n"
    info, _ = _check(monkeypatch, _response(chunks, b"Transfer-Encoding: chunked\r\n"))
    _assert_unknown(info)


@pytest.mark.parametrize("framing", ["close", "length", "chunked"])
def test_oversized_body_is_unknown_even_with_valid_json_prefix(monkeypatch, framing):
    monkeypatch.setattr(netcheck, "_MAX_BODY", len(_BODY))
    body = _BODY + b" "
    headers = b""
    if framing == "length":
        headers = f"Content-Length: {len(body)}\r\n".encode()
    elif framing == "chunked":
        headers = b"Transfer-Encoding: chunked\r\n"
        body = f"{len(body):x}\r\n".encode() + body + b"\r\n0\r\n\r\n"
    info, _ = _check(monkeypatch, _response(body, headers))
    _assert_unknown(info)


def test_body_exactly_at_limit_is_allowed(monkeypatch):
    monkeypatch.setattr(netcheck, "_MAX_BODY", len(_BODY))
    info, _ = _check(monkeypatch, _response())
    assert info.is_tor is True


@pytest.mark.parametrize("part", ["headers", "extensions", "trailers"])
def test_framing_bytes_are_also_bounded(monkeypatch, part):
    monkeypatch.setattr(netcheck, "_MAX_RESPONSE", 200)
    if part == "headers":
        raw = _response(headers=b"X-Large: " + b"a" * 201 + b"\r\n")
    else:
        size = f"{len(_BODY):x}".encode()
        if part == "extensions":
            size += b";large=" + b"a" * 201
        chunks = size + b"\r\n" + _BODY + b"\r\n0\r\n"
        if part == "trailers":
            chunks += b"X-Large: " + b"a" * 201 + b"\r\n"
        raw = _response(chunks + b"\r\n", b"Transfer-Encoding: chunked\r\n")
    info, _ = _check(monkeypatch, raw)
    _assert_unknown(info)


@pytest.mark.parametrize(
    "url",
    [
        "",
        "check.example/api/ip",
        "ftp://check.example/api/ip",
        "https:///api/ip",
        "http://[broken/api/ip",
        "http://check.example:invalid/api/ip",
        "http://check.example:70000/api/ip",
        "http://check.example:0/api/ip",
        "http://check.example/api/ip\r\nX-Fake: yes",
        " http://check.example/api/ip",
        "http://user:secret@check.example/api/ip",
        None,
        "http://check\\.example/api/ip",
        "http://check%2eexample/api/ip",
    ],
)
def test_invalid_url_is_unknown_before_connecting(monkeypatch, url):
    def connect(*a, **k):
        pytest.fail("invalid check URL must not open a tunnel")

    monkeypatch.setattr(netcheck, "socks5_connect", connect)
    info = netcheck.check_exit("127.0.0.1", 9050, url)
    _assert_unknown(info)
    assert info.error.startswith("url:")


@pytest.mark.parametrize(
    ("url", "authority", "target"),
    [
        ("http://check.example:8080/api/ip?q=1#ignored", "check.example:8080", "/api/ip?q=1"),
        ("http://[::1]:8080", "[::1]:8080", "/"),
        ("http://münich.example/api/ip", "xn--mnich-kva.example", "/api/ip"),
    ],
)
def test_request_preserves_port_and_query(monkeypatch, url, authority, target):
    info, sock = _check(monkeypatch, _response(), url)
    assert info.is_tor is True
    assert f"GET {target} HTTP/1.1\r\n".encode() in sock.sent
    assert f"Host: {authority}\r\n".encode() in sock.sent
    assert sock.timeout == 15.0


def test_check_exit_socks_failure_is_unknown(monkeypatch):
    def boom(*a, **k):
        raise OSError("connection refused")

    monkeypatch.setattr(netcheck, "socks5_connect", boom)
    info = netcheck.check_exit("127.0.0.1", 9050, "https://check.torproject.org/api/ip")
    _assert_unknown(info)
    assert info.error.startswith("socks:")


def test_response_timeout_is_unknown_and_closes_tunnel(monkeypatch):
    class _TimedOutStream(io.BytesIO):
        def read(self, size=-1):
            raise TimeoutError("read timed out")

    sock = _Socket(b"")
    sock.stream = _TimedOutStream(_response())
    monkeypatch.setattr(netcheck, "socks5_connect", lambda *a, **k: sock)
    info = netcheck.check_exit("127.0.0.1", 9050, _URL)
    _assert_unknown(info)
    assert sock.closed
    assert sock.stream.closed


def test_tls_failure_closes_tunnel(monkeypatch):
    tunnel = _Socket(b"")
    monkeypatch.setattr(netcheck, "socks5_connect", lambda *a, **k: tunnel)

    class _Context:
        def wrap_socket(self, sock, *, server_hostname):
            assert sock is tunnel
            assert server_hostname == "check.example"
            raise ssl.SSLCertVerificationError("certificate verify failed")

    monkeypatch.setattr(netcheck.ssl, "create_default_context", _Context)
    info = netcheck.check_exit("127.0.0.1", 9050, "https://check.example/api/ip")
    _assert_unknown(info)
    assert info.error.startswith("http:")
    assert tunnel.closed


def test_https_uses_verified_context_and_closes_both_sockets(monkeypatch):
    tunnel = _Socket(b"")
    tls = _Socket(_response())
    monkeypatch.setattr(netcheck, "socks5_connect", lambda *a, **k: tunnel)
    context = ssl.create_default_context()
    assert context.check_hostname
    assert context.verify_mode == ssl.CERT_REQUIRED

    def wrap(sock, *, server_hostname):
        assert sock is tunnel
        assert server_hostname == "check.example"
        return tls

    monkeypatch.setattr(context, "wrap_socket", wrap)
    monkeypatch.setattr(netcheck.ssl, "create_default_context", lambda: context)
    info = netcheck.check_exit("127.0.0.1", 9050, "https://check.example/api/ip")
    assert info.is_tor is True
    assert tunnel.closed
    assert tls.closed
    assert tls.stream.closed


def test_exitinfo_as_dict_shape():
    d = netcheck.ExitInfo(True, "1.2.3.4").as_dict()
    assert d == {
        "is_tor": True,
        "ip": "1.2.3.4",
        "error": None,
        "country": None,
        "lat": None,
        "lon": None,
        "city": None,
    }
