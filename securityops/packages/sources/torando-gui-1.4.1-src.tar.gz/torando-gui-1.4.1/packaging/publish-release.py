#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only
"""Publish a verified release to the project's four forges without storing tokens."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

HOSTS = (
    ("github.com", "cristiancmoises", "GITHUB_TOKEN"),
    ("codeberg.org", "berkeley", "CODEBERG_TOKEN"),
    ("git.securityops.com.br", "cristiancmoises", "SECURITYOPS_BR_TOKEN"),
    ("git.securityops.co", "cristiancmoises", "SECURITYOPS_CO_TOKEN"),
)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def file_hash(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def artifact_hashes(directory: Path) -> dict[str, str]:
    """Reject unsafe names, unlisted files, symlinks and mismatched checksums."""
    checksums = directory / "SHA256SUMS"
    hashes = {}
    for line in checksums.read_text(encoding="ascii").splitlines():
        match = re.fullmatch(r"([a-f0-9]{64})  ([A-Za-z0-9][A-Za-z0-9_.-]*)", line)
        if not match:
            raise ValueError("invalid SHA256SUMS entry")
        digest, name = match.groups()
        if name in hashes or name == "SHA256SUMS":
            raise ValueError("duplicate or recursive checksum entry")
        path = directory / name
        if path.is_symlink() or not path.is_file() or file_hash(path) != digest:
            raise ValueError(f"checksum verification failed: {name}")
        hashes[name] = digest
    if not hashes or {p.name for p in directory.iterdir()} != {*hashes, "SHA256SUMS"}:
        raise ValueError("artifact directory must contain exactly the files in SHA256SUMS")
    if checksums.is_symlink():
        raise ValueError("SHA256SUMS must be a regular file")
    hashes["SHA256SUMS"] = file_hash(checksums)
    return hashes


def release_notes(project: str, version: str, root: Path) -> str:
    if project == "torando-gui":
        changelog = (root / "CHANGELOG.md").read_text()
        heading = f"## [{version}]"
        start = changelog.find(heading)
        if start < 0:
            raise ValueError("version has no changelog entry")
        end = changelog.find("\n## [", start + len(heading))
        changes = (
            changelog[start:].split("\n", 1)[1]
            if end < 0
            else changelog[start:end].split("\n", 1)[1]
        )
        intro = "Torando-Gui is the GUI for [Torando](https://github.com/cristiancmoises/torando)."
    else:
        intro = "Torando routes a selected Linux user's TCP connections and DNS through Tor."
        changes = "See the source README for setup, changes and recovery instructions."
    return (
        f"{intro}\n\n{changes.strip()}\n\n"
        "All release files are listed in `SHA256SUMS`. Download it alongside the files "
        "you need and verify their SHA-256 checksums before installing."
    )


class Forge:
    def __init__(self, host: str, owner: str, variable: str, project: str):
        self.host, self.owner, self.project = host, owner, project
        self.token = os.environ.get(variable, "")
        if not self.token:
            raise ValueError(f"missing release credential: {variable}")
        self.github = host == "github.com"
        self.api = "https://api.github.com" if self.github else f"https://{host}/api/v1"
        self.repo = f"/repos/{owner}/{project}"
        self.opener = urllib.request.build_opener(NoRedirect)

    def request(self, method: str, path: str, document=None, *, payload=None, content_type=None):
        url = path if path.startswith("https://") else self.api + path
        allowed = {urllib.parse.urlsplit(self.api).hostname}
        if self.github:
            allowed.add("uploads.github.com")
        if (
            urllib.parse.urlsplit(url).scheme != "https"
            or urllib.parse.urlsplit(url).hostname not in allowed
            or urllib.parse.urlsplit(url).username is not None
        ):
            raise ValueError("refusing to send credentials to an unexpected host")
        headers = {"Authorization": f"token {self.token}", "User-Agent": "torando-release"}
        if document is not None:
            payload = json.dumps(document).encode()
            content_type = "application/json"
        if content_type:
            headers["Content-Type"] = content_type
        req = urllib.request.Request(url, data=payload, headers=headers, method=method)  # noqa: S310 — HTTPS allowlist above
        for attempt in range(3):
            try:
                with self.opener.open(
                    req, timeout=180 if payload and len(payload) > 1 << 20 else 30
                ) as response:
                    body = response.read()
                    return json.loads(body) if body else None
            except OSError as exc:
                retry = not isinstance(exc, urllib.error.HTTPError) or exc.code in {
                    429,
                    500,
                    502,
                    503,
                    504,
                }
                if method not in {"GET", "PUT", "PATCH", "DELETE"} or not retry or attempt == 2:
                    raise
                time.sleep(2**attempt)

    def tagged_commit(self, tag: str) -> str | None:
        try:
            if self.github:
                ref = self.request("GET", self.repo + "/git/ref/tags/" + tag)["object"]
                while ref["type"] == "tag":
                    ref = self.request("GET", self.repo + "/git/tags/" + ref["sha"])["object"]
                return ref["sha"] if ref["type"] == "commit" else None
            commit = self.request("GET", self.repo + "/tags/" + tag)["commit"]
            return commit.get("sha") or commit.get("id")
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                return None
            raise

    def sync_refs(self, tag: str, commit: str, root: Path) -> None:
        repo = self.request("GET", self.repo)
        if repo.get("mirror"):
            self.request("POST", self.repo + "/mirror-sync")
            for _ in range(30):
                if self.tagged_commit(tag) == commit:
                    return
                time.sleep(3)
            raise RuntimeError(f"{self.host}: mirror has not synchronized {tag}")
        helper_source = (
            """#!/usr/bin/env python3
import os, sys
if len(sys.argv) != 2 or sys.argv[1] != "get": raise SystemExit(0)
fields = dict(line.rstrip("\\n").split("=", 1) for line in sys.stdin if "=" in line)
mapping = """
            + repr({h: (u, v) for h, u, v in HOSTS})
            + """
if fields.get("protocol") == "https" and fields.get("host") in mapping:
    owner, variable = mapping[fields["host"]]
    print("username=" + owner)
    print("password=" + os.environ[variable])
"""
        )
        with tempfile.TemporaryDirectory(prefix="torando-git-auth-") as directory:
            helper = Path(directory) / "credential-helper"
            helper.write_text(helper_source)
            helper.chmod(0o700)
            subprocess.run(  # noqa: S603 — fixed hosts and validated refs; no shell
                [
                    shutil.which("git") or "/usr/bin/git",
                    "-c",
                    "credential.helper=",
                    "-c",
                    f"credential.helper={helper}",
                    "-c",
                    "http.followRedirects=false",
                    "push",
                    f"https://{self.host}/{self.owner}/{self.project}.git",
                    f"{commit}:refs/heads/main",
                    f"refs/tags/{tag}:refs/tags/{tag}",
                ],
                cwd=root,
                env={**os.environ, "GIT_TERMINAL_PROMPT": "0"},
                check=True,
            )

    def find_release(self, tag: str):
        # Listing also finds drafts, which some tag lookup endpoints omit.
        for page in range(1, 101):
            releases = self.request(
                "GET", self.repo + f"/releases?limit=50&per_page=50&page={page}"
            )
            for release in releases:
                if release["tag_name"] == tag:
                    return release
            if len(releases) < 50:
                return None
        raise RuntimeError("too many releases to search safely")

    def assets(self, release_id: int) -> list[dict]:
        found = []
        for page in range(1, 101):
            assets = self.request(
                "GET", self.repo + f"/releases/{release_id}/assets?limit=50&per_page=50&page={page}"
            )
            found.extend(assets)
            if len(assets) < 50:
                return found
        raise RuntimeError("too many release assets")

    def upload(self, release_id: int, path: Path):
        if self.github:
            url = f"https://uploads.github.com{self.repo}/releases/{release_id}/assets?name={path.name}"
            return self.request(
                "POST", url, payload=path.read_bytes(), content_type="application/octet-stream"
            )
        boundary = "torando" + os.urandom(16).hex()
        prefix = (
            f'--{boundary}\r\nContent-Disposition: form-data; name="attachment"; '
            f'filename="{path.name}"\r\nContent-Type: application/octet-stream\r\n\r\n'
        ).encode()
        payload = prefix + path.read_bytes() + f"\r\n--{boundary}--\r\n".encode()
        return self.request(
            "POST",
            self.repo + f"/releases/{release_id}/assets?name={path.name}",
            payload=payload,
            content_type=f"multipart/form-data; boundary={boundary}",
        )


def download_hash(url: str, *, token: str | None = None, auth_host: str | None = None) -> str:
    """Hash a download; an optional draft token never follows a different host."""
    opener = urllib.request.build_opener(NoRedirect)
    for attempt in range(4):
        current = url
        try:
            for _ in range(10):
                parts = urllib.parse.urlsplit(current)
                if parts.scheme != "https" or parts.username is not None:
                    raise ValueError("release download is not a plain HTTPS URL")
                headers = {"User-Agent": "torando-release-verification"}
                if token and parts.hostname == auth_host:
                    headers["Authorization"] = "token " + token
                request = urllib.request.Request(current, headers=headers)  # noqa: S310 — HTTPS only
                try:
                    with opener.open(request, timeout=180) as response:
                        return hashlib.file_digest(response, "sha256").hexdigest()
                except urllib.error.HTTPError as exc:
                    if exc.code not in {301, 302, 303, 307, 308}:
                        raise
                    location = exc.headers.get("Location")
                    if not location:
                        raise ValueError("download redirect has no location") from exc
                    current = urllib.parse.urljoin(current, location)
            raise ValueError("too many download redirects")
        except OSError as exc:
            retry = not isinstance(exc, urllib.error.HTTPError) or exc.code in {
                404,
                429,
                500,
                502,
                503,
                504,
            }
            if not retry or attempt == 3:
                raise
            time.sleep(2**attempt)
    raise RuntimeError("download retry limit exceeded")


def publish(args) -> None:
    root = Path.cwd()
    if not re.fullmatch(r"\d+\.\d+\.\d+", args.version):
        raise ValueError("expected a semantic release version")
    if not re.fullmatch(r"[a-f0-9]{40}", args.commit):
        raise ValueError("--commit must be a full commit hash")
    tag = "v" + args.version
    head = subprocess.check_output(  # noqa: S603 — fixed read-only git command
        [shutil.which("git") or "/usr/bin/git", "rev-parse", "HEAD"], cwd=root, text=True
    )
    head = head.strip()
    if head != args.commit:
        raise ValueError("checkout does not match --commit")
    directory = args.artifacts.resolve()
    hashes = artifact_hashes(directory)
    if args.project == "torando-gui":
        spec = importlib.util.spec_from_file_location(
            "release_verifier", Path(__file__).with_name("verify-release.py")
        )
        verifier = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(verifier)
        if set(hashes) != verifier.expected_assets(args.version) | {"SHA256SUMS"}:
            raise ValueError("the complete GUI build set is required")
    elif set(hashes) != {
        f"torando-{args.version}-src.tar.gz",
        f"torando-{args.version}-src.zip",
        "SHA256SUMS",
    }:
        raise ValueError("Torando requires source tar.gz, source zip and SHA256SUMS")
    notes = (
        args.notes.read_text() if args.notes else release_notes(args.project, args.version, root)
    )
    forges = [Forge(*host, args.project) for host in HOSTS]  # Validate every token before mutation.
    for forge in forges:
        print(f"{forge.host}: checking release tag", flush=True)
        if args.sync_refs:
            forge.sync_refs(tag, args.commit, root)
        if forge.tagged_commit(tag) != args.commit:
            raise RuntimeError(f"{forge.host}: {tag} does not identify the release commit")
        repository = forge.request("GET", forge.repo)
        if repository.get("has_releases") is False:
            forge.request("PATCH", forge.repo, {"has_releases": True})
    title = "Torando-Gui" if args.project == "torando-gui" else "Torando"
    prepared = []
    for forge in forges:
        print(f"{forge.host}: preparing verified release files", flush=True)
        release = forge.find_release(tag)
        if release is None:
            release = forge.request(
                "POST",
                forge.repo + "/releases",
                {
                    "tag_name": tag,
                    "target_commitish": args.commit,
                    "name": f"{title} {args.version}",
                    "body": notes,
                    "draft": True,
                    "prerelease": False,
                },
            )
        release_id = release["id"]
        assets = {asset["name"]: asset for asset in forge.assets(release_id)}
        if set(assets) - set(hashes):
            raise ValueError(f"{forge.host}: release contains unexpected assets")
        if not release["draft"] and set(assets) != set(hashes):
            raise ValueError(f"{forge.host}: refusing to modify an incomplete public release")
        for name, digest in hashes.items():
            path = directory / name
            if name in assets and not release["draft"]:
                if download_hash(assets[name]["browser_download_url"]) != digest:
                    raise ValueError(f"{forge.host}: published asset differs: {name}")
            elif name in assets and not assets[name].get("digest"):  # noqa: SIM102
                # Forgejo exposes draft downloads to the repository token even
                # though it provides no digest field in asset metadata.
                if (
                    download_hash(
                        assets[name]["browser_download_url"],
                        token=forge.token,
                        auth_host=forge.host,
                    )
                    != digest
                ):
                    raise ValueError(f"{forge.host}: draft asset differs: {name}")
            if name not in assets:
                print(f"{forge.host}: uploading {name}", flush=True)
                try:
                    assets[name] = forge.upload(release_id, path)
                except OSError:
                    # The server may have saved the upload before the connection
                    # closed. Recover only after verifying that complete file.
                    recovered = [a for a in forge.assets(release_id) if a["name"] == name]
                    if len(recovered) != 1:
                        raise
                    asset = recovered[0]
                    if (
                        download_hash(
                            asset["browser_download_url"], token=forge.token, auth_host=forge.host
                        )
                        != digest
                    ):
                        raise ValueError(
                            f"{forge.host}: interrupted upload differs: {name}"
                        ) from None
                    assets[name] = asset
            asset = assets[name]
            if asset["size"] != path.stat().st_size:
                raise ValueError(f"{forge.host}: asset size mismatch for {name}")
            remote_digest = asset.get("digest")
            if remote_digest and remote_digest != "sha256:" + digest:
                raise ValueError(f"{forge.host}: asset checksum mismatch for {name}")
        prepared.append((forge, release, assets))
    # Every forge has a complete staged set before any new release becomes public.
    for forge, release, assets in prepared:
        print(f"{forge.host}: publishing and checking public downloads", flush=True)
        if release["draft"]:
            release = forge.request(
                "PATCH", forge.repo + f"/releases/{release['id']}", {"draft": False, "body": notes}
            )
        # GitHub draft uploads can have provisional URLs. Read the final
        # metadata after publication instead of using the upload response.
        assets = {asset["name"]: asset for asset in forge.assets(release["id"])}
        if set(assets) != set(hashes):
            raise ValueError(f"{forge.host}: published asset list is incomplete")
        for name, digest in hashes.items():
            asset = assets[name]
            if download_hash(asset["browser_download_url"]) != digest:
                raise ValueError(f"{forge.host}: public download checksum mismatch for {name}")
        print(f"Verified release: {release['html_url']}", flush=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True, choices=["torando", "torando-gui"])
    parser.add_argument("--version", required=True)
    parser.add_argument("--commit", required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--notes", type=Path)
    parser.add_argument(
        "--sync-refs", action="store_true", help="push main/tag, or synchronize a pull mirror"
    )
    args = parser.parse_args()
    try:
        publish(args)
    except (OSError, ValueError, RuntimeError, subprocess.CalledProcessError) as exc:
        print(f"Release failed: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
