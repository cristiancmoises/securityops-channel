#!/bin/sh
# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only
#
# Stage the Windows ALL-IN-ONE release: the pure-Python package plus a bundled
# embeddable CPython and the Tor Expert Bundle, so the user needs neither Python
# nor Tor pre-installed — just unzip and run install.ps1. Buildable on Linux
# (downloads the Windows binaries and assembles the tree; no Windows toolchain).
set -eu
. "$(dirname -- "$0")/_common.sh"

require zip "install the 'zip' package" || exit 1
require curl "install 'curl'" || exit 1
require python3 "install Python 3.11 or newer" || exit 1

# Pins verified against python.org release checksums and Tor's
# sha256sums-signed-build.txt. Custom versions must supply their own checksum.
PYVER="${TORANDO_PYVER:-3.13.15}"
TORVER="${TORANDO_TORVER:-15.0.21}"
PY_SHA256="${TORANDO_PY_SHA256:-}"
TOR_SHA256="${TORANDO_TOR_SHA256:-}"
if [ "$PYVER" = 3.13.15 ] && [ -z "$PY_SHA256" ]; then
    PY_SHA256=d1f04d990aee1253d8569e8e5104e30fa9f5fa830899f14843448872d936a2cf
fi
if [ "$TORVER" = 15.0.21 ] && [ -z "$TOR_SHA256" ]; then
    TOR_SHA256=f22b8b17cb18c9fa775dfcf68acf6a2fe788336535fe94645204ca85158aa490
fi
if [ -z "$PY_SHA256" ] || [ -z "$TOR_SHA256" ]; then
    echo "error: custom versions require TORANDO_PY_SHA256 / TORANDO_TOR_SHA256" >&2
    exit 1
fi
PY_URL="https://www.python.org/ftp/python/${PYVER}/python-${PYVER}-embed-amd64.zip"
TOR_URL="https://archive.torproject.org/tor-package-archive/torbrowser/${TORVER}/tor-expert-bundle-windows-x86_64-${TORVER}.tar.gz"

CACHE="$ROOT/build/windows-cache"
mkdir -p "$CACHE"
PY_ZIP="$CACHE/python-${PYVER}-embed-amd64.zip"
TOR_TGZ="$CACHE/tor-expert-bundle-${TORVER}.tar.gz"
DOWNLOAD=""
TT=""
trap 'rm -f "${DOWNLOAD:-}"; [ -z "${TT:-}" ] || rm -rf "$TT"' EXIT
trap 'exit 1' HUP INT TERM

check_sha256() {
    python3 - "$1" "$2" <<'PYEOF'
import hashlib
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
with path.open("rb") as source:
    actual = hashlib.file_digest(source, "sha256").hexdigest()
if actual != sys.argv[2].lower():
    sys.exit(f"error: SHA256 mismatch for {path.name}; delete the cache file and retry")
PYEOF
}

fetch_verified() {
    if [ ! -f "$2" ]; then
        echo "fetching ${2##*/}..." >&2
        DOWNLOAD=$(mktemp "$CACHE/.download.XXXXXX")
        curl -fsSL --retry 3 --connect-timeout 30 --max-time 600 "$1" -o "$DOWNLOAD"
        check_sha256 "$DOWNLOAD" "$3"
        mv "$DOWNLOAD" "$2"
        DOWNLOAD=""
    else
        check_sha256 "$2" "$3"
    fi
}
fetch_verified "$PY_URL" "$PY_ZIP" "$PY_SHA256"
fetch_verified "$TOR_URL" "$TOR_TGZ" "$TOR_SHA256"

TOP="$ROOT/build/windows/${PKGNAME}-${VERSION}"
rm -rf "$TOP"
install -d "$TOP/lib" "$TOP/python" "$TOP/tor"

# 1) The application package.
cp -r "$ROOT/backend/torando_gui" "$TOP/lib/torando_gui"
find "$TOP/lib" -name '__pycache__' -type d -prune -exec rm -rf {} +

# 2) Embeddable CPython. Extract, then point its isolated path file at ..\lib so
#    `python -m torando_gui` resolves the bundled package (an embeddable Python
#    with a ._pth uses ONLY those paths and ignores PYTHONPATH).
python3 -m zipfile -e "$PY_ZIP" "$TOP/python"
set -- "$TOP/python"/python*._pth
if [ "$#" -ne 1 ] || [ ! -f "$1" ]; then
    echo "error: missing or ambiguous Python path file" >&2
    exit 1
fi
PTH="$1"
printf '..\\lib\n' >> "$PTH"

# 3) Tor: tor.exe + DLLs under tor\, geoip data under tor\data\.
TT=$(mktemp -d)
tar -C "$TT" -xzf "$TOR_TGZ"
cp -r "$TT/tor/." "$TOP/tor/"
cp -r "$TT/docs" "$TOP/tor/docs"
install -d "$TOP/tor/data"
cp "$TT/data/geoip" "$TT/data/geoip6" "$TOP/tor/data/"
rm -rf "$TT"
TT=""

# 4) Bootstrap scripts (explicit sys.path + logging), launchers, installer.
install -d "$TOP/boot"
install -m 0644 "$PKG_DIR/windows/boot/daemon.py" "$TOP/boot/daemon.py"
install -m 0644 "$PKG_DIR/windows/boot/gui.py"    "$TOP/boot/gui.py"
install -m 0644 "$PKG_DIR/windows/torando-guid.cmd" "$TOP/torando-guid.cmd"
install -m 0644 "$PKG_DIR/windows/torando-gui.cmd"  "$TOP/torando-gui.cmd"
install -m 0644 "$PKG_DIR/windows/install.ps1"      "$TOP/install.ps1"
install -m 0644 "$PKG_DIR/windows/uninstall.ps1"    "$TOP/uninstall.ps1"
install -m 0644 "$PKG_DIR/windows/torrc.template"   "$TOP/torrc.template"
install -m 0644 "$ROOT/README.md"       "$TOP/README.md"
install -m 0644 "$ROOT/THREAT_MODEL.md" "$TOP/THREAT_MODEL.md"
install -m 0644 "$ROOT/LICENSE"         "$TOP/LICENSE.txt"

# Record what was bundled (for provenance / updates).
cat > "$TOP/BUNDLED.txt" <<EOF
torando-gui $VERSION - Windows all-in-one
Bundled CPython:  $PYVER  ($PY_URL)
CPython SHA256:   $PY_SHA256
Bundled Tor:      $TORVER ($TOR_URL)
Tor SHA256:       $TOR_SHA256

Torando-Gui is the GUI for Torando.
For runtime security updates, install a newer Torando-Gui release. If updating
Tor manually, replace the complete tor directory, including its DLLs and data.
EOF

# GUARD: PowerShell 5.1 reads a BOM-less .ps1 as the system ANSI codepage, so a
# non-ASCII char (em-dash, accented letter) becomes mojibake and the script
# fails to PARSE ("does not install"). .cmd has the same hazard. Fail the build
# if any shipped script is not pure ASCII.
python3 - "$TOP" <<'PYEOF'
import sys, glob, os
top = sys.argv[1]
bad = []
for pat in ("*.ps1", "*.cmd"):
    for f in glob.glob(os.path.join(top, "**", pat), recursive=True):
        data = open(f, "rb").read()
        nz = [(i, b) for i, b in enumerate(data) if b > 127]
        if nz:
            bad.append((f, nz[0]))
if bad:
    for f, (i, b) in bad:
        sys.stderr.write(f"NON-ASCII in {f} at byte {i} (0x{b:02X}) -- would break PowerShell/cmd\n")
    sys.exit(1)
print("  ascii-guard: all .ps1/.cmd are pure ASCII")
PYEOF

mkdir -p "$DIST"
OUT="$DIST/${PKGNAME}-${VERSION}-windows.zip"
rm -f "$OUT"
( cd "$ROOT/build/windows" && zip -qry "$OUT" "${PKGNAME}-${VERSION}" )
echo "built: $OUT  (all-in-one: Python ${PYVER} + Tor ${TORVER})"
