#!/bin/sh
# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only
# Build torando-gui-<ver>-x86_64.AppImage
set -eu
. "$(dirname -- "$0")/_common.sh"

APPDIR="$ROOT/build/AppDir"
stage_tree "$APPDIR"   # puts the package under $APPDIR/usr/lib/torando-gui
install -d "$APPDIR/usr/share/licenses/$PKGNAME"
install -m 0644 "$ROOT/LICENSE" "$APPDIR/usr/share/licenses/$PKGNAME/LICENSE"

# AppImage top-level requirements
install -m 0755 "$PKG_DIR/AppRun" "$APPDIR/AppRun"
install -m 0644 "$PKG_DIR/desktop/torando-gui.desktop" "$APPDIR/torando-gui.desktop"
python3 "$PKG_DIR/icons/make_icon.py" "$APPDIR/torando-gui.png" 256 >/dev/null
# top-level icon also expected as .DirIcon
cp "$APPDIR/torando-gui.png" "$APPDIR/.DirIcon"

# Verify cached files too; a partial or altered download must never be used.
fetch_verified() {
    fetch_cache=$1 fetch_url=$2 fetch_digest=$3
    require sha256sum "install 'coreutils'" || exit 1
    if [ ! -f "$fetch_cache" ]; then
        require curl "install 'curl' to download AppImage build tools" || exit 1
        download=$(mktemp "$fetch_cache.XXXXXX")
        trap 'rm -f "$download"' EXIT
        trap 'exit 129' HUP
        trap 'exit 130' INT
        trap 'exit 143' TERM
        echo "fetching $(basename "$fetch_cache")…" >&2
        curl --fail --silent --show-error --location --retry 3 --connect-timeout 30 \
            "$fetch_url" -o "$download"
        printf '%s  %s\n' "$fetch_digest" "$download" | sha256sum -c -
        chmod 0755 "$download"
        mv "$download" "$fetch_cache"
        trap - EXIT HUP INT TERM
    fi
    printf '%s  %s\n' "$fetch_digest" "$fetch_cache" | sha256sum -c -
}

# Builders can supply local tools for offline builds. The defaults pin both
# appimagetool and the runtime it embeds to official versioned release assets.
TOOL="${APPIMAGETOOL:-}"
if [ -z "$TOOL" ]; then
    TOOL_VERSION=1.9.1
    TOOL="$ROOT/build/appimagetool-$TOOL_VERSION-x86_64.AppImage"
    fetch_verified "$TOOL" \
        "https://github.com/AppImage/appimagetool/releases/download/$TOOL_VERSION/appimagetool-x86_64.AppImage" \
        ed4ce84f0d9caff66f50bcca6ff6f35aae54ce8135408b3fa33abfc3cb384eb0
fi
RUNTIME="${APPIMAGE_RUNTIME:-}"
if [ -z "$RUNTIME" ]; then
    RUNTIME_VERSION=20251108
    RUNTIME="$ROOT/build/appimage-runtime-$RUNTIME_VERSION-x86_64"
    fetch_verified "$RUNTIME" \
        "https://github.com/AppImage/type2-runtime/releases/download/$RUNTIME_VERSION/runtime-x86_64" \
        2fca8b443c92510f1483a883f60061ad09b46b978b2631c807cd873a47ec260d
fi

mkdir -p "$DIST"
OUT="$DIST/${PKGNAME}-${VERSION}-x86_64.AppImage"

# Many CI/container hosts lack FUSE; the runtime's environment switch avoids
# it and also works when APPIMAGETOOL points to an extracted executable.
export ARCH="x86_64"
export VERSION
APPIMAGE_EXTRACT_AND_RUN=1 "$TOOL" --runtime-file "$RUNTIME" "$APPDIR" "$OUT"
echo "built: $OUT"
