#!/bin/sh
# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (c) 2026 Cristian Cezar Moisés
# A release is complete only when every supported package has passed verification.
set -eu
. "$(dirname -- "$0")/_common.sh"

python3 "$PKG_DIR/verify-release.py" --metadata-only
if [ -n "$(git -C "$ROOT" status --porcelain --untracked-files=normal)" ]; then
    echo "error: commit source changes before building a release" >&2
    exit 1
fi
FINAL="$DIST/v$VERSION"
if [ -e "$FINAL" ]; then
    echo "error: $FINAL already exists; move it aside before rebuilding" >&2
    exit 1
fi
mkdir -p "$ROOT/build" "$DIST"
STAGING=$(mktemp -d "$ROOT/build/release.XXXXXX")
trap 'rm -rf "$STAGING"' EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
export TORANDO_DIST="$STAGING"

for format in deb rpm tarball appimage windows macos; do
    sh "$PKG_DIR/build-$format.sh"
done
sh "$PKG_DIR/build-bsd.sh" freebsd
sh "$PKG_DIR/build-bsd.sh" openbsd
sh "$PKG_DIR/build-source.sh"
python3 -m build --wheel --outdir "$STAGING" "$ROOT"
python3 "$PKG_DIR/verify-release.py" "$STAGING" --write-checksums
python3 "$PKG_DIR/verify-release.py" "$STAGING"
mv "$STAGING" "$FINAL"
echo "release ready: $FINAL"
