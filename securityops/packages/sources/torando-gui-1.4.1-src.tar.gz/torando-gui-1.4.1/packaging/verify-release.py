#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (c) 2026 Cristian Cezar Moisés
"""Reject incomplete, stale or damaged release sets before uploading anything."""

from __future__ import annotations

import argparse
import hashlib
import io
import plistlib
import re
import subprocess
import tarfile
import tomllib
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def release_version(root: Path = ROOT) -> str:
    with (root / "pyproject.toml").open("rb") as source:
        return tomllib.load(source)["project"]["version"]


def expected_assets(version: str) -> set[str]:
    return {
        f"torando-gui_{version}_all.deb",
        f"torando-gui-{version}-1.noarch.rpm",
        f"torando-gui-{version}.tar.zst",
        f"torando-gui-{version}-x86_64.AppImage",
        f"torando-gui-{version}-windows.zip",
        f"torando-gui-{version}-macos.zip",
        f"torando-gui-{version}-freebsd.tar.gz",
        f"torando-gui-{version}-openbsd.tar.gz",
        f"torando-gui-{version}-source.tar.gz",
        f"torando_gui-{version}-py3-none-any.whl",
    }


def check_module(data: bytes, version: str) -> None:
    match = re.search(rb'^__version__ = "([^"]+)"$', data, re.MULTILINE)
    if match is None or match[1].decode() != version:
        raise ValueError(f"packaged Python version does not match {version}")


def check_versions(root: Path, version: str) -> None:
    check_module((root / "backend/torando_gui/__init__.py").read_bytes(), version)
    definitions = {
        "packaging/PKGBUILD": f"pkgver={version}",
        "packaging/torando-gui.spec": f"Version:        {version}",
        "packaging/guix.scm": f'(version "{version}")',
        "packaging/macos/torando-gui.rb": f"/v{version}.tar.gz",
    }
    for name, marker in definitions.items():
        if marker not in (root / name).read_text():
            raise ValueError(f"{name} does not match version {version}")
    with (root / "packaging/macos/Info.plist").open("rb") as source:
        info = plistlib.load(source)
    for key in ("CFBundleShortVersionString", "CFBundleVersion"):
        if info.get(key) != version:
            raise ValueError(f"macOS {key} does not match version {version}")


def check_file_set(directory: Path, version: str, *, checksums: bool) -> list[Path]:
    expected = expected_assets(version)
    if checksums:
        expected.add("SHA256SUMS")
    actual = {path.name for path in directory.iterdir()}
    if actual != expected:
        raise ValueError(
            f"release files differ: missing={sorted(expected - actual)}, "
            f"unexpected={sorted(actual - expected)}"
        )
    paths = [directory / name for name in sorted(expected_assets(version))]
    for path in paths:
        if path.is_symlink() or not path.is_file() or path.stat().st_size == 0:
            raise ValueError(f"empty or invalid release asset: {path.name}")
    return paths


def read_tar(archive: tarfile.TarFile, name: str) -> bytes:
    member = archive.extractfile(name)
    if member is None:
        raise ValueError(f"missing archive file: {name}")
    return member.read()


def check_bundle(path: Path, version: str) -> None:
    top = f"torando-gui-{version}/"
    module = top + "lib/torando_gui/__init__.py"
    common = ["lib/torando_gui/webroot/app.js", "lib/torando_gui/webroot/index.html"]
    if path.suffix == ".zip":
        with zipfile.ZipFile(path) as archive:
            bad = archive.testzip()
            if bad:
                raise ValueError(f"damaged zip member: {bad}")
            required = [*common, "README.md", "THREAT_MODEL.md"]
            if path.name.endswith("-windows.zip"):
                required += [
                    "python/python.exe",
                    "tor/tor.exe",
                    "tor/data/geoip",
                    "tor/data/geoip6",
                    "boot/daemon.py",
                    "boot/gui.py",
                    "install.ps1",
                    "uninstall.ps1",
                    "torando-gui.cmd",
                    "torando-guid.cmd",
                    "BUNDLED.txt",
                ]
            else:
                required += [
                    "Torando Control.app/Contents/Info.plist",
                    "Torando Control.app/Contents/MacOS/torando-gui",
                    "bin/torando-gui",
                    "bin/torando-guid",
                    "install.sh",
                    "uninstall.sh",
                ]
            for member in required:
                if archive.getinfo(top + member).file_size == 0:
                    raise ValueError(f"empty bundle member: {member}")
            check_module(archive.read(module), version)
    else:
        with tarfile.open(path, "r:gz") as archive:
            required = [*common, "bin/torando-gui", "bin/torando-guid", "install.sh"]
            service = "torando-gui" if path.name.endswith("-freebsd.tar.gz") else "torando_gui"
            required += ["uninstall.sh", "rc/" + service, "README.md", "THREAT_MODEL.md"]
            for member in required:
                if not read_tar(archive, top + member):
                    raise ValueError(f"empty bundle member: {member}")
            check_module(read_tar(archive, module), version)


def command(*args: str | Path, data: bytes | None = None) -> bytes:
    # Only the checked-in build tools and locally built AppImage are invoked.
    return subprocess.check_output([str(arg) for arg in args], input=data)  # noqa: S603


def check_rpm_scripts(scripts: bytes) -> None:
    if b"%systemd_" in scripts:
        raise ValueError("RPM contains unexpanded systemd macros")
    command("sh", "-n", data=scripts)


def check_asset(path: Path, version: str) -> None:
    top = f"torando-gui-{version}/"
    if path.name.endswith("-source.tar.gz"):
        with tarfile.open(path, "r:gz") as archive:
            metadata = tomllib.loads(read_tar(archive, top + "pyproject.toml").decode())
            if metadata["project"]["version"] != version:
                raise ValueError("source archive version mismatch")
            check_module(read_tar(archive, top + "backend/torando_gui/__init__.py"), version)
            for member in ("Makefile", "LICENSE", "README.md", "packaging/build-release.sh"):
                read_tar(archive, top + member)
    elif path.suffix == ".whl":
        with zipfile.ZipFile(path) as archive:
            if archive.testzip():
                raise ValueError("damaged wheel")
            check_module(archive.read("torando_gui/__init__.py"), version)
            metadata = archive.read(f"torando_gui-{version}.dist-info/METADATA").decode()
            if f"\nVersion: {version}\n" not in metadata:
                raise ValueError("wheel metadata version mismatch")
            archive.getinfo("torando_gui/webroot/app.js")
            archive.getinfo("torando_gui/webroot/index.html")
    elif path.suffix == ".deb":
        if command("dpkg-deb", "--field", path, "Version").decode().strip() != version:
            raise ValueError("Debian package version mismatch")
        with tarfile.open(fileobj=io.BytesIO(command("dpkg-deb", "--fsys-tarfile", path))) as tree:
            check_module(read_tar(tree, "./usr/lib/torando-gui/torando_gui/__init__.py"), version)
    elif path.suffix == ".rpm":
        value = command("rpm", "-qp", "--queryformat", "%{VERSION}-%{RELEASE} %{ARCH}", path)
        if value.decode() != f"{version}-1 noarch":
            raise ValueError("RPM package version or architecture mismatch")
        scripts = command("rpm", "-qp", "--queryformat", "%{POSTIN}\n%{PREUN}\n%{POSTUN}", path)
        check_rpm_scripts(scripts)
    elif path.name.endswith(".tar.zst"):
        module = top + "root/usr/lib/torando-gui/torando_gui/__init__.py"
        check_module(command("tar", "--zstd", "-xOf", path, module), version)
    elif path.suffix == ".AppImage":
        with path.open("rb") as executable:
            magic = executable.read(4)
        if magic != b"\x7fELF":
            raise ValueError("AppImage is not an ELF executable")
        offset = command(path.resolve(), "--appimage-offset").decode().strip()
        if not offset.isdecimal():
            raise ValueError("invalid AppImage filesystem offset")
        module = "usr/lib/torando-gui/torando_gui/__init__.py"
        check_module(command("unsquashfs", "-cat", "-offset", offset, path, module), version)
    else:
        check_bundle(path, version)


def checksum_text(paths: list[Path]) -> str:
    lines = []
    for path in paths:
        with path.open("rb") as source:
            digest = hashlib.file_digest(source, "sha256").hexdigest()
        lines.append(f"{digest}  {path.name}\n")
    return "".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", nargs="?", type=Path)
    parser.add_argument("--write-checksums", action="store_true")
    parser.add_argument("--metadata-only", action="store_true")
    args = parser.parse_args()
    version = release_version()
    try:
        check_versions(ROOT, version)
        if args.metadata_only:
            print(f"version metadata matches {version}")
            return
        directory = args.directory or ROOT / "dist" / f"v{version}"
        paths = check_file_set(directory, version, checksums=not args.write_checksums)
        for path in paths:
            check_asset(path, version)
        checksums = checksum_text(paths)
        if args.write_checksums:
            (directory / "SHA256SUMS").write_text(checksums)
        elif (directory / "SHA256SUMS").read_text() != checksums:
            raise ValueError("SHA256SUMS does not match the release assets")
    except (
        OSError,
        ValueError,
        KeyError,
        tarfile.TarError,
        zipfile.BadZipFile,
        subprocess.CalledProcessError,
    ) as error:
        parser.exit(1, f"release verification failed: {error}\n")
    print(f"verified {len(paths)} release assets for {version}")


if __name__ == "__main__":
    main()
