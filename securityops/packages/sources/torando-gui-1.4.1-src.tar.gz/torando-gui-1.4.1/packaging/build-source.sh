#!/bin/sh
# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (c) 2026 Cristian Cezar Moisés
set -eu
. "$(dirname -- "$0")/_common.sh"

require git "install git to archive the release commit"
if [ -n "$(git -C "$ROOT" status --porcelain --untracked-files=normal)" ]; then
    echo "error: commit source changes before building release sources" >&2
    exit 1
fi
mkdir -p "$DIST"
OUT="$DIST/${PKGNAME}-${VERSION}-source.tar.gz"
git -C "$ROOT" archive --format=tar.gz --prefix="${PKGNAME}-${VERSION}/" \
    --output="$OUT" HEAD
echo "built: $OUT"
