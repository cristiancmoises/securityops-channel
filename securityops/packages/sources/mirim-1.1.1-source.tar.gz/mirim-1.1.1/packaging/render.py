#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Render downstream recipes using actual release bytes, never guessed hashes."""

import argparse
import base64
import hashlib
import json
import pathlib
import re
import tarfile
import zipfile


def guix_base32(digest):
    alphabet = "0123456789abcdfghijklmnpqrsvwxyz"
    value = int.from_bytes(digest, "little")
    return "".join(alphabet[(value >> (5 * index)) & 31] for index in range(51, -1, -1))


def hashes(path, prefix):
    data = path.read_bytes()
    sha256 = hashlib.sha256(data).digest()
    return {
        prefix + "_SHA256": sha256.hex(),
        prefix + "_SHA256_UPPER": sha256.hex().upper(),
        prefix + "_SHA512": hashlib.sha512(data).hexdigest(),
        prefix + "_SRI": "sha256-" + base64.b64encode(sha256).decode(),
        prefix + "_GUIX": guix_base32(sha256),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("version")
    parser.add_argument("artifacts", type=pathlib.Path)
    parser.add_argument("output", type=pathlib.Path)
    args = parser.parse_args()
    if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", args.version):
        parser.error("version must be X.Y.Z")
    if args.output.exists() and any(args.output.iterdir()):
        parser.error("output directory must be empty")
    prefix = "mirim-" + args.version
    source = args.artifacts / (prefix + "-source.tar.gz")
    vendor = args.artifacts / (prefix + "-vendor.tar.gz")
    windows = args.artifacts / (prefix + "-x86_64-windows.zip")
    for artifact in (source, vendor):
        if not artifact.is_file():
            parser.error(f"missing required artifact: {artifact}")
    values = {"VERSION": args.version, **hashes(source, "SOURCE"), **hashes(vendor, "VENDOR")}
    with tarfile.open(source) as archive:
        manifest = archive.extractfile(prefix + "/Cargo.toml").read().decode()
        actual = re.search(r'^version = "([^"]+)"', manifest, re.M)[1]
        if actual != args.version:
            parser.error(f"source Cargo.toml version is {actual}")
        lock = archive.extractfile(prefix + "/Cargo.lock").read()
        doc_names = {"README.md", "README.pt-BR.md", "SECURITY.md", "LICENSE",
                     "LICENSE-AGPL-3.0", "LICENSE-COMMERCIAL", "NOTICE",
                     "LICENSING.md", "LICENSING.pt-BR.md"}
        docs = []
        for member in archive.getmembers():
            if not member.isfile() or not member.name.startswith(prefix + "/"):
                continue
            name = member.name[len(prefix) + 1:]
            if name in doc_names or name.startswith(("docs/", "samples/")):
                if ".." in pathlib.PurePosixPath(name).parts or "\n" in name:
                    parser.error("unsafe source archive path")
                docs.append("share/doc/mirim/" + name)
    with tarfile.open(vendor) as archive:
        names = set(archive.getnames())
        if ".cargo/config.toml" not in names or not any(name.startswith("vendor/") for name in names):
            parser.error("vendor archive must contain .cargo/config.toml and vendor/")
    if windows.is_file():
        with zipfile.ZipFile(windows) as archive:
            if not {"mirim.exe", "mirim-sign.exe"}.issubset(archive.namelist()):
                parser.error("Windows ZIP must contain both executables at its root")
        values.update(hashes(windows, "WINDOWS"))
    templates = pathlib.Path(__file__).parent / "templates"
    for template in sorted(templates.rglob("*")):
        if not template.is_file():
            continue
        relative = template.relative_to(templates)
        if relative.parts[0] in ("scoop", "winget") and not windows.is_file():
            continue
        result = re.sub(r"@([A-Z_0-9]+)@", lambda match: values[match[1]], template.read_text())
        destination = args.output / str(relative).removesuffix(".in")
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(result)
    (args.output / "nix/Cargo.lock").write_bytes(lock)
    with (args.output / "pkgsrc/PLIST").open("a") as output:
        for name in sorted(docs):
            print(name, file=output)
    directories = {"share/doc/mirim/"}
    for name in docs:
        path = pathlib.PurePosixPath(name).parent
        while str(path) != "share/doc":
            directories.add(str(path) + "/")
            path = path.parent
    with (args.output / "openbsd/pkg/PLIST").open("a") as output:
        for name in sorted(directories | set(docs)):
            print(name, file=output)
    freebsd, pkgsrc, openbsd = [], ["$NetBSD$\n"], []
    for artifact in (source, vendor):
        data = artifact.read_bytes()
        name = artifact.name
        size = len(data)
        freebsd.extend([f"SHA256 ({name}) = {hashlib.sha256(data).hexdigest()}", f"SIZE ({name}) = {size}"])
        pkgsrc.extend([f"BLAKE2s ({name}) = {hashlib.blake2s(data).hexdigest()}",
                       f"SHA512 ({name}) = {hashlib.sha512(data).hexdigest()}", f"Size ({name}) = {size} bytes"])
        openbsd.extend([f"SHA256 ({name}) = {base64.b64encode(hashlib.sha256(data).digest()).decode()}",
                        f"SIZE ({name}) = {size}"])
    for name, lines in (("freebsd", freebsd), ("pkgsrc", pkgsrc), ("openbsd", openbsd)):
        (args.output / name / "distinfo").write_text("\n".join(lines) + "\n")
    receipt = {"version": args.version, "hashes": values,
               "status": "Prepared for native validation; no upstream submission implied"}
    (args.output / "provenance.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(f"Recipes written to {args.output}; validate natively before submitting.")
    if not windows.is_file():
        print("Windows recipes skipped: release ZIP is not available.")


if __name__ == "__main__":
    main()
