;;; mirim.scm — GNU Guix package for the mirim encrypted database.
;;;
;;; Installs the mirim CLI/REPL (`mirim`), the ML-DSA-87 signing tool
;;; (`mirim-sign`), and the secure-by-default desktop GUI (`mirim-gui`).
;;;
;;; This packages the release binaries and desktop integration. The
;;; release tarball is verified by hash, the ELF interpreter/RPATH are
;;; patched to this Guix's glibc, and the GUI is wrapped so its runtime
;;; dlopen of GL / X11 / Wayland / font libraries resolves. For an offline
;;; source build of the CLI and signing tool using the release's vendored
;;; dependencies, see packaging/templates/guix and packaging/README.
;;;
;;; Install:   guix install -f mirim.scm
;;; Try it:    guix build -f mirim.scm          # just build, don't install
;;; Run:       mirim mydata.mrm                 # CLI/REPL
;;;            mirim-gui                         # desktop GUI
;;;
;;; Verify the download independently:
;;;   mirim-sign verify <artifact> <artifact>.mf mirim-release.pub
;;;
;;; Copyright (c) 2026 Cristian Cezar Moisés — MIT (this packaging file).

(use-modules (guix packages)
             (guix download)
             (guix gexp)
             (guix build-system gnu)
             ((guix licenses) #:prefix license:)
             (gnu packages base)          ; glibc
             (gnu packages bash)          ; bash-minimal (wrap-program)
             (gnu packages elf)           ; patchelf
             (gnu packages gcc)           ; gcc "lib" output
             (gnu packages gl)            ; mesa
             (gnu packages xorg)          ; libx11, libxcursor, …
             (gnu packages xdisorg)       ; libxkbcommon
             (gnu packages freedesktop)   ; wayland
             (gnu packages fontutils))    ; fontconfig, freetype

(define %mirim-version "1.1.1")

(define-public mirim
  (package
    (name "mirim")
    (version %mirim-version)
    (source
     (origin
       (method url-fetch)
       (uri (string-append
             "https://github.com/cristiancmoises/mirim/releases/download/v"
             version "/mirim-" version "-x86_64-linux.tar.gz"))
       (sha256
        (base32 "0z1zwwzbymlixwzz47x6xqh32xvva7zhkirpb3457q1zs8lxz4nm"))))
    (build-system gnu-build-system)
    (arguments
     `(#:strip-binaries? #f            ; already stripped; keep patchelf happy
       #:phases
       (modify-phases %standard-phases
         (delete 'configure)
         (delete 'build)
         (delete 'check)
         (replace 'install
           (lambda* (#:key inputs outputs #:allow-other-keys)
             (let* ((out    (assoc-ref outputs "out"))
                    (bin    (string-append out "/bin"))
                    (doc    (string-append out "/share/doc/mirim-" ,version))
                    (glibc  (assoc-ref inputs "glibc"))
                    (ld     (string-append glibc "/lib/ld-linux-x86-64.so.2"))
                    (core   (string-append glibc "/lib:"
                                           (assoc-ref inputs "gcc:lib") "/lib"))
                    ;; Libraries the GUI dlopens at runtime.
                    (gui-libs
                     (map (lambda (n) (string-append (assoc-ref inputs n) "/lib"))
                          '("mesa" "libx11" "libxcursor" "libxrandr" "libxi"
                            "libxkbcommon" "wayland" "fontconfig" "freetype"
                            "libxext" "libxfixes" "libxrender" "libxcb"
                            "gcc:lib"))))
               (mkdir-p bin)
               ;; CLI tools: interpreter + rpath to glibc/libgcc only.
               (for-each
                (lambda (b)
                  (install-file b bin)
                  (let ((p (string-append bin "/" b)))
                    (invoke "patchelf" "--set-interpreter" ld p)
                    (invoke "patchelf" "--set-rpath" core p)))
                '("mirim" "mirim-sign"))
               ;; GUI: interpreter + rpath incl. the graphics libraries so a
               ;; bare dlopen("libGL.so.1") etc. resolves from the caller's
               ;; run path.
               (install-file "mirim-gui" bin)
               (let ((p (string-append bin "/mirim-gui")))
                 (invoke "patchelf" "--set-interpreter" ld p)
                 ;; Plain --set-rpath writes DT_RUNPATH (what Guix validates and
                 ;; what resolves the binary's own NEEDED libc/libgcc/libm); the
                 ;; GUI's runtime dlopen of GL/X11/Wayland is handled by the
                 ;; LD_LIBRARY_PATH wrapper added below.
                 (invoke "patchelf" "--set-rpath"
                         (string-join (cons core gui-libs) ":") p))
               ;; Docs + samples.
               (mkdir-p doc)
               (for-each (lambda (f) (when (file-exists? f) (install-file f doc)))
                         '("README.md" "README.pt-BR.md" "LICENSE" "LICENSE-AGPL-3.0"
                           "LICENSE-COMMERCIAL" "NOTICE" "LICENSING.md" "LICENSING.pt-BR.md"
                           "SECURITY.md" "GUIDE.md" "FONT_LICENSES.txt"))
               (when (file-exists? "docs")
                 (copy-recursively "docs" (string-append doc "/docs")))
               (when (file-exists? "samples")
                 (copy-recursively "samples" (string-append doc "/samples")))
               ;; Desktop launcher entry + icon, so mirim-gui appears in the
               ;; applications menu (files come from this repo via local-file).
               (let ((appdir  (string-append out "/share/applications"))
                     (icondir (string-append out "/share/icons/hicolor/256x256/apps")))
                 (mkdir-p appdir)
                 (copy-file (assoc-ref inputs "mirim-desktop")
                            (string-append appdir "/mirim.desktop"))
                 (mkdir-p icondir)
                 (copy-file (assoc-ref inputs "mirim-icon")
                            (string-append icondir "/mirim.png")))
               #t)))
         ;; Belt-and-suspenders: also export LD_LIBRARY_PATH for the GUI, so
         ;; libraries dlopened transitively (not just by the main binary) are
         ;; found regardless of run-path semantics.
         (add-after 'install 'wrap-gui
           (lambda* (#:key inputs outputs #:allow-other-keys)
             (let* ((out (assoc-ref outputs "out"))
                    (gui-libs
                     (map (lambda (n) (string-append (assoc-ref inputs n) "/lib"))
                          '("mesa" "libx11" "libxcursor" "libxrandr" "libxi"
                            "libxkbcommon" "wayland" "fontconfig" "freetype"
                            "libxext" "libxfixes" "libxrender" "libxcb"))))
               (wrap-program (string-append out "/bin/mirim-gui")
                 `("LD_LIBRARY_PATH" ":" prefix ,gui-libs))
               #t))))))
    (native-inputs
     `(("patchelf" ,patchelf)))
    (inputs
     ;; Desktop integration assets live in this repo; local-file resolves
     ;; them relative to this mirim.scm.
     `(("mirim-desktop" ,(local-file "gui/mirim-gui.desktop"))
       ("mirim-icon" ,(local-file "gui/mirim.png"))
       ("glibc" ,glibc)
       ("gcc:lib" ,gcc "lib")
       ("bash-minimal" ,bash-minimal)
       ("mesa" ,mesa)
       ("libx11" ,libx11)
       ("libxcursor" ,libxcursor)
       ("libxrandr" ,libxrandr)
       ("libxi" ,libxi)
       ("libxkbcommon" ,libxkbcommon)
       ("wayland" ,wayland)
       ("fontconfig" ,fontconfig)
       ("freetype" ,freetype)
       ("libxext" ,libxext)
       ("libxfixes" ,libxfixes)
       ("libxrender" ,libxrender)
       ("libxcb" ,libxcb)))
    (supported-systems '("x86_64-linux"))
    (home-page "https://mirim.securityops.co")
    (synopsis "Tiny embedded SQL database, encrypted at rest, with post-quantum sealed exports")
    (description
     "mirim is a tiny embedded SQL database written in safe Rust.  It is
encrypted at rest by default with XChaCha20-Poly1305 keyed by Argon2id,
supports post-quantum ML-KEM-768 sealed exports and ML-DSA-87 signed
manifests, and keeps a durable, crash-safe write-ahead log.  This package
installs the @command{mirim} CLI/REPL, the @command{mirim-sign} signing
tool, and the secure-by-default @command{mirim-gui} desktop application.")
    (license license:agpl3)))

;; Returned so `guix build/install -f mirim.scm` resolves to this package.
mirim
