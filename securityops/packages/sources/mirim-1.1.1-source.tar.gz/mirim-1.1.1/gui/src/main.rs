// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! `mirim-gui` — a simple, secure-by-default desktop front end for the
//! mirim encrypted database.
//!
//! Security posture, by construction:
//! - **Offline.** There is no network code anywhere; the app only ever
//!   touches the local vault file you open.
//! - **Encrypted + durable.** It opens through `DurableDb`, so the vault is
//!   XChaCha20-Poly1305 at rest, every acknowledged write is fsynced, and
//!   the per-database writer lock keeps a second instance out.
//! - **Read-only until you say otherwise.** Mutating statements
//!   (`INSERT`/`UPDATE`/`DELETE`/`CREATE`…) are refused until you tick
//!   "Allow writes", so a stray keystroke cannot change data.
//! - **The passphrase input is zeroized** as soon as the vault is open.
//!   The durable session retains a zeroizing copy for checkpointing until
//!   the vault is locked or the app exits; it is never written to disk.

#![forbid(unsafe_code)]
// GUI binary; no library docs required.
#![windows_subsystem = "windows"]

use std::path::PathBuf;

use eframe::egui;
use zeroize::Zeroize;

use mirim::vault::Secret;
use mirim::{DurableDb, Output, Value};

// ---- palette: dark background, cyan accents ------------------------------

const BG: egui::Color32 = egui::Color32::from_rgb(0x0d, 0x11, 0x17); // near-black slate
const BG_DEEP: egui::Color32 = egui::Color32::from_rgb(0x08, 0x0b, 0x0f);
const PANEL: egui::Color32 = egui::Color32::from_rgb(0x13, 0x18, 0x20);
const CYAN: egui::Color32 = egui::Color32::from_rgb(0x22, 0xd3, 0xee); // #22d3ee
const CYAN_DIM: egui::Color32 = egui::Color32::from_rgb(0x0e, 0x74, 0x90);
const TEXT: egui::Color32 = egui::Color32::from_rgb(0xd6, 0xe2, 0xea);
const DANGER: egui::Color32 = egui::Color32::from_rgb(0xff, 0x6b, 0x6b);
const OK_GREEN: egui::Color32 = egui::Color32::from_rgb(0x51, 0xcf, 0x66);

fn install_theme(ctx: &egui::Context) {
    let mut visuals = egui::Visuals::dark();
    visuals.override_text_color = Some(TEXT);
    visuals.panel_fill = BG;
    visuals.window_fill = PANEL;
    visuals.faint_bg_color = PANEL;
    visuals.extreme_bg_color = BG_DEEP;
    visuals.hyperlink_color = CYAN;
    visuals.window_stroke = egui::Stroke::new(1.0, CYAN_DIM);
    visuals.selection.bg_fill = CYAN.gamma_multiply(0.35);
    visuals.selection.stroke = egui::Stroke::new(1.0, CYAN);

    // Cyan accents on interactive widgets.
    let w = &mut visuals.widgets;
    w.inactive.bg_fill = PANEL;
    w.inactive.weak_bg_fill = PANEL;
    w.hovered.bg_stroke = egui::Stroke::new(1.0, CYAN);
    w.hovered.fg_stroke = egui::Stroke::new(1.0, CYAN);
    w.active.bg_stroke = egui::Stroke::new(1.5, CYAN);
    w.active.fg_stroke = egui::Stroke::new(1.5, CYAN);
    ctx.set_visuals(visuals);

    let mut style = (*ctx.style()).clone();
    style.spacing.item_spacing = egui::vec2(8.0, 8.0);
    style.spacing.button_padding = egui::vec2(10.0, 6.0);
    ctx.set_style(style);
}

// ---- app state -----------------------------------------------------------

// The Unlocked variant is much larger than Locked (it owns a DurableDb),
// which is inherent to an app-state enum; boxing it would only add
// indirection to the hot render path for no real benefit.
#[allow(clippy::large_enum_variant)]
enum Screen {
    Locked(Locked),
    Unlocked(Unlocked),
}

#[derive(Default)]
struct Locked {
    path: String,
    passphrase: String,
    confirm: String,
    creating: bool,
    error: Option<String>,
}

impl Drop for Locked {
    fn drop(&mut self) {
        self.passphrase.zeroize();
        self.confirm.zeroize();
    }
}

struct Unlocked {
    path: String,
    db: DurableDb,
    tables: Vec<String>,
    sql: String,
    view: ResultView,
    allow_writes: bool,
    status: Status,
    rotate: Option<Rotate>,
}

#[derive(Default)]
struct Rotate {
    new: String,
    confirm: String,
    error: Option<String>,
}

impl Drop for Rotate {
    fn drop(&mut self) {
        self.new.zeroize();
        self.confirm.zeroize();
    }
}

struct Status {
    text: String,
    color: egui::Color32,
}

impl Status {
    fn info(text: impl Into<String>) -> Self {
        Status {
            text: text.into(),
            color: CYAN,
        }
    }
    fn good(text: impl Into<String>) -> Self {
        Status {
            text: text.into(),
            color: OK_GREEN,
        }
    }
    fn bad(text: impl Into<String>) -> Self {
        Status {
            text: text.into(),
            color: DANGER,
        }
    }
}

enum ResultView {
    Empty,
    Rows {
        columns: Vec<String>,
        rows: Vec<Vec<String>>,
    },
    Message(String),
}

struct App {
    screen: Screen,
    licenses_open: bool,
}

impl App {
    fn new(cc: &eframe::CreationContext<'_>) -> Self {
        install_theme(&cc.egui_ctx);
        App {
            screen: Screen::Locked(Locked::default()),
            licenses_open: false,
        }
    }
}

// ---- helpers -------------------------------------------------------------

fn render_value(v: &Value) -> String {
    match v {
        Value::Null => "NULL".to_string(),
        Value::Int(i) => i.to_string(),
        Value::Text(s) => s.clone(),
    }
}

/// A statement is treated as read-only iff its first keyword is SELECT.
/// This is a safety convenience (the real guard is that writes are opt-in),
/// not a security boundary.
fn is_read_only(stmt: &str) -> bool {
    let lower = stmt.trim_start().to_ascii_lowercase();
    lower.starts_with("select ")
        || lower.starts_with("select\t")
        || lower.starts_with("select\n")
        || lower == "select"
        || lower.starts_with("select*")
}

fn refresh_tables(u: &mut Unlocked) {
    u.tables =
        u.db.db()
            .table_names()
            .into_iter()
            .map(String::from)
            .collect();
}

/// Run one or more `;`-separated statements. Honors the read-only guard.
fn run_sql(u: &mut Unlocked, sql: &str) {
    let stmts = mirim::split_statements(sql);
    if stmts.is_empty() {
        u.status = Status::info("nothing to run");
        return;
    }
    if !u.allow_writes {
        if let Some(bad) = stmts.iter().find(|s| !is_read_only(s)) {
            let preview: String = bad.chars().take(48).collect();
            u.status = Status::bad(format!(
                "blocked (read-only): enable “Allow writes” to run “{preview}”"
            ));
            u.view = ResultView::Message(
                "This statement would modify the database. Tick “Allow writes” \
                 in the toolbar to permit it."
                    .to_string(),
            );
            return;
        }
    }

    let mut last_rows: Option<(Vec<String>, Vec<Vec<String>>)> = None;
    let mut affected_total: u64 = 0;
    let mut ran = 0usize;
    for stmt in &stmts {
        match u.db.execute(stmt) {
            Ok(Output::Rows { columns, rows }) => {
                let rendered = rows
                    .iter()
                    .map(|r| r.iter().map(render_value).collect())
                    .collect();
                last_rows = Some((columns, rendered));
                ran += 1;
            }
            Ok(Output::Affected(n)) => {
                affected_total += n;
                ran += 1;
            }
            Ok(Output::Done) => ran += 1,
            Err(e) => {
                u.status = Status::bad(format!("error at statement {}: {e}", ran + 1));
                return;
            }
        }
    }

    match last_rows {
        Some((columns, rows)) => {
            let n = rows.len();
            u.view = ResultView::Rows { columns, rows };
            u.status = Status::good(format!("{n} row(s) — {ran} statement(s) ok"));
        }
        None => {
            u.view = ResultView::Message(if affected_total > 0 {
                format!("{affected_total} row(s) affected")
            } else {
                "ok".to_string()
            });
            u.status = Status::good(format!("{ran} statement(s) ok"));
        }
    }
    // A write may have changed the table set.
    refresh_tables(u);
}

// ---- rendering -----------------------------------------------------------

impl eframe::App for App {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        // Transitions are collected here and applied after rendering to keep
        // the borrow of `self.screen` simple.
        let mut open_request: Option<(PathBuf, String, bool)> = None;
        let mut lock_request = false;

        match &mut self.screen {
            Screen::Locked(l) => {
                render_locked(ctx, l, &mut open_request, &mut self.licenses_open);
            }
            Screen::Unlocked(u) => {
                render_unlocked(ctx, u, &mut lock_request, &mut self.licenses_open);
            }
        }

        if let Some((path, mut pass, _creating)) = open_request {
            match DurableDb::open(&path, &Secret::Passphrase(&pass)) {
                Ok(db) => {
                    pass.zeroize();
                    let mut u = Unlocked {
                        path: path.display().to_string(),
                        db,
                        tables: Vec::new(),
                        sql: String::new(), // set from the table list just below
                        view: ResultView::Empty,
                        allow_writes: false,
                        status: Status::good(format!("opened {} (read-only)", path.display())),
                        rotate: None,
                    };
                    refresh_tables(&mut u);
                    // A friendlier starter query than the placeholder above.
                    u.sql = match u.tables.first() {
                        Some(t) => format!("SELECT * FROM {t} LIMIT 50;"),
                        None => "-- No tables yet. Tick “Allow writes”, then:\n\
                                  CREATE TABLE notes (id INTEGER PRIMARY KEY, body TEXT);"
                            .to_string(),
                    };
                    self.screen = Screen::Unlocked(u);
                }
                Err(e) => {
                    pass.zeroize();
                    if let Screen::Locked(l) = &mut self.screen {
                        // One indistinguishable error for wrong pass / tamper.
                        l.error = Some(format!("could not open: {e}"));
                    }
                }
            }
        }

        if lock_request {
            if let Screen::Unlocked(u) = &mut self.screen {
                let _ = u.db.checkpoint();
            }
            self.screen = Screen::Locked(Locked::default());
        }
        egui::Window::new("Embedded font licenses")
            .open(&mut self.licenses_open)
            .default_size([640.0, 480.0])
            .show(ctx, |ui| {
                egui::ScrollArea::vertical().show(ui, |ui| {
                    ui.label(include_str!("../FONT_LICENSES.txt"));
                });
            });
    }
}

fn header(ui: &mut egui::Ui, licenses_open: &mut bool) {
    ui.horizontal(|ui| {
        ui.heading(egui::RichText::new("◆ mirim").color(CYAN).strong());
        ui.label(
            egui::RichText::new("encrypted · durable · offline")
                .color(CYAN_DIM)
                .small(),
        );
        if ui.small_button("Licenses").clicked() {
            *licenses_open = true;
        }
    });
}

fn render_locked(
    ctx: &egui::Context,
    l: &mut Locked,
    open: &mut Option<(PathBuf, String, bool)>,
    licenses_open: &mut bool,
) {
    egui::CentralPanel::default().show(ctx, |ui| {
        ui.add_space(24.0);
        ui.vertical_centered(|ui| {
            ui.set_max_width(460.0);
            header(ui, licenses_open);
            ui.add_space(6.0);
            ui.label(
                egui::RichText::new(
                    "Open an encrypted vault, or create a new one. Your \
                     passphrase never leaves this machine.",
                )
                .color(TEXT),
            );
            ui.add_space(18.0);

            egui::Frame::NONE
                .fill(PANEL)
                .stroke(egui::Stroke::new(1.0, CYAN_DIM))
                .corner_radius(8.0)
                .inner_margin(egui::Margin::same(16))
                .show(ui, |ui| {
                    egui::Grid::new("open_form")
                        .num_columns(2)
                        .spacing([12.0, 12.0])
                        .show(ui, |ui| {
                            ui.label("Vault file");
                            ui.add(
                                egui::TextEdit::singleline(&mut l.path)
                                    .hint_text("/path/to/data.mrm")
                                    .desired_width(280.0),
                            );
                            ui.end_row();

                            ui.label("Passphrase");
                            ui.add(
                                egui::TextEdit::singleline(&mut l.passphrase)
                                    .password(true)
                                    .desired_width(280.0),
                            );
                            ui.end_row();

                            if l.creating {
                                ui.label("Confirm");
                                ui.add(
                                    egui::TextEdit::singleline(&mut l.confirm)
                                        .password(true)
                                        .desired_width(280.0),
                                );
                                ui.end_row();
                            }
                        });

                    ui.add_space(6.0);
                    ui.checkbox(&mut l.creating, "Create a new vault");
                    ui.add_space(10.0);

                    ui.horizontal(|ui| {
                        let label = if l.creating { "Create & open" } else { "Open" };
                        let btn = egui::Button::new(egui::RichText::new(label).color(BG).strong())
                            .fill(CYAN);
                        if ui.add(btn).clicked() {
                            l.error = None;
                            if l.path.trim().is_empty() {
                                l.error = Some("choose a vault file path".into());
                            } else if l.passphrase.is_empty() {
                                l.error = Some("enter a passphrase".into());
                            } else if l.creating && l.passphrase != l.confirm {
                                l.error = Some("passphrases do not match".into());
                            } else if l.creating && PathBuf::from(l.path.trim()).exists() {
                                l.error = Some("that file already exists — untick “Create”".into());
                            } else if !l.creating && !PathBuf::from(l.path.trim()).exists() {
                                l.error = Some("no such file — tick “Create a new vault”".into());
                            } else {
                                *open = Some((
                                    PathBuf::from(l.path.trim()),
                                    std::mem::take(&mut l.passphrase),
                                    l.creating,
                                ));
                                l.confirm.zeroize();
                                l.confirm.clear();
                            }
                        }
                    });

                    if let Some(err) = &l.error {
                        ui.add_space(8.0);
                        ui.colored_label(DANGER, format!("✖ {err}"));
                    }
                });

            ui.add_space(14.0);
            ui.label(
                egui::RichText::new(
                    "A wrong passphrase and a tampered file fail the same way, \
                     on purpose.",
                )
                .color(CYAN_DIM)
                .small(),
            );
        });
    });
}

fn render_unlocked(
    ctx: &egui::Context,
    u: &mut Unlocked,
    lock: &mut bool,
    licenses_open: &mut bool,
) {
    // Top toolbar.
    egui::TopBottomPanel::top("toolbar")
        .frame(
            egui::Frame::NONE
                .fill(BG_DEEP)
                .inner_margin(egui::Margin::symmetric(12, 8)),
        )
        .show(ctx, |ui| {
            ui.horizontal(|ui| {
                header(ui, licenses_open);
                ui.separator();
                let writes = &mut u.allow_writes;
                let resp = ui.checkbox(writes, "Allow writes");
                if resp.changed() && u.allow_writes {
                    u.status = Status::info("writes enabled — changes are durable immediately");
                }
                if u.allow_writes {
                    ui.colored_label(DANGER, "● write");
                } else {
                    ui.colored_label(OK_GREEN, "● read-only");
                }

                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    if ui
                        .button("Lock")
                        .on_hover_text("Checkpoint & close")
                        .clicked()
                    {
                        *lock = true;
                    }
                    if ui.button("Change passphrase").clicked() {
                        u.rotate = Some(Rotate::default());
                    }
                    if ui
                        .button("Checkpoint")
                        .on_hover_text("Fold the log into the vault")
                        .clicked()
                    {
                        match u.db.checkpoint() {
                            Ok(()) => u.status = Status::good("checkpointed"),
                            Err(e) => u.status = Status::bad(format!("checkpoint failed: {e}")),
                        }
                    }
                });
            });
        });

    // Status bar.
    egui::TopBottomPanel::bottom("status")
        .frame(
            egui::Frame::NONE
                .fill(BG_DEEP)
                .inner_margin(egui::Margin::symmetric(12, 6)),
        )
        .show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.colored_label(u.status.color, &u.status.text);
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    ui.label(egui::RichText::new(&u.path).color(CYAN_DIM).small());
                });
            });
        });

    // Left: tables.
    egui::SidePanel::left("tables")
        .resizable(true)
        .default_width(200.0)
        .frame(
            egui::Frame::NONE
                .fill(PANEL)
                .inner_margin(egui::Margin::same(10)),
        )
        .show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.label(egui::RichText::new("TABLES").color(CYAN).strong().small());
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    if ui.small_button("⟳").on_hover_text("Refresh").clicked() {
                        refresh_tables(u);
                    }
                });
            });
            ui.separator();
            let mut clicked: Option<String> = None;
            egui::ScrollArea::vertical().show(ui, |ui| {
                if u.tables.is_empty() {
                    ui.label(egui::RichText::new("(no tables)").color(CYAN_DIM).italics());
                }
                for t in &u.tables {
                    if ui.selectable_label(false, t).clicked() {
                        clicked = Some(t.clone());
                    }
                }
            });
            if let Some(t) = clicked {
                u.sql = format!("SELECT * FROM {t} LIMIT 50;");
                run_sql(u, &u.sql.clone());
            }
        });

    // Center: SQL editor + results.
    egui::CentralPanel::default()
        .frame(
            egui::Frame::NONE
                .fill(BG)
                .inner_margin(egui::Margin::same(12)),
        )
        .show(ctx, |ui| {
            ui.label(egui::RichText::new("SQL").color(CYAN).strong().small());
            let editor = egui::TextEdit::multiline(&mut u.sql)
                .desired_rows(4)
                .desired_width(f32::INFINITY)
                .code_editor()
                .hint_text("SELECT * FROM …  (Ctrl+Enter to run)");
            let resp = ui.add(editor);
            let run_shortcut = resp.has_focus()
                && ui.input(|i| i.key_pressed(egui::Key::Enter) && i.modifiers.command);

            ui.add_space(6.0);
            ui.horizontal(|ui| {
                let run =
                    egui::Button::new(egui::RichText::new("Run ▶").color(BG).strong()).fill(CYAN);
                let clicked = ui.add(run).clicked();
                ui.label(egui::RichText::new("Ctrl+Enter").color(CYAN_DIM).small());
                if clicked || run_shortcut {
                    run_sql(u, &u.sql.clone());
                }
            });

            ui.add_space(10.0);
            ui.separator();
            ui.add_space(6.0);

            render_results(ui, &u.view);
        });

    // Change-passphrase modal.
    let mut close_rotate = false;
    let mut do_rotate: Option<String> = None;
    if let Some(r) = &mut u.rotate {
        egui::Window::new("Change passphrase")
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, egui::vec2(0.0, 0.0))
            .show(ctx, |ui| {
                ui.label("Re-encrypts the vault and rebinds the log atomically.");
                ui.add_space(8.0);
                egui::Grid::new("rotate_form")
                    .num_columns(2)
                    .show(ui, |ui| {
                        ui.label("New passphrase");
                        ui.add(
                            egui::TextEdit::singleline(&mut r.new)
                                .password(true)
                                .desired_width(240.0),
                        );
                        ui.end_row();
                        ui.label("Confirm");
                        ui.add(
                            egui::TextEdit::singleline(&mut r.confirm)
                                .password(true)
                                .desired_width(240.0),
                        );
                        ui.end_row();
                    });
                if let Some(e) = &r.error {
                    ui.colored_label(DANGER, e);
                }
                ui.add_space(8.0);
                ui.horizontal(|ui| {
                    let apply = egui::Button::new(egui::RichText::new("Apply").color(BG).strong())
                        .fill(CYAN);
                    if ui.add(apply).clicked() {
                        if r.new.is_empty() {
                            r.error = Some("enter a new passphrase".into());
                        } else if r.new != r.confirm {
                            r.error = Some("passphrases do not match".into());
                        } else {
                            do_rotate = Some(r.new.clone());
                        }
                    }
                    if ui.button("Cancel").clicked() {
                        close_rotate = true;
                    }
                });
            });
    }
    if let Some(new) = do_rotate {
        match u.db.rotate_secret(&Secret::Passphrase(&new)) {
            Ok(()) => {
                u.status = Status::good("passphrase changed; old one no longer opens this vault");
                close_rotate = true;
            }
            Err(e) => {
                if let Some(r) = &mut u.rotate {
                    r.error = Some(format!("rotation failed: {e}"));
                }
            }
        }
    }
    if close_rotate {
        u.rotate = None;
    }
}

fn render_results(ui: &mut egui::Ui, view: &ResultView) {
    match view {
        ResultView::Empty => {
            ui.colored_label(CYAN_DIM, "Run a query to see results here.");
        }
        ResultView::Message(m) => {
            ui.colored_label(TEXT, m);
        }
        ResultView::Rows { columns, rows } => {
            if columns.is_empty() {
                ui.colored_label(CYAN_DIM, "(no columns)");
                return;
            }
            egui::ScrollArea::both()
                .auto_shrink([false, false])
                .show(ui, |ui| {
                    egui::Grid::new("results_grid")
                        .striped(true)
                        .spacing([18.0, 4.0])
                        .show(ui, |ui| {
                            for c in columns {
                                ui.label(egui::RichText::new(c).color(CYAN).strong());
                            }
                            ui.end_row();
                            for row in rows {
                                for cell in row {
                                    if cell == "NULL" {
                                        ui.colored_label(
                                            CYAN_DIM,
                                            egui::RichText::new("NULL").italics(),
                                        );
                                    } else {
                                        ui.label(cell);
                                    }
                                }
                                ui.end_row();
                            }
                            if rows.is_empty() {
                                for _ in columns {
                                    ui.label(egui::RichText::new("—").color(CYAN_DIM));
                                }
                                ui.end_row();
                            }
                        });
                });
        }
    }
}

fn main() -> eframe::Result<()> {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([980.0, 640.0])
            .with_min_inner_size([680.0, 460.0])
            .with_title("mirim"),
        ..Default::default()
    };
    eframe::run_native("mirim", options, Box::new(|cc| Ok(Box::new(App::new(cc)))))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn read_only_guard_recognizes_selects() {
        // The secure default only auto-permits SELECTs.
        assert!(is_read_only("SELECT * FROM t"));
        assert!(is_read_only("select id from t where a = 1"));
        assert!(is_read_only("  \t SELECT 1")); // leading whitespace is trimmed
        assert!(is_read_only("SELECT*FROM t"));
        assert!(is_read_only("select"));
    }

    #[test]
    fn read_only_guard_blocks_mutations() {
        for s in [
            "INSERT INTO t VALUES (1)",
            "update t set a = 1",
            "DELETE FROM t",
            "CREATE TABLE t (id INTEGER)",
            "  drop table t", // not even valid mirim SQL, still must not be auto-run
            "/* select? */ delete from t", // a comment prefix must not fool the guard
        ] {
            assert!(!is_read_only(s), "should be blocked when read-only: {s:?}");
        }
    }

    #[test]
    fn value_rendering() {
        assert_eq!(render_value(&Value::Null), "NULL");
        assert_eq!(render_value(&Value::Int(-7)), "-7");
        assert_eq!(render_value(&Value::Text("hi".into())), "hi");
    }
}
