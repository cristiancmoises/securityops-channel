Maintainer ML-DSA-87 (FIPS 204) release signing key.

  mirim-release.pub  — the public key (2592 bytes), committed here so that
                       release signatures verify offline:
                         mirim-sign verify <artifact> <artifact>.mf mirim-release.pub

The matching 32-byte secret seed is kept OUT of the repository. In CI it is
the MIRIM_SIGN_SEED_HEX secret, decoded to a 32-byte file at sign time and
shredded afterwards. Regenerate a keypair with:

  mirim-sign keygen <seed-out> mirim-release.pub

Each release ships the signed artifacts, their detached `.mf` manifests, and
a copy of this public key.
