# Sample databases

[Guia dos exemplos em português](../docs/GUIDE.pt-BR.md#bancos-de-exemplo)

Five ready-to-load sample databases, each a small, sensitive, realistic
dataset of the kind mirim is built for — the sort of thing you want
encrypted at rest and able to travel as a post-quantum sealed export.

Every file is plain mirim SQL with comments (mirim understands `--` line
and `/* */` block comments as of 1.1.0). Each header comment explains the
schema and lists example queries to try.

| File | What it models | Tables |
|------|----------------|--------|
| [`secrets_vault.sql`](secrets_vault.sql) | Service credential store + access audit log | `services`, `secrets`, `access_log` |
| [`ctf_scoreboard.sql`](ctf_scoreboard.sql) | Capture-the-flag competition scoreboard | `teams`, `challenges`, `solves` |
| [`device_fleet.sql`](device_fleet.sql) | Endpoint / IoT fleet inventory + telemetry | `devices`, `firmware`, `checkins` |
| [`audit_trail.sql`](audit_trail.sql) | Compliance audit trail (principals, policies, events) | `principals`, `policies`, `events` |
| [`password_manager.sql`](password_manager.sql) | Personal password manager (metadata only) | `vaults`, `entries`, `tags` |

## Loading a sample

### Into a live encrypted vault (CLI)

```text
mirim secrets.mrm
new passphrase: ****
repeat passphrase: ****
mirim> .read samples/secrets_vault.sql
ok: ran 30 statement(s) from samples/secrets_vault.sql
mirim> .tables
mirim> .schema
mirim> SELECT name, endpoint FROM services ORDER BY name;
```

`.read <path>` runs statements individually and stops at the first error;
previous successful statements remain applied. `.schema` prints reconstructed
`CREATE TABLE` statements, not table contents. Successful mutations are
synced to the WAL before acknowledgement; see the
[durability limits](../SECURITY.md#durability-and-recovery).

### Generate encrypted vaults for all five at once

```text
cargo run --example gen_samples             # writes into a temp directory
cargo run --example gen_samples ./out       # writes into ./out
```

This loads each sample, prints its row counts, writes an encrypted `.mrm`
vault (demo passphrase `sample-pass`), and additionally seals one to a
fresh ML-KEM-768 recipient to demonstrate the post-quantum sealed-export
round-trip. The public demo passphrase is unsuitable for real secrets;
rotate it before storing real data.

### From your own code (library)

```rust
use mirim::{Db, vault, vault::Secret};

let mut db = Db::new();
db.execute_script(include_str!("../samples/audit_trail.sql"))?;
vault::save(&db, "audit.mrm".as_ref(), &Secret::Passphrase("…"))?;
# Ok::<(), mirim::Error>(())
```

## The mirim SQL dialect, in one breath

These samples stay inside mirim's deliberately small dialect, so they double
as a reference for what is and isn't supported:

- Types are **`INTEGER`** (i64) and **`TEXT`** (UTF-8) only. Timestamps are
  Unix epoch seconds; booleans are `0` / `1`; there is no `REAL`, `BLOB`,
  `DATE`, or `BOOLEAN`.
- Constraints are single-column **`PRIMARY KEY`** and **`UNIQUE`** (each
  carries an O(1) equality index). No `FOREIGN KEY`, `NOT NULL`, `DEFAULT`,
  `CHECK`, or composite keys — relationships between tables are by
  convention (store the parent's id or name as a plain column).
- One row per `INSERT`; no multi-row `VALUES (…), (…)`.
- `SELECT` supports projection, `WHERE` (AND-chained comparisons and
  `IS [NOT] NULL`), `ORDER BY … [ASC|DESC]`, `LIMIT … [OFFSET …]`, and
  `COUNT(*)`. `NULL` never matches a comparison; under `ORDER BY` it sorts
  first (ASC) / last (DESC).
- Carry untrusted values with `?` parameter binding, never string splicing.

See [`../docs/GUIDE.md`](../docs/GUIDE.md) for a gentle end-to-end walkthrough.
