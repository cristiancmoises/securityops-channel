# mirim

Banco de dados SQL embarcado e pequeno, com armazenamento criptografado,
registro de escrita antecipada durável e exportações seladas pós-quânticas.
O núcleo usa Rust com `#![forbid(unsafe_code)]`; a interface C e a aplicação
gráfica são crates separados.

**Versão 1.1.1** · [Site](https://mirim.securityops.co) · [English](README.md)

## Documentação

| Para começar | Referência e políticas |
|---|---|
| [Guia completo em português](docs/GUIDE.pt-BR.md) | [Modelo de segurança](SECURITY.md), em inglês |
| [Guia em inglês](docs/GUIDE.md) | [Histórico de versões](CHANGELOG.md) |
| [Exemplos de bancos](samples/README.md) | [Processo de publicação](RELEASE.md) |
| [Exemplos em Rust](examples/) | [Decisão de armazenamento](docs/ADR-001-storage.md) |
| [Cabeçalho da API C](ffi/include/mirim.h) | [Licenciamento](LICENSING.pt-BR.md) |

## Recursos

- **Armazenamento criptografado.** Arquivos `.mrm` usam XChaCha20-Poly1305,
  com chave derivada de uma frase-senha por Argon2id ou uma chave bruta de
  32 bytes fornecida pela aplicação. Os cabeçalhos são autenticados.
- **Sessões duráveis.** CLI, GUI, API C e `DurableDb` usam um WAL
  criptografado. As alterações bem-sucedidas são sincronizadas antes da
  confirmação. O checkpoint incorpora o WAL ao arquivo principal. Sessões
  usam bloqueio exclusivo do sistema em Unix e Windows; se o bloqueio não
  for suportado, a abertura falha.
- **SQL objetivo.** `CREATE TABLE`, `INSERT`, `SELECT`, `UPDATE` e `DELETE`;
  `INTEGER`, `TEXT` e `NULL`; `PRIMARY KEY` e `UNIQUE` por coluna;
  parâmetros `?`; filtros com `AND`, comparações e `IS [NOT] NULL`;
  `ORDER BY`, `LIMIT`/`OFFSET` e `COUNT(*)`.
- **Exportações pós-quânticas.** ML-KEM-768 permite selar um banco para um
  ou vários destinatários. O recurso opcional `sign` fornece manifestos
  assinados com ML-DSA-87.
- **Várias interfaces.** Terminal (`mirim`), aplicação gráfica
  (`mirim-gui`), ferramenta de assinatura (`mirim-sign`), API Rust e API C.

Todos os dados e índices precisam caber na RAM. Não há joins, transações
entre vários comandos, paginação em disco nem suporte a escritores
concorrentes. O tipo `Db` trabalha somente em memória até uma chamada
explícita a `vault::save`. Leia os [limites do SQL](docs/GUIDE.pt-BR.md#referencia-sql)
e as [orientações de segurança](docs/GUIDE.pt-BR.md#seguranca-e-limites).

## Instalação

Baixe os arquivos correspondentes ao seu sistema e à sua arquitetura:

- [git.securityops.co](https://git.securityops.co/cristiancmoises/mirim/releases)
- [git.securityops.com.br](https://git.securityops.com.br/cristiancmoises/mirim/releases)
- [GitHub](https://github.com/cristiancmoises/mirim/releases)
- [Codeberg](https://codeberg.org/berkeley/mirim/releases)

A lista de anexos de cada versão define os binários disponíveis. Uma receita
de empacotamento ou um PR enviado não significa que o pacote já entrou no
repositório oficial de uma distribuição. O
[guia de instalação](docs/GUIDE.pt-BR.md#instalacao) inclui GNU/Linux,
macOS, Windows, compilação para BSD e a receita local do GNU Guix.

Verifique os downloads no GNU/Linux:

```sh
sha256sum -c SHA256SUMS --ignore-missing
```

O checksum detecta alterações, mas não autentica o publicador. Se houver
um manifesto `.mf`, use um `mirim-sign` confiável e uma cópia previamente
autenticada da chave pública do mantenedor:

```sh
mirim-sign verify <artefato> <artefato>.mf mirim-release.pub
```

### Compilar o código-fonte

Instale rustup e as ferramentas nativas de compilação do seu sistema.
O arquivo `rust-toolchain.toml` fixa Rust 1.96.0.

```sh
git clone https://github.com/cristiancmoises/mirim.git
cd mirim
git checkout v1.1.1
cargo build --release --locked --features sign
```

Os executáveis ficam em `target/release/`, com extensão `.exe` no Windows.
As interfaces opcionais têm compilação própria:

```sh
cargo build --release --locked --manifest-path gui/Cargo.toml
cargo build --release --locked --manifest-path ffi/Cargo.toml
```

## Primeiro banco criptografado

```text
$ mirim notas.mrm
creating new vault: notas.mrm
new passphrase:
repeat passphrase:
mirim 1.1.1 — .help for commands
mirim> CREATE TABLE notas (id INTEGER PRIMARY KEY, texto TEXT);
ok
mirim> INSERT INTO notas VALUES (1, 'minha primeira nota');
1 row(s)
mirim> SELECT texto FROM notas WHERE id = 1;
mirim> .quit
```

As mensagens da aplicação continuam em inglês. Cada alteração bem-sucedida
é registrada no WAL antes de ser confirmada. `.save` faz um checkpoint;
`.quit` faz um checkpoint e encerra. `.read <caminho>` executa um arquivo
SQL comando por comando; um erro não desfaz os comandos anteriores.

```sh
cargo run --locked --example quickstart
cargo run --locked --example sealed_export
```

Não existe recuperação de frase-senha ou de chave secreta perdida. Para
backup, interrompa as escritas e encerre a sessão com sucesso antes de
copiar os arquivos. Veja o [procedimento completo](docs/GUIDE.pt-BR.md#backup-e-recuperacao).

## Desenvolvimento e verificação

```sh
cargo fmt --all --check
cargo clippy --locked --all-features --all-targets -- -D warnings
cargo test --locked --all-features
cargo audit
cargo deny check
```

O [guia de verificação](docs/GUIDE.pt-BR.md#desenvolvimento-e-auditoria)
explica a matriz de recursos, os lockfiles separados, os testes de
recuperação, o fuzzing e o harness C com sanitizadores. Esses testes não
constituem uma certificação independente de segurança.

## Licença

Os arquivos próprios identificados como
`AGPL-3.0-only OR LicenseRef-Mirim-Commercial` podem ser usados sob a
AGPL-3.0-only ou mediante contrato comercial separado e assinado. Arquivos
marcados MIT e dependências mantêm suas respectivas licenças. Consulte
[LICENSING.pt-BR.md](LICENSING.pt-BR.md), [LICENSE](LICENSE) e
[LICENSE-COMMERCIAL](LICENSE-COMMERCIAL). Contato comercial:
`sac@securityops.co`. Copyright © 2026 Cristian Cezar Moisés.
