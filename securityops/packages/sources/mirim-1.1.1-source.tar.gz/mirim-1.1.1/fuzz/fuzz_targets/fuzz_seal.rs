// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial
//! Sealed-export parser, both format versions, fixed recipient key.
#![no_main]
use std::sync::OnceLock;

use libfuzzer_sys::fuzz_target;
use mirim::pq::RecipientSecret;

fn recipient() -> &'static RecipientSecret {
    static SK: OnceLock<RecipientSecret> = OnceLock::new();
    SK.get_or_init(|| mirim::pq::keygen().0)
}

fuzz_target!(|data: &[u8]| {
    let _ = mirim::pq::open(data, recipient());
});
