// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial
//! Lexer, parser, and engine on arbitrary UTF-8 against a live schema.
#![no_main]
use libfuzzer_sys::fuzz_target;
use mirim::Db;

fuzz_target!(|sql: &str| {
    let mut db = Db::new();
    db.execute("create table t (id integer primary key, s text unique)")
        .expect("schema");
    let _ = db.execute(sql);
});
