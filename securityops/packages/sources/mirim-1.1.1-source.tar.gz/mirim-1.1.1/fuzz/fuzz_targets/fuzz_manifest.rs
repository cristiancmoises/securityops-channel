// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial
//! Manifest parsing and verification against a fixed key and target.
#![no_main]
use std::sync::OnceLock;

use libfuzzer_sys::fuzz_target;
use mirim::manifest::ManifestPublic;

fn public() -> &'static ManifestPublic {
    static PK: OnceLock<ManifestPublic> = OnceLock::new();
    PK.get_or_init(|| mirim::manifest::keygen().1)
}

fuzz_target!(|data: &[u8]| {
    let _ = mirim::manifest::verify_manifest(data, b"fuzz target bytes", public());
});
