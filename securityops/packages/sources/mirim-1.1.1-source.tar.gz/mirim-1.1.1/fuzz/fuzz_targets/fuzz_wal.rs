// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial
//! Full WAL open path: header checks, torn-tail repair, record
//! decryption, replay. One tempdir per process, one file write per exec.
#![no_main]
use std::path::PathBuf;
use std::sync::OnceLock;

use libfuzzer_sys::fuzz_target;

fn dir() -> &'static PathBuf {
    static DIR: OnceLock<PathBuf> = OnceLock::new();
    DIR.get_or_init(|| {
        let d = std::env::temp_dir().join(format!("mirim-fuzz-wal-{}", std::process::id()));
        std::fs::create_dir_all(&d).expect("fuzz tempdir");
        d
    })
}

fuzz_target!(|data: &[u8]| {
    mirim::fuzz_api::wal_open(dir(), data);
});
