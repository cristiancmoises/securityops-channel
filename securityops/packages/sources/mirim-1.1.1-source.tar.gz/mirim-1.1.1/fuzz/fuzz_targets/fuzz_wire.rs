// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial
//! Snapshot wire decode: the bytes an attacker controls after stealing a
//! key, or any bug that lets unauthenticated data reach the decoder.
#![no_main]
use libfuzzer_sys::fuzz_target;

fuzz_target!(|data: &[u8]| {
    mirim::fuzz_api::wire_decode(data);
});
