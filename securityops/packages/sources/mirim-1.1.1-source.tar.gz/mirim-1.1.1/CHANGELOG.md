# Changelog

All notable changes to mirim. Format follows Keep a Changelog; versions
are git tags `vX.Y.Z` on git.securityops.co/cristiancmoises/mirim.
MSRV is pinned in `rust-toolchain.toml`; any bump is noted here.

## [1.1.1] — Unreleased

A maintenance and release-engineering update. The vault, WAL, sealed-export,
manifest and trust-file formats remain unchanged.

### Fixed
- Atomic vault and trust-file saves use unpredictable, exclusively created
  temporary files. On Unix those files are private from creation; pre-existing
  files and symlinks are not followed or truncated.
- Durable sessions enforce the one-writer lock on Windows as well as Unix,
  using Rust's standard file-locking API. Unsupported locking fails closed.
- Durable writes reject records beyond the WAL replay limit before appending
  or acknowledging them. Oversized writes can no longer appear successful and
  then disappear when the vault is reopened.
- Table creation rejects schemas beyond the serialized column-count limit.
  Snapshot serialization checks encoded lengths instead of truncating them;
  partially built plaintext buffers are zeroized if serialization fails.
- Signing-key generation refuses to overwrite existing paths, including
  symlinks, and creates private seed files on Unix. Loaded signing seeds are
  zeroized when released.
- CLI and signer accept `--help`/`--version`; the CLI supports `--` before a
  filename, and rejects unknown options without opening a vault.
- Corrected GUI text about secret lifetime: the input buffer is cleared after
  opening, while the durable session retains the secret needed for checkpoints.

### Dependencies and assurance
- Updated the desktop dependency chain to eframe 0.33.3 and refreshed locked
  dependencies to address the XML parsing and browser-launch advisories.
- Updated `anyhow` and `der`, removed the direct `rustix` runtime dependency,
  and regenerated the runtime SBOM. License checks cover every first-party
  crate; only two documented GUI maintenance advisories are excepted.
- Retained the bundled font license texts in GUI packages and an offline
  Licenses window. Font-specific license allowances are scoped to the font crate.
- Fixed a sign-feature-only test import that failed strict default builds.
- CI now includes the standalone GUI and FFI crates, all four lockfile audits,
  and the FFI sanitizer harness on GitHub as well as Forgejo.

### Documentation and distribution
- Reorganized the English README and user guide, added complete Brazilian
  Portuguese equivalents, and consolidated the redundant comparison document.
- Corrected documentation about backup consistency, error handling, locking,
  passphrase lifetime, and the limits of crash-durability tests.
- Hardened release scripts: required artifacts fail the build when missing;
  signing is mandatory and each signature is checked against the existing
  public key; reproducibility compares two separate build directories.
- Updated macOS runners, preserved the Linux GUI artifact, added standalone
  Windows executables and source/vendor archives, and included pt-BR docs in
  packages. Platform availability depends on successful native release builds.

## [1.1.0] — 2026-07-15

A query-ergonomics and distribution release. **No on-disk format changed** —
the vault, sealed-export, WAL, manifest, and trust-file layouts are all
still v1 and frozen, so every 1.0.0 file opens unchanged under 1.1.0. All
new SQL is query-only.

### Added
- SQL: `ORDER BY <col> [ASC|DESC]` (multi-key, stable; `NULL` sorts first
  under ASC / last under DESC), `LIMIT <n> [OFFSET <m>]`, and `COUNT(*)`.
  `--` line and `/* */` block comments are now skipped by the lexer. These
  are *contextual* keywords, so existing tables/columns named `order`,
  `count`, `limit`, `offset`, `asc`, `desc`, or `by` keep working unquoted.
- Library: `Db::execute_script` and `mirim::split_statements` to load a
  multi-statement SQL file (string- and comment-aware splitting);
  `Db::schema_sql` and `Db::table_columns` for schema introspection.
- CLI: `.read <path>` runs the statements in a `.sql` file; `.schema`
  prints the reconstructed `CREATE TABLE` statements.
- Five realistic sample databases under `samples/` (secrets vault, CTF
  scoreboard, device fleet, audit trail, password manager), a
  `gen_samples` example that materializes encrypted vaults and a
  post-quantum sealed export, and `samples/README.md`.
- Documentation: `docs/GUIDE.md` (a friendly, end-to-end getting-started
  guide) and `docs/comparison.md` (a sourced comparison against SQLite,
  SQLCipher, DuckDB, libSQL/Turso, and redb/sled), plus a comparison table
  in the README.
- OS packaging and release automation: `cargo-deb` / `cargo-generate-rpm` /
  `cargo-bundle` metadata; a GitHub Actions release workflow that builds
  `.deb`, `.rpm`, AppImage, `.tar.gz` (Linux), `.dmg` / `.pkg` (macOS), and
  `.exe` / `.zip` (Windows), all checksummed and ML-DSA-87 signed; the
  Forgejo `ci.yaml` / `release.yaml` the docs referenced; helper scripts
  under `scripts/`; and `ffi/tests/run-sanitizers.sh` for the ASan+UBSan
  harness.
- `required-features` on the `gen_fuzz_corpus` example, so a bare
  `cargo test` (default features) builds and runs cleanly.
- A GNU Guix package (`mirim.scm`): `guix install -f mirim.scm` installs the
  CLI, `mirim-sign`, and the desktop GUI from the verified release binaries.

### Changed
- Version is 1.1.0 for both `mirim` and `mirim-ffi`; `mirim_version()` and
  the CLI banner report `1.1.0`.
- The stripped CLI binary is ~477 KiB (was ~436 KiB) — the growth is the
  new query features; the crypto stack is unchanged.

### Security / dependencies
- No dependency changes; `Cargo.lock` and the committed SBOM are unchanged
  except for the version bump. The crypto primitives and all on-disk
  formats are identical to 1.0.0.

## [1.0.0] — 2026-06-13

First stable release. No code change from 0.14.0; this milestone declares
the public API and the on-disk formats stable. The per-version history
that follows records how the project reached here.

### What mirim is
A tiny embedded SQL database (~3.4 kLOC of safe Rust, `#![forbid(unsafe_code)]`),
encrypted at rest by default, with post-quantum sealed exports and no
classical asymmetric cryptography anywhere in any file format.

### Capabilities
- SQL subset over in-memory tables: CREATE/INSERT/SELECT/UPDATE/DELETE,
  INTEGER and TEXT, single-column PRIMARY KEY / UNIQUE with an O(1)
  equality index, `?` parameter binding, no type coercion.
- Encrypted vault (`.mrm`): XChaCha20-Poly1305 over the snapshot, key from
  Argon2id (passphrase) or a caller-held 32-byte key; atomic saves.
- Durable sessions (`DurableDb`): an encrypted write-ahead log; an
  acknowledged mutation survives `kill -9` and power loss, enforced by a
  SIGKILL harness. `checkpoint()` folds the log into a fresh snapshot.
- Post-quantum sealed exports: ML-KEM-768 (FIPS 203), single- and
  multi-recipient. Signed manifests: ML-DSA-87 (FIPS 204) via `mirim-sign`,
  with monotonic-counter rollback enforcement; mirim signs its own
  releases with it.
- Key rotation, one-writer advisory locking, and a C FFI (`mirim-ffi`).

### Security
- No classical public-key cryptography in any persisted artifact, so
  archived vaults and sealed exports are outside harvest-now-decrypt-later
  scope. Primitives are vetted RustCrypto / ML-KEM / ML-DSA crates.
- Official test vectors pass: FIPS 203, FIPS 204, RFC 9106, RFC 8439.
- A plain-English threat model with an explicit "does NOT protect against"
  section lives in SECURITY.md.

### Assurance
- 97 native tests, a SIGKILL power-cut harness, 5 libFuzzer targets, a
  proptest property layer, a model-based differential test against an
  independent oracle, and Miri on the logic-bearing suites.
- The C FFI runs under ASan + UBSan.
- Reproducible release builds (bit-identical), a CycloneDX SBOM of the
  runtime dependency closure, and `cargo audit` / `cargo deny` gates in CI.

### Measured (x86-64, in-memory, vs SQLite)
- Bulk insert 10k rows with a PRIMARY KEY: 13.4 ms (SQLite 33.6 ms).
- Point SELECT by PK over 10k rows: 1.42 µs (SQLite 0.62 µs).
- Durable commit (fsynced): 578 µs. CLI binary with the full crypto
  stack: ~436 KiB.

### Licensing
Dual-licensed: AGPL-3.0-only (see LICENSE), or a commercial license for
uses the AGPL does not fit — closed-source embedding, or running a
modified version as a network service without publishing source. See
LICENSING.md; commercial licensing via securityops.co. (Relicensed from
MIT during 1.0.0 finalization, before any tagged release.)

### Stability commitment
The vault, WAL, sealed-export, and manifest formats are frozen at their
v1/v2 layouts and will remain readable. The public Rust API and the C ABI
are stable; breaking changes would be a 2.0.

## [0.14.0] — 2026-06-13

### Added
- In-memory equality index on PRIMARY KEY and UNIQUE columns
  (`HashMap<Value, usize>` per indexed column, non-NULL values only).
  INSERT duplicate checks and point lookups (`WHERE indexed_col = ?`,
  with any additional AND predicates) are now O(1) instead of O(rows).
  The index is pure derived state — excluded from equality, rebuilt on
  load and after deletes — so the on-disk vault/seal formats are
  unchanged.

### Changed
- `bench_insert` now measures a bulk build (O(N²)→O(N) with the index)
  rather than a single insert paired with a delete; point-select bench
  label is `mirim_indexed`. Measured: bulk insert 10k rows 13.4 ms
  (sqlite 33.6 ms); point SELECT 10k 1.42 µs (sqlite 0.62 µs), down from
  47.2 µs when it was a scan. README, ADR-001, and the "no indexes"
  claims updated to match.

### Performance notes
- DELETE rebuilds the affected table's index after removing rows — an
  O(rows) pass on top of the existing retain scan, asymptotically
  unchanged, a modest constant. Equality on non-indexed columns still
  scans O(rows). Correctness is unchanged: the differential model test
  and all property invariants pass with the index.

## [0.13.0] — 2026-06-13

### Added
- `examples/sealed_export.rs`: a runnable demonstration of the
  post-quantum sealed-export path — builds a small database, seals it to
  two ML-KEM-768 recipients with `pq::seal_multi`, writes the sealed blob
  to a file, shows each recipient opening it and an outsider being
  rejected, and round-trips the single-recipient `pq::seal` path.
  `cargo run --example sealed_export`.

### Changed
- README Quickstart section now points at the sealed-export example
  alongside the credential-store sample.

## [0.12.0] — 2026-06-13

### Added
- Sample database (`examples/quickstart.rs`): a runnable, self-contained
  demo — a service credential store with an access audit log
  (`services`, `secrets`, `access_log`) — that seeds data, runs
  representative queries (projection, `WHERE`, `IS NULL`, parameter
  binding), shows a `UNIQUE` constraint rejecting a duplicate, rotates a
  secret, and checkpoints. Re-running it demonstrates durability: the
  data persists from the prior run. `cargo run --example quickstart`.
- The same schema as plain SQL in `examples/schema.sql`, loadable through
  the CLI.

### Changed
- README: added a Quickstart section; corrected the source-size figure
  (~3.2 kLOC), the signed-manifest description (counter enforcement has
  shipped since 0.4.0), and the CLI transcript (`.save` checkpoints,
  `.quit` no longer prompts since every `ok` is already durable); removed
  a duplicated sentence.

## [0.11.0] — 2026-06-13

### Added
- CycloneDX 1.5 SBOM (`sbom.cdx.json`) over the runtime dependency
  closure (normal edges, all features; dev/test/build deps excluded as
  they are not in the shipped artifact), generated by `scripts/gen-sbom.py`
  from `cargo metadata` (Python stdlib only, no external tool). Output is
  deterministic — no timestamp or serial number — so it is a pure
  function of Cargo.lock and the feature set.
- CI `sbom` job regenerates and diffs the committed SBOM, failing on
  drift; the release workflow ships `sbom.cdx.json` with each artifact.
  Completes the supply-chain transparency triad with the existing
  reproducible-build and `cargo audit`/`cargo deny` gates.

## [0.10.0] — 2026-06-13

### Added
- `mirim-sign` binary (built with `--features sign`): detached
  post-quantum signatures over arbitrary files using mirim's own
  ML-DSA-87 (FIPS 204) manifest format — `keygen`, `sign`
  (`--kind`/`--counter`/`-o`), and `verify` (`--enforce <trustfile>` for
  monotonic-counter rollback protection). Exit 0 on success, nonzero with
  a typed message otherwise; the loaded seed is zeroized.
- Release signing wired into the release workflow: the reproducible
  binary is signed with `mirim-sign`, self-verified against the committed
  `keys/mirim-release.pub`, and shipped with its `.mf` manifest and the
  public key. RELEASE.md documents the maintainer key handling and the
  counter discipline.
- End-to-end test (`tests/cli_sign.rs`) driving the compiled binary
  through keygen/sign/verify, tamper detection, wrong-key rejection,
  truncated-manifest handling, and rollback enforcement.

### Notes
- Dogfooding: mirim now signs its own releases with the FIPS 204
  primitive its KAT and property suites already exercise. Verified by
  signing the actual 0.10.0 release binary and detecting a one-byte
  tamper.

## [0.9.0] — 2026-06-13

### Added
- Model-based differential test (`tests/model.rs`, proptest): an
  independent reference model reimplements the table and WHERE-clause
  semantics (insertion order, the exact `cmp` rules incl. NULL/type
  mismatch and `Ne`, `retain`-style delete); generated statement
  sequences run against both the model and the engine, asserting
  agreement on affected counts, ordered query result sets, and full-table
  contents after each mutation. Mutation-checked: a deliberate operator
  flip in the model is caught and shrunk. No `src/` changes — engine and
  model agreed across the explored space.

## [0.8.0] — 2026-06-13

### Added
- Property-based test layer (`tests/properties.rs`, proptest 1.11):
  round-trip identities for the vault (save/load), sealed exports
  (seal/open, single and multi-recipient), and signed manifests
  (sign/verify); the WAL replay and checkpoint state-preservation
  invariants over arbitrary operation sequences; PRIMARY KEY uniqueness
  and insert/delete consistency as global engine invariants; and counter
  enforcement monotonicity. All exercised through the public API with
  TEXT values supplied via parameter binding. No `src/` changes — no
  invariant violations were found.

## [0.6.0] — 2026-06-13

### Added
- C ABI (`ffi/`): `libmirim_ffi` cdylib + staticlib against
  `ffi/include/mirim.h`. Open (raw key or passphrase), parameterized
  execute, length-delimited result accessors, checkpoint, per-handle
  error retrieval. Every entry point panic-fenced; the core crate stays
  `#![forbid(unsafe_code)]` with all unsafe confined to the FFI crate.
- Criterion benchmark suite (`benches/core.rs`) with SQLite (rusqlite,
  bundled) as the reference on commensurable operations.
- Fuzz coverage wiring (`cargo +nightly fuzz coverage`).

### Notes
- Benchmark numbers in README were measured in a virtualized container;
  fsync-bound figures are machine-dependent.

## [0.5.0] — 2026-06-13

### Added
- Five libFuzzer targets (`fuzz/`): wire decode, sealed-export open
  (v1+v2), manifest verify, SQL, WAL open/replay. Corpus generator at
  `examples/gen_fuzz_corpus.rs`.
- Deterministic randomized smoke harness (`tests/fuzz_smoke.rs`) over
  every attacker-reachable decoder, on stable, every `cargo test`.
- CLI `.rotate` command.

### Security
- Constant-time review recorded in SECURITY.md: no mirim-owned
  secret-dependent branch exists; dudect deferred until one does.
- Logic suites verified under Miri (`-Zmiri-disable-isolation`).

## [0.4.0] — 2026-06-13

### Added
- Manifest counter enforcement (`verify_manifest_enforcing` + 49-byte
  trust file): replayed older files rejected as `Error::Rollback`.
- Unix advisory `flock` per database: second opener fails `Error::Locked`;
  released by the kernel on process death.
- `DurableDb::rotate_secret`: atomic re-encrypt + WAL rebind.
- Multi-recipient sealed exports (`pq::seal_multi`, format v2).

## [0.3.0] — 2026-06-12

### Added
- Durable sessions (`DurableDb`): encrypted, fsynced write-ahead log;
  acknowledged commits survive `kill -9` and power loss. Crash-safe
  checkpointing. SIGKILL power-cut harness (`tests/powercut.rs`).
- Single-column `PRIMARY KEY` and `UNIQUE` constraints; UPDATE validates
  before mutating (all-or-nothing per statement).
- Snapshot wire format v2 (per-column constraint byte); v1 still decoded.

## [0.2.0] — 2026-06-12

### Added
- SQL: `UPDATE`, column-list `INSERT`, `IS [NOT] NULL`, `?` parameter
  binding (`execute_params`, prepared statements).
- ML-DSA-87 (FIPS 204) signed manifests behind the `sign` feature.
- Pinned NIST ACVP FIPS 203/204 and RFC 9106 vectors.

## [0.1.0] — 2026-06-12

### Added
- SQL core (`CREATE TABLE`, `INSERT`, `SELECT`, `DELETE`; INTEGER/TEXT/
  NULL, no coercion).
- Encrypted vault `.mrm` (XChaCha20-Poly1305, Argon2id or raw key,
  atomic durable writes).
- ML-KEM-768 (FIPS 203) sealed exports.
- CLI REPL. RFC 8439 vectors.
