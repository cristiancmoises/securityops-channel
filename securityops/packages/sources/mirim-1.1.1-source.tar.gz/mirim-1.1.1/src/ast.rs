// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! AST for the v0.2 SQL subset.

use crate::value::{ColType, Constraint, Value};

/// Comparison operators usable in WHERE predicates.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CmpOp {
    Eq,
    Ne,
    Lt,
    Le,
    Gt,
    Ge,
}

/// A literal as written in SQL text. Converted to [`Value`] at execution.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Lit {
    Int(i64),
    Text(String),
    Null,
}

impl Lit {
    /// Convert the literal into a runtime value.
    pub fn into_value(self) -> Value {
        match self {
            Lit::Int(i) => Value::Int(i),
            Lit::Text(s) => Value::Text(s),
            Lit::Null => Value::Null,
        }
    }
}

/// A value position in a statement: either a literal or a `?` placeholder
/// bound at execution time. Placeholders are numbered left to right,
/// starting at 0, across the whole statement.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Arg {
    Lit(Lit),
    Param(u16),
}

/// One WHERE predicate. Predicates in a WHERE clause are AND-combined.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Pred {
    /// `col <op> arg`
    Cmp { col: String, op: CmpOp, arg: Arg },
    /// `col IS NULL` / `col IS NOT NULL`
    Null { col: String, negated: bool },
}

/// SELECT projection.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Proj {
    Star,
    Cols(Vec<String>),
    /// `COUNT(*)` — the number of matching rows, as a single-row,
    /// single-column result named `count(*)`.
    CountStar,
}

/// One `ORDER BY` sort key: a column and its direction.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OrderKey {
    pub col: String,
    /// `true` for `DESC`, `false` for `ASC` (the default).
    pub desc: bool,
}

/// A parsed statement.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Stmt {
    Create {
        table: String,
        cols: Vec<(String, ColType, Constraint)>,
    },
    Insert {
        table: String,
        /// Explicit column list, if written. Unlisted columns get NULL.
        cols: Option<Vec<String>>,
        values: Vec<Arg>,
    },
    Select {
        table: String,
        proj: Proj,
        wher: Vec<Pred>,
        /// `ORDER BY` keys, in priority order; empty means insertion order.
        order: Vec<OrderKey>,
        /// `LIMIT` count, if written.
        limit: Option<u64>,
        /// `OFFSET` count, if written (only meaningful with `LIMIT`).
        offset: Option<u64>,
    },
    Update {
        table: String,
        sets: Vec<(String, Arg)>,
        wher: Vec<Pred>,
    },
    Delete {
        table: String,
        wher: Vec<Pred>,
    },
}
