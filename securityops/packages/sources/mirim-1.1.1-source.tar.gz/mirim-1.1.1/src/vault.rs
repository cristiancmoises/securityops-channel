// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! Encrypted vault file (`.mrm`).
//!
//! Layout:
//! ```text
//! offset  size  field
//! 0       8     magic "MIRIM1\0\0"
//! 8       1     file version (1)
//! 9       1     kdf id: 0 = raw 32-byte key, 1 = Argon2id
//! 10      16    salt (random; all-zero unused padding for raw keys)
//! 26      24    XChaCha20-Poly1305 nonce (random per save)
//! 50      ..    AEAD ciphertext of the snapshot (wire format v1)
//! ```
//! The full 50-byte header is bound as AEAD associated data, so flipping
//! the version, kdf id, or salt invalidates the tag. The nonce is drawn
//! fresh from the OS CSPRNG on every save; with a 192-bit nonce the
//! collision bound stays negligible without nonce bookkeeping.

use std::fs;
use std::io::Write;
use std::path::Path;

use argon2::{Algorithm, Argon2, Params, Version};
use chacha20poly1305::aead::{Aead, KeyInit, Payload};
use chacha20poly1305::XChaCha20Poly1305;
use rand_core::{OsRng, RngCore};
use zeroize::Zeroizing;

use crate::engine::Db;
use crate::error::{Error, Result};
use crate::wire;

const MAGIC: &[u8; 8] = b"MIRIM1\0\0";
const FILE_VERSION: u8 = 1;
const KDF_RAW: u8 = 0;
const KDF_ARGON2ID: u8 = 1;
const SALT_LEN: usize = 16;
const NONCE_LEN: usize = 24;
const HEADER_LEN: usize = 8 + 1 + 1 + SALT_LEN + NONCE_LEN;

/// Argon2id parameters (RFC 9106 second recommended profile, scaled up):
/// 64 MiB memory, 3 passes, 4 lanes, 32-byte output.
const ARGON2_M_KIB: u32 = 65536;
const ARGON2_T: u32 = 3;
const ARGON2_P: u32 = 4;

/// Secret used to lock or unlock a vault.
pub enum Secret<'a> {
    /// A human passphrase, stretched with Argon2id.
    Passphrase(&'a str),
    /// A caller-managed 32-byte key, used as-is (no KDF). For callers that
    /// already hold a high-entropy key, e.g. from an HSM or another KDF.
    RawKey(&'a [u8; 32]),
}

impl Secret<'_> {
    fn kdf_id(&self) -> u8 {
        match self {
            Secret::Passphrase(_) => KDF_ARGON2ID,
            Secret::RawKey(_) => KDF_RAW,
        }
    }
}

fn argon2() -> Argon2<'static> {
    // Params are compile-time constants within documented ranges; treat a
    // rejection as a programming error rather than a runtime path.
    let params = Params::new(ARGON2_M_KIB, ARGON2_T, ARGON2_P, Some(32))
        .expect("Argon2 params are valid constants");
    Argon2::new(Algorithm::Argon2id, Version::V0x13, params)
}

fn derive_key(secret: &Secret<'_>, salt: &[u8; SALT_LEN]) -> Result<Zeroizing<[u8; 32]>> {
    let mut key = Zeroizing::new([0u8; 32]);
    match secret {
        Secret::Passphrase(p) => {
            argon2()
                .hash_password_into(p.as_bytes(), salt, key.as_mut())
                .map_err(|_| Error::Crypto)?;
        }
        Secret::RawKey(k) => key.copy_from_slice(*k),
    }
    Ok(key)
}

/// Seal a snapshot and also return the derived master key, for layers
/// (the WAL) that need to derive further keys bound to this snapshot.
pub(crate) fn seal_snapshot_full(
    db: &Db,
    secret: &Secret<'_>,
) -> Result<(Vec<u8>, Zeroizing<[u8; 32]>)> {
    let mut salt = [0u8; SALT_LEN];
    if secret.kdf_id() == KDF_ARGON2ID {
        OsRng.fill_bytes(&mut salt);
    }
    let mut nonce = [0u8; NONCE_LEN];
    OsRng.fill_bytes(&mut nonce);

    let mut header = Vec::with_capacity(HEADER_LEN);
    header.extend_from_slice(MAGIC);
    header.push(FILE_VERSION);
    header.push(secret.kdf_id());
    header.extend_from_slice(&salt);
    header.extend_from_slice(&nonce);
    debug_assert_eq!(header.len(), HEADER_LEN);

    let key = derive_key(secret, &salt)?;
    let cipher = XChaCha20Poly1305::new((&*key).into());
    let plaintext = wire::encode(db)?;
    let ct = cipher
        .encrypt(
            (&nonce).into(),
            Payload {
                msg: &plaintext,
                aad: &header,
            },
        )
        .map_err(|_| Error::Crypto)?;

    header.extend_from_slice(&ct);
    Ok((header, key))
}

/// Open a snapshot and also return the derived master key; see
/// [`seal_snapshot_full`].
pub(crate) fn open_snapshot_full(
    bytes: &[u8],
    secret: &Secret<'_>,
) -> Result<(Db, Zeroizing<[u8; 32]>)> {
    if bytes.len() < HEADER_LEN {
        return Err(Error::Corrupt("file shorter than header"));
    }
    let (header, ct) = bytes.split_at(HEADER_LEN);
    if &header[..8] != MAGIC {
        return Err(Error::Corrupt("bad magic"));
    }
    if header[8] != FILE_VERSION {
        return Err(Error::Corrupt("unsupported file version"));
    }
    let kdf = header[9];
    if kdf != secret.kdf_id() {
        return Err(Error::KdfMismatch);
    }
    let mut salt = [0u8; SALT_LEN];
    salt.copy_from_slice(&header[10..10 + SALT_LEN]);
    let nonce: [u8; NONCE_LEN] = header[10 + SALT_LEN..HEADER_LEN]
        .try_into()
        .expect("header slice has fixed length");

    let key = derive_key(secret, &salt)?;
    let cipher = XChaCha20Poly1305::new((&*key).into());
    let plaintext = Zeroizing::new(
        cipher
            .decrypt(
                (&nonce).into(),
                Payload {
                    msg: ct,
                    aad: header,
                },
            )
            .map_err(|_| Error::Crypto)?,
    );
    Ok((wire::decode(&plaintext)?, key))
}

/// Encrypt `db` and write it to `path` atomically: the snapshot is written
/// to an exclusively created sibling file, fsynced, then renamed over
/// the destination. On Unix, the new file is owner-readable/writable only.
/// A crash before the rename leaves the previous vault intact.
pub fn save(db: &Db, path: &Path, secret: &Secret<'_>) -> Result<()> {
    let (bytes, _key) = seal_snapshot_full(db, secret)?;
    write_atomic(path, &bytes)
}

/// Write `bytes` to `path` atomically: private temporary file, fsync, rename,
/// directory fsync. Shared by the vault and the WAL layer.
pub(crate) fn write_atomic(path: &Path, bytes: &[u8]) -> Result<()> {
    // A fixed `.tmp` name can be a pre-existing symlink or hard link.
    // Exclusive creation avoids following either and isolates concurrent saves.
    let (tmp, mut f) = loop {
        let mut random = [0u8; 16];
        OsRng
            .try_fill_bytes(&mut random)
            .map_err(|_| Error::Crypto)?;
        let mut name = path.as_os_str().to_owned();
        name.push(format!(".{:032x}.tmp", u128::from_le_bytes(random)));
        let tmp = std::path::PathBuf::from(name);
        let mut options = fs::OpenOptions::new();
        options.write(true).create_new(true);
        #[cfg(unix)]
        {
            use std::os::unix::fs::OpenOptionsExt;
            options.mode(0o600);
        }
        match options.open(&tmp) {
            Ok(f) => break (tmp, f),
            Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => continue,
            Err(e) => return Err(e.into()),
        }
    };
    let result = (|| {
        f.write_all(bytes)?;
        f.sync_all()?;
        drop(f);
        fs::rename(&tmp, path)
    })();
    if let Err(e) = result {
        let _ = fs::remove_file(&tmp);
        return Err(e.into());
    }
    // Best-effort directory sync for platform/filesystem compatibility.
    // Power-loss durability of the rename depends on this sync succeeding;
    // syncing the file alone does not persist its directory entry.
    if let Some(dir) = path.parent() {
        if let Ok(d) = fs::File::open(if dir.as_os_str().is_empty() {
            Path::new(".")
        } else {
            dir
        }) {
            let _ = d.sync_all();
        }
    }
    Ok(())
}

/// Read and decrypt a vault file. Fails closed: any tampering with header
/// or body, a wrong secret, or a secret of the wrong kind is an error.
pub fn load(path: &Path, secret: &Secret<'_>) -> Result<Db> {
    let bytes = fs::read(path)?;
    Ok(open_snapshot_full(&bytes, secret)?.0)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn header_len_is_50() {
        assert_eq!(HEADER_LEN, 50);
    }

    #[test]
    fn in_memory_roundtrip_raw_key() {
        let mut db = Db::new();
        db.execute("create table t (a integer)").unwrap();
        db.execute("insert into t values (7)").unwrap();
        let key = [0x42u8; 32];
        let (sealed, k1) = seal_snapshot_full(&db, &Secret::RawKey(&key)).unwrap();
        let (back, k2) = open_snapshot_full(&sealed, &Secret::RawKey(&key)).unwrap();
        assert_eq!(db, back);
        assert_eq!(*k1, *k2);
    }
}
