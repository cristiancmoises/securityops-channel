// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

#![forbid(unsafe_code)]
#![warn(missing_docs)]

//! # mirim
//!
//! A tiny embedded SQL database, encrypted at rest by default.
//!
//! - SQL subset: `CREATE TABLE`, `INSERT` (with column lists), `SELECT`,
//!   `UPDATE`, `DELETE`; `WHERE` with AND-chained comparisons and
//!   `IS [NOT] NULL`. Types: `INTEGER`, `TEXT`. `?` parameter binding via
//!   [`Db::execute_params`] and prepared [`Statement`]s.
//! - At rest: XChaCha20-Poly1305 over the whole snapshot, key from
//!   Argon2id (passphrase) or a caller-held raw key. See [`vault`].
//! - Post-quantum sealed exports: ML-KEM-768 (FIPS 203) to a recipient
//!   key, so archived copies resist harvest-now-decrypt-later. See [`pq`].
//! - Optional ML-DSA-87 (FIPS 204) signed manifests for vault files and
//!   sealed exports, behind the `sign` feature (`manifest` module).
//! - Durable sessions ([`DurableDb`]): an encrypted, fsynced write-ahead
//!   log makes every acknowledged mutation survive `kill -9` and power
//!   loss; `checkpoint` folds the log into the vault, `rotate_secret`
//!   re-keys it, and a per-database advisory lock (Unix) keeps a second
//!   writer out. See [`durable`].
//! - No classical public-key cryptography anywhere in the file formats.
//!
//! ```
//! use mirim::{Db, Output, Value};
//!
//! let mut db = Db::new();
//! db.execute("CREATE TABLE users (id INTEGER, name TEXT)").unwrap();
//! db.execute("INSERT INTO users VALUES (1, 'ana')").unwrap();
//! db.execute("INSERT INTO users VALUES (2, 'bia')").unwrap();
//!
//! match db.execute("SELECT name FROM users WHERE id = 1").unwrap() {
//!     Output::Rows { rows, .. } => {
//!         assert_eq!(rows, vec![vec![Value::Text("ana".into())]]);
//!     }
//!     _ => unreachable!(),
//! }
//!
//! // Untrusted input goes through `?` binding, never string splicing.
//! let out = db
//!     .execute_params("SELECT id FROM users WHERE name = ?",
//!                     &[Value::Text("bia".into())])
//!     .unwrap();
//! assert!(matches!(out, Output::Rows { rows, .. } if rows == vec![vec![Value::Int(2)]]));
//! ```

mod ast;
pub mod durable;
mod engine;
mod error;
mod lexer;
mod parser;
mod value;
mod wire;

#[cfg(feature = "sign")]
pub mod manifest;
pub mod pq;
pub mod vault;

/// Internal decoders re-exported for the out-of-tree fuzz targets
/// (`fuzz/`). Not API; gated behind the `fuzzing` feature and hidden
/// from docs. Nothing here weakens checks — these are the exact code
/// paths production inputs reach.
#[cfg(feature = "fuzzing")]
#[doc(hidden)]
pub mod fuzz_api {
    /// Snapshot wire decode, as reached after vault/seal authentication.
    pub fn wire_decode(bytes: &[u8]) {
        let _ = crate::wire::decode(bytes);
    }

    /// WAL open path: writes `wal` next to a fixed empty vault in `dir`
    /// and runs the full replay (header checks, torn-tail repair,
    /// record decryption, statement re-execution).
    pub fn wal_open(dir: &std::path::Path, wal: &[u8]) {
        let key = [0u8; 32];
        let vault_path = dir.join("fuzz.mrm");
        if !vault_path.exists() {
            crate::vault::save(
                &crate::Db::new(),
                &vault_path,
                &crate::vault::Secret::RawKey(&key),
            )
            .expect("seed vault");
        }
        let mut wal_path = vault_path.as_os_str().to_owned();
        wal_path.push(".wal");
        std::fs::write(std::path::PathBuf::from(wal_path), wal).expect("write fuzz wal");
        let _ = crate::DurableDb::open(&vault_path, &crate::vault::Secret::RawKey(&key));
    }
}

pub use durable::DurableDb;
pub use engine::{split_statements, Db, Output, Statement};
pub use error::{Error, Result};
pub use value::{ColType, Constraint, Value};
