// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! Durable sessions: an encrypted write-ahead log next to the vault.
//!
//! [`DurableDb`] wraps the in-memory engine with commit durability. Every
//! mutating statement is appended to `<vault>.wal` and fsynced *before*
//! it executes; once `execute` returns `Ok`, the statement survives any
//! crash, including `kill -9` and power loss. `SELECT`s never touch the
//! log. [`DurableDb::checkpoint`] folds the log into a fresh snapshot and
//! resets it.
//!
//! WAL file layout:
//! ```text
//! header (plaintext, 41 bytes, bound as AAD into every record):
//!   0   8   magic "MIRIMWL1"
//!   8   1   version (1)
//!   9   32  snapshot id = SHA-256 of the vault file this log extends
//! record (repeated):
//!   0   8   sequence number, u64 LE, 1-based, consecutive
//!   8   24  XChaCha20-Poly1305 nonce (random per record)
//!   32  4   ciphertext length, u32 LE (<= 16 MiB)
//!   36  ..  ciphertext; AAD = header || sequence-number bytes
//! record plaintext:
//!   u32 LE sql length | sql UTF-8 | u16 LE param count | params,
//!   each in the snapshot value encoding (tag byte + payload)
//! ```
//! Record key: `HKDF-SHA256(ikm = vault master key, salt = snapshot id,
//! info = "mirim.v1.wal.xchacha20poly1305")`. Keying *and* AAD bind every
//! record to the exact snapshot bytes it extends, so a log can neither be
//! replayed against a different vault nor have records reordered
//! (sequence numbers are authenticated and must be consecutive).
//!
//! Crash analysis of [`DurableDb::checkpoint`] (snapshot rename happens
//! strictly before the log reset):
//! - crash before the snapshot rename: old snapshot + old log; replay
//!   reconstructs the full state.
//! - crash between snapshot rename and log reset: the on-disk log names a
//!   snapshot id that no longer matches. Its contents are already folded
//!   into the new snapshot, so it is discarded and recreated empty.
//! - a torn final record (the only kind an honest crash can produce, as
//!   each record is fsynced before the next is written) is detected and
//!   truncated on open.
//!
//! A complete record that fails authentication *followed by more data*
//! cannot result from a crash and is reported as corruption, not
//! repaired.
//!
//! Statements are logged before execution; one that then fails (e.g. a
//! PRIMARY KEY violation) stays in the log and is skipped identically on
//! replay — the engine is deterministic, so replay converges on the same
//! state.
//!
//! An exclusive file lock on `<vault>.lock` is held for the whole
//! session: a second open fails fast with [`Error::Locked`] instead of
//! corrupting the log, and the kernel releases the lock on process death
//! (so `kill -9` recovery is never wedged by a stale lock). This uses
//! `flock` on Unix and `LockFileEx` on Windows through Rust's standard
//! library. Unsupported locking returns an error; see SECURITY.md.
//!
//! Not provided, deliberately and visibly: rollback protection (an
//! adversary with write access can truncate the log or restore an older
//! snapshot+log pair; tampering with the *final* record is equivalent to
//! truncation) and record padding (record count and sizes leak statement
//! count and approximate sizes).

use std::fs::{self, File, OpenOptions};
use std::io::Write;
use std::path::{Path, PathBuf};

use chacha20poly1305::aead::{Aead, KeyInit, Payload};
use chacha20poly1305::XChaCha20Poly1305;
use hkdf::Hkdf;
use rand_core::{OsRng, RngCore};
use sha2::{Digest, Sha256};
use zeroize::Zeroizing;

use crate::engine::{Db, Output, Statement};
use crate::error::{Error, Result};
use crate::value::Value;
use crate::vault::{self, Secret};
use crate::wire;

const WAL_MAGIC: &[u8; 8] = b"MIRIMWL1";
const WAL_VERSION: u8 = 1;
const SNAP_ID_LEN: usize = 32;
const WAL_HEADER_LEN: usize = 8 + 1 + SNAP_ID_LEN;
const NONCE_LEN: usize = 24;
const REC_FIXED_LEN: usize = 8 + NONCE_LEN + 4;
/// Upper bound on one record's ciphertext; anything larger is treated as
/// framing damage before any allocation happens.
const MAX_RECORD_CT: u32 = 1 << 24;
const WAL_INFO: &[u8] = b"mirim.v1.wal.xchacha20poly1305";

/// An owned copy of the vault secret, kept for checkpointing.
enum OwnedSecret {
    Passphrase(Zeroizing<String>),
    RawKey(Zeroizing<[u8; 32]>),
}

impl OwnedSecret {
    fn of(s: &Secret<'_>) -> Self {
        match s {
            Secret::Passphrase(p) => OwnedSecret::Passphrase(Zeroizing::new((*p).to_owned())),
            Secret::RawKey(k) => OwnedSecret::RawKey(Zeroizing::new(**k)),
        }
    }

    fn borrow(&self) -> Secret<'_> {
        match self {
            OwnedSecret::Passphrase(p) => Secret::Passphrase(p),
            OwnedSecret::RawKey(k) => Secret::RawKey(k),
        }
    }
}

/// A database with commit durability. See the module docs for the exact
/// guarantees and their limits.
pub struct DurableDb {
    db: Db,
    snapshot_path: PathBuf,
    wal_path: PathBuf,
    secret: OwnedSecret,
    wal: File,
    wal_key: Zeroizing<[u8; 32]>,
    header: [u8; WAL_HEADER_LEN],
    next_seq: u64,
    poisoned: bool,
    /// Held for the session; dropping releases the advisory lock.
    _lock: File,
}

/// Take the per-database advisory lock, failing fast if another live
/// process holds it. std uses flock on Unix and LockFileEx on Windows;
/// unsupported filesystems/platforms return an error instead of opening unlocked.
fn take_lock(snapshot_path: &Path) -> Result<File> {
    let mut lock_path = snapshot_path.as_os_str().to_owned();
    lock_path.push(".lock");
    let f = OpenOptions::new()
        .create(true)
        .write(true)
        .truncate(false)
        .open(PathBuf::from(lock_path))?;
    match f.try_lock() {
        Ok(()) => Ok(f),
        Err(std::fs::TryLockError::WouldBlock) => Err(Error::Locked),
        Err(std::fs::TryLockError::Error(e)) => Err(e.into()),
    }
}

fn wal_key_for(master: &[u8; 32], snap_id: &[u8; SNAP_ID_LEN]) -> Zeroizing<[u8; 32]> {
    let hk = Hkdf::<Sha256>::new(Some(snap_id), master);
    let mut key = Zeroizing::new([0u8; 32]);
    hk.expand(WAL_INFO, key.as_mut())
        .expect("32 bytes is a valid HKDF-SHA256 output length");
    key
}

fn wal_header(snap_id: &[u8; SNAP_ID_LEN]) -> [u8; WAL_HEADER_LEN] {
    let mut h = [0u8; WAL_HEADER_LEN];
    h[..8].copy_from_slice(WAL_MAGIC);
    h[8] = WAL_VERSION;
    h[9..].copy_from_slice(snap_id);
    h
}

fn encode_record_plaintext(sql: &str, params: &[Value]) -> Result<Zeroizing<Vec<u8>>> {
    let mut out = Zeroizing::new(Vec::with_capacity(4 + sql.len() + 2));
    out.extend_from_slice(&(sql.len() as u32).to_le_bytes());
    out.extend_from_slice(sql.as_bytes());
    out.extend_from_slice(&(params.len() as u16).to_le_bytes());
    for p in params {
        wire::put_value(&mut out, p)?;
    }
    Ok(out)
}

fn decode_record_plaintext(bytes: &[u8]) -> Result<(String, Vec<Value>)> {
    let mut c = wire::Cursor::new(bytes);
    let sql = c.str()?;
    let nparams = c.u16()?;
    let mut params = Vec::new();
    for _ in 0..nparams {
        params.push(c.value()?);
    }
    if !c.done() {
        return Err(Error::Corrupt("trailing bytes in wal record"));
    }
    Ok((sql, params))
}

impl DurableDb {
    /// Open a durable session on `path`, creating an empty vault if the
    /// file does not exist. Replays the write-ahead log, repairing a torn
    /// tail and discarding a log left behind by an interrupted
    /// checkpoint.
    pub fn open(path: &Path, secret: &Secret<'_>) -> Result<Self> {
        let lock = take_lock(path)?;
        if !path.exists() {
            vault::save(&Db::new(), path, secret)?;
        }
        let bytes = fs::read(path)?;
        let (mut db, master) = vault::open_snapshot_full(&bytes, secret)?;
        let snap_id: [u8; SNAP_ID_LEN] = Sha256::digest(&bytes).into();
        drop(bytes);
        let wal_key = wal_key_for(&master, &snap_id);
        let header = wal_header(&snap_id);

        let mut wal_path = path.as_os_str().to_owned();
        wal_path.push(".wal");
        let wal_path = PathBuf::from(wal_path);

        let next_seq = if wal_path.exists() {
            replay_wal(&wal_path, &header, &wal_key, &mut db)?
        } else {
            vault::write_atomic(&wal_path, &header)?;
            1
        };

        let wal = OpenOptions::new().append(true).open(&wal_path)?;
        Ok(DurableDb {
            db,
            snapshot_path: path.to_owned(),
            wal_path,
            secret: OwnedSecret::of(secret),
            wal,
            wal_key,
            header,
            next_seq,
            poisoned: false,
            _lock: lock,
        })
    }

    /// Read-only view of the current state.
    pub fn db(&self) -> &Db {
        &self.db
    }

    /// Number of records in the log since the last checkpoint.
    pub fn wal_records(&self) -> u64 {
        self.next_seq - 1
    }

    /// Execute one statement durably; see [`Self::execute_params`].
    pub fn execute(&mut self, sql: &str) -> Result<Output> {
        self.execute_params(sql, &[])
    }

    /// Execute one statement with bound parameters. Mutating statements
    /// are fsynced to the log before they run; `Ok` means durable.
    /// `SELECT`s bypass the log entirely.
    pub fn execute_params(&mut self, sql: &str, params: &[Value]) -> Result<Output> {
        self.check_poisoned()?;
        let stmt = Statement::prepare(sql)?;
        if params.len() != usize::from(stmt.param_count()) {
            return Err(Error::Exec(format!(
                "statement has {} parameter(s) but {} were bound",
                stmt.param_count(),
                params.len()
            )));
        }
        if stmt.is_read_only() {
            return self.db.run(&stmt, params);
        }
        // The writer must honor the same limit as replay. Otherwise an
        // acknowledged large write would be silently discarded on reopen.
        // Reject before touching the log so this does not poison the session.
        validate_record_size(sql, params)?;
        if let Err(e) = self.append_record(sql, params) {
            // The file position is now unknown territory; refuse further
            // writes so the log cannot be interleaved with garbage.
            self.poisoned = true;
            return Err(e);
        }
        self.next_seq += 1;
        // An execution failure here (e.g. a constraint violation) is
        // fine: the logged statement fails identically on replay.
        self.db.run(&stmt, params)
    }

    /// Fold the log into a fresh snapshot and reset it. The snapshot is
    /// written atomically first; only then is the log replaced, so a
    /// crash at any point leaves a consistent pair on disk.
    pub fn checkpoint(&mut self) -> Result<()> {
        self.check_poisoned()?;
        if self.next_seq == 1 {
            return Ok(());
        }
        if let Err(e) = self.checkpoint_inner() {
            self.poisoned = true;
            return Err(e);
        }
        Ok(())
    }

    /// Re-encrypt the vault under `new_secret` and reset the log. The
    /// snapshot and the log rebind immediately; the old secret stops
    /// opening the database from this moment on. The previous ciphertext
    /// is replaced, not shredded — freed blocks on the underlying medium
    /// may retain it (see SECURITY.md).
    pub fn rotate_secret(&mut self, new_secret: &Secret<'_>) -> Result<()> {
        self.check_poisoned()?;
        let owned = OwnedSecret::of(new_secret);
        if let Err(e) = self.checkpoint_with(&owned) {
            self.poisoned = true;
            return Err(e);
        }
        self.secret = owned;
        Ok(())
    }

    fn checkpoint_inner(&mut self) -> Result<()> {
        let (bytes, master) = vault::seal_snapshot_full(&self.db, &self.secret.borrow())?;
        self.finish_checkpoint(bytes, master)
    }

    fn checkpoint_with(&mut self, secret: &OwnedSecret) -> Result<()> {
        let (bytes, master) = vault::seal_snapshot_full(&self.db, &secret.borrow())?;
        self.finish_checkpoint(bytes, master)
    }

    fn finish_checkpoint(&mut self, bytes: Vec<u8>, master: Zeroizing<[u8; 32]>) -> Result<()> {
        vault::write_atomic(&self.snapshot_path, &bytes)?;
        let snap_id: [u8; SNAP_ID_LEN] = Sha256::digest(&bytes).into();
        self.wal_key = wal_key_for(&master, &snap_id);
        self.header = wal_header(&snap_id);
        vault::write_atomic(&self.wal_path, &self.header)?;
        self.wal = OpenOptions::new().append(true).open(&self.wal_path)?;
        self.next_seq = 1;
        Ok(())
    }

    fn check_poisoned(&self) -> Result<()> {
        if self.poisoned {
            return Err(Error::Exec(
                "durable session poisoned by an earlier i/o failure; reopen the database".into(),
            ));
        }
        Ok(())
    }

    fn append_record(&mut self, sql: &str, params: &[Value]) -> Result<()> {
        let plaintext = encode_record_plaintext(sql, params)?;
        let mut nonce = [0u8; NONCE_LEN];
        OsRng.fill_bytes(&mut nonce);
        let seq = self.next_seq.to_le_bytes();
        let mut aad = Vec::with_capacity(WAL_HEADER_LEN + 8);
        aad.extend_from_slice(&self.header);
        aad.extend_from_slice(&seq);

        let cipher = XChaCha20Poly1305::new((&*self.wal_key).into());
        let ct = cipher
            .encrypt(
                (&nonce).into(),
                Payload {
                    msg: &plaintext,
                    aad: &aad,
                },
            )
            .map_err(|_| Error::Crypto)?;

        let mut rec = Vec::with_capacity(REC_FIXED_LEN + ct.len());
        rec.extend_from_slice(&seq);
        rec.extend_from_slice(&nonce);
        rec.extend_from_slice(&(ct.len() as u32).to_le_bytes());
        rec.extend_from_slice(&ct);
        self.wal.write_all(&rec)?;
        self.wal.sync_data()?;
        Ok(())
    }
}

fn validate_record_size(sql: &str, params: &[Value]) -> Result<()> {
    // SQL length prefix + parameter count + authentication tag.
    let mut len = sql.len().checked_add(4 + 2 + 16);
    for param in params {
        let value_len = match param {
            Value::Null => Some(1),
            Value::Int(_) => Some(9),
            Value::Text(text) => text.len().checked_add(5),
        };
        len = len.and_then(|n| value_len.and_then(|v| n.checked_add(v)));
    }
    match len {
        Some(n) if n <= MAX_RECORD_CT as usize => Ok(()),
        _ => Err(Error::Exec(
            "WAL record exceeds the 16 MiB ciphertext limit".into(),
        )),
    }
}

/// Replay a log onto `db`. Returns the next sequence number. Repairs a
/// torn tail (truncates the file); rejects everything else that is wrong.
fn replay_wal(
    wal_path: &Path,
    expected_header: &[u8; WAL_HEADER_LEN],
    wal_key: &Zeroizing<[u8; 32]>,
    db: &mut Db,
) -> Result<u64> {
    let bytes = fs::read(wal_path)?;
    if bytes.len() < WAL_HEADER_LEN {
        return Err(Error::Corrupt("wal shorter than its header"));
    }
    let header: &[u8; WAL_HEADER_LEN] = bytes[..WAL_HEADER_LEN]
        .try_into()
        .expect("fixed-length slice");
    if &header[..8] != WAL_MAGIC {
        return Err(Error::Corrupt("bad wal magic"));
    }
    if header[8] != WAL_VERSION {
        return Err(Error::Corrupt("unsupported wal version"));
    }
    if header != expected_header {
        // The log names a different snapshot: an interrupted checkpoint
        // replaced the snapshot but not the log. Its records are already
        // folded into the snapshot we just loaded; start fresh.
        vault::write_atomic(wal_path, expected_header)?;
        return Ok(1);
    }

    let cipher = XChaCha20Poly1305::new((&**wal_key).into());
    let mut off = WAL_HEADER_LEN;
    let mut seq: u64 = 1;
    loop {
        if off == bytes.len() {
            return Ok(seq);
        }
        // Anything that prevents reading one complete record is, by the
        // write protocol, only possible as a torn final write: truncate.
        let rest = bytes.len() - off;
        if rest < REC_FIXED_LEN {
            return truncate_tail(wal_path, off, seq);
        }
        let rec_seq = u64::from_le_bytes(bytes[off..off + 8].try_into().expect("fixed"));
        let nonce: [u8; NONCE_LEN] = bytes[off + 8..off + 8 + NONCE_LEN]
            .try_into()
            .expect("fixed");
        let ct_len = u32::from_le_bytes(
            bytes[off + 8 + NONCE_LEN..off + REC_FIXED_LEN]
                .try_into()
                .expect("fixed"),
        );
        if ct_len > MAX_RECORD_CT || rest - REC_FIXED_LEN < ct_len as usize {
            return truncate_tail(wal_path, off, seq);
        }
        let end = off + REC_FIXED_LEN + ct_len as usize;
        let ct = &bytes[off + REC_FIXED_LEN..end];
        let last = end == bytes.len();

        // A wrong sequence number or failed authentication on the *final*
        // record is a torn write; anywhere else it cannot come from a
        // crash and is corruption.
        if rec_seq != seq {
            return if last {
                truncate_tail(wal_path, off, seq)
            } else {
                Err(Error::Corrupt("wal sequence break before end of log"))
            };
        }
        let mut aad = Vec::with_capacity(WAL_HEADER_LEN + 8);
        aad.extend_from_slice(expected_header);
        aad.extend_from_slice(&rec_seq.to_le_bytes());
        let plaintext = match cipher.decrypt((&nonce).into(), Payload { msg: ct, aad: &aad }) {
            Ok(p) => Zeroizing::new(p),
            Err(_) if last => return truncate_tail(wal_path, off, seq),
            Err(_) => return Err(Error::Corrupt("wal record failed authentication mid-log")),
        };

        let (sql, params) = decode_record_plaintext(&plaintext)?;
        let stmt = Statement::prepare(&sql)
            .map_err(|_| Error::Corrupt("logged statement no longer parses"))?;
        match db.run(&stmt, &params) {
            Ok(_) => {}
            // Deterministic re-failure of a statement that failed when it
            // was first logged (e.g. a constraint violation).
            Err(Error::Exec(_)) => {}
            Err(e) => return Err(e),
        }
        off = end;
        seq += 1;
    }
}

fn truncate_tail(wal_path: &Path, keep: usize, next_seq: u64) -> Result<u64> {
    let f = OpenOptions::new().write(true).open(wal_path)?;
    f.set_len(keep as u64)?;
    f.sync_data()?;
    Ok(next_seq)
}
