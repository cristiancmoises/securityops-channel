// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! In-memory execution engine.

use std::cmp::Ordering;
use std::collections::{BTreeMap, HashMap};

use crate::ast::{Arg, CmpOp, OrderKey, Pred, Proj, Stmt};
use crate::error::{Error, Result};
use crate::parser;
use crate::value::{ColType, Constraint, Value};

/// A table: ordered column schema, row storage, and a derived per-column
/// equality index over PRIMARY KEY / UNIQUE columns.
///
/// `indexes[i]` is `Some(map)` exactly when column `i` is a PRIMARY KEY or
/// UNIQUE column; `map` sends each *non-NULL* value to the single row that
/// holds it (the constraint guarantees at most one). NULLs are never
/// indexed: PRIMARY KEY forbids them and UNIQUE permits any number. The
/// index is pure derived state — a function of `cols` and `rows` — so it
/// is excluded from equality and rebuilt whenever rows shift.
#[derive(Debug, Clone)]
pub(crate) struct Table {
    pub(crate) cols: Vec<(String, ColType, Constraint)>,
    pub(crate) rows: Vec<Vec<Value>>,
    indexes: Vec<Option<HashMap<Value, usize>>>,
}

impl PartialEq for Table {
    fn eq(&self, other: &Self) -> bool {
        // Identity is schema + data; the index is derived, not stored.
        self.cols == other.cols && self.rows == other.rows
    }
}
impl Eq for Table {}

impl Table {
    /// Empty table with index slots allocated per the column constraints.
    fn new(cols: Vec<(String, ColType, Constraint)>) -> Table {
        Self::from_parts(cols, Vec::new())
    }

    /// Build a table from a schema and rows (e.g. after decoding a
    /// snapshot), allocating and populating the indexes.
    pub(crate) fn from_parts(
        cols: Vec<(String, ColType, Constraint)>,
        rows: Vec<Vec<Value>>,
    ) -> Table {
        let indexes = cols
            .iter()
            .map(|(_, _, c)| match c {
                Constraint::PrimaryKey | Constraint::Unique => Some(HashMap::new()),
                Constraint::None => None,
            })
            .collect();
        let mut t = Table {
            cols,
            rows,
            indexes,
        };
        t.rebuild_indexes();
        t
    }

    /// Whether column `i` carries an equality index.
    fn is_indexed(&self, i: usize) -> bool {
        matches!(self.indexes.get(i), Some(Some(_)))
    }

    /// Rebuild every index from `rows`. Used after row indices shift
    /// (DELETE) or after constructing from external data (decode).
    fn rebuild_indexes(&mut self) {
        for map in self.indexes.iter_mut().flatten() {
            map.clear();
        }
        for (r, row) in self.rows.iter().enumerate() {
            for (i, slot) in self.indexes.iter_mut().enumerate() {
                if let Some(map) = slot {
                    if row[i] != Value::Null {
                        map.insert(row[i].clone(), r);
                    }
                }
            }
        }
    }

    /// Index a freshly appended row at position `r`.
    fn index_appended(&mut self, r: usize) {
        for (i, slot) in self.indexes.iter_mut().enumerate() {
            if let Some(map) = slot {
                if self.rows[r][i] != Value::Null {
                    map.insert(self.rows[r][i].clone(), r);
                }
            }
        }
    }
}

/// An in-memory database. Persistence and sealing live in [`crate::vault`]
/// and [`crate::pq`]; the engine itself never touches keys or disk.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct Db {
    pub(crate) tables: BTreeMap<String, Table>,
}

/// Result of executing one statement.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Output {
    /// DDL succeeded (CREATE TABLE).
    Done,
    /// Number of rows inserted, updated, or deleted.
    Affected(u64),
    /// Result set of a SELECT.
    Rows {
        /// Projected column names, in output order.
        columns: Vec<String>,
        /// Matching rows; each row is in `columns` order.
        rows: Vec<Vec<Value>>,
    },
}

/// A parsed statement, reusable across executions with different bound
/// parameters. Parsing is schema-independent, so a `Statement` prepared
/// once can run against any [`Db`].
#[derive(Debug, Clone)]
pub struct Statement {
    stmt: Stmt,
    nparams: u16,
}

impl Statement {
    /// Parse `sql` once for repeated execution via [`Db::run`].
    pub fn prepare(sql: &str) -> Result<Self> {
        let (stmt, nparams) = parser::parse(sql)?;
        Ok(Self { stmt, nparams })
    }

    /// Number of `?` placeholders in the statement.
    pub fn param_count(&self) -> u16 {
        self.nparams
    }

    /// Whether the statement cannot mutate the database (only `SELECT`
    /// qualifies). Used by the durable layer to skip logging reads.
    pub(crate) fn is_read_only(&self) -> bool {
        matches!(self.stmt, Stmt::Select { .. })
    }
}

impl Db {
    /// Create an empty in-memory database.
    pub fn new() -> Self {
        Self::default()
    }

    /// Names of all tables, in sorted order.
    pub fn table_names(&self) -> Vec<&str> {
        self.tables.keys().map(String::as_str).collect()
    }

    /// The column schema of `table` — `(name, type, constraint)` in
    /// declaration order — or `None` if there is no such table. Useful for
    /// tools that introspect a database (the CLI `.schema` command uses it).
    pub fn table_columns(&self, table: &str) -> Option<Vec<(String, ColType, Constraint)>> {
        self.tables.get(table).map(|t| t.cols.clone())
    }

    /// Reconstruct the `CREATE TABLE` statements for the whole database, one
    /// per line, in sorted table order. The output re-parses to the same
    /// schema; it is a faithful description, not the original SQL text
    /// (comments and formatting are not retained anywhere).
    pub fn schema_sql(&self) -> String {
        let mut out = String::new();
        for (name, t) in &self.tables {
            out.push_str("CREATE TABLE ");
            out.push_str(name);
            out.push_str(" (");
            for (i, (col, ty, con)) in t.cols.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                out.push_str(col);
                out.push(' ');
                out.push_str(&ty.to_string());
                match con {
                    Constraint::PrimaryKey => out.push_str(" PRIMARY KEY"),
                    Constraint::Unique => out.push_str(" UNIQUE"),
                    Constraint::None => {}
                }
            }
            out.push_str(");\n");
        }
        out
    }

    /// Parse and execute one SQL statement with no bound parameters.
    pub fn execute(&mut self, sql: &str) -> Result<Output> {
        self.execute_params(sql, &[])
    }

    /// Parse and execute one SQL statement, binding `params` to its `?`
    /// placeholders in order. Binding is the supported way to carry
    /// untrusted input into a statement; never splice strings into SQL.
    pub fn execute_params(&mut self, sql: &str, params: &[Value]) -> Result<Output> {
        let stmt = Statement::prepare(sql)?;
        self.run(&stmt, params)
    }

    /// Execute every statement in a multi-statement script, in order.
    /// Statements are separated by `;`, and the split is string- and
    /// comment-aware (see [`split_statements`]). Returns the number of
    /// statements run on success. There are no transactions: on the first
    /// error, statements already applied stay applied, and the error names
    /// the offending statement's position (1-based).
    ///
    /// This is a convenience for loading fixtures and sample databases into
    /// an in-memory [`Db`]; it takes no bound parameters, so it is for
    /// trusted script text, not untrusted input.
    pub fn execute_script(&mut self, sql: &str) -> Result<usize> {
        let mut ran = 0usize;
        for stmt in split_statements(sql) {
            self.execute(&stmt).map_err(|e| match e {
                Error::Parse(m) => Error::Parse(format!("statement {}: {m}", ran + 1)),
                Error::Exec(m) => Error::Exec(format!("statement {}: {m}", ran + 1)),
                other => other,
            })?;
            ran += 1;
        }
        Ok(ran)
    }

    /// Execute a prepared [`Statement`] with `params` bound to its `?`
    /// placeholders in order.
    pub fn run(&mut self, stmt: &Statement, params: &[Value]) -> Result<Output> {
        if params.len() != usize::from(stmt.nparams) {
            return Err(Error::Exec(format!(
                "statement has {} parameter(s) but {} were bound",
                stmt.nparams,
                params.len()
            )));
        }
        self.dispatch(&stmt.stmt, params)
    }

    fn dispatch(&mut self, stmt: &Stmt, params: &[Value]) -> Result<Output> {
        match stmt {
            Stmt::Create { table, cols } => self.create(table, cols),
            Stmt::Insert {
                table,
                cols,
                values,
            } => self.insert(table, cols.as_deref(), values, params),
            Stmt::Select {
                table,
                proj,
                wher,
                order,
                limit,
                offset,
            } => self.select(table, proj, wher, order, *limit, *offset, params),
            Stmt::Update { table, sets, wher } => self.update(table, sets, wher, params),
            Stmt::Delete { table, wher } => self.delete(table, wher, params),
        }
    }

    fn create(&mut self, table: &str, cols: &[(String, ColType, Constraint)]) -> Result<Output> {
        if cols.is_empty() {
            return Err(Error::Exec("a table needs at least one column".into()));
        }
        if cols.len() > usize::from(u16::MAX) {
            return Err(Error::Exec("a table cannot exceed 65535 columns".into()));
        }
        for i in 0..cols.len() {
            for j in (i + 1)..cols.len() {
                if cols[i].0 == cols[j].0 {
                    return Err(Error::Exec(format!("duplicate column: {}", cols[i].0)));
                }
            }
        }
        if cols
            .iter()
            .filter(|(_, _, c)| *c == Constraint::PrimaryKey)
            .count()
            > 1
        {
            return Err(Error::Exec("at most one PRIMARY KEY per table".into()));
        }
        if self.tables.contains_key(table) {
            return Err(Error::Exec(format!("table already exists: {table}")));
        }
        self.tables
            .insert(table.to_owned(), Table::new(cols.to_vec()));
        Ok(Output::Done)
    }

    fn insert(
        &mut self,
        table: &str,
        cols: Option<&[String]>,
        values: &[Arg],
        params: &[Value],
    ) -> Result<Output> {
        let t = self
            .tables
            .get_mut(table)
            .ok_or_else(|| Error::Exec(format!("no such table: {table}")))?;
        let mut row = vec![Value::Null; t.cols.len()];
        match cols {
            None => {
                if values.len() != t.cols.len() {
                    return Err(Error::Exec(format!(
                        "table {table} has {} columns but {} values were supplied",
                        t.cols.len(),
                        values.len()
                    )));
                }
                for (i, arg) in values.iter().enumerate() {
                    row[i] = resolve_arg(arg, params);
                }
            }
            Some(names) => {
                if values.len() != names.len() {
                    return Err(Error::Exec(format!(
                        "{} column(s) listed but {} value(s) supplied",
                        names.len(),
                        values.len()
                    )));
                }
                let mut seen = vec![false; t.cols.len()];
                for (name, arg) in names.iter().zip(values) {
                    let idx = col_index(t, name)?;
                    if seen[idx] {
                        return Err(Error::Exec(format!("duplicate column in list: {name}")));
                    }
                    seen[idx] = true;
                    row[idx] = resolve_arg(arg, params);
                }
            }
        }
        for (v, (cname, cty, _)) in row.iter().zip(t.cols.iter()) {
            if !v.fits(*cty) {
                return Err(Error::Exec(format!(
                    "value {v} does not fit column {cname} of type {cty}"
                )));
            }
        }
        check_insert_constraints(t, &row)?;
        let r = t.rows.len();
        t.rows.push(row);
        t.index_appended(r);
        Ok(Output::Affected(1))
    }

    #[allow(clippy::too_many_arguments)]
    fn select(
        &mut self,
        table: &str,
        proj: &Proj,
        wher: &[Pred],
        order: &[OrderKey],
        limit: Option<u64>,
        offset: Option<u64>,
        params: &[Value],
    ) -> Result<Output> {
        let t = self
            .tables
            .get(table)
            .ok_or_else(|| Error::Exec(format!("no such table: {table}")))?;
        let preds = resolve_preds(t, wher, params)?;

        // Resolve ORDER BY columns to indices up front (fails on unknown
        // column before any work). Direction travels alongside the index.
        let order_idx: Vec<(usize, bool)> = order
            .iter()
            .map(|k| Ok((col_index(t, &k.col)?, k.desc)))
            .collect::<Result<_>>()?;

        // Collect matching row positions. The index narrows the candidate
        // set when WHERE pins an indexed column; the fallback scan yields
        // positions in insertion order, which is the default result order.
        let mut matched: Vec<usize> = match candidate_indices(t, &preds) {
            Some(cands) => cands
                .into_iter()
                .filter(|&c| row_matches(&t.rows[c], &preds))
                .collect(),
            None => (0..t.rows.len())
                .filter(|&i| row_matches(&t.rows[i], &preds))
                .collect(),
        };

        // COUNT(*) collapses to one row; LIMIT/OFFSET still apply to that
        // single-row result set (LIMIT 0 or OFFSET ≥ 1 yields no rows).
        if let Proj::CountStar = proj {
            let mut rows = vec![vec![Value::Int(matched.len() as i64)]];
            apply_window(&mut rows, offset, limit);
            return Ok(Output::Rows {
                columns: vec!["count(*)".to_string()],
                rows,
            });
        }

        // Stable multi-key sort. `sort_by` preserves insertion order among
        // rows equal on every key, so ORDER BY is a refinement, never a
        // reshuffle. NULLs sort first under ASC (see `value_order`).
        if !order_idx.is_empty() {
            matched.sort_by(|&x, &y| {
                for &(ci, desc) in &order_idx {
                    let ord = value_order(&t.rows[x][ci], &t.rows[y][ci]);
                    let ord = if desc { ord.reverse() } else { ord };
                    if ord != Ordering::Equal {
                        return ord;
                    }
                }
                Ordering::Equal
            });
        }

        apply_window(&mut matched, offset, limit);

        let (idx, columns): (Vec<usize>, Vec<String>) = match proj {
            Proj::Star => t
                .cols
                .iter()
                .enumerate()
                .map(|(i, (n, _, _))| (i, n.clone()))
                .unzip(),
            Proj::Cols(names) => {
                let mut idx = Vec::with_capacity(names.len());
                for n in names {
                    idx.push(col_index(t, n)?);
                }
                (idx, names.clone())
            }
            Proj::CountStar => unreachable!("handled above"),
        };
        let rows = matched
            .iter()
            .map(|&r| idx.iter().map(|&i| t.rows[r][i].clone()).collect())
            .collect();
        Ok(Output::Rows { columns, rows })
    }

    fn update(
        &mut self,
        table: &str,
        sets: &[(String, Arg)],
        wher: &[Pred],
        params: &[Value],
    ) -> Result<Output> {
        let t = self
            .tables
            .get_mut(table)
            .ok_or_else(|| Error::Exec(format!("no such table: {table}")))?;
        let preds = resolve_preds(t, wher, params)?;
        let mut assigns = Vec::with_capacity(sets.len());
        let mut seen = vec![false; t.cols.len()];
        for (name, arg) in sets {
            let idx = col_index(t, name)?;
            if seen[idx] {
                return Err(Error::Exec(format!("duplicate column in SET: {name}")));
            }
            seen[idx] = true;
            let v = resolve_arg(arg, params);
            let cty = t.cols[idx].1;
            if !v.fits(cty) {
                return Err(Error::Exec(format!(
                    "value {v} does not fit column {name} of type {cty}"
                )));
            }
            assigns.push((idx, v));
        }
        // Two passes: validate everything, then mutate. A constraint
        // violation must leave the table untouched. Row identification
        // uses the index when WHERE pins an indexed column; validation
        // still scans (the rare path), which is always correct.
        let matched: Vec<usize> = match candidate_indices(t, &preds) {
            Some(cands) => cands
                .into_iter()
                .filter(|&i| row_matches(&t.rows[i], &preds))
                .collect(),
            None => t
                .rows
                .iter()
                .enumerate()
                .filter(|(_, row)| row_matches(row, &preds))
                .map(|(i, _)| i)
                .collect(),
        };
        for (idx, v) in &assigns {
            let (cname, _, con) = &t.cols[*idx];
            if *con == Constraint::None || matched.is_empty() {
                continue;
            }
            // Every matched row receives the same value, so two or more
            // matches on a non-NULL unique value is already a duplicate.
            if matched.len() > 1 && (*con == Constraint::PrimaryKey || *v != Value::Null) {
                return Err(Error::Exec(format!(
                    "UPDATE would duplicate {cname} across {} rows",
                    matched.len()
                )));
            }
            check_constraint(*con, cname, v, &t.rows, *idx, &matched)?;
        }
        let mut affected = 0u64;
        for i in &matched {
            for (idx, v) in &assigns {
                // Keep the index consistent for indexed columns: drop the
                // old key, record the new one (NULLs are never indexed).
                if t.is_indexed(*idx) {
                    let old = t.rows[*i][*idx].clone();
                    let map = t.indexes[*idx].as_mut().expect("indexed column");
                    if old != Value::Null {
                        map.remove(&old);
                    }
                    if *v != Value::Null {
                        map.insert(v.clone(), *i);
                    }
                }
                t.rows[*i][*idx] = v.clone();
            }
            affected += 1;
        }
        Ok(Output::Affected(affected))
    }

    fn delete(&mut self, table: &str, wher: &[Pred], params: &[Value]) -> Result<Output> {
        let t = self
            .tables
            .get_mut(table)
            .ok_or_else(|| Error::Exec(format!("no such table: {table}")))?;
        let preds = resolve_preds(t, wher, params)?;
        let before = t.rows.len();
        t.rows.retain(|row| !row_matches(row, &preds));
        if t.rows.len() != before {
            // retain shifts surviving row positions; rebuild the index.
            t.rebuild_indexes();
        }
        Ok(Output::Affected((before - t.rows.len()) as u64))
    }
}

fn col_index(t: &Table, name: &str) -> Result<usize> {
    t.cols
        .iter()
        .position(|(n, _, _)| n == name)
        .ok_or_else(|| Error::Exec(format!("no such column: {name}")))
}

/// If `preds` contains an equality on an indexed column against a
/// non-NULL value, return the at-most-one row that value maps to (a fully
/// narrowed candidate set); otherwise `None`, meaning the caller scans.
/// Callers still apply the complete predicate set to each candidate, so
/// the index only narrows the search — it never changes which rows match.
fn candidate_indices(t: &Table, preds: &[ResolvedPred]) -> Option<Vec<usize>> {
    for p in preds {
        if let ResolvedPred::Cmp {
            idx,
            op: CmpOp::Eq,
            rhs,
        } = p
        {
            if *rhs != Value::Null {
                if let Some(Some(map)) = t.indexes.get(*idx) {
                    return Some(map.get(rhs).copied().into_iter().collect());
                }
            }
        }
    }
    None
}

/// Enforce PRIMARY KEY / UNIQUE for a row about to be inserted, using the
/// per-column index (O(1) per column) instead of a row scan. PRIMARY KEY
/// forbids NULL; UNIQUE permits any number of NULLs.
fn check_insert_constraints(t: &Table, row: &[Value]) -> Result<()> {
    for (i, (cname, _, con)) in t.cols.iter().enumerate() {
        match con {
            Constraint::None => {}
            Constraint::PrimaryKey => {
                if row[i] == Value::Null {
                    return Err(Error::Exec(format!("PRIMARY KEY {cname} cannot be NULL")));
                }
                if t.indexes[i]
                    .as_ref()
                    .expect("indexed")
                    .contains_key(&row[i])
                {
                    return Err(Error::Exec(format!(
                        "duplicate value for PRIMARY KEY column {cname}"
                    )));
                }
            }
            Constraint::Unique => {
                if row[i] != Value::Null
                    && t.indexes[i]
                        .as_ref()
                        .expect("indexed")
                        .contains_key(&row[i])
                {
                    return Err(Error::Exec(format!(
                        "duplicate value for UNIQUE column {cname}"
                    )));
                }
            }
        }
    }
    Ok(())
}

/// Enforce a column constraint for `candidate` going into column `idx`,
/// scanning `rows` for collisions and skipping the row indices in
/// `exempt` (rows about to be overwritten by the same UPDATE). O(rows);
/// there are no indexes. NULL: forbidden for PRIMARY KEY, always
/// permitted for UNIQUE (NULL never equals NULL).
fn check_constraint(
    con: Constraint,
    cname: &str,
    candidate: &Value,
    rows: &[Vec<Value>],
    idx: usize,
    exempt: &[usize],
) -> Result<()> {
    match con {
        Constraint::None => return Ok(()),
        Constraint::PrimaryKey => {
            if *candidate == Value::Null {
                return Err(Error::Exec(format!("PRIMARY KEY {cname} cannot be NULL")));
            }
        }
        Constraint::Unique => {
            if *candidate == Value::Null {
                return Ok(());
            }
        }
    }
    for (i, row) in rows.iter().enumerate() {
        if !exempt.contains(&i) && row[idx] == *candidate {
            return Err(Error::Exec(format!(
                "duplicate value for {} column {cname}",
                if con == Constraint::PrimaryKey {
                    "PRIMARY KEY"
                } else {
                    "UNIQUE"
                }
            )));
        }
    }
    Ok(())
}

/// Resolve a literal-or-parameter to a runtime value. Parameter indices
/// were assigned sequentially by the parser and the count was validated
/// against `params` in [`Db::run`], so direct indexing cannot fail.
fn resolve_arg(arg: &Arg, params: &[Value]) -> Value {
    match arg {
        Arg::Lit(l) => l.clone().into_value(),
        Arg::Param(i) => params[usize::from(*i)].clone(),
    }
}

/// Predicate with the column resolved to an index and the operand
/// resolved to a runtime value, so the row scan does no name lookups.
enum ResolvedPred {
    Cmp { idx: usize, op: CmpOp, rhs: Value },
    Null { idx: usize, negated: bool },
}

fn resolve_preds(t: &Table, preds: &[Pred], params: &[Value]) -> Result<Vec<ResolvedPred>> {
    preds
        .iter()
        .map(|p| {
            Ok(match p {
                Pred::Cmp { col, op, arg } => ResolvedPred::Cmp {
                    idx: col_index(t, col)?,
                    op: *op,
                    rhs: resolve_arg(arg, params),
                },
                Pred::Null { col, negated } => ResolvedPred::Null {
                    idx: col_index(t, col)?,
                    negated: *negated,
                },
            })
        })
        .collect()
}

fn row_matches(row: &[Value], preds: &[ResolvedPred]) -> bool {
    preds.iter().all(|p| match p {
        ResolvedPred::Cmp { idx, op, rhs } => cmp(&row[*idx], *op, rhs),
        ResolvedPred::Null { idx, negated } => (row[*idx] == Value::Null) != *negated,
    })
}

/// Total order used by `ORDER BY`. Unlike [`cmp`] (which is for WHERE and
/// never treats NULL as matching), sorting needs every pair of values to be
/// comparable, so this defines a total order: NULL sorts before all
/// non-NULL values (NULLs first under ASC, last under DESC), integers sort
/// numerically, text by Unicode scalar order. A column is single-typed, so
/// the cross-type arms below are unreachable in practice; they are pinned
/// only to keep the order total (integers before text).
fn value_order(a: &Value, b: &Value) -> Ordering {
    match (a, b) {
        (Value::Null, Value::Null) => Ordering::Equal,
        (Value::Null, _) => Ordering::Less,
        (_, Value::Null) => Ordering::Greater,
        (Value::Int(x), Value::Int(y)) => x.cmp(y),
        (Value::Text(x), Value::Text(y)) => x.cmp(y),
        (Value::Int(_), Value::Text(_)) => Ordering::Less,
        (Value::Text(_), Value::Int(_)) => Ordering::Greater,
    }
}

/// Apply `OFFSET` then `LIMIT` to a result set in place: drop the first
/// `offset` elements (saturating at the length), then keep at most `limit`.
fn apply_window<T>(rows: &mut Vec<T>, offset: Option<u64>, limit: Option<u64>) {
    if let Some(off) = offset {
        let off = usize::try_from(off).unwrap_or(usize::MAX).min(rows.len());
        rows.drain(..off);
    }
    if let Some(lim) = limit {
        let lim = usize::try_from(lim).unwrap_or(usize::MAX);
        rows.truncate(lim);
    }
}

/// Split a SQL script into individual statements on top-level `;`. A `;`
/// inside a single-quoted string (`''` escapes a quote) or inside a `--`
/// line comment or `/* */` block comment is not a separator. Comment text
/// is left in the returned statements — the lexer skips it — so only the
/// split points here are comment-aware. Blank statements are dropped.
///
/// This mirrors the lexer's string- and comment-handling closely enough to
/// split correctly; it is used by [`Db::execute_script`] and by the CLI's
/// `.read` command to load `.sql` files.
pub fn split_statements(src: &str) -> Vec<String> {
    let b = src.as_bytes();
    let mut out = Vec::new();
    let mut start = 0usize;
    let mut i = 0usize;
    while i < b.len() {
        match b[i] {
            b'\'' => {
                i += 1;
                while i < b.len() {
                    if b[i] == b'\'' {
                        if i + 1 < b.len() && b[i + 1] == b'\'' {
                            i += 2; // escaped quote stays in the string
                        } else {
                            i += 1; // closing quote
                            break;
                        }
                    } else {
                        i += 1;
                    }
                }
            }
            b'-' if i + 1 < b.len() && b[i + 1] == b'-' => {
                i += 2;
                while i < b.len() && b[i] != b'\n' {
                    i += 1;
                }
            }
            b'/' if i + 1 < b.len() && b[i + 1] == b'*' => {
                i += 2;
                while i + 1 < b.len() && !(b[i] == b'*' && b[i + 1] == b'/') {
                    i += 1;
                }
                i = (i + 2).min(b.len());
            }
            b';' => {
                push_stmt(&mut out, src[start..i].trim());
                i += 1;
                start = i;
            }
            _ => i += 1,
        }
    }
    push_stmt(&mut out, src[start..].trim());
    out
}

/// Push a candidate statement unless it carries no actual tokens — i.e. it
/// is empty or contains only comments/whitespace. A comment-only segment
/// (e.g. a trailing `-- done` after the final `;`) is a no-op, so dropping
/// it here keeps [`Db::execute_script`] and the CLI `.read` from handing an
/// empty token stream to the parser (which would reject it). If the segment
/// fails to lex at all, keep it so the real error surfaces downstream.
fn push_stmt(out: &mut Vec<String>, stmt: &str) {
    if stmt.is_empty() {
        return;
    }
    match crate::lexer::lex(stmt) {
        Ok(toks) if toks.is_empty() => {} // comment-only: drop it
        _ => out.push(stmt.to_string()),
    }
}

/// Three-valued-logic-lite comparison: NULL on either side never matches,
/// and a type mismatch never matches. Values are never coerced.
fn cmp(lhs: &Value, op: CmpOp, rhs: &Value) -> bool {
    let ord = match (lhs, rhs) {
        (Value::Int(a), Value::Int(b)) => a.cmp(b),
        (Value::Text(a), Value::Text(b)) => a.cmp(b),
        _ => return false,
    };
    match op {
        CmpOp::Eq => ord == Ordering::Equal,
        CmpOp::Ne => ord != Ordering::Equal,
        CmpOp::Lt => ord == Ordering::Less,
        CmpOp::Le => ord != Ordering::Greater,
        CmpOp::Gt => ord == Ordering::Greater,
        CmpOp::Ge => ord != Ordering::Less,
    }
}
