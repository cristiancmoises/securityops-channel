// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! Recursive-descent parser.
//!
//! Grammar (v0.3):
//! ```text
//! stmt    := create | insert | select | update | delete
//! create  := CREATE TABLE ident '(' coldef (',' coldef)* ')'
//! coldef  := ident type constraint?    -- type: INTEGER | INT | TEXT
//! constraint := PRIMARY KEY | UNIQUE
//! insert  := INSERT INTO ident collist? VALUES '(' arg (',' arg)* ')'
//! collist := '(' ident (',' ident)* ')'
//! select  := SELECT proj FROM ident where? orderby? limit?
//! proj    := '*' | COUNT '(' '*' ')' | ident (',' ident)*
//! orderby := ORDER BY ordkey (',' ordkey)*
//! ordkey  := ident (ASC | DESC)?
//! limit   := LIMIT uint (OFFSET uint)?
//! update  := UPDATE ident SET ident '=' arg (',' ident '=' arg)* where?
//! delete  := DELETE FROM ident where?
//! where   := WHERE pred (AND pred)*
//! pred    := ident ( cmp arg | IS NOT? NULL )
//! cmp     := '=' | '!=' | '<>' | '<' | '<=' | '>' | '>='
//! arg     := lit | '?'
//! lit     := int | '-' int | string | NULL
//! ```
//! A single optional trailing `;` is accepted. Identifiers are case-folded
//! to lowercase by the lexer. `?` placeholders are numbered left to right
//! from 0 across the whole statement.
//!
//! `COUNT`, `ORDER`, `BY`, `ASC`, `DESC`, `LIMIT`, and `OFFSET` are
//! *contextual* keywords: they are recognized only in the positions above,
//! so a table or column may still be named `order`, `count`, `limit`, etc.
//! without quoting.

use crate::ast::{Arg, CmpOp, Lit, OrderKey, Pred, Proj, Stmt};
use crate::error::{Error, Result};
use crate::lexer::{lex, Kw, Tok};
use crate::value::{ColType, Constraint};

struct Parser {
    toks: Vec<Tok>,
    pos: usize,
    nparams: u16,
}

impl Parser {
    fn peek(&self) -> Option<&Tok> {
        self.toks.get(self.pos)
    }

    fn bump(&mut self) -> Option<Tok> {
        let t = self.toks.get(self.pos).cloned();
        if t.is_some() {
            self.pos += 1;
        }
        t
    }

    fn expect_kw(&mut self, k: Kw) -> Result<()> {
        match self.bump() {
            Some(Tok::Kw(got)) if got == k => Ok(()),
            other => Err(Error::Parse(format!("expected {k:?}, found {other:?}"))),
        }
    }

    fn expect(&mut self, want: &Tok) -> Result<()> {
        match self.bump() {
            Some(ref got) if got == want => Ok(()),
            other => Err(Error::Parse(format!("expected {want:?}, found {other:?}"))),
        }
    }

    fn ident(&mut self) -> Result<String> {
        match self.bump() {
            Some(Tok::Ident(s)) => Ok(s),
            other => Err(Error::Parse(format!(
                "expected identifier, found {other:?}"
            ))),
        }
    }

    fn literal(&mut self) -> Result<Lit> {
        match self.bump() {
            Some(Tok::Int(i)) => Ok(Lit::Int(i)),
            Some(Tok::Str(s)) => Ok(Lit::Text(s)),
            Some(Tok::Kw(Kw::Null)) => Ok(Lit::Null),
            Some(Tok::Minus) => match self.bump() {
                Some(Tok::Int(i)) => i
                    .checked_neg()
                    .map(Lit::Int)
                    .ok_or_else(|| Error::Parse("integer literal out of range".into())),
                other => Err(Error::Parse(format!(
                    "expected integer after '-', found {other:?}"
                ))),
            },
            other => Err(Error::Parse(format!("expected literal, found {other:?}"))),
        }
    }

    fn arg(&mut self) -> Result<Arg> {
        if let Some(Tok::Question) = self.peek() {
            self.bump();
            let idx = self.nparams;
            self.nparams = self
                .nparams
                .checked_add(1)
                .ok_or_else(|| Error::Parse("too many '?' parameters".into()))?;
            return Ok(Arg::Param(idx));
        }
        Ok(Arg::Lit(self.literal()?))
    }

    /// Whether the token `ahead` positions past the cursor is the
    /// lowercased identifier `name` (contextual-keyword lookahead).
    fn ident_ahead_is(&self, ahead: usize, name: &str) -> bool {
        matches!(self.toks.get(self.pos + ahead), Some(Tok::Ident(s)) if s == name)
    }

    /// If the next token is the identifier `name`, consume it and return
    /// true. Used for contextual keywords (ASC/DESC/LIMIT/OFFSET).
    fn eat_ident(&mut self, name: &str) -> bool {
        if self.ident_ahead_is(0, name) {
            self.bump();
            true
        } else {
            false
        }
    }

    /// Parse a non-negative integer literal (for LIMIT / OFFSET counts).
    /// A leading `-` is a separate token, so negatives are rejected here.
    fn uint(&mut self) -> Result<u64> {
        match self.bump() {
            Some(Tok::Int(i)) if i >= 0 => Ok(i as u64),
            other => Err(Error::Parse(format!(
                "expected a non-negative integer, found {other:?}"
            ))),
        }
    }

    fn cmp_op(&mut self) -> Result<CmpOp> {
        match self.bump() {
            Some(Tok::Eq) => Ok(CmpOp::Eq),
            Some(Tok::Ne) => Ok(CmpOp::Ne),
            Some(Tok::Lt) => Ok(CmpOp::Lt),
            Some(Tok::Le) => Ok(CmpOp::Le),
            Some(Tok::Gt) => Ok(CmpOp::Gt),
            Some(Tok::Ge) => Ok(CmpOp::Ge),
            other => Err(Error::Parse(format!(
                "expected comparison operator, found {other:?}"
            ))),
        }
    }

    fn pred(&mut self) -> Result<Pred> {
        let col = self.ident()?;
        if let Some(Tok::Kw(Kw::Is)) = self.peek() {
            self.bump();
            let negated = if let Some(Tok::Kw(Kw::Not)) = self.peek() {
                self.bump();
                true
            } else {
                false
            };
            self.expect_kw(Kw::Null)?;
            return Ok(Pred::Null { col, negated });
        }
        let op = self.cmp_op()?;
        let arg = self.arg()?;
        Ok(Pred::Cmp { col, op, arg })
    }

    fn where_clause(&mut self) -> Result<Vec<Pred>> {
        let mut preds = Vec::new();
        if let Some(Tok::Kw(Kw::Where)) = self.peek() {
            self.bump();
            loop {
                preds.push(self.pred()?);
                if let Some(Tok::Kw(Kw::And)) = self.peek() {
                    self.bump();
                } else {
                    break;
                }
            }
        }
        Ok(preds)
    }

    fn col_type(&mut self) -> Result<ColType> {
        let name = self.ident()?;
        match name.as_str() {
            "integer" | "int" => Ok(ColType::Integer),
            "text" => Ok(ColType::Text),
            other => Err(Error::Parse(format!("unknown column type: {other}"))),
        }
    }

    /// `'(' item (',' item)* ')'` driven by a closure.
    fn paren_list<T>(&mut self, mut item: impl FnMut(&mut Self) -> Result<T>) -> Result<Vec<T>> {
        self.expect(&Tok::LParen)?;
        let mut out = Vec::new();
        loop {
            out.push(item(self)?);
            match self.bump() {
                Some(Tok::Comma) => continue,
                Some(Tok::RParen) => break,
                other => {
                    return Err(Error::Parse(format!(
                        "expected ',' or ')', found {other:?}"
                    )))
                }
            }
        }
        Ok(out)
    }

    fn constraint(&mut self) -> Result<Constraint> {
        match self.peek() {
            Some(Tok::Kw(Kw::Primary)) => {
                self.bump();
                self.expect_kw(Kw::Key)?;
                Ok(Constraint::PrimaryKey)
            }
            Some(Tok::Kw(Kw::Unique)) => {
                self.bump();
                Ok(Constraint::Unique)
            }
            _ => Ok(Constraint::None),
        }
    }

    /// SELECT projection: `*`, `COUNT(*)`, or a comma-separated column list.
    /// `count` is contextual — a bare `count` not followed by `(` is an
    /// ordinary column name.
    fn projection(&mut self) -> Result<Proj> {
        if let Some(Tok::Star) = self.peek() {
            self.bump();
            return Ok(Proj::Star);
        }
        if self.ident_ahead_is(0, "count")
            && matches!(self.toks.get(self.pos + 1), Some(Tok::LParen))
        {
            self.bump(); // count
            self.expect(&Tok::LParen)?;
            self.expect(&Tok::Star)?;
            self.expect(&Tok::RParen)?;
            return Ok(Proj::CountStar);
        }
        let mut cols = vec![self.ident()?];
        while let Some(Tok::Comma) = self.peek() {
            self.bump();
            cols.push(self.ident()?);
        }
        Ok(Proj::Cols(cols))
    }

    /// Optional `ORDER BY col [ASC|DESC] (, col [ASC|DESC])*`. `ORDER` and
    /// `BY` are contextual keywords recognized only here.
    fn order_by(&mut self) -> Result<Vec<OrderKey>> {
        if !(self.ident_ahead_is(0, "order") && self.ident_ahead_is(1, "by")) {
            return Ok(Vec::new());
        }
        self.bump(); // order
        self.bump(); // by
        let mut keys = Vec::new();
        loop {
            let col = self.ident()?;
            // ASC is the default; DESC reverses. Anything else (e.g. LIMIT)
            // is left for the caller.
            let desc = if self.eat_ident("desc") {
                true
            } else {
                self.eat_ident("asc");
                false
            };
            keys.push(OrderKey { col, desc });
            if let Some(Tok::Comma) = self.peek() {
                self.bump();
            } else {
                break;
            }
        }
        Ok(keys)
    }

    /// Optional `LIMIT n [OFFSET m]`, all contextual keywords.
    fn limit_clause(&mut self) -> Result<(Option<u64>, Option<u64>)> {
        if !self.eat_ident("limit") {
            return Ok((None, None));
        }
        let limit = self.uint()?;
        let offset = if self.eat_ident("offset") {
            Some(self.uint()?)
        } else {
            None
        };
        Ok((Some(limit), offset))
    }

    fn stmt(&mut self) -> Result<Stmt> {
        match self.bump() {
            Some(Tok::Kw(Kw::Create)) => {
                self.expect_kw(Kw::Table)?;
                let table = self.ident()?;
                let cols = self.paren_list(|p| {
                    let name = p.ident()?;
                    let ty = p.col_type()?;
                    let con = p.constraint()?;
                    Ok((name, ty, con))
                })?;
                Ok(Stmt::Create { table, cols })
            }
            Some(Tok::Kw(Kw::Insert)) => {
                self.expect_kw(Kw::Into)?;
                let table = self.ident()?;
                let cols = if let Some(Tok::LParen) = self.peek() {
                    Some(self.paren_list(Self::ident)?)
                } else {
                    None
                };
                self.expect_kw(Kw::Values)?;
                let values = self.paren_list(Self::arg)?;
                Ok(Stmt::Insert {
                    table,
                    cols,
                    values,
                })
            }
            Some(Tok::Kw(Kw::Select)) => {
                let proj = self.projection()?;
                self.expect_kw(Kw::From)?;
                let table = self.ident()?;
                let wher = self.where_clause()?;
                let order = self.order_by()?;
                let (limit, offset) = self.limit_clause()?;
                Ok(Stmt::Select {
                    table,
                    proj,
                    wher,
                    order,
                    limit,
                    offset,
                })
            }
            Some(Tok::Kw(Kw::Update)) => {
                let table = self.ident()?;
                self.expect_kw(Kw::Set)?;
                let mut sets = Vec::new();
                loop {
                    let col = self.ident()?;
                    self.expect(&Tok::Eq)?;
                    sets.push((col, self.arg()?));
                    if let Some(Tok::Comma) = self.peek() {
                        self.bump();
                    } else {
                        break;
                    }
                }
                let wher = self.where_clause()?;
                Ok(Stmt::Update { table, sets, wher })
            }
            Some(Tok::Kw(Kw::Delete)) => {
                self.expect_kw(Kw::From)?;
                let table = self.ident()?;
                let wher = self.where_clause()?;
                Ok(Stmt::Delete { table, wher })
            }
            other => Err(Error::Parse(format!(
                "expected CREATE, INSERT, SELECT, UPDATE or DELETE, found {other:?}"
            ))),
        }
    }
}

/// Parse exactly one statement, with an optional trailing semicolon.
/// Returns the statement and the number of `?` placeholders it contains.
pub fn parse(sql: &str) -> Result<(Stmt, u16)> {
    let toks = lex(sql)?;
    let mut p = Parser {
        toks,
        pos: 0,
        nparams: 0,
    };
    let stmt = p.stmt()?;
    if let Some(Tok::Semi) = p.peek() {
        p.bump();
    }
    if let Some(t) = p.peek() {
        return Err(Error::Parse(format!(
            "trailing tokens after statement: {t:?}"
        )));
    }
    Ok((stmt, p.nparams))
}
