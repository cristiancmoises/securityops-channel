// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! Runtime values and column types.

use std::fmt;

/// A single cell value.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum Value {
    /// 64-bit signed integer.
    Int(i64),
    /// UTF-8 text.
    Text(String),
    /// SQL NULL. Any comparison involving NULL is not true.
    Null,
}

impl fmt::Display for Value {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Value::Int(i) => write!(f, "{i}"),
            Value::Text(s) => write!(f, "{s}"),
            Value::Null => write!(f, "NULL"),
        }
    }
}

/// Per-column constraint. `PrimaryKey` implies `Unique` plus NOT NULL;
/// at most one column per table may be the primary key. `Unique` permits
/// any number of NULLs (NULL never equals NULL), per SQL convention.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Constraint {
    /// No constraint.
    None,
    /// Values must be pairwise distinct; NULLs are exempt.
    Unique,
    /// UNIQUE plus NOT NULL; at most one per table.
    PrimaryKey,
}

/// Declared type of a column.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ColType {
    /// 64-bit signed integer.
    Integer,
    /// UTF-8 text.
    Text,
}

impl fmt::Display for ColType {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ColType::Integer => write!(f, "INTEGER"),
            ColType::Text => write!(f, "TEXT"),
        }
    }
}

impl Value {
    /// Whether this value may be stored in a column of type `ty`.
    /// NULL is storable in any column except a PRIMARY KEY (enforced by
    /// the engine, not here).
    pub fn fits(&self, ty: ColType) -> bool {
        matches!(
            (self, ty),
            (Value::Null, _) | (Value::Int(_), ColType::Integer) | (Value::Text(_), ColType::Text)
        )
    }
}
