// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! Error type shared across the crate.

use std::fmt;

/// Crate-wide error type.
#[derive(Debug)]
pub enum Error {
    /// SQL text could not be tokenized or parsed.
    Parse(String),
    /// Statement is well-formed but violates the schema or its types.
    Exec(String),
    /// Authenticated decryption failed: wrong key/passphrase, or the data
    /// (including its header) was tampered with. Intentionally carries no
    /// detail beyond this, to avoid acting as a decryption oracle.
    Crypto,
    /// Stored bytes violate the wire format. This is structural (public)
    /// information only; it is reported *after* authentication succeeds or
    /// before any key is used.
    Corrupt(&'static str),
    /// The provided secret kind does not match the KDF recorded in the file
    /// header (e.g. a raw key was supplied for a passphrase-derived file).
    KdfMismatch,
    /// A validly signed manifest carries a counter older than the highest
    /// one this machine has already accepted: a replayed (rolled-back)
    /// file. Reported only by the enforcing verification path.
    Rollback,
    /// Another live process holds the database (advisory lock taken).
    Locked,
    /// Underlying I/O failure.
    Io(std::io::Error),
}

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Error::Parse(m) => write!(f, "parse error: {m}"),
            Error::Exec(m) => write!(f, "execution error: {m}"),
            Error::Crypto => write!(f, "authentication failed: wrong key or tampered data"),
            Error::Corrupt(m) => write!(f, "corrupt file: {m}"),
            Error::KdfMismatch => write!(f, "secret kind does not match file header KDF"),
            Error::Rollback => write!(
                f,
                "manifest counter is older than the highest already accepted (rollback)"
            ),
            Error::Locked => write!(f, "database is locked by another process"),
            Error::Io(e) => write!(f, "i/o error: {e}"),
        }
    }
}

impl std::error::Error for Error {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Error::Io(e) => Some(e),
            _ => None,
        }
    }
}

impl From<std::io::Error> for Error {
    fn from(e: std::io::Error) -> Self {
        Error::Io(e)
    }
}

/// Crate-wide result alias.
pub type Result<T> = std::result::Result<T, Error>;
