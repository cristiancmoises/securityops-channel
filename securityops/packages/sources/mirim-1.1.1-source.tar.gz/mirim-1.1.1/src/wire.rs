// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! Snapshot wire format (plaintext side; the vault/seal layers encrypt it).
//!
//! Layout, little-endian:
//! ```text
//! u8  format version (2; version 1 is still decoded)
//! u32 table count
//! per table:
//!   str  name                       -- str := u32 len, UTF-8 bytes
//!   u16  column count (>= 1)
//!   per column: str name, u8 type, u8 constraint
//!     -- type: 0 = INTEGER, 1 = TEXT
//!     -- constraint: 0 = none, 1 = UNIQUE, 2 = PRIMARY KEY
//!     -- (version 1 has no constraint byte; decoded as none)
//!   u64  row count
//!   per row, per column:
//!     u8 tag: 0 = NULL, 1 = INT (+ i64), 2 = TEXT (+ str)
//! ```
//! Decoding treats the input as attacker-controlled even though it is only
//! reached after AEAD authentication: every length is checked against the
//! remaining input before any allocation, and collections are grown by
//! `push` rather than pre-allocated from header-declared counts.

use std::collections::BTreeMap;
use zeroize::Zeroizing;

use crate::engine::{Db, Table};
use crate::error::{Error, Result};
use crate::value::{ColType, Constraint, Value};

const FORMAT_VERSION: u8 = 2;
const FORMAT_VERSION_V1: u8 = 1;

const TAG_NULL: u8 = 0;
const TAG_INT: u8 = 1;
const TAG_TEXT: u8 = 2;

fn put_len32(out: &mut Vec<u8>, len: usize) -> Result<()> {
    let len = u32::try_from(len)
        .map_err(|_| Error::Exec("snapshot length exceeds the 32-bit format limit".into()))?;
    out.extend_from_slice(&len.to_le_bytes());
    Ok(())
}

fn put_str(out: &mut Vec<u8>, s: &str) -> Result<()> {
    put_len32(out, s.len())?;
    out.extend_from_slice(s.as_bytes());
    Ok(())
}

/// Encode a database snapshot.
pub fn encode(db: &Db) -> Result<Zeroizing<Vec<u8>>> {
    let mut out = Zeroizing::new(Vec::new());
    out.push(FORMAT_VERSION);
    put_len32(&mut out, db.tables.len())?;
    for (name, t) in &db.tables {
        put_str(&mut out, name)?;
        let ncols = u16::try_from(t.cols.len())
            .map_err(|_| Error::Exec("snapshot column count exceeds 65535".into()))?;
        out.extend_from_slice(&ncols.to_le_bytes());
        for (cname, cty, con) in &t.cols {
            put_str(&mut out, cname)?;
            out.push(match cty {
                ColType::Integer => 0,
                ColType::Text => 1,
            });
            out.push(match con {
                Constraint::None => 0,
                Constraint::Unique => 1,
                Constraint::PrimaryKey => 2,
            });
        }
        out.extend_from_slice(&(t.rows.len() as u64).to_le_bytes());
        for row in &t.rows {
            for v in row {
                put_value(&mut out, v)?;
            }
        }
    }
    Ok(out)
}

/// Append one value in tag-prefixed form. Shared by the snapshot body
/// and the WAL record parameter list.
pub(crate) fn put_value(out: &mut Vec<u8>, v: &Value) -> Result<()> {
    match v {
        Value::Null => out.push(TAG_NULL),
        Value::Int(i) => {
            out.push(TAG_INT);
            out.extend_from_slice(&i.to_le_bytes());
        }
        Value::Text(s) => {
            out.push(TAG_TEXT);
            put_str(out, s)?;
        }
    }
    Ok(())
}

pub(crate) struct Cursor<'a> {
    b: &'a [u8],
    i: usize,
}

impl<'a> Cursor<'a> {
    pub(crate) fn new(b: &'a [u8]) -> Self {
        Cursor { b, i: 0 }
    }

    pub(crate) fn done(&self) -> bool {
        self.i == self.b.len()
    }

    /// Read one tag-prefixed value, the inverse of [`put_value`].
    pub(crate) fn value(&mut self) -> Result<Value> {
        Ok(match self.u8()? {
            TAG_NULL => Value::Null,
            TAG_INT => Value::Int(self.i64()?),
            TAG_TEXT => Value::Text(self.str()?),
            _ => return Err(Error::Corrupt("unknown value tag")),
        })
    }

    fn take(&mut self, n: usize) -> Result<&'a [u8]> {
        let end = self
            .i
            .checked_add(n)
            .ok_or(Error::Corrupt("length overflow"))?;
        if end > self.b.len() {
            return Err(Error::Corrupt("truncated input"));
        }
        let s = &self.b[self.i..end];
        self.i = end;
        Ok(s)
    }

    pub(crate) fn u8(&mut self) -> Result<u8> {
        Ok(self.take(1)?[0])
    }

    pub(crate) fn u16(&mut self) -> Result<u16> {
        let b = self.take(2)?;
        Ok(u16::from_le_bytes([b[0], b[1]]))
    }

    pub(crate) fn u32(&mut self) -> Result<u32> {
        let b = self.take(4)?;
        Ok(u32::from_le_bytes([b[0], b[1], b[2], b[3]]))
    }

    pub(crate) fn u64(&mut self) -> Result<u64> {
        let b = self.take(8)?;
        let mut a = [0u8; 8];
        a.copy_from_slice(b);
        Ok(u64::from_le_bytes(a))
    }

    fn i64(&mut self) -> Result<i64> {
        let b = self.take(8)?;
        let mut a = [0u8; 8];
        a.copy_from_slice(b);
        Ok(i64::from_le_bytes(a))
    }

    pub(crate) fn str(&mut self) -> Result<String> {
        let len = self.u32()? as usize;
        // `take` enforces len <= remaining before any allocation.
        let bytes = self.take(len)?;
        String::from_utf8(bytes.to_vec()).map_err(|_| Error::Corrupt("invalid UTF-8"))
    }
}

/// Decode a database snapshot. Fails closed on any structural violation.
pub fn decode(bytes: &[u8]) -> Result<Db> {
    let mut c = Cursor::new(bytes);
    let version = c.u8()?;
    if version != FORMAT_VERSION && version != FORMAT_VERSION_V1 {
        return Err(Error::Corrupt("unsupported snapshot version"));
    }
    let ntables = c.u32()?;
    let mut tables = BTreeMap::new();
    for _ in 0..ntables {
        let name = c.str()?;
        let ncols = c.u16()? as usize;
        if ncols == 0 {
            // A zero-column table would let a hostile row count loop for
            // free; the engine never produces one either.
            return Err(Error::Corrupt("table with zero columns"));
        }
        let mut cols = Vec::new();
        let mut pk_seen = false;
        for _ in 0..ncols {
            let cname = c.str()?;
            let cty = match c.u8()? {
                0 => ColType::Integer,
                1 => ColType::Text,
                _ => return Err(Error::Corrupt("unknown column type")),
            };
            let con = if version == FORMAT_VERSION_V1 {
                Constraint::None
            } else {
                match c.u8()? {
                    0 => Constraint::None,
                    1 => Constraint::Unique,
                    2 => {
                        if pk_seen {
                            return Err(Error::Corrupt("multiple primary keys"));
                        }
                        pk_seen = true;
                        Constraint::PrimaryKey
                    }
                    _ => return Err(Error::Corrupt("unknown column constraint")),
                }
            };
            cols.push((cname, cty, con));
        }
        let nrows = c.u64()?;
        // Each row consumes at least `ncols` bytes (one tag per column), so
        // a declared row count larger than the remaining input is invalid.
        if nrows > (c.b.len() - c.i) as u64 {
            return Err(Error::Corrupt("row count exceeds input size"));
        }
        let mut rows = Vec::new();
        for _ in 0..nrows {
            let mut row = Vec::new();
            for _ in 0..ncols {
                row.push(c.value()?);
            }
            rows.push(row);
        }
        if tables.insert(name, Table::from_parts(cols, rows)).is_some() {
            return Err(Error::Corrupt("duplicate table name"));
        }
    }
    if !c.done() {
        return Err(Error::Corrupt("trailing bytes after snapshot"));
    }
    Ok(Db { tables })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[cfg(target_pointer_width = "64")]
    #[test]
    fn oversized_length_is_rejected_without_writing_a_truncated_prefix() {
        let mut out = vec![0xab];
        assert!(put_len32(&mut out, u32::MAX as usize + 1).is_err());
        assert_eq!(out, [0xab]);
        put_len32(&mut out, u32::MAX as usize).unwrap();
        assert_eq!(&out[1..], &u32::MAX.to_le_bytes());
    }

    #[test]
    fn empty_snapshot_serialization_stays_compatible() {
        let bytes = encode(&Db::new()).unwrap();
        assert_eq!(bytes.as_slice(), &[2, 0, 0, 0, 0]);
        assert_eq!(decode(&bytes).unwrap(), Db::new());
    }
}
