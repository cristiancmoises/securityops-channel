// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! Post-quantum sealed exports.
//!
//! `seal` encrypts a database snapshot to a recipient's ML-KEM-768 (FIPS
//! 203) encapsulation key; only the holder of the matching decapsulation
//! key can `open` it. This is the harvest-now-decrypt-later defence: no
//! classical public-key cryptography appears anywhere in the format.
//!
//! Layout:
//! ```text
//! offset  size  field
//! 0       8     magic "MIRIMSL1"
//! 8       1     format version (1)
//! 9       1088  ML-KEM-768 ciphertext
//! 1097    24    XChaCha20-Poly1305 nonce
//! 1121    ..    AEAD ciphertext of the snapshot (wire format v1)
//! ```
//! The 1121-byte header is bound as AEAD associated data. The AEAD key is
//! `HKDF-SHA256(ikm = ML-KEM shared secret, info = DOMAIN)`; the
//! domain-separation string pins suite and version, so a future suite
//! cannot be confused with this one even if magic bytes were mishandled.
//!
//! ML-KEM decapsulation is implicit-rejection: a forged or mismatched KEM
//! ciphertext yields a pseudorandom shared secret rather than an error,
//! and the failure surfaces uniformly as an AEAD authentication failure
//! ([`Error::Crypto`]). No oracle distinguishes "wrong key" from
//! "tampered body".

use chacha20poly1305::aead::{Aead, KeyInit, Payload};
use chacha20poly1305::XChaCha20Poly1305;
use hkdf::Hkdf;
use ml_kem::array::Array;
use ml_kem::kem::{Decapsulate, Encapsulate};
use ml_kem::{Ciphertext, Encoded, EncodedSizeUser, KemCore, MlKem768};
use rand_core::{OsRng, RngCore};
use sha2::Sha256;
use zeroize::{Zeroize, Zeroizing};

use crate::engine::Db;
use crate::error::{Error, Result};
use crate::wire;

type Dk = <MlKem768 as KemCore>::DecapsulationKey;
type Ek = <MlKem768 as KemCore>::EncapsulationKey;

/// Encoded length of an ML-KEM-768 encapsulation (public) key.
pub const PUBLIC_LEN: usize = 1184;
/// Encoded length of an ML-KEM-768 decapsulation (secret) key.
pub const SECRET_LEN: usize = 2400;
/// Length of an ML-KEM-768 ciphertext.
pub const KEM_CT_LEN: usize = 1088;

const MAGIC: &[u8; 8] = b"MIRIMSL1";
const FORMAT_VERSION: u8 = 1;
const FORMAT_VERSION_MULTI: u8 = 2;
/// Wrapped content-encryption key: 32-byte CEK + 16-byte AEAD tag.
const WRAP_LEN: usize = 32 + 16;
/// Hard cap on the recipient count, checked before any allocation.
const MAX_RECIPIENTS: usize = 1024;
const WRAP_DOMAIN: &[u8] = b"mirim.v2.seal.wrap.mlkem768+xchacha20poly1305";
const NONCE_LEN: usize = 24;
const HEADER_LEN: usize = 8 + 1 + KEM_CT_LEN + NONCE_LEN;

/// Domain-separation string for the HKDF expand step. Versioned with the
/// format: a v2 suite must use a different string.
const DOMAIN: &[u8] = b"mirim.v1.seal.mlkem768+xchacha20poly1305";

/// Recipient's public half. Safe to publish.
pub struct RecipientPublic {
    ek: Ek,
}

/// Recipient's secret half. Keep offline; zeroized on drop by the
/// underlying `ml-kem` types (built with the `zeroize` feature).
pub struct RecipientSecret {
    dk: Dk,
}

impl RecipientPublic {
    /// Serialize to the 1184-byte FIPS 203 encoding.
    pub fn to_bytes(&self) -> Vec<u8> {
        self.ek.as_bytes().to_vec()
    }

    /// Parse the 1184-byte FIPS 203 encoding.
    pub fn from_bytes(bytes: &[u8]) -> Result<Self> {
        let enc =
            Encoded::<Ek>::try_from(bytes).map_err(|_| Error::Corrupt("bad public key length"))?;
        Ok(Self {
            ek: Ek::from_bytes(&enc),
        })
    }
}

impl RecipientSecret {
    /// Serialize to the 2400-byte FIPS 203 encoding. The buffer is
    /// zeroized when dropped; the caller decides where it persists.
    pub fn to_bytes(&self) -> Zeroizing<Vec<u8>> {
        Zeroizing::new(self.dk.as_bytes().to_vec())
    }

    /// Parse the 2400-byte FIPS 203 encoding.
    pub fn from_bytes(bytes: &[u8]) -> Result<Self> {
        let enc =
            Encoded::<Dk>::try_from(bytes).map_err(|_| Error::Corrupt("bad secret key length"))?;
        Ok(Self {
            dk: Dk::from_bytes(&enc),
        })
    }
}

/// Generate a fresh ML-KEM-768 recipient key pair from the OS CSPRNG.
pub fn keygen() -> (RecipientSecret, RecipientPublic) {
    let (dk, ek) = MlKem768::generate(&mut OsRng);
    (RecipientSecret { dk }, RecipientPublic { ek })
}

fn derive_aead_key(shared: &Array<u8, ml_kem::array::typenum::U32>) -> Zeroizing<[u8; 32]> {
    let hk = Hkdf::<Sha256>::new(None, shared.as_slice());
    let mut key = Zeroizing::new([0u8; 32]);
    hk.expand(DOMAIN, key.as_mut())
        .expect("32 bytes is a valid HKDF-SHA256 output length");
    key
}

/// Seal a snapshot of `db` to `recipient`.
pub fn seal(db: &Db, recipient: &RecipientPublic) -> Result<Vec<u8>> {
    let (kem_ct, mut shared) = recipient
        .ek
        .encapsulate(&mut OsRng)
        .map_err(|_| Error::Crypto)?;
    let key = derive_aead_key(&shared);
    // The shared-secret array is `Copy`; zeroize the binding we hold.
    // Transient stack copies are outside what safe Rust can scrub — see
    // SECURITY.md (memory disclosure is out of scope).
    shared.zeroize();

    let mut nonce = [0u8; NONCE_LEN];
    OsRng.fill_bytes(&mut nonce);

    let mut header = Vec::with_capacity(HEADER_LEN);
    header.extend_from_slice(MAGIC);
    header.push(FORMAT_VERSION);
    header.extend_from_slice(kem_ct.as_slice());
    header.extend_from_slice(&nonce);
    debug_assert_eq!(header.len(), HEADER_LEN);

    let cipher = XChaCha20Poly1305::new((&*key).into());
    let plaintext = wire::encode(db)?;
    let ct = cipher
        .encrypt(
            (&nonce).into(),
            Payload {
                msg: &plaintext,
                aad: &header,
            },
        )
        .map_err(|_| Error::Crypto)?;

    header.extend_from_slice(&ct);
    Ok(header)
}

/// Seal a snapshot of `db` to several recipients at once (format v2).
/// The payload is encrypted once under a random content-encryption key;
/// the CEK is wrapped per recipient under an ML-KEM-768 encapsulation.
/// Any listed recipient can open the result; order does not matter.
///
/// The recipient *count* is visible in the clear, and opening trial-
/// decrypts the wrap slots in order, so timing reveals which slot
/// matched. Recipient-set privacy is not a goal of this format.
pub fn seal_multi(db: &Db, recipients: &[&RecipientPublic]) -> Result<Vec<u8>> {
    if recipients.is_empty() {
        return Err(Error::Exec(
            "seal_multi needs at least one recipient".into(),
        ));
    }
    if recipients.len() > MAX_RECIPIENTS {
        return Err(Error::Exec(format!(
            "seal_multi caps recipients at {MAX_RECIPIENTS}"
        )));
    }
    let mut cek = Zeroizing::new([0u8; 32]);
    OsRng.fill_bytes(cek.as_mut());

    let mut header =
        Vec::with_capacity(11 + recipients.len() * (KEM_CT_LEN + WRAP_LEN) + NONCE_LEN);
    header.extend_from_slice(MAGIC);
    header.push(FORMAT_VERSION_MULTI);
    header.extend_from_slice(&(recipients.len() as u16).to_le_bytes());
    let prefix: [u8; 11] = header[..11].try_into().expect("fixed slice");

    for r in recipients {
        let (kem_ct, mut shared) = r.ek.encapsulate(&mut OsRng).map_err(|_| Error::Crypto)?;
        let wrap_key = derive_wrap_key(&shared);
        shared.zeroize();
        // Single-use key, fresh per encapsulation: a fixed all-zero nonce
        // is sound and saves 24 bytes per recipient.
        let wrap_cipher = XChaCha20Poly1305::new((&*wrap_key).into());
        let wrapped = wrap_cipher
            .encrypt(
                (&[0u8; NONCE_LEN]).into(),
                Payload {
                    msg: cek.as_slice(),
                    aad: &prefix,
                },
            )
            .map_err(|_| Error::Crypto)?;
        debug_assert_eq!(wrapped.len(), WRAP_LEN);
        header.extend_from_slice(kem_ct.as_slice());
        header.extend_from_slice(&wrapped);
    }

    let mut nonce = [0u8; NONCE_LEN];
    OsRng.fill_bytes(&mut nonce);
    header.extend_from_slice(&nonce);

    let cipher = XChaCha20Poly1305::new((&*cek).into());
    let plaintext = wire::encode(db)?;
    let ct = cipher
        .encrypt(
            (&nonce).into(),
            Payload {
                msg: &plaintext,
                aad: &header,
            },
        )
        .map_err(|_| Error::Crypto)?;
    header.extend_from_slice(&ct);
    Ok(header)
}

fn derive_wrap_key(shared: &Array<u8, ml_kem::array::typenum::U32>) -> Zeroizing<[u8; 32]> {
    let hk = Hkdf::<Sha256>::new(None, shared.as_slice());
    let mut key = Zeroizing::new([0u8; 32]);
    hk.expand(WRAP_DOMAIN, key.as_mut())
        .expect("32 bytes is a valid HKDF-SHA256 output length");
    key
}

fn open_multi(bytes: &[u8], recipient: &RecipientSecret) -> Result<Db> {
    if bytes.len() < 11 {
        return Err(Error::Corrupt("sealed input shorter than header"));
    }
    let n = u16::from_le_bytes(bytes[9..11].try_into().expect("fixed slice")) as usize;
    if n == 0 || n > MAX_RECIPIENTS {
        return Err(Error::Corrupt("recipient count out of range"));
    }
    let header_len = 11 + n * (KEM_CT_LEN + WRAP_LEN) + NONCE_LEN;
    if bytes.len() < header_len {
        return Err(Error::Corrupt("sealed input shorter than header"));
    }
    let (header, ct) = bytes.split_at(header_len);
    let prefix = &header[..11];
    let nonce: [u8; NONCE_LEN] = header[header_len - NONCE_LEN..]
        .try_into()
        .expect("fixed slice");

    let mut cek: Option<Zeroizing<Vec<u8>>> = None;
    for i in 0..n {
        let off = 11 + i * (KEM_CT_LEN + WRAP_LEN);
        let kem_ct = Ciphertext::<MlKem768>::try_from(&header[off..off + KEM_CT_LEN])
            .map_err(|_| Error::Corrupt("bad KEM ciphertext length"))?;
        let wrapped = &header[off + KEM_CT_LEN..off + KEM_CT_LEN + WRAP_LEN];
        // Implicit rejection: a wrong slot yields a pseudorandom secret
        // and the wrap AEAD below rejects; we just try the next slot.
        let mut shared = recipient
            .dk
            .decapsulate(&kem_ct)
            .map_err(|_| Error::Crypto)?;
        let wrap_key = derive_wrap_key(&shared);
        shared.zeroize();
        let wrap_cipher = XChaCha20Poly1305::new((&*wrap_key).into());
        if let Ok(k) = wrap_cipher.decrypt(
            (&[0u8; NONCE_LEN]).into(),
            Payload {
                msg: wrapped,
                aad: prefix,
            },
        ) {
            cek = Some(Zeroizing::new(k));
            break;
        }
    }
    let cek = cek.ok_or(Error::Crypto)?;
    if cek.len() != 32 {
        return Err(Error::Corrupt("wrapped key has wrong length"));
    }
    let key: [u8; 32] = cek.as_slice().try_into().expect("length checked");

    let cipher = XChaCha20Poly1305::new((&key).into());
    let plaintext = Zeroizing::new(
        cipher
            .decrypt(
                (&nonce).into(),
                Payload {
                    msg: ct,
                    aad: header,
                },
            )
            .map_err(|_| Error::Crypto)?,
    );
    wire::decode(&plaintext)
}

/// Open a sealed export (format v1 or v2) with the recipient's secret
/// key.
pub fn open(bytes: &[u8], recipient: &RecipientSecret) -> Result<Db> {
    if bytes.len() < 9 {
        return Err(Error::Corrupt("sealed input shorter than header"));
    }
    if &bytes[..8] != MAGIC {
        return Err(Error::Corrupt("bad magic"));
    }
    if bytes[8] == FORMAT_VERSION_MULTI {
        return open_multi(bytes, recipient);
    }
    if bytes.len() < HEADER_LEN {
        return Err(Error::Corrupt("sealed input shorter than header"));
    }
    let (header, ct) = bytes.split_at(HEADER_LEN);
    if header[8] != FORMAT_VERSION {
        return Err(Error::Corrupt("unsupported seal version"));
    }
    let kem_ct = Ciphertext::<MlKem768>::try_from(&header[9..9 + KEM_CT_LEN])
        .map_err(|_| Error::Corrupt("bad KEM ciphertext length"))?;
    let nonce: [u8; NONCE_LEN] = header[9 + KEM_CT_LEN..HEADER_LEN]
        .try_into()
        .expect("header slice has fixed length");

    // Implicit rejection: this never fails for a well-sized ciphertext; a
    // wrong key produces a pseudorandom secret and the AEAD step below
    // rejects uniformly.
    let mut shared = recipient
        .dk
        .decapsulate(&kem_ct)
        .map_err(|_| Error::Crypto)?;
    let key = derive_aead_key(&shared);
    shared.zeroize();

    let cipher = XChaCha20Poly1305::new((&*key).into());
    let plaintext = Zeroizing::new(
        cipher
            .decrypt(
                (&nonce).into(),
                Payload {
                    msg: ct,
                    aad: header,
                },
            )
            .map_err(|_| Error::Crypto)?,
    );
    wire::decode(&plaintext)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn encoded_lengths_match_constants() {
        let (sk, pk) = keygen();
        assert_eq!(pk.to_bytes().len(), PUBLIC_LEN);
        assert_eq!(sk.to_bytes().len(), SECRET_LEN);
    }
}
