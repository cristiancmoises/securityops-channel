// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! SQL tokenizer. Keywords are case-insensitive; identifiers are case-folded
//! to ASCII lowercase by the parser. String literals are single-quoted with
//! `''` as the escape for a literal quote. Comments are skipped: `--` to end
//! of line, and `/* ... */` block comments (which do not nest).

use crate::error::{Error, Result};

/// SQL keywords recognized by the v0.1 grammar.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Kw {
    Create,
    Table,
    Insert,
    Into,
    Values,
    Select,
    From,
    Where,
    Delete,
    And,
    Null,
    Update,
    Set,
    Is,
    Not,
    Primary,
    Key,
    Unique,
}

/// A lexed token.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Tok {
    Kw(Kw),
    Ident(String),
    Int(i64),
    Str(String),
    LParen,
    RParen,
    Comma,
    Semi,
    Star,
    Minus,
    Question,
    Eq,
    Ne,
    Lt,
    Le,
    Gt,
    Ge,
}

fn keyword(upper: &str) -> Option<Kw> {
    Some(match upper {
        "CREATE" => Kw::Create,
        "TABLE" => Kw::Table,
        "INSERT" => Kw::Insert,
        "INTO" => Kw::Into,
        "VALUES" => Kw::Values,
        "SELECT" => Kw::Select,
        "FROM" => Kw::From,
        "WHERE" => Kw::Where,
        "DELETE" => Kw::Delete,
        "AND" => Kw::And,
        "NULL" => Kw::Null,
        "UPDATE" => Kw::Update,
        "SET" => Kw::Set,
        "IS" => Kw::Is,
        "NOT" => Kw::Not,
        "PRIMARY" => Kw::Primary,
        "KEY" => Kw::Key,
        "UNIQUE" => Kw::Unique,
        _ => return None,
    })
}

/// Tokenize `src` into a vector of tokens.
pub fn lex(src: &str) -> Result<Vec<Tok>> {
    let mut out = Vec::new();
    let b = src.as_bytes();
    let mut i = 0usize;
    while i < b.len() {
        let c = b[i];
        match c {
            b' ' | b'\t' | b'\r' | b'\n' => i += 1,
            b'(' => {
                out.push(Tok::LParen);
                i += 1;
            }
            b')' => {
                out.push(Tok::RParen);
                i += 1;
            }
            b',' => {
                out.push(Tok::Comma);
                i += 1;
            }
            b';' => {
                out.push(Tok::Semi);
                i += 1;
            }
            b'*' => {
                out.push(Tok::Star);
                i += 1;
            }
            b'-' => {
                // `--` starts a line comment (there is no binary minus in
                // the grammar, only negative literals, so `--` is never an
                // operator). Skip to the end of the line.
                if i + 1 < b.len() && b[i + 1] == b'-' {
                    i += 2;
                    while i < b.len() && b[i] != b'\n' {
                        i += 1;
                    }
                } else {
                    out.push(Tok::Minus);
                    i += 1;
                }
            }
            b'/' => {
                // `/* ... */` block comment (non-nesting). A lone `/` is not
                // a token in this grammar.
                if i + 1 < b.len() && b[i + 1] == b'*' {
                    i += 2;
                    let mut closed = false;
                    while i + 1 < b.len() {
                        if b[i] == b'*' && b[i + 1] == b'/' {
                            i += 2;
                            closed = true;
                            break;
                        }
                        i += 1;
                    }
                    if !closed {
                        return Err(Error::Parse("unterminated block comment".into()));
                    }
                } else {
                    return Err(Error::Parse(format!("unexpected '/' at byte {i}")));
                }
            }
            b'?' => {
                out.push(Tok::Question);
                i += 1;
            }
            b'=' => {
                out.push(Tok::Eq);
                i += 1;
            }
            b'!' => {
                if i + 1 < b.len() && b[i + 1] == b'=' {
                    out.push(Tok::Ne);
                    i += 2;
                } else {
                    return Err(Error::Parse(format!("unexpected '!' at byte {i}")));
                }
            }
            b'<' => {
                if i + 1 < b.len() && b[i + 1] == b'=' {
                    out.push(Tok::Le);
                    i += 2;
                } else if i + 1 < b.len() && b[i + 1] == b'>' {
                    out.push(Tok::Ne);
                    i += 2;
                } else {
                    out.push(Tok::Lt);
                    i += 1;
                }
            }
            b'>' => {
                if i + 1 < b.len() && b[i + 1] == b'=' {
                    out.push(Tok::Ge);
                    i += 2;
                } else {
                    out.push(Tok::Gt);
                    i += 1;
                }
            }
            b'\'' => {
                i += 1;
                let mut s = String::new();
                loop {
                    if i >= b.len() {
                        return Err(Error::Parse("unterminated string literal".into()));
                    }
                    if b[i] == b'\'' {
                        if i + 1 < b.len() && b[i + 1] == b'\'' {
                            s.push('\'');
                            i += 2;
                        } else {
                            i += 1;
                            break;
                        }
                    } else {
                        // Re-decode the UTF-8 character starting at i.
                        let rest = &src[i..];
                        let ch = rest.chars().next().expect("in-bounds char");
                        s.push(ch);
                        i += ch.len_utf8();
                    }
                }
                out.push(Tok::Str(s));
            }
            b'0'..=b'9' => {
                let start = i;
                while i < b.len() && b[i].is_ascii_digit() {
                    i += 1;
                }
                let digits = &src[start..i];
                let n: i64 = digits
                    .parse()
                    .map_err(|_| Error::Parse(format!("integer literal out of range: {digits}")))?;
                out.push(Tok::Int(n));
            }
            b'a'..=b'z' | b'A'..=b'Z' | b'_' => {
                let start = i;
                while i < b.len() && (b[i].is_ascii_alphanumeric() || b[i] == b'_') {
                    i += 1;
                }
                let word = &src[start..i];
                let upper = word.to_ascii_uppercase();
                match keyword(&upper) {
                    Some(k) => out.push(Tok::Kw(k)),
                    None => out.push(Tok::Ident(word.to_ascii_lowercase())),
                }
            }
            _ => {
                return Err(Error::Parse(format!(
                    "unexpected character {:?} at byte {i}",
                    src[i..].chars().next().unwrap_or('\u{fffd}')
                )));
            }
        }
    }
    Ok(out)
}
