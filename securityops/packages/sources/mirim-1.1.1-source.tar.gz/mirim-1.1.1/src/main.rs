// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

#![forbid(unsafe_code)]

//! `mirim <file.mrm>` — open (or create) an encrypted vault and run SQL.

use std::io::{self, BufRead, Write};
use std::path::PathBuf;
use std::process::ExitCode;

use zeroize::Zeroizing;

use mirim::vault::Secret;
use mirim::{DurableDb, Output, Value};

fn main() -> ExitCode {
    let args: Vec<_> = std::env::args_os().skip(1).collect();
    let path = match args.as_slice() {
        [flag] if flag == "--version" || flag == "-V" => {
            println!("mirim {}", env!("CARGO_PKG_VERSION"));
            return ExitCode::SUCCESS;
        }
        [flag] if flag == "--help" || flag == "-h" => {
            println!("{}", usage());
            return ExitCode::SUCCESS;
        }
        [separator, path] if separator == "--" => PathBuf::from(path),
        [path] if !path.to_string_lossy().starts_with('-') => PathBuf::from(path),
        _ => {
            eprintln!("{}", usage());
            return ExitCode::from(2);
        }
    };
    match run(&path) {
        Ok(()) => ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("error: {e}");
            ExitCode::FAILURE
        }
    }
}

fn usage() -> &'static str {
    "usage: mirim [--] <file.mrm>\n\
     Open or create an encrypted vault and run SQL interactively.\n\n\
     -h, --help     Show this help\n\
     -V, --version  Show the version\n\
     --             Treat the next argument as a path, even if it starts with '-'"
}

fn run(path: &std::path::Path) -> mirim::Result<()> {
    let mut db = if path.exists() {
        let pass = Zeroizing::new(rpassword::prompt_password("passphrase: ")?);
        DurableDb::open(path, &Secret::Passphrase(&pass))?
    } else {
        eprintln!("creating new vault: {}", path.display());
        let pass = Zeroizing::new(rpassword::prompt_password("new passphrase: ")?);
        let again = Zeroizing::new(rpassword::prompt_password("repeat passphrase: ")?);
        if *pass != *again {
            return Err(
                io::Error::new(io::ErrorKind::InvalidInput, "passphrases do not match").into(),
            );
        }
        DurableDb::open(path, &Secret::Passphrase(&pass))?
    };

    eprintln!("mirim {} — .help for commands", env!("CARGO_PKG_VERSION"));
    let stdin = io::stdin();
    let mut buf = String::new();

    loop {
        let prompt = if buf.is_empty() { "mirim> " } else { "  ...> " };
        eprint!("{prompt}");
        io::stderr().flush().ok();

        let mut line = String::new();
        if stdin.lock().read_line(&mut line)? == 0 {
            eprintln!();
            db.checkpoint()?;
            return Ok(());
        }
        let trimmed = line.trim();

        if buf.is_empty() && trimmed.starts_with('.') {
            // A dot-command is a single word plus an optional argument.
            let (cmd, rest) = match trimmed.split_once(char::is_whitespace) {
                Some((c, r)) => (c, r.trim()),
                None => (trimmed, ""),
            };
            match cmd {
                ".help" => {
                    eprintln!(".tables       list tables");
                    eprintln!(".schema       show CREATE TABLE statements");
                    eprintln!(".read <path>  run the SQL statements in a file");
                    eprintln!(".save         checkpoint: fold the log into the vault");
                    eprintln!(".rotate       re-encrypt under a new passphrase");
                    eprintln!(".quit         exit (every Ok statement is already durable)");
                    eprintln!("SQL statements end with ';'");
                }
                ".tables" => {
                    for n in db.db().table_names() {
                        println!("{n}");
                    }
                }
                ".schema" => {
                    let schema = db.db().schema_sql();
                    if schema.is_empty() {
                        eprintln!("(no tables)");
                    } else {
                        print!("{schema}");
                    }
                }
                ".read" => {
                    if rest.is_empty() {
                        eprintln!("usage: .read <path>");
                    } else {
                        read_script(&mut db, rest);
                    }
                }
                ".save" => {
                    db.checkpoint()?;
                    eprintln!("checkpointed {}", path.display());
                }
                ".rotate" => {
                    let new = Zeroizing::new(rpassword::prompt_password("new passphrase: ")?);
                    let again = Zeroizing::new(rpassword::prompt_password("repeat passphrase: ")?);
                    if *new != *again {
                        eprintln!("error: passphrases do not match");
                        continue;
                    }
                    db.rotate_secret(&Secret::Passphrase(&new))?;
                    eprintln!("rotated; old passphrase no longer opens {}", path.display());
                }
                ".quit" => {
                    db.checkpoint()?;
                    return Ok(());
                }
                other => eprintln!("unknown command: {other}"),
            }
            continue;
        }

        buf.push_str(&line);
        if !buf.trim_end().ends_with(';') {
            if buf.trim().is_empty() {
                buf.clear();
            }
            continue;
        }
        let sql = std::mem::take(&mut buf);

        match db.execute(sql.trim()) {
            Ok(Output::Done) => eprintln!("ok"),
            Ok(Output::Affected(n)) => eprintln!("{n} row(s)"),
            Ok(Output::Rows { columns, rows }) => print_table(&columns, &rows),
            Err(e) => eprintln!("error: {e}"),
        }
    }
}

/// Load and run every statement in a SQL file against the live database.
/// Each statement is executed (and, in the durable session, fsynced)
/// individually — there are no multi-statement transactions — so on the
/// first error the statements already applied stay applied, and we report
/// how far we got.
fn read_script(db: &mut DurableDb, path: &str) {
    let script = match std::fs::read_to_string(path) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("error: cannot read {path}: {e}");
            return;
        }
    };
    let mut done = 0usize;
    for stmt in mirim::split_statements(&script) {
        match db.execute(&stmt) {
            Ok(_) => done += 1,
            Err(e) => {
                let preview: String = stmt.chars().take(60).collect();
                eprintln!("error after {done} statement(s), at \"{preview}\": {e}");
                return;
            }
        }
    }
    eprintln!("ok: ran {done} statement(s) from {path}");
}

fn print_table(columns: &[String], rows: &[Vec<Value>]) {
    let mut w: Vec<usize> = columns.iter().map(String::len).collect();
    let cells: Vec<Vec<String>> = rows
        .iter()
        .map(|r| r.iter().map(ToString::to_string).collect())
        .collect();
    for row in &cells {
        for (i, c) in row.iter().enumerate() {
            if c.len() > w[i] {
                w[i] = c.len();
            }
        }
    }
    let line = |cs: &[String]| {
        let parts: Vec<String> = cs
            .iter()
            .enumerate()
            .map(|(i, c)| format!("{c:<width$}", width = w[i]))
            .collect();
        println!("{}", parts.join(" | "));
    };
    line(columns);
    let total: usize = w.iter().sum::<usize>() + 3 * w.len().saturating_sub(1);
    println!("{}", "-".repeat(total));
    for row in &cells {
        line(row);
    }
    eprintln!("{} row(s)", rows.len());
}
