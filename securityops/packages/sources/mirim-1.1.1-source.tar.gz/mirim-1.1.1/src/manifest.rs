// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! ML-DSA-87 signed manifests for vault files and sealed exports
//! (feature `sign`).
//!
//! A manifest binds a target file's SHA-256, a target kind, and a caller-
//! supplied counter under an ML-DSA-87 (FIPS 204) signature. It travels
//! next to the file it covers (e.g. `data.mrm` + `data.mrm.mf`).
//!
//! Layout:
//! ```text
//! offset  size  field
//! 0       8     magic "MIRIMMF1"
//! 8       1     manifest version (1)
//! 9       1     target kind: 0 = vault (.mrm), 1 = sealed export
//! 10      8     counter, u64 little-endian
//! 18      32    SHA-256 of the full target file
//! 50      4627  ML-DSA-87 signature over bytes 0..50,
//!               context string "mirim.v1.manifest.mldsa87"
//! ```
//! Signing is the FIPS 204 deterministic variant, so no RNG state is
//! involved at signing time; the secret key is a 32-byte seed.
//!
//! Two verification paths:
//! - [`verify_manifest`]: offline check that the file was produced (or
//!   endorsed) by the holder of the signing seed. The counter is returned
//!   as an authenticated datum but **not** enforced.
//! - [`verify_manifest_enforcing`]: additionally persists the highest
//!   accepted counter (and target hash) in a small trust file and rejects
//!   anything older with [`Error::Rollback`]. This is the rollback
//!   defence: replaying an old file with its matching old manifest now
//!   fails. It is only as strong as the trust file — an adversary who can
//!   rewrite local state can reset it (see SECURITY.md). Use one trust
//!   file per target lineage; vaults and sealed exports are separate
//!   lineages.
//!
//! Trust file layout (49 bytes):
//! ```text
//! magic "MIRIMTS1" (8) | version 1 (1) | counter u64 LE (8)
//! | SHA-256 of the last accepted target (32)
//! ```
//! Rules: a higher counter is accepted and persisted; an equal counter is
//! accepted only for the byte-identical target (idempotent re-check, no
//! write); a lower counter is [`Error::Rollback`]. Writes are atomic and
//! fsynced; a persistence failure rejects the verification (fail closed).

use ml_dsa::{
    EncodedSignature, EncodedVerifyingKey, MlDsa87, Seed, Signature, SigningKey, VerifyingKey,
};
use rand_core::{OsRng, RngCore};
use sha2::{Digest, Sha256};
use zeroize::Zeroizing;

use crate::error::{Error, Result};

/// Encoded length of an ML-DSA-87 verifying (public) key.
pub const SIGN_PUBLIC_LEN: usize = 2592;
/// Length of the signing seed (the serialized secret).
pub const SIGN_SEED_LEN: usize = 32;
/// Length of an ML-DSA-87 signature.
pub const SIG_LEN: usize = 4627;

const MAGIC: &[u8; 8] = b"MIRIMMF1";
const FORMAT_VERSION: u8 = 1;
const HEADER_LEN: usize = 8 + 1 + 1 + 8 + 32;
/// Total length of a v1 manifest.
pub const MANIFEST_LEN: usize = HEADER_LEN + SIG_LEN;

/// FIPS 204 context string; versioned with the format.
const CTX: &[u8] = b"mirim.v1.manifest.mldsa87";

/// What kind of file a manifest covers.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TargetKind {
    /// An encrypted vault file (`.mrm`).
    Vault,
    /// A sealed export.
    Sealed,
}

impl TargetKind {
    fn to_byte(self) -> u8 {
        match self {
            TargetKind::Vault => 0,
            TargetKind::Sealed => 1,
        }
    }

    fn from_byte(b: u8) -> Result<Self> {
        match b {
            0 => Ok(TargetKind::Vault),
            1 => Ok(TargetKind::Sealed),
            _ => Err(Error::Corrupt("unknown manifest target kind")),
        }
    }
}

/// Manifest signing secret. Serializes as the 32-byte FIPS 204 seed;
/// keep it offline.
pub struct ManifestSecret {
    sk: SigningKey<MlDsa87>,
}

/// Manifest verifying key. Safe to publish.
pub struct ManifestPublic {
    vk: VerifyingKey<MlDsa87>,
}

impl ManifestSecret {
    /// Serialize as the 32-byte seed. Zeroized on drop; the caller
    /// decides where it persists.
    pub fn to_bytes(&self) -> Zeroizing<[u8; SIGN_SEED_LEN]> {
        let mut out = Zeroizing::new([0u8; SIGN_SEED_LEN]);
        out.copy_from_slice(self.sk.as_seed().as_slice());
        out
    }

    /// Reconstruct from a 32-byte seed.
    pub fn from_bytes(bytes: &[u8]) -> Result<Self> {
        let seed = Seed::try_from(bytes).map_err(|_| Error::Corrupt("bad signing seed length"))?;
        Ok(Self {
            sk: SigningKey::from_seed(&seed),
        })
    }

    /// The matching verifying key.
    pub fn public(&self) -> ManifestPublic {
        ManifestPublic {
            vk: self.sk.expanded_key().verifying_key().clone(),
        }
    }
}

impl ManifestPublic {
    /// Serialize to the 2592-byte FIPS 204 encoding.
    pub fn to_bytes(&self) -> Vec<u8> {
        self.vk.encode().to_vec()
    }

    /// Parse the 2592-byte FIPS 204 encoding.
    pub fn from_bytes(bytes: &[u8]) -> Result<Self> {
        let enc = EncodedVerifyingKey::<MlDsa87>::try_from(bytes)
            .map_err(|_| Error::Corrupt("bad verifying key length"))?;
        Ok(Self {
            vk: VerifyingKey::decode(&enc),
        })
    }
}

/// Generate a fresh ML-DSA-87 signing key pair: a 32-byte seed from the
/// OS CSPRNG, expanded per FIPS 204.
pub fn keygen() -> (ManifestSecret, ManifestPublic) {
    let mut seed = Zeroizing::new(Seed::default());
    OsRng.fill_bytes(seed.as_mut_slice());
    let sk = SigningKey::from_seed(&seed);
    let vk = sk.expanded_key().verifying_key().clone();
    (ManifestSecret { sk }, ManifestPublic { vk })
}

fn header(kind: TargetKind, counter: u64, target: &[u8]) -> [u8; HEADER_LEN] {
    let mut h = [0u8; HEADER_LEN];
    h[..8].copy_from_slice(MAGIC);
    h[8] = FORMAT_VERSION;
    h[9] = kind.to_byte();
    h[10..18].copy_from_slice(&counter.to_le_bytes());
    h[18..50].copy_from_slice(&Sha256::digest(target));
    h
}

/// Sign a manifest for `target` (the full file bytes). `counter` is an
/// authenticated value chosen by the caller; see the module docs for what
/// it does and does not provide in 0.2.x.
pub fn sign_manifest(
    target: &[u8],
    kind: TargetKind,
    counter: u64,
    secret: &ManifestSecret,
) -> Vec<u8> {
    let h = header(kind, counter, target);
    let sig: Signature<MlDsa87> = secret
        .sk
        .expanded_key()
        .sign_deterministic(&h, CTX)
        .expect("context string is shorter than 255 bytes");
    let mut out = Vec::with_capacity(MANIFEST_LEN);
    out.extend_from_slice(&h);
    out.extend_from_slice(sig.encode().as_slice());
    out
}

/// Verify `manifest` against `target` (the full file bytes). On success,
/// returns the authenticated target kind and counter. Signature failure
/// and hash mismatch are indistinguishable ([`Error::Crypto`]).
pub fn verify_manifest(
    manifest: &[u8],
    target: &[u8],
    public: &ManifestPublic,
) -> Result<(TargetKind, u64)> {
    if manifest.len() != MANIFEST_LEN {
        return Err(Error::Corrupt("manifest has wrong length"));
    }
    let (h, sig_bytes) = manifest.split_at(HEADER_LEN);
    if &h[..8] != MAGIC {
        return Err(Error::Corrupt("bad magic"));
    }
    if h[8] != FORMAT_VERSION {
        return Err(Error::Corrupt("unsupported manifest version"));
    }
    let kind = TargetKind::from_byte(h[9])?;
    let counter = u64::from_le_bytes(h[10..18].try_into().expect("fixed slice"));

    let enc = EncodedSignature::<MlDsa87>::try_from(sig_bytes).map_err(|_| Error::Crypto)?;
    let sig = Signature::<MlDsa87>::decode(&enc).ok_or(Error::Crypto)?;
    if !public.vk.verify_with_context(h, CTX, &sig) {
        return Err(Error::Crypto);
    }
    let expected: [u8; 32] = Sha256::digest(target).into();
    if h[18..50] != expected {
        return Err(Error::Crypto);
    }
    Ok((kind, counter))
}

const TRUST_MAGIC: &[u8; 8] = b"MIRIMTS1";
const TRUST_VERSION: u8 = 1;
const TRUST_LEN: usize = 8 + 1 + 8 + 32;

fn read_trust(path: &std::path::Path) -> Result<Option<(u64, [u8; 32])>> {
    let bytes = match std::fs::read(path) {
        Ok(b) => b,
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(e) => return Err(e.into()),
    };
    if bytes.len() != TRUST_LEN {
        return Err(Error::Corrupt("trust file has wrong length"));
    }
    if &bytes[..8] != TRUST_MAGIC {
        return Err(Error::Corrupt("bad trust file magic"));
    }
    if bytes[8] != TRUST_VERSION {
        return Err(Error::Corrupt("unsupported trust file version"));
    }
    let counter = u64::from_le_bytes(bytes[9..17].try_into().expect("fixed slice"));
    let hash: [u8; 32] = bytes[17..].try_into().expect("fixed slice");
    Ok(Some((counter, hash)))
}

fn write_trust(path: &std::path::Path, counter: u64, hash: &[u8; 32]) -> Result<()> {
    let mut out = Vec::with_capacity(TRUST_LEN);
    out.extend_from_slice(TRUST_MAGIC);
    out.push(TRUST_VERSION);
    out.extend_from_slice(&counter.to_le_bytes());
    out.extend_from_slice(hash);
    crate::vault::write_atomic(path, &out)
}

/// [`verify_manifest`], plus counter enforcement against the trust file
/// at `trust_path` (created on first acceptance). See the module docs
/// for the exact accept/reject rules. On acceptance the trust state is
/// persisted (atomically, fsynced) *before* this returns; if persisting
/// fails, verification fails.
pub fn verify_manifest_enforcing(
    manifest: &[u8],
    target: &[u8],
    public: &ManifestPublic,
    trust_path: &std::path::Path,
) -> Result<(TargetKind, u64)> {
    let (kind, counter) = verify_manifest(manifest, target, public)?;
    let hash: [u8; 32] = Sha256::digest(target).into();
    match read_trust(trust_path)? {
        None => write_trust(trust_path, counter, &hash)?,
        Some((stored, stored_hash)) => {
            if counter < stored || (counter == stored && hash != stored_hash) {
                return Err(Error::Rollback);
            }
            if counter > stored {
                write_trust(trust_path, counter, &hash)?;
            }
        }
    }
    Ok((kind, counter))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn manifest_len_is_fixed() {
        assert_eq!(MANIFEST_LEN, 4677);
    }

    #[test]
    fn trust_len_is_fixed() {
        assert_eq!(TRUST_LEN, 49);
    }
}
