# mirim

A small embedded SQL database with encrypted storage, a durable write-ahead
log, and post-quantum sealed exports. The database engine is written in Rust
with `#![forbid(unsafe_code)]`; C bindings and a desktop GUI are separate crates.

**Version 1.1.1** · [Website](https://mirim.securityops.co) ·
[Português do Brasil](README.pt-BR.md)

## Documentation

| Start here | Reference and project policy |
|---|---|
| [User guide](docs/GUIDE.md) | [Security model](SECURITY.md) |
| [Guia em português](docs/GUIDE.pt-BR.md) | [Release history](CHANGELOG.md) |
| [Sample databases](samples/README.md) | [Release process](RELEASE.md) |
| [Rust examples](examples/) | [Storage decision](docs/ADR-001-storage.md) |
| [C header](ffi/include/mirim.h) | [Licensing](LICENSING.md) / [Licenciamento](LICENSING.pt-BR.md) |

## What you get

- **Encrypted storage.** `.mrm` snapshots use XChaCha20-Poly1305, with a
  key derived by Argon2id from a passphrase or supplied as a 32-byte raw key.
  Headers are authenticated. The in-memory `Db` API persists only when you save it.
- **Durable sessions.** The CLI, GUI, C API, and Rust `DurableDb` use an
  encrypted write-ahead log. Successful mutations are synced before returning;
  checkpoints fold the log into the snapshot. Sessions hold an exclusive OS
  writer lock on Unix and Windows; unsupported locking fails the open.
  Platform and storage limits are in the [security model](SECURITY.md).
- **A focused SQL subset.** `CREATE TABLE`, `INSERT`, `SELECT`, `UPDATE`,
  and `DELETE`; `INTEGER`, `TEXT`, and `NULL`; single-column `PRIMARY KEY`
  and `UNIQUE`; bound `?` parameters; `WHERE` with `AND`, comparisons, and
  `IS [NOT] NULL`; `ORDER BY`, `LIMIT`/`OFFSET`, and `COUNT(*)`.
- **Post-quantum exports.** ML-KEM-768 encapsulation and symmetric
  authenticated encryption seal a snapshot to one or several recipients.
  The optional `sign` feature adds ML-DSA-87 detached signed manifests.
- **Several interfaces.** A terminal REPL (`mirim`), desktop application
  (`mirim-gui`), signing tool (`mirim-sign`), Rust API, and C API.

The whole working set lives in RAM. There are no joins, multi-statement
transactions, out-of-core paging, or concurrent writer support. PRIMARY KEY
and UNIQUE equality indexes accelerate matching lookups; other predicates
scan rows. Use a more complete database when these limits do not fit your
application. See the [SQL reference](docs/GUIDE.md#sql-reference).

## Install

Find the release matching your operating system and architecture on any mirror:

- [git.securityops.co](https://git.securityops.co/cristiancmoises/mirim/releases)
- [git.securityops.com.br](https://git.securityops.com.br/cristiancmoises/mirim/releases)
- [GitHub](https://github.com/cristiancmoises/mirim/releases)
- [Codeberg](https://codeberg.org/berkeley/mirim/releases)

Use the assets actually attached to that release; a packaging recipe or
upstream submission does not mean a package is already in an OS repository.
The [installation guide](docs/GUIDE.md#installation) covers GNU/Linux,
macOS, Windows, BSD source builds, and the local GNU Guix recipe.

On GNU/Linux, verify downloaded files against `SHA256SUMS` before installing:

```sh
sha256sum -c SHA256SUMS --ignore-missing
```

Checksums detect corruption, but authenticate neither the publisher nor the
checksum file. When an artifact has a `.mf` signature, use a trusted
`mirim-sign` and a previously authenticated maintainer public key:

```sh
mirim-sign verify <artifact> <artifact>.mf mirim-release.pub
```

### Build from source

Install Rust through rustup and the native compiler tools for your OS.
The repository pins Rust 1.96.0 in `rust-toolchain.toml`.

```sh
git clone https://github.com/cristiancmoises/mirim.git
cd mirim
git checkout v1.1.1
cargo build --release --locked --features sign
```

The CLI and signing tool are in `target/release/` (`.exe` on Windows).
Build the optional interfaces separately:

```sh
cargo build --release --locked --manifest-path gui/Cargo.toml
cargo build --release --locked --manifest-path ffi/Cargo.toml
```

The GUI requires native graphics libraries on GNU/Linux. See the
[guide](docs/GUIDE.md#build-from-source) for prerequisites.

## Your first vault

```text
$ mirim notes.mrm
creating new vault: notes.mrm
new passphrase:
repeat passphrase:
mirim 1.1.1 — .help for commands
mirim> CREATE TABLE notes (id INTEGER PRIMARY KEY, body TEXT);
ok
mirim> INSERT INTO notes VALUES (1, 'my first encrypted note');
1 row(s)
mirim> SELECT body FROM notes WHERE id = 1;
mirim> .quit
```

Each successful mutation is logged durably before the CLI reports success.
`.save` checkpoints; `.quit` checkpoints and exits. `.read <path>` imports a
SQL script one statement at a time: an error leaves earlier statements applied.

Try the commented [sample datasets](samples/README.md), or run the examples:

```sh
cargo run --locked --example quickstart
cargo run --locked --example sealed_export
```

Keep passphrases and recipient secret keys safe: there is no recovery backdoor.
For backups, stop writes and close the vault successfully before copying it.
Read the [backup procedure](docs/GUIDE.md#backups-and-recovery), especially if
recovering a crashed session with a `.wal` file.

## Development and verification

```sh
cargo fmt --all --check
cargo clippy --locked --all-features --all-targets -- -D warnings
cargo test --locked --all-features
cargo audit
cargo deny check
```

The repository also contains cryptographic vectors, property and differential
tests, decoder fuzz targets, a Unix SIGKILL recovery harness, and a C sanitizer
harness. The [verification guide](docs/GUIDE.md#development-and-audit) explains
how to run them and inspect the GUI and FFI dependency graphs. Test coverage
and dependency checks are evidence about those checks, not an independent
security certification.

## Source and license

Source is published on [git.securityops.co](https://git.securityops.co/cristiancmoises/mirim),
[git.securityops.com.br](https://git.securityops.com.br/cristiancmoises/mirim),
[GitHub](https://github.com/cristiancmoises/mirim), and
[Codeberg](https://codeberg.org/berkeley/mirim).

First-party files marked `AGPL-3.0-only OR LicenseRef-Mirim-Commercial` are
available under AGPL-3.0-only or a separately signed commercial agreement.
Files marked MIT and third-party dependencies retain their own licenses.
See [LICENSING.md](LICENSING.md), [LICENSE](LICENSE), and
[LICENSE-COMMERCIAL](LICENSE-COMMERCIAL). Commercial inquiries:
`sac@securityops.co`. Copyright © 2026 Cristian Cezar Moisés.
