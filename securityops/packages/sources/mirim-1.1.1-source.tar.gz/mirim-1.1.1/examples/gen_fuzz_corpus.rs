// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! Writes one valid artifact per fuzz target into `fuzz/corpus/<target>/`
//! so mutation starts from structurally correct inputs instead of noise.
//! Run: `cargo run --example gen_fuzz_corpus --features fuzzing,sign`

use std::fs;

use mirim::vault::Secret;
use mirim::{Db, DurableDb, Value};

fn main() {
    let mut db = Db::new();
    db.execute("create table t (id integer primary key, s text unique)")
        .unwrap();
    db.execute_params(
        "insert into t values (?, ?)",
        &[Value::Int(1), Value::Text("seed".into())],
    )
    .unwrap();

    let put = |target: &str, name: &str, bytes: &[u8]| {
        let dir = format!("fuzz/corpus/{target}");
        fs::create_dir_all(&dir).unwrap();
        fs::write(format!("{dir}/{name}"), bytes).unwrap();
    };

    // wire: a valid v2 snapshot, reached via a vault round-trip is not
    // needed — encode is what decode parses. fuzz_api keeps wire private,
    // so regenerate through the sealed path instead: seal -> open is
    // authenticated, but the *wire bytes* equal the plaintext; simplest
    // valid sample is a sealed export opened by the target itself. For
    // the wire target, use the one public producer of raw wire bytes:
    // none exists. A structural sample is enough: build it by hand from
    // the documented format.
    let mut wire = vec![2u8]; // version
    wire.extend_from_slice(&1u32.to_le_bytes()); // one table
    wire.extend_from_slice(&1u32.to_le_bytes());
    wire.extend_from_slice(b"t"); // name
    wire.extend_from_slice(&2u16.to_le_bytes()); // two columns
    wire.extend_from_slice(&2u32.to_le_bytes());
    wire.extend_from_slice(b"id");
    wire.push(0); // INTEGER
    wire.push(2); // PRIMARY KEY
    wire.extend_from_slice(&1u32.to_le_bytes());
    wire.extend_from_slice(b"s");
    wire.push(1); // TEXT
    wire.push(1); // UNIQUE
    wire.extend_from_slice(&1u64.to_le_bytes()); // one row
    wire.push(1); // INT tag
    wire.extend_from_slice(&1i64.to_le_bytes());
    wire.push(2); // TEXT tag
    wire.extend_from_slice(&4u32.to_le_bytes());
    wire.extend_from_slice(b"seed");
    put("fuzz_wire", "snapshot_v2", &wire);

    let (_, pk) = mirim::pq::keygen();
    let (_, pk2) = mirim::pq::keygen();
    put("fuzz_seal", "v1", &mirim::pq::seal(&db, &pk).unwrap());
    put(
        "fuzz_seal",
        "v2_two_recipients",
        &mirim::pq::seal_multi(&db, &[&pk, &pk2]).unwrap(),
    );

    let (msk, _) = mirim::manifest::keygen();
    put(
        "fuzz_manifest",
        "counter3",
        &mirim::manifest::sign_manifest(
            b"fuzz target bytes",
            mirim::manifest::TargetKind::Vault,
            3,
            &msk,
        ),
    );

    put("fuzz_sql", "stmt", b"insert into t (id, s) values (2, 'x')");

    let dir = std::env::temp_dir().join(format!("mirim-corpus-{}", std::process::id()));
    fs::create_dir_all(&dir).unwrap();
    let vp = dir.join("c.mrm");
    {
        let mut d = DurableDb::open(&vp, &Secret::RawKey(&[0u8; 32])).unwrap();
        d.execute("create table t (id integer primary key)")
            .unwrap();
        for i in 0..3 {
            d.execute_params("insert into t values (?)", &[Value::Int(i)])
                .unwrap();
        }
    }
    let mut wp = vp.as_os_str().to_owned();
    wp.push(".wal");
    put(
        "fuzz_wal",
        "three_records",
        &fs::read(std::path::PathBuf::from(wp)).unwrap(),
    );
    let _ = fs::remove_dir_all(&dir);
    println!("corpus written");
}
