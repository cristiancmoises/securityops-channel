// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! Sample database — a self-hosted service credential store with an
//! access audit log, the kind of small, sensitive, durable dataset mirim
//! is built for. Run it:
//!
//! ```text
//! cargo run --example quickstart
//! ```
//!
//! It opens an encrypted vault (in your temp directory), and on the first
//! run creates three tables and seeds them; on later runs it finds the
//! data already there — the write-ahead log made every insert durable, so
//! re-running demonstrates persistence rather than recreating anything.
//! Then it runs representative queries, shows a UNIQUE constraint
//! rejecting a duplicate, rotates a secret with a bound parameter, and
//! checkpoints.
//!
//! The demo opens the vault with a fixed raw key so the example is
//! self-contained. A real deployment uses a passphrase
//! (`Secret::Passphrase`, Argon2id) or a key from a hardware token / KMS —
//! never a hard-coded key like this one.

use std::path::PathBuf;

use mirim::vault::Secret;
use mirim::{DurableDb, Output, Value};

// Demonstration key only. Do not ship a hard-coded key.
const DEMO_KEY: [u8; 32] = *b"mirim quickstart demo key -- 32B";

const SCHEMA: &[&str] = &[
    // Registered services that hold credentials.
    "CREATE TABLE services (id INTEGER PRIMARY KEY, name TEXT UNIQUE, endpoint TEXT)",
    // Secret references. rotated_at is a Unix timestamp, NULL = never rotated.
    "CREATE TABLE secrets (id INTEGER PRIMARY KEY, service TEXT, label TEXT UNIQUE, rotated_at INTEGER)",
    // Access audit log. allowed is 1/0 (no boolean type).
    "CREATE TABLE access_log (id INTEGER PRIMARY KEY, service TEXT, actor TEXT, ts INTEGER, allowed INTEGER)",
];

fn seed(db: &mut DurableDb) -> mirim::Result<()> {
    for (id, name, endpoint) in [
        (1, "postgres-prod", "db.internal:5432"),
        (2, "redis-cache", "cache.internal:6379"),
        (3, "smtp-relay", "mail.internal:587"),
    ] {
        db.execute_params(
            "INSERT INTO services VALUES (?, ?, ?)",
            &[
                Value::Int(id),
                Value::Text(name.into()),
                Value::Text(endpoint.into()),
            ],
        )?;
    }

    // rotated_at NULL for never-rotated secrets.
    let secrets: &[(i64, &str, &str, Option<i64>)] = &[
        (1, "postgres-prod", "pg_app_password", Some(1_717_200_000)),
        (2, "postgres-prod", "pg_replica_password", None),
        (3, "redis-cache", "redis_auth", Some(1_715_000_000)),
        (4, "smtp-relay", "smtp_api_key", None),
    ];
    for (id, service, label, rotated) in secrets {
        db.execute_params(
            "INSERT INTO secrets VALUES (?, ?, ?, ?)",
            &[
                Value::Int(*id),
                Value::Text((*service).into()),
                Value::Text((*label).into()),
                rotated.map(Value::Int).unwrap_or(Value::Null),
            ],
        )?;
    }

    let log: &[(i64, &str, &str, i64, i64)] = &[
        (1, "postgres-prod", "svc-web", 1_717_300_000, 1),
        (2, "postgres-prod", "svc-web", 1_717_300_100, 1),
        (3, "redis-cache", "svc-worker", 1_717_300_200, 1),
        (4, "postgres-prod", "unknown-host", 1_717_300_300, 0),
        (5, "smtp-relay", "svc-mailer", 1_717_300_400, 1),
        (6, "redis-cache", "svc-web", 1_717_300_500, 0),
    ];
    for (id, service, actor, ts, allowed) in log {
        db.execute_params(
            "INSERT INTO access_log VALUES (?, ?, ?, ?, ?)",
            &[
                Value::Int(*id),
                Value::Text((*service).into()),
                Value::Text((*actor).into()),
                Value::Int(*ts),
                Value::Int(*allowed),
            ],
        )?;
    }
    Ok(())
}

/// Print a query result as a simple aligned table.
fn show(title: &str, out: Output) {
    println!("\n{title}");
    match out {
        Output::Rows { columns, rows } => {
            println!("  {}", columns.join(" | "));
            if rows.is_empty() {
                println!("  (no rows)");
            }
            for row in rows {
                let cells: Vec<String> = row.iter().map(render).collect();
                println!("  {}", cells.join(" | "));
            }
        }
        Output::Affected(n) => println!("  {n} row(s) affected"),
        Output::Done => println!("  ok"),
    }
}

fn render(v: &Value) -> String {
    match v {
        Value::Null => "NULL".to_string(),
        Value::Int(i) => i.to_string(),
        Value::Text(s) => s.clone(),
    }
}

fn main() -> mirim::Result<()> {
    let path: PathBuf = std::env::args()
        .nth(1)
        .map(PathBuf::from)
        .unwrap_or_else(|| std::env::temp_dir().join("mirim-sample.mrm"));

    let mut db = DurableDb::open(&path, &Secret::RawKey(&DEMO_KEY))?;

    if db.db().table_names().is_empty() {
        println!("Creating and seeding sample database at {}", path.display());
        for stmt in SCHEMA {
            db.execute(stmt)?;
        }
        seed(&mut db)?;
    } else {
        println!(
            "Opened existing sample database at {} (data persisted from a prior run)",
            path.display()
        );
    }

    show(
        "Registered services:",
        db.execute("SELECT name, endpoint FROM services")?,
    );
    show(
        "Secrets that have never been rotated (rotated_at IS NULL):",
        db.execute("SELECT label, service FROM secrets WHERE rotated_at IS NULL")?,
    );
    show(
        "Denied access attempts (allowed = 0):",
        db.execute("SELECT actor, service FROM access_log WHERE allowed = 0")?,
    );
    show(
        "Access by postgres-prod (parameter-bound lookup):",
        db.execute_params(
            "SELECT actor, ts FROM access_log WHERE service = ?",
            &[Value::Text("postgres-prod".into())],
        )?,
    );

    // UNIQUE constraint: a duplicate label is rejected, the table unchanged.
    println!("\nAttempting to insert a duplicate secret label 'redis_auth':");
    match db.execute_params(
        "INSERT INTO secrets VALUES (?, ?, ?, ?)",
        &[
            Value::Int(99),
            Value::Text("redis-cache".into()),
            Value::Text("redis_auth".into()),
            Value::Null,
        ],
    ) {
        Ok(_) => println!("  unexpected: insert succeeded"),
        Err(e) => println!("  rejected as expected: {e}"),
    }

    // Rotate a secret with a bound timestamp, then re-check the never-rotated set.
    db.execute_params(
        "UPDATE secrets SET rotated_at = ? WHERE label = ?",
        &[
            Value::Int(1_717_400_000),
            Value::Text("pg_replica_password".into()),
        ],
    )?;
    show(
        "After rotating pg_replica_password, still-never-rotated:",
        db.execute("SELECT label FROM secrets WHERE rotated_at IS NULL")?,
    );

    // Fold the log into a fresh encrypted snapshot.
    db.checkpoint()?;
    println!("\nCheckpointed. Re-run this example to see the data persist.");
    Ok(())
}
