// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! Materialize the shipped sample schemas (`samples/*.sql`) into encrypted
//! mirim vaults, and demonstrate a post-quantum sealed export of one of
//! them. Run it:
//!
//! ```text
//! cargo run --example gen_samples             # writes into a temp dir
//! cargo run --example gen_samples ./out       # writes into ./out
//! ```
//!
//! For each sample it loads the SQL into an in-memory database
//! (`Db::execute_script`), reports the row counts, and saves an encrypted
//! `.mrm` vault under a demo passphrase (Argon2id at rest). Open one with
//! the CLI using the same passphrase:
//!
//! ```text
//! mirim /tmp/mirim-samples/secrets_vault.mrm      # passphrase: sample-pass
//! ```
//!
//! The passphrase here is fixed so the example is self-contained; a real
//! deployment uses a passphrase you actually keep secret, or a raw key from
//! a hardware token / KMS.

use std::path::PathBuf;

use mirim::vault::Secret;
use mirim::{pq, Db};

/// (file stem, embedded SQL). `include_str!` binds the samples at build
/// time, so the example does not depend on the working directory.
const SAMPLES: &[(&str, &str)] = &[
    (
        "secrets_vault",
        include_str!("../samples/secrets_vault.sql"),
    ),
    (
        "ctf_scoreboard",
        include_str!("../samples/ctf_scoreboard.sql"),
    ),
    ("device_fleet", include_str!("../samples/device_fleet.sql")),
    ("audit_trail", include_str!("../samples/audit_trail.sql")),
    (
        "password_manager",
        include_str!("../samples/password_manager.sql"),
    ),
];

const DEMO_PASSPHRASE: &str = "sample-pass";

fn build(sql: &str) -> mirim::Result<Db> {
    let mut db = Db::new();
    db.execute_script(sql)?;
    Ok(db)
}

/// Count the rows in a table via `COUNT(*)`.
fn row_count(db: &mut Db, table: &str) -> mirim::Result<i64> {
    match db.execute(&format!("SELECT COUNT(*) FROM {table}"))? {
        mirim::Output::Rows { rows, .. } => match rows.first().and_then(|r| r.first()) {
            Some(mirim::Value::Int(n)) => Ok(*n),
            _ => Ok(0),
        },
        _ => Ok(0),
    }
}

fn main() -> mirim::Result<()> {
    let out_dir: PathBuf = std::env::args()
        .nth(1)
        .map(PathBuf::from)
        .unwrap_or_else(|| std::env::temp_dir().join("mirim-samples"));
    std::fs::create_dir_all(&out_dir)?;

    println!("Writing encrypted sample vaults to {}", out_dir.display());
    println!("(passphrase for every vault: {DEMO_PASSPHRASE:?})\n");

    let mut first_db: Option<Db> = None;
    for (name, sql) in SAMPLES {
        let mut db = build(sql)?;

        // Report the shape of each sample.
        let tables = db
            .table_names()
            .into_iter()
            .map(String::from)
            .collect::<Vec<_>>();
        let mut parts = Vec::new();
        for t in &tables {
            parts.push(format!("{t}={}", row_count(&mut db, t)?));
        }
        println!("  {name:<18} tables: {}", parts.join(", "));

        // Save an encrypted vault.
        let path = out_dir.join(format!("{name}.mrm"));
        // A fresh save should not collide with a stale WAL from a prior run.
        let _ = std::fs::remove_file(path.with_extension("mrm.wal"));
        mirim::vault::save(&db, &path, &Secret::Passphrase(DEMO_PASSPHRASE))?;

        if first_db.is_none() {
            first_db = Some(db);
        }
    }

    // Demonstrate a post-quantum sealed export of the first sample: sealed
    // to a fresh ML-KEM-768 recipient, then reopened with that recipient's
    // secret to prove the round-trip. No classical asymmetric crypto is
    // involved anywhere in this path.
    if let Some(db) = first_db {
        let (sk, pk) = pq::keygen();
        let sealed = pq::seal(&db, &pk)?;
        let sealed_path = out_dir.join("secrets_vault.sealed");
        std::fs::write(&sealed_path, &sealed)?;
        let reopened = pq::open(&sealed, &sk)?;
        assert_eq!(db.table_names(), reopened.table_names());
        println!(
            "\nSealed export (ML-KEM-768): {} ({} bytes), reopened OK.",
            sealed_path.display(),
            sealed.len()
        );
    }

    println!(
        "\nDone. Open one with:  mirim {}/secrets_vault.mrm",
        out_dir.display()
    );
    Ok(())
}
