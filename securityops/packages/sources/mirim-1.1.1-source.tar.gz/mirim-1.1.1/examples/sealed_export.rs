// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! Post-quantum sealed exports — mirim's headline capability. Run it:
//!
//! ```text
//! cargo run --example sealed_export
//! ```
//!
//! It builds a small sensitive database, seals it to two recipients at
//! once with ML-KEM-768 (FIPS 203), writes the sealed blob to a file, and
//! then shows each recipient opening it while an outsider — whose key is
//! not in the recipient set — is rejected. No classical asymmetric
//! cryptography is involved anywhere, so a sealed export sitting in a
//! backup is not exposed to harvest-now-decrypt-later collection.
//!
//! The companion `quickstart` example covers the encrypted-at-rest vault,
//! durability, and queries; this one is only about the sealed-export path.

use std::path::PathBuf;

use mirim::{pq, Db, Output, Value};

fn build_db() -> mirim::Result<Db> {
    let mut db = Db::new();
    db.execute("CREATE TABLE secrets (id INTEGER PRIMARY KEY, label TEXT UNIQUE, value TEXT)")?;
    for (id, label, value) in [
        (1, "pg_app_password", "s3cr3t-pg"),
        (2, "redis_auth", "s3cr3t-redis"),
        (3, "smtp_api_key", "s3cr3t-smtp"),
    ] {
        db.execute_params(
            "INSERT INTO secrets VALUES (?, ?, ?)",
            &[
                Value::Int(id),
                Value::Text(label.into()),
                Value::Text(value.into()),
            ],
        )?;
    }
    Ok(db)
}

fn secret_count(db: &mut Db) -> usize {
    match db.execute("SELECT id FROM secrets") {
        Ok(Output::Rows { rows, .. }) => rows.len(),
        _ => 0,
    }
}

fn main() -> mirim::Result<()> {
    let db = build_db()?;

    // Two recipients. In practice each generates their own key pair and
    // publishes the public key; the sealer needs only the public keys.
    let (ops_sk, ops_pk) = pq::keygen();
    let (auditor_sk, auditor_pk) = pq::keygen();

    // Seal once to both recipients. The snapshot is encrypted under a
    // single random key, which is wrapped to each recipient's ML-KEM-768
    // public key; any listed recipient can open the result.
    let sealed = pq::seal_multi(&db, &[&ops_pk, &auditor_pk])?;

    let path: PathBuf = std::env::temp_dir().join("mirim-export.sealed");
    std::fs::write(&path, &sealed)?;
    println!(
        "Sealed the database to 2 recipients (ML-KEM-768): {} bytes -> {}",
        sealed.len(),
        path.display()
    );

    // Each recipient opens it with their own secret key.
    for (name, sk) in [("ops", &ops_sk), ("auditor", &auditor_sk)] {
        let mut opened = pq::open(&sealed, sk)?;
        println!(
            "  {name} opened the export: {} secrets recovered",
            secret_count(&mut opened)
        );
    }

    // An outsider — not in the recipient set — cannot open it.
    let (outsider_sk, _outsider_pk) = pq::keygen();
    match pq::open(&sealed, &outsider_sk) {
        Ok(_) => println!("  UNEXPECTED: an outsider opened the export"),
        Err(e) => println!("  outsider rejected, as expected: {e}"),
    }

    // The single-recipient path (`pq::seal`) produces the original v1
    // format and round-trips the same way.
    let single = pq::seal(&db, &ops_pk)?;
    let mut back = pq::open(&single, &ops_sk)?;
    println!(
        "\nSingle-recipient seal/open round-trip: {} secrets recovered",
        secret_count(&mut back)
    );
    println!(
        "The sealed file at {} can be shipped to any recipient.",
        path.display()
    );
    Ok(())
}
