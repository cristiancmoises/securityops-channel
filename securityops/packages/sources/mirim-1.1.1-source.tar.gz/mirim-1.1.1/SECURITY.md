# Security model — mirim 1.1.1

This document describes implemented protections and their limits. It is not
an independent security audit or certification. A Portuguese operational
summary is in the [user guide](docs/GUIDE.pt-BR.md#seguranca-e-limites).

## Intended use and trust boundaries

mirim protects small datasets stored as encrypted snapshots and, for durable
sessions, encrypted write-ahead logs. The host, running application, operating
system random source, and cryptographic dependencies are trusted. The whole
working set is decrypted into ordinary process memory while open.

The core crate forbids unsafe Rust. Dependencies may contain unsafe code;
the separate C FFI crate deliberately contains an unsafe boundary. Neither
that policy nor the test suite proves the application is free of flaws.

## Encryption and authentication

Vault snapshots use XChaCha20-Poly1305, with the 50-byte header bound as
associated data. Passphrases derive a 32-byte key using Argon2id with 64 MiB,
three passes, and four lanes. Callers can instead supply a 32-byte raw key.
Passphrase guessing remains possible; Argon2id raises its cost without
making a weak passphrase safe.

Sealed exports use ML-KEM-768 (FIPS 203) with HKDF-SHA256 and
XChaCha20-Poly1305. Multi-recipient exports encrypt the snapshot once under a
random content key and wrap that key for each recipient. The formats use
no classical asymmetric encryption and are designed to resist known quantum
attacks; that is not a guarantee against future cryptanalytic advances.

The optional manifest API uses ML-DSA-87 (FIPS 204) to sign a target hash,
type, and counter. Use an authenticated public key and a trusted verifier.
A signature proves origin relative to that key, not that a file or software
is safe. A sealed export alone does not authenticate its sender: anyone
holding the recipient's public key can create one.

Random 192-bit nonces come from the OS random source for vault, WAL, and
payload encryption. Each multi-recipient key wrap uses a zero nonce under
its separately derived, single-use key. Nonce safety depends on the random
source and the underlying cryptographic implementations.

## Errors and hostile input

Wrong secrets and failed authenticated decryption return `Error::Crypto`
without distinguishing the reason. Public structural checks, unsupported
versions, a mismatched secret kind, and I/O failures can produce different
errors. It is inaccurate to say every modified file has the same error.
ML-KEM decapsulation uses the dependency's implicit rejection behavior.

Snapshot decoding checks lengths before allocation and rejects structural
violations, even though it follows authentication. These bounds do not impose
a global memory budget: a large file or validly decrypted dataset can still
exhaust memory. Applications must limit externally supplied file sizes and
resource use for their deployment.

## Durability and recovery

`DurableDb` writes each mutating statement to an encrypted WAL and syncs it
before successful execution is acknowledged. The CLI, GUI, and C API use
this session type. Plain `Db` is in memory; `vault::save` persists a snapshot
but does not provide per-statement durability.

WAL keys are derived from the vault master key and snapshot hash. Each
record authenticates the expected header and its consecutive sequence
number. Records cannot be successfully decrypted as another snapshot's
records. During checkpoint recovery, a WAL naming a different snapshot is
discarded as an interrupted checkpoint; this is not rollback protection.

Checkpointing replaces the snapshot before resetting the WAL. A process
crash can leave the old pair, or a new snapshot containing the commits
and a WAL that recovery resets. A torn or unauthenticated final record can
be truncated on open. A complete bad record followed by more data is
rejected as corruption; damaged framing can cause tail truncation.
Opening a vault can modify recovery files even without executing write SQL.

The Unix SIGKILL harness checks process-crash recovery of acknowledged
mutations. Physical power-loss behavior also depends on the filesystem,
device, and their sync guarantees. File sync failures are reported, but
parent-directory syncing is best effort, so this is not an unconditional
power-loss guarantee on every platform or storage stack.

After an I/O failure, a durable session can become poisoned and refuses
further operations until reopened. Retain its files. Back up an inactive,
consistent snapshot/WAL pair, or checkpoint and close successfully before
copying the snapshot. Never independently copy actively changing files or
delete a WAL as a recovery shortcut. See the
[backup procedure](docs/GUIDE.md#backups-and-recovery).

## Writer coordination

Durable sessions hold an exclusive OS file lock on `<vault>.lock` through
safe Rust `std::fs::File::try_lock`: Unix uses `flock`, Windows uses
`LockFileEx`. A second cooperating opener of the same lock path returns
`Error::Locked`; dropping the held file or terminating the process releases
the lock. Platforms or filesystems without locking support return an I/O
error and fail the open rather than silently running without a lock.

A surviving lock file is not evidence that a process still holds the lock.
Deleting or replacing a live lock file can undermine coordination; do not
use removal of `.lock` as an unlock procedure. The Unix lock is advisory.
The Windows lock covers the separate lock file, not all database files,
so neither is a defense against an attacker who can directly alter vaults.

Direct `vault::save` calls do not take the durable-session lock on any
platform. Use a stable path and do not bypass coordination via path aliases
or other tools. Applications must serialize access that bypasses the session
API. These locks enforce one cooperating writer, not concurrent transactions.

## Rollback and signed trust state

An adversary with write access can replace the snapshot with an older copy,
truncate or delete its WAL, alter a WAL header to trigger checkpoint recovery,
or tamper with a final record that recovery then discards. Authenticated
encryption does not prove freshness or completeness of a file collection.
Do not rely on the WAL to detect malicious rollback.

`verify_manifest_enforcing` stores the highest accepted counter and target
hash in a trust file. It rejects a lower counter, and rejects a different
target at the same counter. Re-verifying the same target is allowed.
The caller must increase counters, use separate trust files for independent
artifact streams, serialize verification updates, and protect trust state
from deletion or replacement. An attacker who can reset the trust file can
reset this protection. Plain `verify_manifest` checks origin only.

Manifest verification is explicit; opening a vault does not automatically
verify a manifest, and manifest checks do not extend freshness protection
to a changing WAL. Distribution and authentication of verifying keys remain
the caller's responsibility.

## Memory, metadata, and key lifecycle

- **Compromised host:** malware, hostile administrators, or a debugger can
  read plaintext and capture secrets while a vault is open. Swap and core
  dumps are not mitigated by mirim.
- **Secret retention:** protected secret buffers are zeroized on drop, but
  safe Rust cannot guarantee removal of all transient copies. `DurableDb`
  retains an owned secret for checkpoints throughout the session. Clearing
  a CLI or GUI input buffer does not clear that session copy. Decrypted
  rows, query text, and results are ordinary application memory.
- **Metadata:** file names, sizes, times, existence, and access patterns are
  visible. Unpadded WAL records reveal mutation count and approximate
  statement/parameter sizes. Multi-recipient exports do not hide their
  recipient count, and recipient-slot timing privacy is not a goal.
- **Rotation:** rotating the current vault secret replaces ciphertext;
  it does not shred old backups, journals, or residual disk blocks.
- **No forward secrecy at rest:** compromising a vault secret exposes all
  snapshots protected with it. A recipient's long-term decapsulation key
  decrypts earlier sealed exports addressed to that recipient.
- **No secret recovery:** a forgotten passphrase or lost recipient secret
  key cannot be reset or recovered by the maintainer.

## Constant-time posture

Cryptographic constant-time behavior is principally inherited from the
RustCrypto dependencies for AEAD, ML-KEM, ML-DSA, Argon2, and related
primitives. Public format validation and trust-counter comparisons are not
secret-key operations. Recipient-slot selection and interactive passphrase
confirmation can have observable timing differences.

No claim is made that the complete emitted application binary has been
independently established constant-time with dudect or another statistical
side-channel analysis. Test vectors and successful round trips do not
establish that property.

## C FFI boundary

The FFI crate uses `catch_unwind` wrappers and an unwind-enabled release
profile so Rust panics can be reported as `MIRIM_E_PANIC`. Supported NULL
and out-of-range cases have defined behavior described in the
[header](ffi/include/mirim.h). Arbitrary invalid pointers, double-free,
use-after-close, and races over shared handles remain caller errors that
can cause undefined behavior. Serialize handle access and honor the
lifetime of every returned pointer.

The C conformance harness runs documented cases with ASan/UBSan and an
ASan-instrumented Rust library. It exercises the boundary; it does not prove
that every possible misuse is safe.

## Verification coverage

The repository contains pinned cryptographic vectors, property tests, a
model-based SQL differential suite, deterministic malformed-input tests,
SQL sample loading, and a Unix SIGKILL recovery harness. Five libFuzzer
targets cover wire decoding, SQL, manifests, sealed exports, and WAL
open/replay/repair. GUI and FFI are separate crates with separate dependency
lockfiles and must be checked independently of the core.

Use bound `?` parameters for untrusted SQL values. Concatenating input into
SQL can change statement structure; parameter binding does not protect
applications that bypass it.

See the [audit commands](docs/GUIDE.md#development-and-audit) and current CI
configuration for execution details. An audit report should distinguish
what actually ran from what the repository merely supports, including any
unavailable platform, sanitizer, or fuzzing checks. Short fuzz runs, clean
dependency scans, and `forbid(unsafe_code)` are useful evidence, not a
security certification.

## Reporting a vulnerability

Use the security contact at <https://securityops.co>. Include the affected
version, reproduction steps, expected and observed behavior, and whether
real data is at risk. Share a minimal sanitized reproduction; do not include
live passphrases, private keys, or production vault contents.
