# Licenciamento

O engine, CLI, FFI, GUI, testes e demais arquivos próprios do Mirim
identificados pela expressão
`AGPL-3.0-only OR LicenseRef-Mirim-Commercial` estão disponíveis sob a GNU
AGPL versão 3 somente ou por contrato comercial separado, assinado pelo
titular dos direitos aplicável e pelo licenciado.

O texto completo da opção pública está em `LICENSE` e
`LICENSE-AGPL-3.0`. `LICENSE-COMMERCIAL` é um aviso de consulta e escopo, não
uma concessão pública. Sem contrato assinado, a AGPLv3-only rege esses
arquivos. Uso comercial é permitido pela AGPL quando suas condições são
cumpridas.

Arquivos marcados explicitamente como MIT—incluindo configurações selecionadas
de empacotamento, build, toolchain e política—continuam sob MIT. Dependências,
vetores de teste, artefatos gerados e arquivos com aviso separado preservam
suas próprias licenças.

Os contribuidores mantêm seus direitos autorais, salvo acordo separado.
Um DCO ou uma contribuição comum sob a AGPL não autoriza automaticamente
relicenciamento comercial. Não inclua contribuições de terceiros na opção
comercial sem uma concessão explícita adequada. Um acordo privado só pode
abranger direitos que seu licenciante detenha ou controle.

Consultas: `sac@securityops.co`. Este documento descreve a política do
repositório e não constitui aconselhamento jurídico.
