// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! C ABI for mirim (`libmirim_ffi`). The core crate stays
//! `#![forbid(unsafe_code)]`; this crate is the *single, deliberate*
//! unsafe boundary, and every `unsafe` block below carries its
//! justification at the site. The authoritative contract is
//! `include/mirim.h`; this file implements it exactly.
//!
//! Boundary rules implemented here:
//! - every `extern "C"` body runs under `catch_unwind`: a Rust panic
//!   never crosses into C (that would be undefined behaviour); it
//!   converts to `MIRIM_E_PANIC` / NULL instead;
//! - NULL pointers in are reported as `MIRIM_E_MISUSE`, never chased;
//! - pointers out are either static, owned by a handle the caller
//!   frees, or valid until the next call on the same handle — per the
//!   header.

#![deny(unsafe_op_in_unsafe_fn)]
#![warn(missing_docs)]
#![doc(hidden)]

use std::ffi::{c_char, CStr, CString};
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::path::Path;

use mirim::vault::Secret;
use mirim::{DurableDb, Error, Output, Value};

const MIRIM_OK: i32 = 0;
const MIRIM_E_PARSE: i32 = -1;
const MIRIM_E_EXEC: i32 = -2;
const MIRIM_E_CRYPTO: i32 = -3;
const MIRIM_E_CORRUPT: i32 = -4;
const MIRIM_E_KDF: i32 = -5;
const MIRIM_E_ROLLBACK: i32 = -6;
const MIRIM_E_LOCKED: i32 = -7;
const MIRIM_E_IO: i32 = -8;
const MIRIM_E_MISUSE: i32 = -9;
const MIRIM_E_PANIC: i32 = -10;

const T_NULL: i32 = 0;
const T_INT: i32 = 1;
const T_TEXT: i32 = 2;

const R_DONE: i32 = 0;
const R_AFFECTED: i32 = 1;
const R_ROWS: i32 = 2;

fn code_of(e: &Error) -> i32 {
    match e {
        Error::Parse(_) => MIRIM_E_PARSE,
        Error::Exec(_) => MIRIM_E_EXEC,
        Error::Crypto => MIRIM_E_CRYPTO,
        Error::Corrupt(_) => MIRIM_E_CORRUPT,
        Error::KdfMismatch => MIRIM_E_KDF,
        Error::Rollback => MIRIM_E_ROLLBACK,
        Error::Locked => MIRIM_E_LOCKED,
        Error::Io(_) => MIRIM_E_IO,
    }
}

/// Opaque database handle (header: `MirimDb`).
pub struct MirimDb {
    db: DurableDb,
    /// NUL-terminated last error, never containing interior NUL.
    last_error: CString,
}

impl MirimDb {
    fn set_error(&mut self, msg: &str) {
        let clean: String = msg
            .chars()
            .map(|c| if c == '\0' { ' ' } else { c })
            .collect();
        self.last_error = CString::new(clean).expect("interior NULs removed");
    }
}

/// Opaque result handle (header: `MirimResult`).
pub struct MirimResult {
    kind: i32,
    affected: u64,
    columns: Vec<String>,
    rows: Vec<Vec<Value>>,
}

/// Bound parameter; layout must match `MirimValue` in the header.
#[repr(C)]
pub struct MirimValueC {
    tag: i32,
    i: i64,
    s: *const c_char,
    s_len: usize,
}

fn write_errbuf(errbuf: *mut c_char, errbuf_len: usize, msg: &str) {
    if errbuf.is_null() || errbuf_len == 0 {
        return;
    }
    let bytes: Vec<u8> = msg
        .bytes()
        .map(|b| if b == 0 { b' ' } else { b })
        .take(errbuf_len - 1)
        .collect();
    // SAFETY: caller promised `errbuf` points at `errbuf_len` writable
    // bytes (header contract); we write at most errbuf_len-1 bytes of
    // message plus one NUL, never past the end.
    unsafe {
        std::ptr::copy_nonoverlapping(bytes.as_ptr().cast::<c_char>(), errbuf, bytes.len());
        *errbuf.add(bytes.len()) = 0;
    }
}

/// SAFETY contract for callers of this helper: `p` is either NULL or a
/// NUL-terminated string valid for the duration of the call.
unsafe fn cstr<'a>(p: *const c_char) -> Option<&'a str> {
    if p.is_null() {
        return None;
    }
    // SAFETY: non-NULL and NUL-terminated per the function's contract,
    // which mirrors the header contract for every `const char *` in.
    unsafe { CStr::from_ptr(p) }.to_str().ok()
}

fn open_common(
    path: *const c_char,
    secret: Secret<'_>,
    errbuf: *mut c_char,
    errbuf_len: usize,
) -> *mut MirimDb {
    let body = || -> Result<*mut MirimDb, String> {
        // SAFETY: `path` follows the header's NUL-terminated contract.
        let path = unsafe { cstr(path) }.ok_or("path is NULL or not UTF-8")?;
        match DurableDb::open(Path::new(path), &secret) {
            Ok(db) => Ok(Box::into_raw(Box::new(MirimDb {
                db,
                last_error: CString::new("").expect("empty string has no NUL"),
            }))),
            Err(e) => Err(e.to_string()),
        }
    };
    match catch_unwind(AssertUnwindSafe(body)) {
        Ok(Ok(h)) => h,
        Ok(Err(msg)) => {
            write_errbuf(errbuf, errbuf_len, &msg);
            std::ptr::null_mut()
        }
        Err(_) => {
            write_errbuf(errbuf, errbuf_len, "internal panic");
            std::ptr::null_mut()
        }
    }
}

/// Header: `mirim_open`.
///
/// # Safety
/// `path` NUL-terminated or NULL; `key` points at 32 readable bytes;
/// `errbuf` NULL or writable for `errbuf_len` bytes.
#[no_mangle]
pub unsafe extern "C" fn mirim_open(
    path: *const c_char,
    key: *const u8,
    errbuf: *mut c_char,
    errbuf_len: usize,
) -> *mut MirimDb {
    if key.is_null() {
        write_errbuf(errbuf, errbuf_len, "key is NULL");
        return std::ptr::null_mut();
    }
    // SAFETY: header contract — `key` points at exactly 32 readable
    // bytes. Copied immediately into an owned array.
    let key: [u8; 32] = unsafe { std::slice::from_raw_parts(key, 32) }
        .try_into()
        .expect("slice of length 32");
    open_common(path, Secret::RawKey(&key), errbuf, errbuf_len)
}

/// Header: `mirim_open_passphrase`.
///
/// # Safety
/// `path` and `passphrase` NUL-terminated or NULL; `errbuf` as above.
#[no_mangle]
pub unsafe extern "C" fn mirim_open_passphrase(
    path: *const c_char,
    passphrase: *const c_char,
    errbuf: *mut c_char,
    errbuf_len: usize,
) -> *mut MirimDb {
    // SAFETY: header contract for `passphrase`.
    let Some(pass) = (unsafe { cstr(passphrase) }) else {
        write_errbuf(errbuf, errbuf_len, "passphrase is NULL or not UTF-8");
        return std::ptr::null_mut();
    };
    open_common(path, Secret::Passphrase(pass), errbuf, errbuf_len)
}

fn result_of(out: Output) -> MirimResult {
    match out {
        Output::Done => MirimResult {
            kind: R_DONE,
            affected: 0,
            columns: Vec::new(),
            rows: Vec::new(),
        },
        Output::Affected(n) => MirimResult {
            kind: R_AFFECTED,
            affected: n,
            columns: Vec::new(),
            rows: Vec::new(),
        },
        Output::Rows { columns, rows } => MirimResult {
            kind: R_ROWS,
            affected: 0,
            columns,
            rows,
        },
    }
}

fn execute_common(db: *mut MirimDb, sql: *const c_char, params: &[Value]) -> *mut MirimResult {
    if db.is_null() {
        return std::ptr::null_mut();
    }
    // SAFETY: non-NULL handle that the header contract says came from
    // mirim_open* and has not been closed; we are the only accessor on
    // this thread per the one-handle-one-thread rule.
    let h = unsafe { &mut *db };
    let body = || match unsafe { cstr(sql) } {
        // SAFETY (inner cstr): header contract for `sql`.
        None => {
            h.set_error("sql is NULL or not UTF-8");
            std::ptr::null_mut()
        }
        Some(sql) => match h.db.execute_params(sql, params) {
            Ok(out) => Box::into_raw(Box::new(result_of(out))),
            Err(e) => {
                h.set_error(&e.to_string());
                std::ptr::null_mut()
            }
        },
    };
    match catch_unwind(AssertUnwindSafe(body)) {
        Ok(p) => p,
        Err(_) => std::ptr::null_mut(),
    }
}

/// Header: `mirim_execute`.
///
/// # Safety
/// `db` from `mirim_open*`, not closed; `sql` NUL-terminated or NULL.
#[no_mangle]
pub unsafe extern "C" fn mirim_execute(db: *mut MirimDb, sql: *const c_char) -> *mut MirimResult {
    execute_common(db, sql, &[])
}

/// Header: `mirim_execute_params`.
///
/// # Safety
/// As `mirim_execute`; additionally `params` points at `nparams`
/// `MirimValue`s, and each TEXT value's `s` points at `s_len` readable
/// bytes of UTF-8.
#[no_mangle]
pub unsafe extern "C" fn mirim_execute_params(
    db: *mut MirimDb,
    sql: *const c_char,
    params: *const MirimValueC,
    nparams: usize,
) -> *mut MirimResult {
    if db.is_null() {
        return std::ptr::null_mut();
    }
    if params.is_null() && nparams != 0 {
        // SAFETY: non-NULL handle per header contract (see above).
        let h = unsafe { &mut *db };
        h.set_error("params is NULL but nparams is nonzero");
        return std::ptr::null_mut();
    }
    // SAFETY: header contract — `params` points at `nparams` elements.
    let raw = if nparams == 0 {
        &[][..]
    } else {
        unsafe { std::slice::from_raw_parts(params, nparams) }
    };
    let mut vals = Vec::with_capacity(raw.len());
    for (i, p) in raw.iter().enumerate() {
        match p.tag {
            T_NULL => vals.push(Value::Null),
            T_INT => vals.push(Value::Int(p.i)),
            T_TEXT => {
                if p.s.is_null() {
                    // SAFETY: non-NULL handle per header contract.
                    let h = unsafe { &mut *db };
                    h.set_error(&format!("text param {i} has NULL pointer"));
                    return std::ptr::null_mut();
                }
                // SAFETY: header contract — `s` points at `s_len`
                // readable bytes for this parameter.
                let bytes = unsafe { std::slice::from_raw_parts(p.s.cast::<u8>(), p.s_len) };
                match std::str::from_utf8(bytes) {
                    Ok(s) => vals.push(Value::Text(s.to_owned())),
                    Err(_) => {
                        // SAFETY: non-NULL handle per header contract.
                        let h = unsafe { &mut *db };
                        h.set_error(&format!("text param {i} is not UTF-8"));
                        return std::ptr::null_mut();
                    }
                }
            }
            t => {
                // SAFETY: non-NULL handle per header contract.
                let h = unsafe { &mut *db };
                h.set_error(&format!("param {i} has unknown tag {t}"));
                return std::ptr::null_mut();
            }
        }
    }
    execute_common(db, sql, &vals)
}

/// SAFETY contract: `r` is NULL or a live result from `mirim_execute*`.
unsafe fn res<'a>(r: *const MirimResult) -> Option<&'a MirimResult> {
    // SAFETY: per this function's contract, mirroring the header.
    unsafe { r.as_ref() }
}

/// Header: `mirim_result_kind`.
/// # Safety
/// `r` NULL or a live result handle.
#[no_mangle]
pub unsafe extern "C" fn mirim_result_kind(r: *const MirimResult) -> i32 {
    // SAFETY: header contract.
    unsafe { res(r) }.map_or(R_DONE, |r| r.kind)
}

/// Header: `mirim_result_affected`.
/// # Safety
/// `r` NULL or a live result handle.
#[no_mangle]
pub unsafe extern "C" fn mirim_result_affected(r: *const MirimResult) -> u64 {
    // SAFETY: header contract.
    unsafe { res(r) }.map_or(0, |r| r.affected)
}

/// Header: `mirim_result_nrows`.
/// # Safety
/// `r` NULL or a live result handle.
#[no_mangle]
pub unsafe extern "C" fn mirim_result_nrows(r: *const MirimResult) -> usize {
    // SAFETY: header contract.
    unsafe { res(r) }.map_or(0, |r| r.rows.len())
}

/// Header: `mirim_result_ncols`.
/// # Safety
/// `r` NULL or a live result handle.
#[no_mangle]
pub unsafe extern "C" fn mirim_result_ncols(r: *const MirimResult) -> usize {
    // SAFETY: header contract.
    unsafe { res(r) }.map_or(0, |r| r.columns.len())
}

/// Header: `mirim_result_col_name`.
/// # Safety
/// `r` NULL or live; `len` NULL or writable.
#[no_mangle]
pub unsafe extern "C" fn mirim_result_col_name(
    r: *const MirimResult,
    col: usize,
    len: *mut usize,
) -> *const c_char {
    // SAFETY: header contract.
    let name = unsafe { res(r) }.and_then(|r| r.columns.get(col));
    let (p, n) = match name {
        Some(s) => (s.as_ptr().cast::<c_char>(), s.len()),
        None => (std::ptr::null(), 0),
    };
    if !len.is_null() {
        // SAFETY: header contract — `len` is writable when non-NULL.
        unsafe { *len = n };
    }
    p
}

fn cell(r: *const MirimResult, row: usize, col: usize) -> Option<&'static Value> {
    // SAFETY: header contract for `r`; lifetime is tied to the result
    // handle, which the header says outlives any returned pointer use.
    unsafe { res(r) }
        .and_then(|r| r.rows.get(row))
        .and_then(|x| x.get(col))
}

/// Header: `mirim_result_value_tag`.
/// # Safety
/// `r` NULL or a live result handle.
#[no_mangle]
pub unsafe extern "C" fn mirim_result_value_tag(
    r: *const MirimResult,
    row: usize,
    col: usize,
) -> i32 {
    match cell(r, row, col) {
        Some(Value::Int(_)) => T_INT,
        Some(Value::Text(_)) => T_TEXT,
        _ => T_NULL,
    }
}

/// Header: `mirim_result_value_int`.
/// # Safety
/// `r` NULL or a live result handle.
#[no_mangle]
pub unsafe extern "C" fn mirim_result_value_int(
    r: *const MirimResult,
    row: usize,
    col: usize,
) -> i64 {
    match cell(r, row, col) {
        Some(Value::Int(i)) => *i,
        _ => 0,
    }
}

/// Header: `mirim_result_value_text`.
/// # Safety
/// `r` NULL or live; `len` NULL or writable.
#[no_mangle]
pub unsafe extern "C" fn mirim_result_value_text(
    r: *const MirimResult,
    row: usize,
    col: usize,
    len: *mut usize,
) -> *const c_char {
    let (p, n) = match cell(r, row, col) {
        Some(Value::Text(s)) => (s.as_ptr().cast::<c_char>(), s.len()),
        _ => (std::ptr::null(), 0),
    };
    if !len.is_null() {
        // SAFETY: header contract — `len` is writable when non-NULL.
        unsafe { *len = n };
    }
    p
}

/// Header: `mirim_result_free`.
/// # Safety
/// `r` NULL (no-op) or a live result handle, freed exactly once.
#[no_mangle]
pub unsafe extern "C" fn mirim_result_free(r: *mut MirimResult) {
    if r.is_null() {
        return;
    }
    // SAFETY: header contract — `r` came from Box::into_raw in
    // execute_common and is freed exactly once.
    drop(unsafe { Box::from_raw(r) });
}

/// Header: `mirim_checkpoint`.
/// # Safety
/// `db` NULL or a live handle.
#[no_mangle]
pub unsafe extern "C" fn mirim_checkpoint(db: *mut MirimDb) -> i32 {
    if db.is_null() {
        return MIRIM_E_MISUSE;
    }
    // SAFETY: non-NULL live handle per header contract.
    let h = unsafe { &mut *db };
    match catch_unwind(AssertUnwindSafe(|| h.db.checkpoint())) {
        Ok(Ok(())) => MIRIM_OK,
        Ok(Err(e)) => {
            let code = code_of(&e);
            h.set_error(&e.to_string());
            code
        }
        Err(_) => MIRIM_E_PANIC,
    }
}

/// Header: `mirim_wal_records`.
/// # Safety
/// `db` NULL or a live handle.
#[no_mangle]
pub unsafe extern "C" fn mirim_wal_records(db: *const MirimDb) -> u64 {
    // SAFETY: NULL-checked dereference of a live handle per contract.
    unsafe { db.as_ref() }.map_or(0, |h| h.db.wal_records())
}

/// Header: `mirim_last_error`.
/// # Safety
/// `db` NULL or a live handle; pointer valid until the next call.
#[no_mangle]
pub unsafe extern "C" fn mirim_last_error(db: *const MirimDb) -> *const c_char {
    // SAFETY: NULL-checked dereference of a live handle per contract.
    match unsafe { db.as_ref() } {
        Some(h) => h.last_error.as_ptr(),
        None => c"".as_ptr(),
    }
}

/// Header: `mirim_close`.
/// # Safety
/// `db` NULL (no-op) or a live handle, closed exactly once.
#[no_mangle]
pub unsafe extern "C" fn mirim_close(db: *mut MirimDb) {
    if db.is_null() {
        return;
    }
    // SAFETY: header contract — handle came from Box::into_raw in
    // open_common and is closed exactly once.
    drop(unsafe { Box::from_raw(db) });
}

/// Header: `mirim_version`.
#[no_mangle]
pub extern "C" fn mirim_version() -> *const c_char {
    // Static NUL-terminated literal; always valid.
    concat!(env!("CARGO_PKG_VERSION"), "\0").as_ptr().cast()
}
