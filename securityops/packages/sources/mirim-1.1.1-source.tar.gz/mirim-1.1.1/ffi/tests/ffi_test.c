/* Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial
 *
 * FFI conformance harness. Compiled with -fsanitize=address,undefined;
 * exercises every exported function, the documented error paths, and
 * durability across close/reopen. Exit 0 = pass; any assert or
 * sanitizer report = fail.
 */
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "mirim.h"

static const uint8_t KEY[32] = {6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
                                6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6};

static char path[256];
static char wal[300];

int main(void) {
    snprintf(path, sizeof path, "/tmp/mirim-ffi-%d.mrm", (int)getpid());
    snprintf(wal, sizeof wal, "%s.wal", path);
    unlink(path);
    unlink(wal);

    assert(strcmp(mirim_version(), "1.1.1") == 0);

    /* --- misuse paths never crash --- */
    char errbuf[128] = {0};
    assert(mirim_open(NULL, KEY, errbuf, sizeof errbuf) == NULL);
    assert(errbuf[0] != '\0');
    assert(mirim_open(path, NULL, errbuf, sizeof errbuf) == NULL);
    assert(mirim_execute(NULL, "select 1") == NULL);
    assert(mirim_checkpoint(NULL) == MIRIM_E_MISUSE);
    assert(mirim_wal_records(NULL) == 0);
    assert(strcmp(mirim_last_error(NULL), "") == 0);
    mirim_result_free(NULL);
    mirim_close(NULL);

    /* --- open, schema, durable inserts --- */
    MirimDb *db = mirim_open(path, KEY, errbuf, sizeof errbuf);
    assert(db != NULL);

    MirimResult *r =
        mirim_execute(db, "create table t (id integer primary key, s text unique)");
    assert(r != NULL && mirim_result_kind(r) == MIRIM_R_DONE);
    mirim_result_free(r);

    MirimValue p1[2] = {
        {.tag = MIRIM_T_INT, .i = 1},
        {.tag = MIRIM_T_TEXT, .s = "alpha", .s_len = 5},
    };
    r = mirim_execute_params(db, "insert into t values (?, ?)", p1, 2);
    assert(r != NULL && mirim_result_kind(r) == MIRIM_R_AFFECTED);
    assert(mirim_result_affected(r) == 1);
    mirim_result_free(r);

    MirimValue p2[2] = {
        {.tag = MIRIM_T_INT, .i = 2},
        {.tag = MIRIM_T_NULL},
    };
    r = mirim_execute_params(db, "insert into t values (?, ?)", p2, 2);
    assert(r != NULL);
    mirim_result_free(r);

    /* --- typed error: duplicate PRIMARY KEY --- */
    r = mirim_execute_params(db, "insert into t values (?, ?)", p1, 2);
    assert(r == NULL);
    assert(strstr(mirim_last_error(db), "PRIMARY KEY") != NULL);

    /* --- parse error path --- */
    r = mirim_execute(db, "selekt nonsense");
    assert(r == NULL);
    assert(strlen(mirim_last_error(db)) > 0);

    /* --- param contract violations --- */
    assert(mirim_execute_params(db, "select * from t where id = ?", NULL, 1) == NULL);
    MirimValue bad = {.tag = 99};
    assert(mirim_execute_params(db, "select * from t where id = ?", &bad, 1) == NULL);
    MirimValue badtext = {.tag = MIRIM_T_TEXT, .s = NULL, .s_len = 3};
    assert(mirim_execute_params(db, "select * from t where s = ?", &badtext, 1) == NULL);

    /* --- result inspection --- */
    r = mirim_execute(db, "select id, s from t");
    assert(r != NULL && mirim_result_kind(r) == MIRIM_R_ROWS);
    assert(mirim_result_nrows(r) == 2 && mirim_result_ncols(r) == 2);
    size_t len = 0;
    const char *cn = mirim_result_col_name(r, 1, &len);
    assert(cn != NULL && len == 1 && cn[0] == 's');
    assert(mirim_result_value_tag(r, 0, 0) == MIRIM_T_INT);
    assert(mirim_result_value_int(r, 0, 0) == 1);
    assert(mirim_result_value_tag(r, 0, 1) == MIRIM_T_TEXT);
    const char *txt = mirim_result_value_text(r, 0, 1, &len);
    assert(txt != NULL && len == 5 && memcmp(txt, "alpha", 5) == 0);
    assert(mirim_result_value_tag(r, 1, 1) == MIRIM_T_NULL);
    assert(mirim_result_value_text(r, 1, 1, &len) == NULL && len == 0);
    /* out-of-range is defined, not UB */
    assert(mirim_result_value_tag(r, 9, 9) == MIRIM_T_NULL);
    assert(mirim_result_value_int(r, 9, 9) == 0);
    assert(mirim_result_col_name(r, 9, &len) == NULL && len == 0);
    mirim_result_free(r);

    /* --- second opener is locked out --- */
    char err2[128] = {0};
    assert(mirim_open(path, KEY, err2, sizeof err2) == NULL);
    assert(strstr(err2, "locked") != NULL);

    /* --- WAL accounting + checkpoint --- */
    assert(mirim_wal_records(db) > 0);
    assert(mirim_checkpoint(db) == MIRIM_OK);
    assert(mirim_wal_records(db) == 0);

    /* --- durability across close/reopen, no checkpoint after insert --- */
    MirimValue p3[2] = {
        {.tag = MIRIM_T_INT, .i = 3},
        {.tag = MIRIM_T_TEXT, .s = "gamma", .s_len = 5},
    };
    r = mirim_execute_params(db, "insert into t values (?, ?)", p3, 2);
    assert(r != NULL);
    mirim_result_free(r);
    mirim_close(db);

    db = mirim_open(path, KEY, errbuf, sizeof errbuf);
    assert(db != NULL);
    r = mirim_execute(db, "select id from t");
    assert(r != NULL && mirim_result_nrows(r) == 3);
    mirim_result_free(r);

    /* --- wrong key fails with a message, not a crash --- */
    mirim_close(db);
    uint8_t wrong[32] = {0};
    char err3[128] = {0};
    assert(mirim_open(path, wrong, err3, sizeof err3) == NULL);
    assert(strstr(err3, "authentication failed") != NULL);

    /* tiny errbuf is truncated safely */
    char err4[4] = {0};
    assert(mirim_open(path, wrong, err4, sizeof err4) == NULL);
    assert(err4[3] == '\0' && strlen(err4) <= 3);

    unlink(path);
    unlink(wal);
    char lock[300];
    snprintf(lock, sizeof lock, "%s.lock", path);
    unlink(lock);
    puts("ffi_test: all assertions passed");
    return 0;
}
