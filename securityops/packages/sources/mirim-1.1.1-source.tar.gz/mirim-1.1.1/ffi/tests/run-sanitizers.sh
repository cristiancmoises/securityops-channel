#!/usr/bin/env bash
# Copyright (c) 2026 Cristian Cezar Moisés — MIT
#
# Build the mirim FFI staticlib with AddressSanitizer (the Rust side
# instrumented too, via -Zbuild-std -Zsanitizer=address), compile the C
# conformance harness with -fsanitize=address,undefined, link them, and run.
# Exit 0 = clean; any assert failure or sanitizer report fails the run.
#
# Requirements: a nightly toolchain with rust-src, and clang. Used by CI
# (.forgejo/workflows/ci.yaml : ffi-sanitizers) and runnable locally:
#   ffi/tests/run-sanitizers.sh
set -euo pipefail
cd "$(dirname "$0")/.."   # -> ffi/

triple="$(rustc -vV | sed -n 's/^host: //p')"
cc="${CC:-clang}"

echo ">> building mirim_ffi staticlib with ASan (nightly, build-std)"
RUSTFLAGS="-Zsanitizer=address" \
  cargo +nightly build -Zbuild-std --target "$triple" --release

lib="target/${triple}/release/libmirim_ffi.a"
[ -f "$lib" ] || { echo "missing staticlib: $lib" >&2; exit 1; }

echo ">> compiling + linking the C harness with ASan+UBSan ($cc)"
bin="$(mktemp -d)/ffi_test"
"$cc" -std=c11 -Wall -Wextra -g -O1 \
  -fsanitize=address,undefined -fno-omit-frame-pointer \
  -I include tests/ffi_test.c "$lib" \
  -o "$bin" -lpthread -ldl -lm

echo ">> running"
ASAN_OPTIONS="detect_leaks=1:abort_on_error=1" \
UBSAN_OPTIONS="print_stacktrace=1:halt_on_error=1" \
  "$bin"

echo "FFI ASan+UBSan conformance harness: PASS"
