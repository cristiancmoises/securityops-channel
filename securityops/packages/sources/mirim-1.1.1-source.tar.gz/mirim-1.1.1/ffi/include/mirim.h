/* Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial
 *
 * mirim C API, v1 (mirim-ffi 0.6.x).
 *
 * Contract:
 *  - One handle, one thread. Handles are not thread-safe; do not share
 *    a MirimDb or MirimResult across threads without external locking.
 *  - Every function tolerates NULL handles/pointers and reports
 *    MIRIM_E_MISUSE instead of crashing, except the *_free/close pair,
 *    where NULL is a no-op and double-free is undefined behaviour.
 *  - Strings going in are NUL-terminated UTF-8. Strings coming out of
 *    results are length-delimited (NOT NUL-terminated) and remain valid
 *    until mirim_result_free; the last-error string is NUL-terminated
 *    and remains valid until the next call on the same handle.
 *  - Statements acknowledged with MIRIM_OK through mirim_execute* are
 *    durable (fsynced) before the call returns, as in the Rust API.
 */
#ifndef MIRIM_H
#define MIRIM_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct MirimDb MirimDb;
typedef struct MirimResult MirimResult;

/* Status codes (negative = error). */
#define MIRIM_OK          0
#define MIRIM_E_PARSE    -1
#define MIRIM_E_EXEC     -2
#define MIRIM_E_CRYPTO   -3
#define MIRIM_E_CORRUPT  -4
#define MIRIM_E_KDF      -5
#define MIRIM_E_ROLLBACK -6
#define MIRIM_E_LOCKED   -7
#define MIRIM_E_IO       -8
#define MIRIM_E_MISUSE   -9
#define MIRIM_E_PANIC   -10

/* Value tags. */
#define MIRIM_T_NULL 0
#define MIRIM_T_INT  1
#define MIRIM_T_TEXT 2

/* Result kinds. */
#define MIRIM_R_DONE     0
#define MIRIM_R_AFFECTED 1
#define MIRIM_R_ROWS     2

/* Bound parameter. tag selects which field is read. `s` need not be
 * NUL-terminated; s_len bytes are read and must be valid UTF-8. */
typedef struct MirimValue {
    int32_t     tag;
    int64_t     i;
    const char *s;
    size_t      s_len;
} MirimValue;

/* Open (creating if absent) with a raw 32-byte key. On failure returns
 * NULL and, if errbuf is non-NULL, writes a NUL-terminated message of
 * at most errbuf_len bytes. */
MirimDb *mirim_open(const char *path, const uint8_t key[32],
                    char *errbuf, size_t errbuf_len);

/* Same, with a passphrase (Argon2id, interactive-grade cost). */
MirimDb *mirim_open_passphrase(const char *path, const char *passphrase,
                               char *errbuf, size_t errbuf_len);

/* Execute one statement. Returns a result handle, or NULL on error
 * (consult mirim_last_error). */
MirimResult *mirim_execute(MirimDb *db, const char *sql);
MirimResult *mirim_execute_params(MirimDb *db, const char *sql,
                                  const MirimValue *params, size_t nparams);

/* Result inspection. Out-of-range row/col indices report MIRIM_T_NULL /
 * NULL / 0; check mirim_result_nrows/ncols first. */
int32_t     mirim_result_kind(const MirimResult *r);
uint64_t    mirim_result_affected(const MirimResult *r);
size_t      mirim_result_nrows(const MirimResult *r);
size_t      mirim_result_ncols(const MirimResult *r);
const char *mirim_result_col_name(const MirimResult *r, size_t col, size_t *len);
int32_t     mirim_result_value_tag(const MirimResult *r, size_t row, size_t col);
int64_t     mirim_result_value_int(const MirimResult *r, size_t row, size_t col);
const char *mirim_result_value_text(const MirimResult *r, size_t row, size_t col,
                                    size_t *len);
void        mirim_result_free(MirimResult *r);

/* Fold the WAL into a fresh snapshot. */
int32_t  mirim_checkpoint(MirimDb *db);
/* Records in the WAL since the last checkpoint. 0 on NULL handle. */
uint64_t mirim_wal_records(const MirimDb *db);

/* NUL-terminated message for the most recent error on this handle. */
const char *mirim_last_error(const MirimDb *db);

/* Checkpoint is NOT implied; call mirim_checkpoint first if you want
 * the log folded. Frees the handle; using it afterwards is UB. */
void mirim_close(MirimDb *db);

/* Static version string, e.g. "0.6.0". */
const char *mirim_version(void);

#ifdef __cplusplus
}
#endif
#endif /* MIRIM_H */
