// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! Core benchmarks, with SQLite as the reference where the operations
//! are commensurable. Sample sizes are kept small on purpose — these
//! are engineering numbers for the README claims table, not a paper.
//! Methodology notes live next to each group.

use criterion::{criterion_group, criterion_main, Criterion};
use mirim::vault::Secret;
use mirim::{Db, DurableDb, Value};

const KEY: [u8; 32] = [6u8; 32];

fn fresh_mirim(rows: i64) -> Db {
    let mut db = Db::new();
    db.execute("create table t (id integer primary key, s text)")
        .unwrap();
    for i in 0..rows {
        db.execute_params(
            "insert into t values (?, ?)",
            &[Value::Int(i), Value::Text(format!("row-{i}"))],
        )
        .unwrap();
    }
    db
}

fn fresh_sqlite(rows: i64) -> rusqlite::Connection {
    let c = rusqlite::Connection::open_in_memory().unwrap();
    c.execute("create table t (id integer primary key, s text)", [])
        .unwrap();
    for i in 0..rows {
        c.execute(
            "insert into t values (?1, ?2)",
            rusqlite::params![i, format!("row-{i}")],
        )
        .unwrap();
    }
    c
}

/// Build an N-row table from empty, with a PRIMARY KEY present, for both
/// engines. This is the honest measure of constrained-insert cost: each
/// insert does a duplicate check, so before the index the build was
/// O(N^2) (every insert scanned all prior rows) and with the index it is
/// O(N) (an O(1) probe per insert). SQLite uses its rowid B-tree. Run at
/// two sizes so the asymptotics are visible. (A single insert into an
/// already-full table is dominated by an amortized-away Vec realloc, not
/// the constraint check, so it is not a useful figure here.)
fn bench_insert(c: &mut Criterion) {
    let mut g = c.benchmark_group("bulk_insert_with_pk");
    for &n in &[1_000i64, 10_000] {
        g.bench_function(format!("mirim_{n}_rows"), |b| {
            b.iter(|| fresh_mirim(n));
        });
        g.bench_function(format!("sqlite_{n}_rows"), |b| {
            b.iter(|| fresh_sqlite(n));
        });
    }
    g.finish();
}

/// Point SELECT by primary key over 10k rows. Both engines now use an
/// index — mirim its PRIMARY KEY hash index, SQLite the rowid B-tree.
fn bench_point_select(c: &mut Criterion) {
    let mut g = c.benchmark_group("point_select_10k");
    let mut m = fresh_mirim(10_000);
    g.bench_function("mirim_indexed", |b| {
        b.iter(|| {
            m.execute_params("select s from t where id = ?", &[Value::Int(7_777)])
                .unwrap()
        });
    });
    let s = fresh_sqlite(10_000);
    let mut stmt = s.prepare("select s from t where id = ?1").unwrap();
    g.bench_function("sqlite_btree", |b| {
        b.iter(|| {
            stmt.query_row(rusqlite::params![7_777i64], |r| r.get::<_, String>(0))
                .unwrap()
        });
    });
    g.finish();
}

/// One durable commit: statement acknowledged only after fsync.
/// mirim: WAL append (XChaCha20-Poly1305 record) + fdatasync.
/// SQLite: WAL journal mode, synchronous=FULL, single-statement commit.
/// Both pay one fsync; the delta is mirim's per-record crypto.
fn bench_durable_commit(c: &mut Criterion) {
    let mut g = c.benchmark_group("durable_commit");
    g.sample_size(20);

    let dir = std::env::temp_dir().join(format!("mirim-bench-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();

    let mp = dir.join("bench.mrm");
    let mut md = DurableDb::open(&mp, &Secret::RawKey(&KEY)).unwrap();
    md.execute("create table t (id integer, s text)").unwrap();
    let mut i = 0i64;
    g.bench_function("mirim_wal_fsync", |b| {
        b.iter(|| {
            md.execute_params("insert into t values (?, 'payload')", &[Value::Int(i)])
                .unwrap();
            i += 1;
        });
    });

    let sp = dir.join("bench.sqlite");
    let sc = rusqlite::Connection::open(&sp).unwrap();
    sc.pragma_update(None, "journal_mode", "WAL").unwrap();
    sc.pragma_update(None, "synchronous", "FULL").unwrap();
    sc.execute("create table t (id integer, s text)", [])
        .unwrap();
    let mut j = 0i64;
    g.bench_function("sqlite_wal_full", |b| {
        b.iter(|| {
            sc.execute("insert into t values (?1, 'payload')", rusqlite::params![j])
                .unwrap();
            j += 1;
        });
    });
    g.finish();
    let _ = std::fs::remove_dir_all(&dir);
}

/// Checkpoint of a 1k-row database: snapshot encrypt + atomic replace +
/// fresh WAL. No SQLite mirror — wal_checkpoint(TRUNCATE) does different
/// work (page copy-back, no re-encryption); the operations are not
/// commensurable, so no number is claimed against it.
fn bench_checkpoint(c: &mut Criterion) {
    let mut g = c.benchmark_group("checkpoint_1k_rows");
    g.sample_size(20);
    let dir = std::env::temp_dir().join(format!("mirim-benchck-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let p = dir.join("ck.mrm");
    let mut d = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
    d.execute("create table t (id integer primary key, s text)")
        .unwrap();
    for i in 0..1_000 {
        d.execute_params(
            "insert into t values (?, ?)",
            &[Value::Int(i), Value::Text(format!("row-{i}"))],
        )
        .unwrap();
    }
    let mut k = 1_000i64;
    g.bench_function("mirim", |b| {
        b.iter(|| {
            // One logged statement so the checkpoint is never a no-op.
            d.execute_params(
                "update t set s = 'x' where id = ?",
                &[Value::Int(k % 1_000)],
            )
            .unwrap();
            k += 1;
            d.checkpoint().unwrap();
        });
    });
    g.finish();
    let _ = std::fs::remove_dir_all(&dir);
}

criterion_group! {
    name = benches;
    config = Criterion::default().sample_size(30).measurement_time(std::time::Duration::from_secs(3)).warm_up_time(std::time::Duration::from_secs(1));
    targets = bench_insert, bench_point_select, bench_durable_commit, bench_checkpoint
}
criterion_main!(benches);
