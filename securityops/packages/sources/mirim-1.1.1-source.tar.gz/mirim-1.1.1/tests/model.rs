// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! Model-based differential testing of the SQL evaluator.
//!
//! An independent reference model (`Model`) reimplements the table
//! semantics from scratch — insertion-ordered rows, the exact `cmp`
//! rules (NULL or type mismatch never match; `Ne` is `ord != Equal`, so
//! it too fails on NULL; integers numeric, text by UTF-8 order), and
//! `retain`-style deletes. A generated sequence of statements is applied
//! to both the model and the real engine; after every statement their
//! observable behavior must agree: the affected count for mutations, and
//! the full ordered result set for queries (plus a whole-table query
//! after each mutation).
//!
//! Unlike `properties.rs` (round-trips and invariants) this checks query
//! *correctness* against a second specification: a WHERE-clause or
//! projection bug that both the engine and a self-consistent property
//! would miss shows up here as a divergence, with shrinking to a minimal
//! failing program.
//!
//! Scope held exact on purpose: predicates are type-correct (integer
//! columns vs integer literals, text columns vs text literals), and
//! UPDATE targets only the non-constrained columns, so the model never
//! has to guess at the engine's type-mismatch error path or PK-update
//! validation (both covered elsewhere). Everything the model *does*
//! cover, it covers exactly.

use proptest::prelude::*;

use mirim::{Db, Output, Value};

const SCHEMA: &str = "create table t (id integer primary key, a integer, b text)";

#[derive(Debug, Clone, PartialEq)]
struct Row {
    id: i64,
    a: Option<i64>,
    b: Option<String>,
}

#[derive(Debug, Clone, Copy)]
enum Col {
    Id,
    A,
    B,
}

impl Col {
    fn name(self) -> &'static str {
        match self {
            Col::Id => "id",
            Col::A => "a",
            Col::B => "b",
        }
    }
}

#[derive(Debug, Clone, Copy)]
enum CmpOp {
    Eq,
    Ne,
    Lt,
    Le,
    Gt,
    Ge,
}

impl CmpOp {
    fn sql(self) -> &'static str {
        match self {
            CmpOp::Eq => "=",
            CmpOp::Ne => "!=",
            CmpOp::Lt => "<",
            CmpOp::Le => "<=",
            CmpOp::Gt => ">",
            CmpOp::Ge => ">=",
        }
    }
}

/// A single predicate. Operands are type-correct by construction.
#[derive(Debug, Clone)]
enum Pred {
    CmpInt(Col, CmpOp, i64),
    CmpText(Col, CmpOp, String),
    IsNull(Col, bool), // bool = negated (IS NOT NULL)
}

#[derive(Debug, Clone)]
enum Stmt {
    Insert {
        id: i64,
        a: Option<i64>,
        b: Option<String>,
    },
    Delete(Vec<Pred>),
    UpdateA(Option<i64>, Vec<Pred>),
    UpdateB(Option<String>, Vec<Pred>),
    Select(Proj, Vec<Pred>),
}

#[derive(Debug, Clone)]
enum Proj {
    Star,
    Cols(Vec<Col>),
}

// ---- reference model ----

struct Model {
    rows: Vec<Row>,
}

impl Model {
    fn new() -> Self {
        Model { rows: Vec::new() }
    }

    fn cell<'r>(row: &'r Row, c: Col) -> CellRef<'r> {
        match c {
            Col::Id => CellRef::Int(Some(row.id)),
            Col::A => CellRef::Int(row.a),
            Col::B => CellRef::Text(row.b.as_deref()),
        }
    }

    /// Mirror of engine `cmp` + `row_matches`: every predicate must hold.
    fn matches(row: &Row, preds: &[Pred]) -> bool {
        preds.iter().all(|p| match p {
            Pred::CmpInt(c, op, lit) => match Self::cell(row, *c) {
                CellRef::Int(Some(v)) => apply_ord(v.cmp(lit), *op),
                // NULL, or a text column compared to an int literal: the
                // engine's cmp returns false on both (NULL arm and the
                // type-mismatch `_ => false` arm).
                _ => false,
            },
            Pred::CmpText(c, op, lit) => match Self::cell(row, *c) {
                CellRef::Text(Some(v)) => apply_ord(v.cmp(lit.as_str()), *op),
                _ => false,
            },
            Pred::IsNull(c, negated) => {
                let is_null = matches!(
                    Self::cell(row, *c),
                    CellRef::Int(None) | CellRef::Text(None)
                );
                is_null != *negated
            }
        })
    }

    fn insert(&mut self, id: i64, a: Option<i64>, b: Option<String>) -> ExecResult {
        if self.rows.iter().any(|r| r.id == id) {
            return ExecResult::Err; // PRIMARY KEY collision
        }
        self.rows.push(Row { id, a, b });
        ExecResult::Affected(1)
    }

    fn delete(&mut self, preds: &[Pred]) -> ExecResult {
        let before = self.rows.len();
        self.rows.retain(|r| !Self::matches(r, preds));
        ExecResult::Affected((before - self.rows.len()) as u64)
    }

    fn update_a(&mut self, v: Option<i64>, preds: &[Pred]) -> ExecResult {
        let mut n = 0u64;
        for r in &mut self.rows {
            if Self::matches(r, preds) {
                r.a = v;
                n += 1;
            }
        }
        ExecResult::Affected(n)
    }

    fn update_b(&mut self, v: Option<String>, preds: &[Pred]) -> ExecResult {
        let mut n = 0u64;
        for r in &mut self.rows {
            if Self::matches(r, preds) {
                r.b = v.clone();
                n += 1;
            }
        }
        ExecResult::Affected(n)
    }

    fn select(&self, proj: &Proj, preds: &[Pred]) -> Vec<Vec<Value>> {
        let cols: Vec<Col> = match proj {
            Proj::Star => vec![Col::Id, Col::A, Col::B],
            Proj::Cols(cs) => cs.clone(),
        };
        self.rows
            .iter()
            .filter(|r| Self::matches(r, preds))
            .map(|r| cols.iter().map(|c| cell_value(r, *c)).collect())
            .collect()
    }
}

enum CellRef<'r> {
    Int(Option<i64>),
    Text(Option<&'r str>),
}

fn cell_value(row: &Row, c: Col) -> Value {
    match c {
        Col::Id => Value::Int(row.id),
        Col::A => row.a.map(Value::Int).unwrap_or(Value::Null),
        Col::B => row.b.clone().map(Value::Text).unwrap_or(Value::Null),
    }
}

fn apply_ord(ord: std::cmp::Ordering, op: CmpOp) -> bool {
    use std::cmp::Ordering::*;
    match op {
        CmpOp::Eq => ord == Equal,
        CmpOp::Ne => ord != Equal,
        CmpOp::Lt => ord == Less,
        CmpOp::Le => ord != Greater,
        CmpOp::Gt => ord == Greater,
        CmpOp::Ge => ord != Less,
    }
}

#[derive(Debug, PartialEq)]
enum ExecResult {
    Affected(u64),
    Err,
}

// ---- SQL rendering (engine side); text via binding, not interpolation ----

/// Render a predicate list to `WHERE ...` plus the ordered bound params.
fn render_where(preds: &[Pred]) -> (String, Vec<Value>) {
    if preds.is_empty() {
        return (String::new(), Vec::new());
    }
    let mut parts = Vec::new();
    let mut params = Vec::new();
    for p in preds {
        match p {
            Pred::CmpInt(c, op, lit) => {
                parts.push(format!("{} {} ?", c.name(), op.sql()));
                params.push(Value::Int(*lit));
            }
            Pred::CmpText(c, op, lit) => {
                parts.push(format!("{} {} ?", c.name(), op.sql()));
                params.push(Value::Text(lit.clone()));
            }
            Pred::IsNull(c, negated) => {
                parts.push(format!(
                    "{} is {}null",
                    c.name(),
                    if *negated { "not " } else { "" }
                ));
            }
        }
    }
    (format!(" where {}", parts.join(" and ")), params)
}

fn run_engine(db: &mut Db, stmt: &Stmt) -> EngineObs {
    match stmt {
        Stmt::Insert { id, a, b } => {
            let params = vec![
                Value::Int(*id),
                a.map(Value::Int).unwrap_or(Value::Null),
                b.clone().map(Value::Text).unwrap_or(Value::Null),
            ];
            EngineObs::from_mut(db.execute_params("insert into t values (?, ?, ?)", &params))
        }
        Stmt::Delete(preds) => {
            let (w, params) = render_where(preds);
            EngineObs::from_mut(db.execute_params(&format!("delete from t{w}"), &params))
        }
        Stmt::UpdateA(v, preds) => {
            let (w, mut params) = render_where(preds);
            let mut p = vec![v.map(Value::Int).unwrap_or(Value::Null)];
            p.append(&mut params);
            EngineObs::from_mut(db.execute_params(&format!("update t set a = ?{w}"), &p))
        }
        Stmt::UpdateB(v, preds) => {
            let (w, mut params) = render_where(preds);
            let mut p = vec![v.clone().map(Value::Text).unwrap_or(Value::Null)];
            p.append(&mut params);
            EngineObs::from_mut(db.execute_params(&format!("update t set b = ?{w}"), &p))
        }
        Stmt::Select(proj, preds) => {
            let cols = match proj {
                Proj::Star => "*".to_string(),
                Proj::Cols(cs) => cs.iter().map(|c| c.name()).collect::<Vec<_>>().join(", "),
            };
            let (w, params) = render_where(preds);
            match db.execute_params(&format!("select {cols} from t{w}"), &params) {
                Ok(Output::Rows { rows, .. }) => EngineObs::Rows(rows),
                other => EngineObs::SelectNonRows(format!("{other:?}")),
            }
        }
    }
}

#[derive(Debug)]
enum EngineObs {
    Affected(u64),
    Err,
    Rows(Vec<Vec<Value>>),
    SelectNonRows(String),
}

impl EngineObs {
    fn from_mut(r: mirim::Result<Output>) -> Self {
        match r {
            Ok(Output::Affected(n)) => EngineObs::Affected(n),
            Ok(Output::Done) => EngineObs::Affected(0),
            Err(_) => EngineObs::Err,
            Ok(Output::Rows { rows, .. }) => EngineObs::Rows(rows),
        }
    }
}

// ---- strategies ----

fn opt_int() -> impl Strategy<Value = Option<i64>> {
    prop::option::of(0i64..8)
}

fn opt_text() -> impl Strategy<Value = Option<String>> {
    prop::option::of(prop_oneof![Just("x"), Just("y"), Just("zz"), Just("")].prop_map(String::from))
}

fn col() -> impl Strategy<Value = Col> {
    prop_oneof![Just(Col::Id), Just(Col::A), Just(Col::B)]
}

fn int_col() -> impl Strategy<Value = Col> {
    prop_oneof![Just(Col::Id), Just(Col::A)]
}

fn cmp_op() -> impl Strategy<Value = CmpOp> {
    prop_oneof![
        Just(CmpOp::Eq),
        Just(CmpOp::Ne),
        Just(CmpOp::Lt),
        Just(CmpOp::Le),
        Just(CmpOp::Gt),
        Just(CmpOp::Ge),
    ]
}

fn pred() -> impl Strategy<Value = Pred> {
    prop_oneof![
        (int_col(), cmp_op(), 0i64..8).prop_map(|(c, op, v)| Pred::CmpInt(c, op, v)),
        // Text comparisons restricted to =/!= to avoid relying on the
        // engine's text-ordering collation; equality is unambiguous.
        (
            prop_oneof![Just(CmpOp::Eq), Just(CmpOp::Ne)],
            prop_oneof![Just("x"), Just("y"), Just("zz"), Just("")]
        )
            .prop_map(|(op, s)| Pred::CmpText(Col::B, op, s.to_string())),
        (col(), any::<bool>()).prop_map(|(c, n)| Pred::IsNull(c, n)),
    ]
}

fn preds() -> impl Strategy<Value = Vec<Pred>> {
    prop::collection::vec(pred(), 0..3)
}

fn proj() -> impl Strategy<Value = Proj> {
    prop_oneof![
        Just(Proj::Star),
        prop::collection::vec(col(), 1..4).prop_map(Proj::Cols),
    ]
}

fn stmt() -> impl Strategy<Value = Stmt> {
    prop_oneof![
        3 => (0i64..10, opt_int(), opt_text()).prop_map(|(id, a, b)| Stmt::Insert { id, a, b }),
        1 => preds().prop_map(Stmt::Delete),
        1 => (opt_int(), preds()).prop_map(|(v, p)| Stmt::UpdateA(v, p)),
        1 => (opt_text(), preds()).prop_map(|(v, p)| Stmt::UpdateB(v, p)),
        3 => (proj(), preds()).prop_map(|(pj, p)| Stmt::Select(pj, p)),
    ]
}

fn program() -> impl Strategy<Value = Vec<Stmt>> {
    prop::collection::vec(stmt(), 1..40)
}

proptest! {
    #![proptest_config(ProptestConfig { cases: 300, ..ProptestConfig::default() })]

    /// Engine and reference model agree, statement by statement, on every
    /// observable: mutation counts, query result sets (ordered), and the
    /// whole-table contents after each mutation.
    #[test]
    fn engine_matches_reference_model(prog in program()) {
        let mut db = Db::new();
        db.execute(SCHEMA).expect("schema");
        let mut model = Model::new();

        for (step, st) in prog.iter().enumerate() {
            let obs = run_engine(&mut db, st);
            match st {
                Stmt::Select(proj, preds) => {
                    let expected = model.select(proj, preds);
                    match obs {
                        EngineObs::Rows(got) => prop_assert_eq!(
                            got, expected,
                            "step {}: SELECT result mismatch for {:?}", step, st
                        ),
                        EngineObs::SelectNonRows(s) => prop_assert!(
                            false, "step {}: SELECT returned non-rows ({}) for {:?}", step, s, st
                        ),
                        other => prop_assert!(
                            false, "step {}: expected rows, got {:?} for {:?}", step, other, st
                        ),
                    }
                }
                _ => {
                    let expected = match st {
                        Stmt::Insert { id, a, b } => model.insert(*id, *a, b.clone()),
                        Stmt::Delete(p) => model.delete(p),
                        Stmt::UpdateA(v, p) => model.update_a(*v, p),
                        Stmt::UpdateB(v, p) => model.update_b(v.clone(), p),
                        Stmt::Select(..) => unreachable!(),
                    };
                    match (&obs, &expected) {
                        (EngineObs::Affected(n), ExecResult::Affected(m)) => prop_assert_eq!(
                            n, m, "step {}: affected-count mismatch for {:?}", step, st
                        ),
                        (EngineObs::Err, ExecResult::Err) => {}
                        _ => prop_assert!(
                            false, "step {}: outcome mismatch: engine {:?} vs model {:?} for {:?}",
                            step, obs, expected, st
                        ),
                    }
                    // Whole-table cross-check after every mutation.
                    let table = match db.execute("select id, a, b from t") {
                        Ok(Output::Rows { rows, .. }) => rows,
                        other => { prop_assert!(false, "table read failed: {:?}", other); unreachable!() }
                    };
                    let model_table = model.select(&Proj::Star, &[]);
                    prop_assert_eq!(table, model_table, "step {}: table diverged after {:?}", step, st);
                }
            }
        }
    }
}
