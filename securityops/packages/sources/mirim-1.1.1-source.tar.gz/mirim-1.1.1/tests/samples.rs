// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! Every sample database under `samples/` must be valid mirim SQL and load
//! cleanly through the engine. This is what keeps the shipped samples (and
//! the documentation that quotes them) honest: a dialect mistake in a
//! sample fails the build instead of a user's first session.

use std::fs;

use mirim::{Db, Output, Value};

/// Load a sample file by name from the crate's `samples/` directory.
fn load(name: &str) -> Db {
    let path = format!("{}/samples/{name}", env!("CARGO_MANIFEST_DIR"));
    let sql = fs::read_to_string(&path).unwrap_or_else(|e| panic!("read {path}: {e}"));
    let mut db = Db::new();
    let n = db
        .execute_script(&sql)
        .unwrap_or_else(|e| panic!("load {name}: {e}"));
    assert!(n > 0, "{name} ran zero statements");
    db
}

/// Convenience: the single scalar returned by a `COUNT(*)` query.
fn count(db: &mut Db, sql: &str) -> i64 {
    match db.execute(sql) {
        Ok(Output::Rows { rows, .. }) => match rows.as_slice() {
            [row] => match row.as_slice() {
                [Value::Int(n)] => *n,
                other => panic!("expected one integer, got {other:?}"),
            },
            other => panic!("expected one row, got {other:?}"),
        },
        other => panic!("expected rows, got {other:?}"),
    }
}

#[test]
fn every_sample_file_loads() {
    // Each shipped sample, loaded end to end. Add new samples here.
    for name in [
        "secrets_vault.sql",
        "ctf_scoreboard.sql",
        "device_fleet.sql",
        "audit_trail.sql",
        "password_manager.sql",
    ] {
        let db = load(name);
        assert!(!db.table_names().is_empty(), "{name} created no tables");
    }
}

#[test]
fn secrets_vault_shape_and_queries() {
    let mut db = load("secrets_vault.sql");
    assert_eq!(db.table_names(), vec!["access_log", "secrets", "services"]);
    // Two secrets have never been rotated (rotated_at IS NULL): pg_replica
    // and smtp_api_key and smtp_dkim_cert -> three.
    assert_eq!(
        count(
            &mut db,
            "SELECT COUNT(*) FROM secrets WHERE rotated_at IS NULL"
        ),
        3
    );
    // Denied access attempts.
    assert_eq!(
        count(&mut db, "SELECT COUNT(*) FROM access_log WHERE allowed = 0"),
        4
    );
    // ORDER BY + LIMIT returns the most recent denied actors deterministically.
    match db
        .execute("SELECT actor FROM access_log WHERE allowed = 0 ORDER BY ts DESC LIMIT 1")
        .unwrap()
    {
        Output::Rows { rows, .. } => {
            assert_eq!(rows, vec![vec![Value::Text("unknown-host".into())]]);
        }
        other => panic!("{other:?}"),
    }
}

#[test]
fn ctf_scoreboard_unsolved_challenges() {
    let mut db = load("ctf_scoreboard.sql");
    // Two challenges are still unsolved (solved_first_by IS NULL).
    assert_eq!(
        count(
            &mut db,
            "SELECT COUNT(*) FROM challenges WHERE solved_first_by IS NULL"
        ),
        2
    );
    // The UNIQUE constraint on team names is real: re-inserting fails.
    assert!(db
        .execute("INSERT INTO teams VALUES (99, 'null_deref', 'US', 0)")
        .is_err());
}

#[test]
fn device_fleet_unhealthy_and_retired() {
    let mut db = load("device_fleet.sql");
    // Check-ins reporting a fault.
    assert_eq!(
        count(&mut db, "SELECT COUNT(*) FROM checkins WHERE healthy = 0"),
        4
    );
    // Exactly one device is decommissioned.
    assert_eq!(
        count(
            &mut db,
            "SELECT COUNT(*) FROM devices WHERE decommissioned_at IS NOT NULL"
        ),
        1
    );
}

#[test]
fn audit_trail_denied_events() {
    let mut db = load("audit_trail.sql");
    // Denied events, and a default-deny (policy IS NULL) among them.
    assert_eq!(
        count(&mut db, "SELECT COUNT(*) FROM events WHERE allowed = 0"),
        4
    );
    assert_eq!(
        count(&mut db, "SELECT COUNT(*) FROM events WHERE policy IS NULL"),
        2
    );
}

#[test]
fn password_manager_hygiene_queries() {
    let mut db = load("password_manager.sql");
    // Reused passwords are flagged.
    assert_eq!(
        count(&mut db, "SELECT COUNT(*) FROM entries WHERE reused = 1"),
        3
    );
    // Weak passwords (strength < 3), ordered ascending, weakest first.
    match db
        .execute("SELECT title FROM entries WHERE strength < 3 ORDER BY strength, title LIMIT 1")
        .unwrap()
    {
        Output::Rows { rows, .. } => {
            assert_eq!(rows, vec![vec![Value::Text("Legacy CRM".into())]]);
        }
        other => panic!("{other:?}"),
    }
}
