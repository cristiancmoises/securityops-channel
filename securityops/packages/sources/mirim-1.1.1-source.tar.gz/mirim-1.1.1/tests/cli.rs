// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial
#![cfg(feature = "cli")]

use std::fs;
use std::process::{Command, Stdio};

#[test]
fn informational_flags_and_invalid_arguments_do_not_touch_a_vault() {
    let dir = std::env::temp_dir().join(format!(
        "mirim-cli-flags-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ));
    fs::create_dir(&dir).unwrap();
    for flag in ["--version", "-V", "--help", "-h", "--unknown", "--"] {
        let output = Command::new(env!("CARGO_BIN_EXE_mirim"))
            .arg(flag)
            .current_dir(&dir)
            .stdin(Stdio::null())
            .output()
            .unwrap();
        match flag {
            "--version" | "-V" => {
                assert!(output.status.success(), "{flag}: {output:?}");
                assert_eq!(
                    String::from_utf8(output.stdout).unwrap().trim(),
                    concat!("mirim ", env!("CARGO_PKG_VERSION"))
                );
                assert!(output.stderr.is_empty());
            }
            "--help" | "-h" => {
                assert!(output.status.success(), "{flag}: {output:?}");
                assert!(String::from_utf8_lossy(&output.stdout).contains("mirim [--] <file.mrm>"));
                assert!(output.stderr.is_empty());
            }
            _ => {
                assert_eq!(output.status.code(), Some(2));
                assert!(String::from_utf8_lossy(&output.stderr).contains("usage:"));
                assert!(!String::from_utf8_lossy(&output.stderr).contains("passphrase:"));
            }
        }
        assert_eq!(
            fs::read_dir(&dir).unwrap().count(),
            0,
            "{flag} created a file"
        );
    }
    fs::remove_dir(dir).unwrap();
}
