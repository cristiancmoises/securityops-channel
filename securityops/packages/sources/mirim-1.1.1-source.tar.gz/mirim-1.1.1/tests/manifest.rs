// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

#![cfg(feature = "sign")]

use mirim::manifest::{
    keygen, sign_manifest, verify_manifest, ManifestPublic, ManifestSecret, TargetKind,
    MANIFEST_LEN, SIGN_PUBLIC_LEN, SIGN_SEED_LEN,
};
use mirim::vault::{save, Secret};
use mirim::{Db, Error};

fn vault_bytes() -> Vec<u8> {
    use std::sync::atomic::{AtomicU64, Ordering};
    // Tests run in parallel within one process, so the PID alone is not a
    // unique temp name — a per-call counter keeps concurrent callers from
    // racing on the same file.
    static SEQ: AtomicU64 = AtomicU64::new(0);
    let mut db = Db::new();
    db.execute("create table t (a integer)").unwrap();
    db.execute("insert into t values (1)").unwrap();
    let mut path = std::env::temp_dir();
    path.push(format!(
        "mirim-mf-{}-{}.mrm",
        std::process::id(),
        SEQ.fetch_add(1, Ordering::Relaxed)
    ));
    save(&db, &path, &Secret::RawKey(&[9u8; 32])).unwrap();
    let bytes = std::fs::read(&path).unwrap();
    std::fs::remove_file(&path).unwrap();
    bytes
}

#[test]
fn sign_verify_roundtrip_with_counter() {
    let target = vault_bytes();
    let (sk, pk) = keygen();
    let mf = sign_manifest(&target, TargetKind::Vault, 41, &sk);
    assert_eq!(mf.len(), MANIFEST_LEN);
    let (kind, counter) = verify_manifest(&mf, &target, &pk).unwrap();
    assert_eq!(kind, TargetKind::Vault);
    assert_eq!(counter, 41);
}

#[test]
fn tampered_target_fails_closed() {
    let mut target = vault_bytes();
    let (sk, pk) = keygen();
    let mf = sign_manifest(&target, TargetKind::Vault, 1, &sk);
    let last = target.len() - 1;
    target[last] ^= 0x01;
    assert!(matches!(
        verify_manifest(&mf, &target, &pk),
        Err(Error::Crypto)
    ));
}

#[test]
fn tampered_manifest_fields_fail_closed() {
    let target = vault_bytes();
    let (sk, pk) = keygen();
    let mf = sign_manifest(&target, TargetKind::Sealed, 7, &sk);

    // Counter byte (authenticated by the signature).
    let mut t = mf.clone();
    t[10] ^= 0x01;
    assert!(matches!(
        verify_manifest(&t, &target, &pk),
        Err(Error::Crypto)
    ));

    // Kind byte: flipping 1 -> 0 keeps it a valid kind but breaks the sig.
    let mut t = mf.clone();
    t[9] = 0;
    assert!(matches!(
        verify_manifest(&t, &target, &pk),
        Err(Error::Crypto)
    ));

    // Signature bit.
    let mut t = mf.clone();
    let last = t.len() - 1;
    t[last] ^= 0x01;
    assert!(matches!(
        verify_manifest(&t, &target, &pk),
        Err(Error::Crypto)
    ));

    // Framing violations are Corrupt, not Crypto.
    assert!(matches!(
        verify_manifest(&mf[..MANIFEST_LEN - 1], &target, &pk),
        Err(Error::Corrupt(_))
    ));
    let mut t = mf.clone();
    t[0] ^= 0xFF;
    assert!(matches!(
        verify_manifest(&t, &target, &pk),
        Err(Error::Corrupt(_))
    ));
    let mut t = mf;
    t[9] = 2;
    assert!(matches!(
        verify_manifest(&t, &target, &pk),
        Err(Error::Corrupt(_))
    ));
}

#[test]
fn wrong_verifying_key_fails_closed() {
    let target = vault_bytes();
    let (sk, _pk) = keygen();
    let (_sk2, pk2) = keygen();
    let mf = sign_manifest(&target, TargetKind::Vault, 1, &sk);
    assert!(matches!(
        verify_manifest(&mf, &target, &pk2),
        Err(Error::Crypto)
    ));
}

#[test]
fn key_serialization_roundtrip() {
    let (sk, pk) = keygen();
    let seed = sk.to_bytes();
    let pkb = pk.to_bytes();
    assert_eq!(seed.len(), SIGN_SEED_LEN);
    assert_eq!(pkb.len(), SIGN_PUBLIC_LEN);

    let sk2 = ManifestSecret::from_bytes(seed.as_ref()).unwrap();
    let pk2 = ManifestPublic::from_bytes(&pkb).unwrap();
    // Same seed reproduces the same verifying key.
    assert_eq!(sk2.public().to_bytes(), pkb);

    let target = vault_bytes();
    let mf = sign_manifest(&target, TargetKind::Vault, 3, &sk2);
    assert_eq!(verify_manifest(&mf, &target, &pk2).unwrap().1, 3);

    assert!(ManifestSecret::from_bytes(&seed[..SIGN_SEED_LEN - 1]).is_err());
    assert!(ManifestPublic::from_bytes(&pkb[..SIGN_PUBLIC_LEN - 1]).is_err());
}

#[test]
fn counter_enforcement_blocks_rollback() {
    let (sk, pk) = mirim::manifest::keygen();
    let mut trust = std::env::temp_dir();
    trust.push(format!("mirim-trust-{}.trust", std::process::id()));
    let _ = std::fs::remove_file(&trust);

    let v1 = b"file contents, publication 1".to_vec();
    let v2 = b"file contents, publication 2".to_vec();
    let m1 = mirim::manifest::sign_manifest(&v1, TargetKind::Vault, 1, &sk);
    let m2 = mirim::manifest::sign_manifest(&v2, TargetKind::Vault, 2, &sk);

    // First acceptance creates the trust file.
    let (_, c) = mirim::manifest::verify_manifest_enforcing(&m1, &v1, &pk, &trust).unwrap();
    assert_eq!(c, 1);
    // Newer counter advances it.
    mirim::manifest::verify_manifest_enforcing(&m2, &v2, &pk, &trust).unwrap();
    // Replaying the older pair is now a rollback.
    assert!(matches!(
        mirim::manifest::verify_manifest_enforcing(&m1, &v1, &pk, &trust),
        Err(Error::Rollback)
    ));
    // Idempotent re-check of the current pair passes.
    mirim::manifest::verify_manifest_enforcing(&m2, &v2, &pk, &trust).unwrap();
    // Equal counter, different bytes: rejected.
    let v2b = b"different contents at the same counter".to_vec();
    let m2b = mirim::manifest::sign_manifest(&v2b, TargetKind::Vault, 2, &sk);
    assert!(matches!(
        mirim::manifest::verify_manifest_enforcing(&m2b, &v2b, &pk, &trust),
        Err(Error::Rollback)
    ));
    // The plain (non-enforcing) path still accepts the old pair.
    mirim::manifest::verify_manifest(&m1, &v1, &pk).unwrap();
    // A bad signature never touches the trust file: still at counter 2.
    let mut forged = m2.clone();
    forged[60] ^= 1;
    assert!(matches!(
        mirim::manifest::verify_manifest_enforcing(&forged, &v2, &pk, &trust),
        Err(Error::Crypto)
    ));
    mirim::manifest::verify_manifest_enforcing(&m2, &v2, &pk, &trust).unwrap();
    std::fs::remove_file(&trust).unwrap();
}

#[test]
fn corrupt_trust_file_fails_closed() {
    let (sk, pk) = mirim::manifest::keygen();
    let mut trust = std::env::temp_dir();
    trust.push(format!("mirim-trustbad-{}.trust", std::process::id()));
    std::fs::write(&trust, b"garbage").unwrap();
    let t = b"target".to_vec();
    let m = mirim::manifest::sign_manifest(&t, TargetKind::Vault, 1, &sk);
    assert!(matches!(
        mirim::manifest::verify_manifest_enforcing(&m, &t, &pk, &trust),
        Err(Error::Corrupt(_))
    ));
    std::fs::remove_file(&trust).unwrap();
}
