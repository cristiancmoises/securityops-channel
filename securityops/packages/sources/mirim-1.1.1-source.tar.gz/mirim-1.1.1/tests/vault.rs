// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

use std::fs;
use std::path::PathBuf;

use mirim::vault::{load, save, Secret};
use mirim::{Db, Error};

fn sample_db() -> Db {
    let mut db = Db::new();
    db.execute("create table users (id integer, name text)")
        .unwrap();
    db.execute("insert into users values (1, 'ana')").unwrap();
    db.execute("insert into users values (2, null)").unwrap();
    db
}

fn tmp(name: &str) -> PathBuf {
    let mut p = std::env::temp_dir();
    p.push(format!("mirim-test-{}-{name}.mrm", std::process::id()));
    p
}

#[test]
fn raw_key_roundtrip() {
    let path = tmp("rawkey");
    let db = sample_db();
    let key = [7u8; 32];
    save(&db, &path, &Secret::RawKey(&key)).unwrap();
    let back = load(&path, &Secret::RawKey(&key)).unwrap();
    assert_eq!(db, back);
    fs::remove_file(&path).unwrap();
}

#[test]
fn wrong_raw_key_fails_closed() {
    let path = tmp("wrongkey");
    save(&sample_db(), &path, &Secret::RawKey(&[1u8; 32])).unwrap();
    assert!(matches!(
        load(&path, &Secret::RawKey(&[2u8; 32])),
        Err(Error::Crypto)
    ));
    fs::remove_file(&path).unwrap();
}

// One passphrase test pair: Argon2id at production parameters (64 MiB,
// t=3) is intentionally slow, so the suite keeps exactly one positive and
// one negative path through it.
#[test]
fn passphrase_roundtrip_and_wrong_passphrase() {
    let path = tmp("pass");
    let db = sample_db();
    save(&db, &path, &Secret::Passphrase("correct horse")).unwrap();
    let back = load(&path, &Secret::Passphrase("correct horse")).unwrap();
    assert_eq!(db, back);
    assert!(matches!(
        load(&path, &Secret::Passphrase("wrong horse")),
        Err(Error::Crypto)
    ));
    fs::remove_file(&path).unwrap();
}

#[test]
fn body_tamper_detected() {
    let path = tmp("tamper-body");
    save(&sample_db(), &path, &Secret::RawKey(&[3u8; 32])).unwrap();
    let mut bytes = fs::read(&path).unwrap();
    let last = bytes.len() - 1;
    bytes[last] ^= 0x01;
    fs::write(&path, &bytes).unwrap();
    assert!(matches!(
        load(&path, &Secret::RawKey(&[3u8; 32])),
        Err(Error::Crypto)
    ));
    fs::remove_file(&path).unwrap();
}

#[test]
fn header_tamper_detected() {
    // Salt bytes live at offsets 10..26; they are AAD, so flipping one must
    // break authentication even though the body is untouched.
    let path = tmp("tamper-header");
    save(&sample_db(), &path, &Secret::RawKey(&[4u8; 32])).unwrap();
    let mut bytes = fs::read(&path).unwrap();
    bytes[12] ^= 0xFF;
    fs::write(&path, &bytes).unwrap();
    assert!(matches!(
        load(&path, &Secret::RawKey(&[4u8; 32])),
        Err(Error::Crypto)
    ));
    fs::remove_file(&path).unwrap();
}

#[test]
fn kdf_mismatch_is_explicit() {
    let path = tmp("kdfmismatch");
    save(&sample_db(), &path, &Secret::RawKey(&[5u8; 32])).unwrap();
    assert!(matches!(
        load(&path, &Secret::Passphrase("irrelevant")),
        Err(Error::KdfMismatch)
    ));
    fs::remove_file(&path).unwrap();
}

#[test]
fn truncated_and_garbage_files_are_corrupt() {
    let path = tmp("garbage");
    fs::write(&path, b"not a vault").unwrap();
    assert!(matches!(
        load(&path, &Secret::RawKey(&[0u8; 32])),
        Err(Error::Corrupt(_))
    ));
    fs::remove_file(&path).unwrap();
}

#[test]
fn save_preserves_existing_temporary_file() {
    let path = tmp("existing-temp");
    let temporary = PathBuf::from(format!("{}.tmp", path.display()));
    fs::write(&temporary, b"unrelated data").unwrap();
    save(&sample_db(), &path, &Secret::RawKey(&[7; 32])).unwrap();
    assert_eq!(fs::read(&temporary).unwrap(), b"unrelated data");
    assert_eq!(load(&path, &Secret::RawKey(&[7; 32])).unwrap(), sample_db());
    fs::remove_file(path).unwrap();
    fs::remove_file(temporary).unwrap();
}

#[cfg(unix)]
#[test]
fn save_does_not_follow_temporary_symlink_and_creates_private_vault() {
    use std::os::unix::fs::{symlink, PermissionsExt};

    let path = tmp("symlink-temp");
    let target = tmp("symlink-target");
    let temporary = PathBuf::from(format!("{}.tmp", path.display()));
    fs::write(&target, b"must survive").unwrap();
    symlink(&target, &temporary).unwrap();
    save(&sample_db(), &path, &Secret::RawKey(&[7; 32])).unwrap();
    assert_eq!(fs::read(&target).unwrap(), b"must survive");
    assert_eq!(
        fs::metadata(&path).unwrap().permissions().mode() & 0o777,
        0o600
    );
    assert!(fs::symlink_metadata(&temporary)
        .unwrap()
        .file_type()
        .is_symlink());
    fs::remove_file(path).unwrap();
    fs::remove_file(temporary).unwrap();
    fs::remove_file(target).unwrap();
}
