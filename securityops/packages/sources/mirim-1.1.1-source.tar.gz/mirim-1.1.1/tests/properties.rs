// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! Property-based tests: round-trip and replay invariants over arbitrary
//! operation sequences, plus global engine invariants. These complement
//! the libFuzzer targets (which assert *no panic* on hostile bytes) by
//! asserting *correctness* on valid inputs, with shrinking to a minimal
//! failing case when an invariant breaks.
//!
//! Everything runs through the public API. Generated TEXT values reach
//! the engine only via parameter binding, never string interpolation —
//! the one sanctioned untrusted-input path — so arbitrary strings are
//! exercised without SQL-quoting hazards.
//!
//! Determinism: proptest seeds from `PROPTEST_RNG_SEED` when set and
//! persists any discovered failing seed under `proptest-regressions/`.
//! Case counts are tuned per group so the fsync-bound (WAL) and
//! lattice-keygen (manifest) groups stay fast.

use std::path::PathBuf;
use std::sync::atomic::{AtomicU64, Ordering};
#[cfg(feature = "sign")]
use std::sync::OnceLock;

use proptest::prelude::*;

use mirim::vault::{load, save, Secret};
use mirim::{Db, DurableDb, Output, Value};

/// A mutation against the fixed two-column schema below. A small `id`
/// range is deliberate: it makes PK collisions, updates that hit live
/// rows, and deletes of present rows frequent, so the interesting engine
/// paths are actually taken.
#[derive(Debug, Clone)]
enum Op {
    Insert(i64, Option<String>),
    Update(i64, Option<String>),
    Delete(i64),
}

const SCHEMA: &str = "create table t (id integer primary key, s text)";

fn text(o: &Option<String>) -> Value {
    match o {
        None => Value::Null,
        Some(s) => Value::Text(s.clone()),
    }
}

impl Op {
    fn parts(&self) -> (&'static str, Vec<Value>) {
        match self {
            Op::Insert(id, s) => (
                "insert into t values (?, ?)",
                vec![Value::Int(*id), text(s)],
            ),
            Op::Update(id, s) => (
                "update t set s = ? where id = ?",
                vec![text(s), Value::Int(*id)],
            ),
            Op::Delete(id) => ("delete from t where id = ?", vec![Value::Int(*id)]),
        }
    }
}

fn small_text() -> impl Strategy<Value = Option<String>> {
    prop::option::of(any::<String>().prop_map(|s| s.chars().take(16).collect::<String>()))
}

fn op_strategy() -> impl Strategy<Value = Op> {
    prop_oneof![
        (0i64..16, small_text()).prop_map(|(id, s)| Op::Insert(id, s)),
        (0i64..16, small_text()).prop_map(|(id, s)| Op::Update(id, s)),
        (0i64..16).prop_map(Op::Delete),
    ]
}

fn ops_strategy(max: usize) -> impl Strategy<Value = Vec<Op>> {
    prop::collection::vec(op_strategy(), 0..max)
}

/// Build an in-memory database by applying `ops` to the fixed schema.
/// Failed statements (PK collisions, etc.) are ignored, exactly as a
/// caller would see them; the result is valid by construction.
fn build(ops: &[Op]) -> Db {
    let mut db = Db::new();
    db.execute(SCHEMA).expect("schema");
    for op in ops {
        let (sql, params) = op.parts();
        let _ = db.execute_params(sql, &params);
    }
    db
}

/// Snapshot the table as an ordered row vector via the public query path.
fn rows_of(db: &Db) -> Vec<Vec<Value>> {
    let mut q = db.clone();
    match q.execute("select id, s from t").expect("select") {
        Output::Rows { rows, .. } => rows,
        other => panic!("unexpected select output: {other:?}"),
    }
}

fn unique_path(tag: &str) -> PathBuf {
    static N: AtomicU64 = AtomicU64::new(0);
    let n = N.fetch_add(1, Ordering::Relaxed);
    std::env::temp_dir().join(format!("mirim-prop-{tag}-{}-{n}.mrm", std::process::id()))
}

fn cleanup(path: &PathBuf) {
    let _ = std::fs::remove_file(path);
    for ext in [".wal", ".lock", ".tmp", ".wal.tmp"] {
        let mut p = path.as_os_str().to_owned();
        p.push(ext);
        let _ = std::fs::remove_file(PathBuf::from(p));
    }
}

proptest! {
    #![proptest_config(ProptestConfig { cases: 128, ..ProptestConfig::default() })]

    /// vault save → load is the identity on any database the engine can
    /// reach. Exercises wire encode/decode and the XChaCha20-Poly1305
    /// vault layer end to end. RawKey avoids Argon2id so case count can
    /// stay high.
    #[test]
    fn prop_vault_roundtrip(ops in ops_strategy(40), key in any::<[u8; 32]>()) {
        let db = build(&ops);
        let path = unique_path("vault");
        save(&db, &path, &Secret::RawKey(&key)).expect("save");
        let back = load(&path, &Secret::RawKey(&key)).expect("load");
        cleanup(&path);
        prop_assert_eq!(db, back);
    }

    /// Single-recipient seal → open is the identity; an outsider key
    /// never opens it.
    #[test]
    fn prop_seal_roundtrip_single(ops in ops_strategy(40)) {
        let db = build(&ops);
        let (sk, pk) = mirim::pq::keygen();
        let sealed = mirim::pq::seal(&db, &pk).expect("seal");
        let back = mirim::pq::open(&sealed, &sk).expect("open");
        prop_assert_eq!(&db, &back);
        let (outsider, _) = mirim::pq::keygen();
        prop_assert!(mirim::pq::open(&sealed, &outsider).is_err());
    }

    /// Multi-recipient seal opens for every listed recipient and for no
    /// one else.
    #[test]
    fn prop_seal_roundtrip_multi(ops in ops_strategy(30), n in 1usize..4) {
        let db = build(&ops);
        let pairs: Vec<_> = (0..n).map(|_| mirim::pq::keygen()).collect();
        let pks: Vec<&mirim::pq::RecipientPublic> = pairs.iter().map(|(_, p)| p).collect();
        let sealed = mirim::pq::seal_multi(&db, &pks).expect("seal_multi");
        for (sk, _) in &pairs {
            prop_assert_eq!(&db, &mirim::pq::open(&sealed, sk).expect("open"));
        }
        let (outsider, _) = mirim::pq::keygen();
        prop_assert!(mirim::pq::open(&sealed, &outsider).is_err());
    }

    /// PRIMARY KEY uniqueness is a global invariant: after ANY operation
    /// sequence, no id value appears more than once.
    #[test]
    fn prop_pk_unique_after_any_ops(ops in ops_strategy(60)) {
        let rows = rows_of(&build(&ops));
        let mut ids: Vec<&Value> = rows.iter().map(|r| &r[0]).collect();
        ids.sort_by(|a, b| format!("{a:?}").cmp(&format!("{b:?}")));
        let mut deduped = ids.clone();
        deduped.dedup();
        prop_assert_eq!(ids.len(), deduped.len(), "duplicate primary key present");
        // PKs are never NULL.
        prop_assert!(rows.iter().all(|r| r[0] != Value::Null));
    }

    /// Insert/delete consistency: after applying ops, deleting an id then
    /// querying it yields nothing, and re-inserting it then querying
    /// yields exactly one row.
    #[test]
    fn prop_delete_then_insert_consistency(ops in ops_strategy(40), id in 0i64..16) {
        let mut db = build(&ops);
        db.execute_params("delete from t where id = ?", &[Value::Int(id)])
            .expect("delete");
        let after_delete = match db
            .execute_params("select id from t where id = ?", &[Value::Int(id)])
            .expect("select")
        {
            Output::Rows { rows, .. } => rows.len(),
            other => panic!("unexpected: {other:?}"),
        };
        prop_assert_eq!(after_delete, 0);
        db.execute_params("insert into t values (?, 'x')", &[Value::Int(id)])
            .expect("insert");
        let after_insert = match db
            .execute_params("select id from t where id = ?", &[Value::Int(id)])
            .expect("select")
        {
            Output::Rows { rows, .. } => rows.len(),
            other => panic!("unexpected: {other:?}"),
        };
        prop_assert_eq!(after_insert, 1);
    }
}

proptest! {
    // fsync per mutation, plus an open/replay per case: keep it modest.
    #![proptest_config(ProptestConfig { cases: 48, ..ProptestConfig::default() })]

    /// The durability invariant over arbitrary operation sequences: the
    /// state visible before closing a `DurableDb` (relying on the WAL
    /// alone, never checkpointed) equals the state after reopening and
    /// replaying. This is the property the SIGKILL harness checks for one
    /// hand-written sequence, generalized.
    #[test]
    fn prop_wal_replay_preserves_state(ops in ops_strategy(16), key in any::<[u8; 32]>()) {
        let path = unique_path("wal");
        let before = {
            let mut d = DurableDb::open(&path, &Secret::RawKey(&key)).expect("open");
            d.execute(SCHEMA).expect("schema");
            for op in &ops {
                let (sql, params) = op.parts();
                let _ = d.execute_params(sql, &params);
            }
            rows_of(d.db())
        }; // dropped without checkpoint: only the WAL carries the state.
        let after = {
            let d = DurableDb::open(&path, &Secret::RawKey(&key)).expect("reopen");
            rows_of(d.db())
        };
        cleanup(&path);
        prop_assert_eq!(before, after);
    }

    /// A checkpoint mid-sequence is state-preserving and resets the log;
    /// further mutations remain durable across a reopen.
    #[test]
    fn prop_checkpoint_preserves_state(
        head in ops_strategy(10),
        tail in ops_strategy(10),
        key in any::<[u8; 32]>(),
    ) {
        let path = unique_path("ckpt");
        let expected = {
            let mut d = DurableDb::open(&path, &Secret::RawKey(&key)).expect("open");
            d.execute(SCHEMA).expect("schema");
            for op in &head {
                let (sql, params) = op.parts();
                let _ = d.execute_params(sql, &params);
            }
            d.checkpoint().expect("checkpoint");
            prop_assert_eq!(d.wal_records(), 0);
            for op in &tail {
                let (sql, params) = op.parts();
                let _ = d.execute_params(sql, &params);
            }
            rows_of(d.db())
        };
        let after = {
            let d = DurableDb::open(&path, &Secret::RawKey(&key)).expect("reopen");
            rows_of(d.db())
        };
        cleanup(&path);
        prop_assert_eq!(expected, after);
    }
}

#[cfg(feature = "sign")]
mod sign_props {
    use super::*;
    use mirim::manifest::{
        keygen, sign_manifest, verify_manifest, verify_manifest_enforcing, ManifestPublic,
        ManifestSecret, TargetKind,
    };
    use mirim::Error;

    fn keys() -> &'static (ManifestSecret, ManifestPublic) {
        static K: OnceLock<(ManifestSecret, ManifestPublic)> = OnceLock::new();
        K.get_or_init(keygen)
    }

    fn kind_strategy() -> impl Strategy<Value = TargetKind> {
        prop::bool::ANY.prop_map(|b| {
            if b {
                TargetKind::Vault
            } else {
                TargetKind::Sealed
            }
        })
    }

    proptest! {
        #![proptest_config(ProptestConfig { cases: 128, ..ProptestConfig::default() })]

        /// sign → verify is the identity on (kind, counter); a single-bit
        /// flip in the manifest is always rejected.
        #[test]
        fn prop_manifest_roundtrip(
            target in prop::collection::vec(any::<u8>(), 0..256),
            counter in any::<u64>(),
            kind in kind_strategy(),
        ) {
            let (sk, pk) = keys();
            let m = sign_manifest(&target, kind, counter, sk);
            let (k2, c2) = verify_manifest(&m, &target, pk).expect("verify");
            prop_assert_eq!(k2, kind);
            prop_assert_eq!(c2, counter);

            // Flip one byte anywhere in the manifest: must fail.
            let mut bad = m.clone();
            let i = (counter as usize) % bad.len();
            bad[i] ^= 1;
            prop_assert!(verify_manifest(&bad, &target, pk).is_err());

            // Verifying against a different target also fails.
            let mut other = target.clone();
            other.push(0);
            prop_assert!(verify_manifest(&m, &other, pk).is_err());
        }

        /// Counter enforcement is monotonic: a strictly increasing
        /// sequence is accepted in order; any earlier counter replayed
        /// afterward is a rollback.
        #[test]
        fn prop_counter_enforcement_monotone(
            steps in prop::collection::vec(1u64..1000, 2..8),
        ) {
            let (sk, pk) = keys();
            // Strictly increasing counters with distinct targets.
            let mut counters = Vec::new();
            let mut acc = 0u64;
            for d in &steps {
                acc += *d;
                counters.push(acc);
            }
            let trust = unique_path("trust");
            let trust = {
                let mut p = trust.into_os_string();
                p.push(".trust");
                PathBuf::from(p)
            };
            let _ = std::fs::remove_file(&trust);

            let target = |c: u64| format!("target-at-{c}").into_bytes();
            for &c in &counters {
                let t = target(c);
                let m = sign_manifest(&t, TargetKind::Vault, c, sk);
                let r = verify_manifest_enforcing(&m, &t, pk, &trust);
                prop_assert!(r.is_ok(), "increasing counter {c} rejected: {r:?}");
            }
            // Replay the first (lowest) counter: must be a rollback now.
            let first = counters[0];
            let t = target(first);
            let m = sign_manifest(&t, TargetKind::Vault, first, sk);
            let r = verify_manifest_enforcing(&m, &t, pk, &trust);
            let _ = std::fs::remove_file(&trust);
            prop_assert!(matches!(r, Err(Error::Rollback)), "expected Rollback, got {r:?}");
        }
    }
}
