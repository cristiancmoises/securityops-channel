// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

use mirim::pq::{
    keygen, open, seal, RecipientPublic, RecipientSecret, KEM_CT_LEN, PUBLIC_LEN, SECRET_LEN,
};
use mirim::{Db, Error};

fn sample_db() -> Db {
    let mut db = Db::new();
    db.execute("create table secrets (k text, v text)").unwrap();
    db.execute("insert into secrets values ('api', 'hunter2')")
        .unwrap();
    db
}

#[test]
fn seal_open_roundtrip() {
    let db = sample_db();
    let (sk, pk) = keygen();
    let sealed = seal(&db, &pk).unwrap();
    // Header: 8 magic + 1 version + KEM ct + 24 nonce, then AEAD body.
    assert!(sealed.len() > 8 + 1 + KEM_CT_LEN + 24);
    let back = open(&sealed, &sk).unwrap();
    assert_eq!(db, back);
}

#[test]
fn wrong_recipient_fails_closed() {
    let db = sample_db();
    let (_sk_a, pk_a) = keygen();
    let (sk_b, _pk_b) = keygen();
    let sealed = seal(&db, &pk_a).unwrap();
    // Implicit rejection inside ML-KEM surfaces uniformly as an AEAD
    // authentication failure — no distinct "wrong key" oracle.
    assert!(matches!(open(&sealed, &sk_b), Err(Error::Crypto)));
}

#[test]
fn body_and_header_tamper_fail_closed() {
    let db = sample_db();
    let (sk, pk) = keygen();
    let sealed = seal(&db, &pk).unwrap();

    let mut t = sealed.clone();
    let last = t.len() - 1;
    t[last] ^= 0x01;
    assert!(matches!(open(&t, &sk), Err(Error::Crypto)));

    let mut t = sealed;
    t[100] ^= 0x01; // inside the KEM ciphertext, which is AAD-bound
    assert!(matches!(open(&t, &sk), Err(Error::Crypto)));
}

#[test]
fn key_serialization_roundtrip() {
    let (sk, pk) = keygen();
    let pkb = pk.to_bytes();
    let skb = sk.to_bytes();
    assert_eq!(pkb.len(), PUBLIC_LEN);
    assert_eq!(skb.len(), SECRET_LEN);

    let pk2 = RecipientPublic::from_bytes(&pkb).unwrap();
    let sk2 = RecipientSecret::from_bytes(&skb).unwrap();
    let db = sample_db();
    let sealed = seal(&db, &pk2).unwrap();
    assert_eq!(open(&sealed, &sk2).unwrap(), db);

    assert!(RecipientPublic::from_bytes(&pkb[..PUBLIC_LEN - 1]).is_err());
    assert!(RecipientSecret::from_bytes(&skb[..SECRET_LEN - 1]).is_err());
}

#[test]
fn truncated_sealed_input_is_corrupt() {
    let (sk, pk) = keygen();
    let sealed = seal(&sample_db(), &pk).unwrap();
    assert!(matches!(open(&sealed[..40], &sk), Err(Error::Corrupt(_))));
    let mut bad_magic = sealed;
    bad_magic[0] ^= 0xFF;
    assert!(matches!(open(&bad_magic, &sk), Err(Error::Corrupt(_))));
}

#[test]
fn multi_recipient_seal_opens_for_every_recipient() {
    let mut db = Db::new();
    db.execute("create table t (id integer primary key)")
        .unwrap();
    db.execute("insert into t values (7)").unwrap();
    let pairs: Vec<_> = (0..3).map(|_| keygen()).collect();
    let pks: Vec<&mirim::pq::RecipientPublic> = pairs.iter().map(|(_, p)| p).collect();
    let sealed = mirim::pq::seal_multi(&db, &pks).unwrap();
    for (sk, _) in &pairs {
        let back = mirim::pq::open(&sealed, sk).unwrap();
        assert_eq!(back, db);
    }
    // A key outside the recipient set fails uniformly.
    let (outsider, _) = keygen();
    assert!(matches!(
        mirim::pq::open(&sealed, &outsider),
        Err(Error::Crypto)
    ));
}

#[test]
fn multi_recipient_tamper_fails_anywhere() {
    let db = Db::new();
    let pairs: Vec<_> = (0..2).map(|_| keygen()).collect();
    let pks: Vec<&mirim::pq::RecipientPublic> = pairs.iter().map(|(_, p)| p).collect();
    let sealed = mirim::pq::seal_multi(&db, &pks).unwrap();
    // Flip one byte in: recipient count, a wrap slot, the payload.
    for idx in [9usize, 11 + 1088 + 5, sealed.len() - 1] {
        let mut bad = sealed.clone();
        bad[idx] ^= 1;
        assert!(
            mirim::pq::open(&bad, &pairs[0].0).is_err(),
            "tamper at {idx} was accepted"
        );
    }
}

#[test]
fn multi_recipient_rejects_empty_and_oversized_lists() {
    let db = Db::new();
    assert!(mirim::pq::seal_multi(&db, &[]).is_err());
}

#[test]
fn single_recipient_v1_still_roundtrips() {
    let mut db = Db::new();
    db.execute("create table t (a text unique)").unwrap();
    db.execute("insert into t values ('x')").unwrap();
    let (sk, pk) = keygen();
    let sealed = mirim::pq::seal(&db, &pk).unwrap();
    assert_eq!(sealed[8], 1, "single-recipient seal stays format v1");
    assert_eq!(mirim::pq::open(&sealed, &sk).unwrap(), db);
}
