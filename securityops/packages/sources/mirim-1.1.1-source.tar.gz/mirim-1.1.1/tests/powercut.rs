// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! Power-cut simulation (`harness = false`).
//!
//! The parent repeatedly spawns a child (this same binary, re-executed
//! with `MIRIM_POWERCUT_CHILD=1`) that appends rows in a tight loop and
//! prints `ACK <n>` after each acknowledged commit, then SIGKILLs it at a
//! random moment. After every kill the parent reopens the database and
//! asserts the durability contract:
//!
//! 1. every acknowledged row is present (durable count > last ACK seen);
//! 2. rows form a contiguous prefix 0..n — no holes, no garbage.
//!
//! A durable row whose ACK never reached the pipe is allowed (the kill
//! can land between fsync and print); the reverse is the bug this test
//! exists to catch.

use std::io::{BufRead, BufReader, Write};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::time::Duration;

use rand_core::{OsRng, RngCore};

use mirim::vault::Secret;
use mirim::{DurableDb, Error, Output, Value};

const KEY: [u8; 32] = [3u8; 32];
const ITERATIONS: u32 = 12;

fn main() {
    if std::env::var_os("MIRIM_POWERCUT_CHILD").is_some() {
        child();
        return;
    }
    parent();
}

fn open(path: &Path) -> DurableDb {
    DurableDb::open(path, &Secret::RawKey(&KEY)).expect("open durable db")
}

fn rows_of(d: &mut DurableDb) -> Vec<i64> {
    match d.execute("select id from t") {
        Ok(Output::Rows { rows, .. }) => rows
            .into_iter()
            .map(|r| match &r[0] {
                Value::Int(i) => *i,
                other => panic!("non-integer id: {other}"),
            })
            .collect(),
        // A kill can land before the child's CREATE TABLE was made
        // durable; an absent table is simply zero rows.
        Err(Error::Exec(_)) => Vec::new(),
        other => panic!("select failed: {other:?}"),
    }
}

fn child() {
    let path = PathBuf::from(std::env::var_os("MIRIM_POWERCUT_PATH").expect("path env"));
    let mut d = open(&path);
    let _ = d.execute("create table t (id integer primary key)");
    let start = rows_of(&mut d).len() as i64;
    let stdout = std::io::stdout();
    let mut out = stdout.lock();
    for i in start..start + 100_000 {
        d.execute_params("insert into t values (?)", &[Value::Int(i)])
            .expect("durable insert");
        // ACK only after execute returned Ok (i.e. after fsync).
        writeln!(out, "ACK {i}").expect("ack write");
        out.flush().expect("ack flush");
    }
}

fn parent() {
    let mut path = std::env::temp_dir();
    path.push(format!("mirim-powercut-{}.mrm", std::process::id()));
    let mut wal = path.as_os_str().to_owned();
    wal.push(".wal");
    let _ = std::fs::remove_file(&path);
    let _ = std::fs::remove_file(PathBuf::from(&wal));

    let exe = std::env::current_exe().expect("current_exe");
    let mut total_acked = 0u64;

    for iter in 0..ITERATIONS {
        let mut chld = Command::new(&exe)
            .env("MIRIM_POWERCUT_CHILD", "1")
            .env("MIRIM_POWERCUT_PATH", &path)
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .spawn()
            .expect("spawn child");

        // Let it commit for a random 5..55 ms, then pull the plug.
        let ms = u64::from(OsRng.next_u32() % 50) + 5;
        std::thread::sleep(Duration::from_millis(ms));
        chld.kill().expect("SIGKILL child");

        // Read every ACK that made it out of the pipe.
        let mut last_ack: Option<i64> = None;
        let reader = BufReader::new(chld.stdout.take().expect("child stdout"));
        for line in reader.lines() {
            let line = line.expect("read ack line");
            if let Some(n) = line.strip_prefix("ACK ") {
                last_ack = Some(n.trim().parse().expect("ack number"));
            }
        }
        chld.wait().expect("reap child");

        let mut d = open(&path);
        let rows = rows_of(&mut d);
        let n = rows.len() as i64;

        // Contiguous prefix 0..n, in insertion order.
        for (i, v) in rows.iter().enumerate() {
            assert_eq!(
                *v, i as i64,
                "iteration {iter}: hole or reorder at row {i} (got {v})"
            );
        }
        // Nothing acknowledged may be missing.
        if let Some(a) = last_ack {
            assert!(
                n > a,
                "iteration {iter}: lost acknowledged commit {a} (durable count {n})"
            );
            total_acked = total_acked.max(a as u64 + 1);
        }
        // Exercise checkpointing under churn every third iteration.
        if iter % 3 == 2 {
            d.checkpoint().expect("checkpoint");
        }
    }

    let mut d = open(&path);
    let n = rows_of(&mut d).len() as u64;
    let _ = std::fs::remove_file(&path);
    let _ = std::fs::remove_file(PathBuf::from(&wal));
    println!(
        "powercut: {ITERATIONS} kill -9 iterations, {n} rows durable, \
         >= {total_acked} acknowledged, 0 lost"
    );
}
