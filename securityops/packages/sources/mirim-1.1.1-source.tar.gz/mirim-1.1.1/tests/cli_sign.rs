// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial
#![cfg(feature = "sign")]

//! End-to-end test of the `mirim-sign` binary: the real artifact-signing
//! path a release uses, driven through the compiled executable.

use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;

fn bin() -> PathBuf {
    // Cargo exposes the built binary's path to integration tests.
    PathBuf::from(env!("CARGO_BIN_EXE_mirim-sign"))
}

struct Tmp(PathBuf);
impl Tmp {
    fn dir() -> Self {
        let p = std::env::temp_dir().join(format!(
            "mirim-sign-it-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        fs::create_dir_all(&p).unwrap();
        Tmp(p)
    }
    fn path(&self, name: &str) -> PathBuf {
        self.0.join(name)
    }
}
impl Drop for Tmp {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}

fn run(args: &[&str]) -> std::process::Output {
    Command::new(bin())
        .args(args)
        .output()
        .expect("spawn mirim-sign")
}

fn s(p: &Path) -> String {
    p.to_str().unwrap().to_owned()
}

#[test]
fn informational_flags_report_success_without_creating_files() {
    let t = Tmp::dir();
    for flag in ["--version", "-V", "--help", "-h"] {
        let out = Command::new(bin())
            .arg(flag)
            .current_dir(&t.0)
            .output()
            .unwrap();
        assert!(out.status.success(), "{flag}: {out:?}");
        assert!(out.stderr.is_empty());
        let text = String::from_utf8(out.stdout).unwrap();
        if flag == "--version" || flag == "-V" {
            assert_eq!(
                text.trim(),
                concat!("mirim-sign ", env!("CARGO_PKG_VERSION"))
            );
        } else {
            assert!(text.contains("keygen <secret-out> <public-out>"));
        }
        assert_eq!(fs::read_dir(&t.0).unwrap().count(), 0);
    }
}

#[test]
fn keygen_sign_verify_roundtrip_and_failures() {
    let t = Tmp::dir();
    let secret = s(&t.path("k.seed"));
    let public = s(&t.path("k.pub"));
    let artifact = s(&t.path("release.bin"));
    let manifest = s(&t.path("release.bin.mf"));

    fs::write(&artifact, b"pretend this is a release tarball").unwrap();

    // keygen
    let out = run(&["keygen", &secret, &public]);
    assert!(out.status.success(), "keygen failed: {out:?}");
    assert_eq!(fs::read(&secret).unwrap().len(), 32);
    assert_eq!(fs::read(&public).unwrap().len(), 2592);
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        assert_eq!(
            fs::metadata(&secret).unwrap().permissions().mode() & 0o777,
            0o600
        );
    }

    // sign (default manifest path, default kind/counter)
    let out = run(&["sign", &artifact, &secret]);
    assert!(out.status.success(), "sign failed: {out:?}");
    assert!(fs::metadata(&manifest).is_ok());

    // verify succeeds
    let out = run(&["verify", &artifact, &manifest, &public]);
    assert!(out.status.success(), "verify failed: {out:?}");
    assert!(String::from_utf8_lossy(&out.stdout).contains("OK"));

    // tampered artifact fails
    fs::write(&artifact, b"pretend this is a DIFFERENT release tarball").unwrap();
    let out = run(&["verify", &artifact, &manifest, &public]);
    assert!(!out.status.success(), "verify accepted a tampered artifact");
    // restore
    fs::write(&artifact, b"pretend this is a release tarball").unwrap();

    // wrong public key fails
    let other_pub = s(&t.path("other.pub"));
    let other_secret = s(&t.path("other.seed"));
    assert!(run(&["keygen", &other_secret, &other_pub]).status.success());
    let out = run(&["verify", &artifact, &manifest, &other_pub]);
    assert!(!out.status.success(), "verify accepted a wrong public key");

    // truncated manifest fails cleanly (no panic, nonzero exit)
    fs::write(&manifest, b"too short").unwrap();
    let out = run(&["verify", &artifact, &manifest, &public]);
    assert!(!out.status.success());
}

#[test]
fn keygen_refuses_existing_outputs_and_identical_paths() {
    let t = Tmp::dir();
    let secret = s(&t.path("k.seed"));
    let public = s(&t.path("k.pub"));
    fs::write(&secret, b"existing seed").unwrap();
    assert!(!run(&["keygen", &secret, &public]).status.success());
    assert_eq!(fs::read(&secret).unwrap(), b"existing seed");
    assert!(!t.path("k.pub").exists());

    fs::remove_file(&secret).unwrap();
    fs::write(&public, b"existing public key").unwrap();
    assert!(!run(&["keygen", &secret, &public]).status.success());
    assert_eq!(fs::read(&public).unwrap(), b"existing public key");
    assert!(!t.path("k.seed").exists());
    assert!(!run(&["keygen", &secret, &secret]).status.success());
    assert!(!t.path("k.seed").exists());
}

#[cfg(unix)]
#[test]
fn keygen_refuses_symlink_outputs() {
    use std::os::unix::fs::symlink;
    let t = Tmp::dir();
    let target = t.path("existing.seed");
    let secret = t.path("k.seed");
    let public = t.path("k.pub");
    fs::write(&target, b"original seed").unwrap();
    symlink(&target, &secret).unwrap();
    assert!(!run(&["keygen", &s(&secret), &s(&public)]).status.success());
    assert_eq!(fs::read(&target).unwrap(), b"original seed");
    assert!(fs::symlink_metadata(&secret)
        .unwrap()
        .file_type()
        .is_symlink());
}

#[test]
fn enforce_rejects_rollback() {
    let t = Tmp::dir();
    let secret = s(&t.path("k.seed"));
    let public = s(&t.path("k.pub"));
    let trust = s(&t.path("releases.trust"));
    assert!(run(&["keygen", &secret, &public]).status.success());

    let v1 = s(&t.path("v1.bin"));
    let v2 = s(&t.path("v2.bin"));
    let m1 = s(&t.path("v1.bin.mf"));
    let m2 = s(&t.path("v2.bin.mf"));
    fs::write(&v1, b"release 0.1.0").unwrap();
    fs::write(&v2, b"release 0.2.0").unwrap();

    assert!(run(&["sign", &v1, &secret, "--counter", "1"])
        .status
        .success());
    assert!(run(&["sign", &v2, &secret, "--counter", "2"])
        .status
        .success());

    // First enforced verify establishes the trust file.
    assert!(run(&["verify", &v1, &m1, &public, "--enforce", &trust])
        .status
        .success());
    // Newer counter advances it.
    assert!(run(&["verify", &v2, &m2, &public, "--enforce", &trust])
        .status
        .success());
    // Replaying the older release is now rejected.
    let out = run(&["verify", &v1, &m1, &public, "--enforce", &trust]);
    assert!(
        !out.status.success(),
        "enforce accepted a rolled-back release"
    );
    assert!(String::from_utf8_lossy(&out.stderr)
        .to_lowercase()
        .contains("rollback"));
}

#[test]
fn kind_and_output_flags() {
    let t = Tmp::dir();
    let secret = s(&t.path("k.seed"));
    let public = s(&t.path("k.pub"));
    let artifact = s(&t.path("a.bin"));
    let manifest = s(&t.path("custom.mf"));
    assert!(run(&["keygen", &secret, &public]).status.success());
    fs::write(&artifact, b"sealed export bytes").unwrap();

    let out = run(&[
        "sign", &artifact, &secret, "--kind", "sealed", "-o", &manifest,
    ]);
    assert!(
        out.status.success(),
        "sign --kind sealed -o failed: {out:?}"
    );
    let out = run(&["verify", &artifact, &manifest, &public]);
    assert!(out.status.success());
    assert!(String::from_utf8_lossy(&out.stdout).contains("kind=sealed"));

    // unknown kind is a clean error
    assert!(!run(&["sign", &artifact, &secret, "--kind", "bogus"])
        .status
        .success());
}
