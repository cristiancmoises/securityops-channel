// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};

use mirim::vault::Secret;
use mirim::{DurableDb, Error, Output, Value};

const KEY: [u8; 32] = [7u8; 32];

fn tmp(name: &str) -> PathBuf {
    let mut p = std::env::temp_dir();
    p.push(format!("mirim-dur-{}-{}", std::process::id(), name));
    let _ = fs::remove_file(&p);
    let mut w = p.clone();
    w.set_extension("mrm.wal");
    let _ = fs::remove_file(&w);
    p.set_extension("mrm");
    p
}

fn wal_of(p: &Path) -> PathBuf {
    let mut w = p.as_os_str().to_owned();
    w.push(".wal");
    PathBuf::from(w)
}

fn count(d: &mut DurableDb) -> usize {
    match d.execute("select * from t").unwrap() {
        Output::Rows { rows, .. } => rows.len(),
        _ => unreachable!(),
    }
}

#[test]
fn survives_reopen_without_checkpoint() {
    let p = tmp("reopen");
    {
        let mut d = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
        d.execute("create table t (id integer primary key)")
            .unwrap();
        for i in 0..10 {
            d.execute_params("insert into t values (?)", &[Value::Int(i)])
                .unwrap();
        }
        assert_eq!(d.wal_records(), 11);
        // No checkpoint; drop relies on the log alone.
    }
    let mut d = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
    assert_eq!(count(&mut d), 10);
    assert_eq!(d.wal_records(), 11);
}

#[test]
fn oversized_record_is_rejected_without_logging_or_poisoning_session() {
    let p = tmp("oversized-record");
    let mut d = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
    d.execute("create table t (body text)").unwrap();
    let sql = "insert into t values (?)";
    // One byte over the exact framing + AEAD ciphertext limit.
    let oversized_len = (1 << 24) - sql.len() - 4 - 2 - 5 - 16 + 1;
    let before = fs::read(wal_of(&p)).unwrap();
    let err = d.execute_params(sql, &[Value::Text("x".repeat(oversized_len))]);
    assert!(matches!(err, Err(Error::Exec(message)) if message.contains("16 MiB")));
    assert_eq!(d.wal_records(), 1);
    assert_eq!(fs::read(wal_of(&p)).unwrap(), before);
    assert_eq!(count(&mut d), 0);
    d.execute_params(sql, &[Value::Text("survives".into())])
        .unwrap();
    drop(d);
    let mut d = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
    assert_eq!(count(&mut d), 1);
    assert_eq!(d.wal_records(), 2);
}

#[test]
fn checkpoint_resets_log_and_preserves_state() {
    let p = tmp("ckpt");
    let mut d = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
    d.execute("create table t (id integer)").unwrap();
    d.execute("insert into t values (1)").unwrap();
    d.checkpoint().unwrap();
    assert_eq!(d.wal_records(), 0);
    assert_eq!(fs::metadata(wal_of(&p)).unwrap().len(), 41);
    d.execute("insert into t values (2)").unwrap();
    drop(d);
    let mut d = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
    assert_eq!(count(&mut d), 2);
    // Empty-log checkpoint is a no-op.
    d.checkpoint().unwrap();
    d.checkpoint().unwrap();
}

#[test]
fn torn_tail_is_repaired() {
    let p = tmp("torn");
    {
        let mut d = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
        d.execute("create table t (id integer)").unwrap();
        d.execute("insert into t values (1)").unwrap();
    }
    let w = wal_of(&p);
    let before = fs::metadata(&w).unwrap().len();
    // Simulate a crash mid-append: a partial record at the tail.
    let mut f = fs::OpenOptions::new().append(true).open(&w).unwrap();
    f.write_all(&3u64.to_le_bytes()).unwrap();
    f.write_all(&[0xAA; 11]).unwrap();
    drop(f);
    let mut d = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
    assert_eq!(count(&mut d), 1);
    assert_eq!(fs::metadata(&w).unwrap().len(), before);
    // The repaired log keeps accepting appends.
    d.execute("insert into t values (2)").unwrap();
    drop(d);
    let mut d = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
    assert_eq!(count(&mut d), 2);
}

#[test]
fn tampered_mid_log_record_is_corruption() {
    let p = tmp("midtamper");
    {
        let mut d = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
        d.execute("create table t (id integer)").unwrap();
        d.execute("insert into t values (1)").unwrap();
        d.execute("insert into t values (2)").unwrap();
    }
    let w = wal_of(&p);
    let mut bytes = fs::read(&w).unwrap();
    // Flip one ciphertext byte inside the *first* record (not the last).
    bytes[41 + 36] ^= 0x01;
    fs::write(&w, &bytes).unwrap();
    assert!(matches!(
        DurableDb::open(&p, &Secret::RawKey(&KEY)),
        Err(Error::Corrupt(_))
    ));
}

#[test]
fn tampered_final_record_is_truncation() {
    let p = tmp("tailtamper");
    {
        let mut d = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
        d.execute("create table t (id integer)").unwrap();
        d.execute("insert into t values (1)").unwrap();
    }
    let w = wal_of(&p);
    let mut bytes = fs::read(&w).unwrap();
    let last = bytes.len() - 1;
    bytes[last] ^= 0x01;
    fs::write(&w, &bytes).unwrap();
    // Equivalent to truncating the final commit: documented non-goal.
    let mut d = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
    assert_eq!(count(&mut d), 0);
}

#[test]
fn stale_log_from_interrupted_checkpoint_is_discarded() {
    let p = tmp("stale");
    let w = wal_of(&p);
    let mut d = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
    d.execute("create table t (id integer)").unwrap();
    d.execute("insert into t values (1)").unwrap();
    let old_wal = fs::read(&w).unwrap();
    d.checkpoint().unwrap();
    d.execute("insert into t values (2)").unwrap();
    drop(d);
    // Crash window reproduced: new snapshot on disk, old log restored.
    fs::write(&w, &old_wal).unwrap();
    let mut d = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
    // The stale log is discarded; state is exactly the checkpoint. The
    // post-checkpoint insert was overwritten by the restored stale log —
    // that is the simulated tampering, not a durability loss.
    assert_eq!(count(&mut d), 1);
    assert_eq!(d.wal_records(), 0);
}

#[test]
fn selects_are_not_logged_and_failed_statements_replay_consistently() {
    let p = tmp("mixed");
    let mut d = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
    d.execute("create table t (id integer primary key)")
        .unwrap();
    d.execute("insert into t values (1)").unwrap();
    let len_before = fs::metadata(wal_of(&p)).unwrap().len();
    for _ in 0..5 {
        count(&mut d);
    }
    assert_eq!(fs::metadata(wal_of(&p)).unwrap().len(), len_before);
    assert_eq!(d.wal_records(), 2);
    // Logged-then-failed statement: skipped identically on replay.
    assert!(matches!(
        d.execute("insert into t values (1)"),
        Err(Error::Exec(_))
    ));
    assert_eq!(d.wal_records(), 3);
    drop(d);
    let mut d = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
    assert_eq!(count(&mut d), 1);
    assert_eq!(d.wal_records(), 3);
}

#[test]
fn wrong_secret_fails_closed() {
    let p = tmp("wrongkey");
    {
        let mut d = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
        d.execute("create table t (id integer)").unwrap();
    }
    assert!(matches!(
        DurableDb::open(&p, &Secret::RawKey(&[8u8; 32])),
        Err(Error::Crypto)
    ));
    assert!(matches!(
        DurableDb::open(&p, &Secret::Passphrase("nope")),
        Err(Error::KdfMismatch)
    ));
}

#[test]
fn param_mismatch_is_rejected_before_logging() {
    let p = tmp("parammism");
    let mut d = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
    d.execute("create table t (id integer)").unwrap();
    let len_before = fs::metadata(wal_of(&p)).unwrap().len();
    assert!(matches!(
        d.execute("insert into t values (?)"),
        Err(Error::Exec(_))
    ));
    assert_eq!(fs::metadata(wal_of(&p)).unwrap().len(), len_before);
}

#[test]
fn second_open_is_locked_out() {
    let p = tmp("lock");
    let d1 = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
    assert!(matches!(
        DurableDb::open(&p, &Secret::RawKey(&KEY)),
        Err(Error::Locked)
    ));
    drop(d1);
    // Released on drop; also exercises reopen after a held lock.
    let _d2 = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
}

#[test]
fn rotate_secret_rebinds_vault_and_log() {
    let p = tmp("rotate");
    let new_key = [9u8; 32];
    {
        let mut d = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
        d.execute("create table t (id integer)").unwrap();
        d.execute("insert into t values (1)").unwrap();
        d.rotate_secret(&Secret::RawKey(&new_key)).unwrap();
        assert_eq!(d.wal_records(), 0);
        // The session keeps working under the new secret.
        d.execute("insert into t values (2)").unwrap();
    }
    assert!(matches!(
        DurableDb::open(&p, &Secret::RawKey(&KEY)),
        Err(Error::Crypto)
    ));
    let mut d = DurableDb::open(&p, &Secret::RawKey(&new_key)).unwrap();
    assert_eq!(count(&mut d), 2);
}

#[test]
fn rotate_to_passphrase_changes_kdf() {
    let p = tmp("rotkdf");
    {
        let mut d = DurableDb::open(&p, &Secret::RawKey(&KEY)).unwrap();
        d.execute("create table t (id integer)").unwrap();
        d.rotate_secret(&Secret::Passphrase("correct horse"))
            .unwrap();
    }
    assert!(matches!(
        DurableDb::open(&p, &Secret::RawKey(&KEY)),
        Err(Error::KdfMismatch)
    ));
    let mut d = DurableDb::open(&p, &Secret::Passphrase("correct horse")).unwrap();
    assert_eq!(count(&mut d), 0);
}
