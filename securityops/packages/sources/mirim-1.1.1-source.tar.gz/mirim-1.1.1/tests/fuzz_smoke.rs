// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! Randomized robustness smoke tests (stable toolchain, deterministic).
//!
//! Not coverage-guided fuzzing — that lives in `fuzz/` under libFuzzer.
//! This harness throws a seeded stream of random and mutated inputs at
//! every attacker-reachable decoder on every `cargo test`, so decoder
//! regressions are caught even where nightly tooling is unavailable.
//! The only assertion is the contract: typed errors or success, never a
//! panic, never an abort.

use mirim::pq::{keygen, seal, seal_multi};
use mirim::vault::Secret;
use mirim::{Db, DurableDb};

/// xorshift64*: tiny, seeded, deterministic. Quality is irrelevant here;
/// reproducibility is the point.
struct Rng(u64);

impl Rng {
    fn next(&mut self) -> u64 {
        let mut x = self.0;
        x ^= x >> 12;
        x ^= x << 25;
        x ^= x >> 27;
        self.0 = x;
        x.wrapping_mul(0x2545_F491_4F6C_DD1D)
    }

    fn byte(&mut self) -> u8 {
        (self.next() >> 56) as u8
    }

    fn below(&mut self, n: usize) -> usize {
        (self.next() % n as u64) as usize
    }

    fn bytes(&mut self, len: usize) -> Vec<u8> {
        (0..len).map(|_| self.byte()).collect()
    }

    /// Mutate a valid artifact: 1-8 random byte flips, sometimes a
    /// truncation, sometimes a random extension.
    fn mutate(&mut self, base: &[u8]) -> Vec<u8> {
        let mut v = base.to_vec();
        for _ in 0..1 + self.below(8) {
            if v.is_empty() {
                break;
            }
            let i = self.below(v.len());
            v[i] ^= self.byte() | 1;
        }
        match self.below(8) {
            0 => {
                let keep = self.below(v.len() + 1);
                v.truncate(keep);
            }
            1 => {
                let n = self.below(64);
                let ext = self.bytes(n);
                v.extend(ext);
            }
            _ => {}
        }
        v
    }
}

#[test]
fn sealed_open_never_panics() {
    let mut rng = Rng(0x5EED_0001);
    let mut db = Db::new();
    db.execute("create table t (id integer primary key, s text unique)")
        .unwrap();
    db.execute("insert into t values (1, 'x')").unwrap();
    let (sk, pk) = keygen();
    let (_, pk2) = keygen();
    let v1 = seal(&db, &pk).unwrap();
    let v2 = seal_multi(&db, &[&pk, &pk2]).unwrap();

    for i in 0..2_000 {
        let input = match i % 4 {
            0 => rng.mutate(&v1),
            1 => rng.mutate(&v2),
            2 => {
                let n = rng.below(2 * v2.len());
                rng.bytes(n)
            }
            _ => {
                // Valid magic + random version + random tail: hits the
                // dispatch and length checks hardest.
                let mut b = b"MIRIMSL1".to_vec();
                let n = rng.below(256);
                let ext = rng.bytes(n);
                b.extend(ext);
                b
            }
        };
        let _ = mirim::pq::open(&input, &sk);
    }
}

#[cfg(feature = "sign")]
#[test]
fn manifest_verify_never_panics() {
    let mut rng = Rng(0x5EED_0002);
    let (sk, pk) = mirim::manifest::keygen();
    let target = b"target bytes".to_vec();
    let m = mirim::manifest::sign_manifest(&target, mirim::manifest::TargetKind::Vault, 3, &sk);
    for i in 0..500 {
        let input = if i % 2 == 0 {
            rng.mutate(&m)
        } else {
            let n = rng.below(2 * m.len());
            rng.bytes(n)
        };
        let _ = mirim::manifest::verify_manifest(&input, &target, &pk);
    }
}

#[test]
fn sql_parser_and_engine_never_panic() {
    let mut rng = Rng(0x5EED_0003);
    let fragments = [
        "select",
        "insert",
        "update",
        "delete",
        "create",
        "table",
        "into",
        "values",
        "where",
        "set",
        "from",
        "and",
        "is",
        "not",
        "null",
        "primary",
        "key",
        "unique",
        "integer",
        "text",
        "(",
        ")",
        ",",
        ";",
        "*",
        "=",
        "<",
        ">",
        "!=",
        "?",
        "'a'",
        "'",
        "0",
        "-9223372036854775808",
        "18446744073709551615",
        "t",
        "\u{1F980}",
        "\"",
        ".",
        "--",
    ];
    let mut db = Db::new();
    db.execute("create table t (id integer primary key, s text)")
        .unwrap();
    for _ in 0..5_000 {
        let n = 1 + rng.below(12);
        let mut sql = String::new();
        for _ in 0..n {
            sql.push_str(fragments[rng.below(fragments.len())]);
            sql.push(' ');
        }
        let _ = db.execute(&sql);
        // Raw bytes too: the lexer must reject arbitrary UTF-8 cleanly.
        let rawlen = rng.below(48);
        let raw = rng.bytes(rawlen);
        if let Ok(s) = String::from_utf8(raw) {
            let _ = db.execute(&s);
        }
    }
}

#[test]
fn wal_open_never_panics_and_recovery_is_typed() {
    let mut rng = Rng(0x5EED_0004);
    let dir = std::env::temp_dir().join(format!("mirim-fuzzsmoke-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let path = dir.join("f.mrm");
    let key = [4u8; 32];

    // A vault with a few committed records to mutate.
    {
        let mut d = DurableDb::open(&path, &Secret::RawKey(&key)).unwrap();
        d.execute("create table t (id integer primary key)")
            .unwrap();
        for i in 0..5 {
            d.execute_params("insert into t values (?)", &[mirim::Value::Int(i)])
                .unwrap();
        }
    }
    let mut wal_path = path.as_os_str().to_owned();
    wal_path.push(".wal");
    let wal_path = std::path::PathBuf::from(wal_path);
    let pristine = std::fs::read(&wal_path).unwrap();

    for i in 0..400 {
        let mutated = if i % 3 == 0 {
            let n = rng.below(2 * pristine.len());
            rng.bytes(n)
        } else {
            rng.mutate(&pristine)
        };
        std::fs::write(&wal_path, &mutated).unwrap();
        // Contract: typed error, or success with a readable database.
        if let Ok(mut d) = DurableDb::open(&path, &Secret::RawKey(&key)) {
            let _ = d.execute("select * from t");
        }
    }
    std::fs::write(&wal_path, &pristine).unwrap();
    let _ = std::fs::remove_dir_all(&dir);
}
