// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

use mirim::{Db, Error, Output, Value};

fn rows(out: Output) -> Vec<Vec<Value>> {
    match out {
        Output::Rows { rows, .. } => rows,
        other => panic!("expected rows, got {other:?}"),
    }
}

#[test]
fn create_insert_select_roundtrip() {
    let mut db = Db::new();
    db.execute("CREATE TABLE users (id INTEGER, name TEXT)")
        .unwrap();
    db.execute("INSERT INTO users VALUES (1, 'ana')").unwrap();
    db.execute("INSERT INTO users VALUES (2, 'bia')").unwrap();
    let r = rows(db.execute("SELECT * FROM users").unwrap());
    assert_eq!(
        r,
        vec![
            vec![Value::Int(1), Value::Text("ana".into())],
            vec![Value::Int(2), Value::Text("bia".into())],
        ]
    );
}

#[test]
fn projection_and_column_order() {
    let mut db = Db::new();
    db.execute("create table t (a integer, b text, c integer)")
        .unwrap();
    db.execute("insert into t values (1, 'x', 10)").unwrap();
    let out = db.execute("select c, a from t").unwrap();
    match out {
        Output::Rows { columns, rows } => {
            assert_eq!(columns, vec!["c", "a"]);
            assert_eq!(rows, vec![vec![Value::Int(10), Value::Int(1)]]);
        }
        _ => unreachable!(),
    }
}

#[test]
fn where_operators() {
    let mut db = Db::new();
    db.execute("create table n (v integer)").unwrap();
    for v in [1, 2, 3, 4, 5] {
        db.execute(&format!("insert into n values ({v})")).unwrap();
    }
    let count = |db: &mut Db, sql: &str| rows(db.execute(sql).unwrap()).len();
    assert_eq!(count(&mut db, "select * from n where v = 3"), 1);
    assert_eq!(count(&mut db, "select * from n where v <> 3"), 4);
    assert_eq!(count(&mut db, "select * from n where v != 3"), 4);
    assert_eq!(count(&mut db, "select * from n where v < 3"), 2);
    assert_eq!(count(&mut db, "select * from n where v <= 3"), 3);
    assert_eq!(count(&mut db, "select * from n where v > 3"), 2);
    assert_eq!(count(&mut db, "select * from n where v >= 3"), 3);
    assert_eq!(count(&mut db, "select * from n where v > 1 and v < 5"), 3);
}

#[test]
fn text_comparison_and_quote_escape() {
    let mut db = Db::new();
    db.execute("create table s (t text)").unwrap();
    db.execute("insert into s values ('it''s')").unwrap();
    let r = rows(db.execute("select t from s where t = 'it''s'").unwrap());
    assert_eq!(r, vec![vec![Value::Text("it's".into())]]);
}

#[test]
fn delete_returns_count() {
    let mut db = Db::new();
    db.execute("create table t (v integer)").unwrap();
    for v in [1, 2, 3] {
        db.execute(&format!("insert into t values ({v})")).unwrap();
    }
    assert_eq!(
        db.execute("delete from t where v >= 2").unwrap(),
        Output::Affected(2)
    );
    assert_eq!(rows(db.execute("select * from t").unwrap()).len(), 1);
    assert_eq!(db.execute("delete from t").unwrap(), Output::Affected(1));
}

#[test]
fn negative_integers() {
    let mut db = Db::new();
    db.execute("create table t (v integer)").unwrap();
    db.execute("insert into t values (-5)").unwrap();
    let r = rows(db.execute("select * from t where v < 0").unwrap());
    assert_eq!(r, vec![vec![Value::Int(-5)]]);
}

#[test]
fn null_never_matches() {
    let mut db = Db::new();
    db.execute("create table t (v integer)").unwrap();
    db.execute("insert into t values (null)").unwrap();
    db.execute("insert into t values (1)").unwrap();
    assert_eq!(
        rows(db.execute("select * from t where v = 1").unwrap()).len(),
        1
    );
    assert_eq!(
        rows(db.execute("select * from t where v <> 1").unwrap()).len(),
        0
    );
    // NULL is storable in either column type and selectable via *.
    assert_eq!(rows(db.execute("select * from t").unwrap()).len(), 2);
}

#[test]
fn schema_errors() {
    let mut db = Db::new();
    db.execute("create table t (a integer)").unwrap();
    assert!(matches!(
        db.execute("create table t (a integer)"),
        Err(Error::Exec(_))
    ));
    assert!(matches!(
        db.execute("create table u (a integer, a text)"),
        Err(Error::Exec(_))
    ));
    assert!(matches!(
        db.execute("insert into missing values (1)"),
        Err(Error::Exec(_))
    ));
    assert!(matches!(
        db.execute("insert into t values (1, 2)"),
        Err(Error::Exec(_))
    ));
    assert!(matches!(
        db.execute("insert into t values ('text')"),
        Err(Error::Exec(_))
    ));
    assert!(matches!(
        db.execute("select nope from t"),
        Err(Error::Exec(_))
    ));
}

#[test]
fn parse_errors() {
    let mut db = Db::new();
    assert!(matches!(db.execute("selec * from t"), Err(Error::Parse(_))));
    assert!(matches!(db.execute(""), Err(Error::Parse(_))));
    assert!(matches!(
        db.execute("select * from t extra"),
        Err(Error::Parse(_))
    ));
    assert!(matches!(
        db.execute("insert into t values (9223372036854775808)"),
        Err(Error::Parse(_))
    ));
}

#[test]
fn identifiers_case_insensitive_keywords_and_names() {
    let mut db = Db::new();
    db.execute("CrEaTe TaBlE Mixed (Col INT)").unwrap();
    db.execute("insert into MIXED values (1)").unwrap();
    assert_eq!(rows(db.execute("SELECT COL FROM mixed").unwrap()).len(), 1);
    assert_eq!(db.table_names(), vec!["mixed"]);
}

#[test]
fn update_with_and_without_where() {
    let mut db = Db::new();
    db.execute("create table t (id integer, name text)")
        .unwrap();
    db.execute("insert into t values (1, 'a')").unwrap();
    db.execute("insert into t values (2, 'b')").unwrap();
    db.execute("insert into t values (3, 'c')").unwrap();
    assert_eq!(
        db.execute("update t set name = 'x' where id >= 2").unwrap(),
        Output::Affected(2)
    );
    assert_eq!(
        rows(db.execute("select * from t where name = 'x'").unwrap()).len(),
        2
    );
    assert_eq!(
        db.execute("update t set name = 'all', id = 0").unwrap(),
        Output::Affected(3)
    );
    assert_eq!(
        rows(db.execute("select * from t where id = 0").unwrap()).len(),
        3
    );
}

#[test]
fn update_errors() {
    let mut db = Db::new();
    db.execute("create table t (id integer, name text)")
        .unwrap();
    db.execute("insert into t values (1, 'a')").unwrap();
    assert!(matches!(
        db.execute("update t set id = 'text'"),
        Err(Error::Exec(_))
    ));
    assert!(matches!(
        db.execute("update t set id = 1, id = 2"),
        Err(Error::Exec(_))
    ));
    assert!(matches!(
        db.execute("update t set nope = 1"),
        Err(Error::Exec(_))
    ));
    assert!(matches!(
        db.execute("update missing set id = 1"),
        Err(Error::Exec(_))
    ));
    // Type errors are detected before any row is touched.
    assert_eq!(
        rows(db.execute("select * from t where id = 1").unwrap()).len(),
        1
    );
}

#[test]
fn update_set_null() {
    let mut db = Db::new();
    db.execute("create table t (id integer, name text)")
        .unwrap();
    db.execute("insert into t values (1, 'a')").unwrap();
    assert_eq!(
        db.execute("update t set name = null where id = 1").unwrap(),
        Output::Affected(1)
    );
    assert_eq!(
        rows(db.execute("select * from t where name is null").unwrap()).len(),
        1
    );
}

#[test]
fn insert_with_column_list() {
    let mut db = Db::new();
    db.execute("create table t (a integer, b text, c integer)")
        .unwrap();
    db.execute("insert into t (c, a) values (30, 1)").unwrap();
    let r = rows(db.execute("select a, b, c from t").unwrap());
    assert_eq!(r, vec![vec![Value::Int(1), Value::Null, Value::Int(30)]]);
}

#[test]
fn insert_column_list_errors() {
    let mut db = Db::new();
    db.execute("create table t (a integer, b text)").unwrap();
    assert!(matches!(
        db.execute("insert into t (a, a) values (1, 2)"),
        Err(Error::Exec(_))
    ));
    assert!(matches!(
        db.execute("insert into t (nope) values (1)"),
        Err(Error::Exec(_))
    ));
    assert!(matches!(
        db.execute("insert into t (a, b) values (1)"),
        Err(Error::Exec(_))
    ));
    assert!(matches!(
        db.execute("insert into t (b) values (1)"),
        Err(Error::Exec(_))
    ));
}

#[test]
fn is_null_and_is_not_null() {
    let mut db = Db::new();
    db.execute("create table t (v integer)").unwrap();
    db.execute("insert into t values (null)").unwrap();
    db.execute("insert into t values (1)").unwrap();
    assert_eq!(
        rows(db.execute("select * from t where v is null").unwrap()).len(),
        1
    );
    assert_eq!(
        rows(db.execute("select * from t where v is not null").unwrap()).len(),
        1
    );
    assert_eq!(
        rows(
            db.execute("select * from t where v is not null and v >= 1")
                .unwrap()
        )
        .len(),
        1
    );
}

#[test]
fn param_binding_in_all_positions() {
    let mut db = Db::new();
    db.execute("create table t (id integer, name text)")
        .unwrap();
    db.execute_params(
        "insert into t values (?, ?)",
        &[Value::Int(1), Value::Text("ana".into())],
    )
    .unwrap();
    db.execute_params(
        "insert into t (name, id) values (?, ?)",
        &[Value::Text("bia".into()), Value::Int(2)],
    )
    .unwrap();
    let r = rows(
        db.execute_params(
            "select id from t where name = ?",
            &[Value::Text("bia".into())],
        )
        .unwrap(),
    );
    assert_eq!(r, vec![vec![Value::Int(2)]]);
    assert_eq!(
        db.execute_params(
            "update t set name = ? where id = ?",
            &[Value::Text("ana maria".into()), Value::Int(1)],
        )
        .unwrap(),
        Output::Affected(1)
    );
    assert_eq!(
        db.execute_params("delete from t where id = ?", &[Value::Int(2)])
            .unwrap(),
        Output::Affected(1)
    );
}

#[test]
fn param_binding_treats_input_as_data_not_sql() {
    let mut db = Db::new();
    db.execute("create table t (name text)").unwrap();
    let hostile = "x' ; delete from t where '1' = '1";
    db.execute_params("insert into t values (?)", &[Value::Text(hostile.into())])
        .unwrap();
    let r = rows(
        db.execute_params(
            "select * from t where name = ?",
            &[Value::Text(hostile.into())],
        )
        .unwrap(),
    );
    assert_eq!(r, vec![vec![Value::Text(hostile.into())]]);
}

#[test]
fn param_count_mismatch_and_type_check() {
    let mut db = Db::new();
    db.execute("create table t (id integer)").unwrap();
    assert!(matches!(
        db.execute("insert into t values (?)"),
        Err(Error::Exec(_))
    ));
    assert!(matches!(
        db.execute_params("insert into t values (?)", &[Value::Int(1), Value::Int(2)]),
        Err(Error::Exec(_))
    ));
    assert!(matches!(
        db.execute_params("insert into t values (?)", &[Value::Text("x".into())]),
        Err(Error::Exec(_))
    ));
    // NULL binds anywhere.
    db.execute_params("insert into t values (?)", &[Value::Null])
        .unwrap();
}

#[test]
fn prepared_statement_reuse() {
    let mut db = Db::new();
    db.execute("create table t (id integer)").unwrap();
    let ins = mirim::Statement::prepare("insert into t values (?)").unwrap();
    assert_eq!(ins.param_count(), 1);
    for i in 0..5 {
        db.run(&ins, &[Value::Int(i)]).unwrap();
    }
    let sel = mirim::Statement::prepare("select * from t where id >= ?").unwrap();
    assert_eq!(rows(db.run(&sel, &[Value::Int(3)]).unwrap()).len(), 2);
    assert_eq!(rows(db.run(&sel, &[Value::Int(0)]).unwrap()).len(), 5);
}

#[test]
fn param_inside_string_literal_is_text() {
    let mut db = Db::new();
    db.execute("create table t (name text)").unwrap();
    db.execute("insert into t values ('what?')").unwrap();
    let r = rows(db.execute("select * from t where name = 'what?'").unwrap());
    assert_eq!(r, vec![vec![Value::Text("what?".into())]]);
}

#[test]
fn primary_key_rejects_duplicates_and_null() {
    let mut db = Db::new();
    db.execute("create table t (id integer primary key, name text)")
        .unwrap();
    db.execute("insert into t values (1, 'a')").unwrap();
    assert!(matches!(
        db.execute("insert into t values (1, 'b')"),
        Err(Error::Exec(_))
    ));
    assert!(matches!(
        db.execute("insert into t values (null, 'b')"),
        Err(Error::Exec(_))
    ));
    // Column-list INSERT that omits the PK implies NULL: rejected.
    assert!(matches!(
        db.execute("insert into t (name) values ('b')"),
        Err(Error::Exec(_))
    ));
    db.execute("insert into t values (2, 'b')").unwrap();
    assert_eq!(rows(db.execute("select * from t").unwrap()).len(), 2);
}

#[test]
fn unique_allows_multiple_nulls() {
    let mut db = Db::new();
    db.execute("create table t (email text unique)").unwrap();
    db.execute("insert into t values ('a@x')").unwrap();
    assert!(matches!(
        db.execute("insert into t values ('a@x')"),
        Err(Error::Exec(_))
    ));
    db.execute("insert into t values (null)").unwrap();
    db.execute("insert into t values (null)").unwrap();
    assert_eq!(rows(db.execute("select * from t").unwrap()).len(), 3);
}

#[test]
fn update_enforces_constraints_atomically() {
    let mut db = Db::new();
    db.execute("create table t (id integer primary key, v integer)")
        .unwrap();
    db.execute("insert into t values (1, 10)").unwrap();
    db.execute("insert into t values (2, 20)").unwrap();
    // Collides with row id=1.
    assert!(matches!(
        db.execute("update t set id = 1 where id = 2"),
        Err(Error::Exec(_))
    ));
    // Multi-row update of a PK to one value: rejected before mutation.
    assert!(matches!(
        db.execute("update t set id = 9"),
        Err(Error::Exec(_))
    ));
    // PK to NULL: rejected.
    assert!(matches!(
        db.execute("update t set id = null where id = 1"),
        Err(Error::Exec(_))
    ));
    // Nothing changed.
    let r = rows(db.execute("select id from t").unwrap());
    assert_eq!(r, vec![vec![Value::Int(1)], vec![Value::Int(2)]]);
    // Self-assignment (exempting the matched row) is fine.
    assert_eq!(
        db.execute("update t set id = 1 where id = 1").unwrap(),
        Output::Affected(1)
    );
    // Multi-row update of a UNIQUE column to NULL is fine.
    db.execute("create table u (e text unique)").unwrap();
    db.execute("insert into u values ('a')").unwrap();
    db.execute("insert into u values ('b')").unwrap();
    assert_eq!(
        db.execute("update u set e = null").unwrap(),
        Output::Affected(2)
    );
}

#[test]
fn one_primary_key_per_table() {
    let mut db = Db::new();
    assert!(matches!(
        db.execute("create table t (a integer primary key, b integer primary key)"),
        Err(Error::Exec(_))
    ));
}

#[test]
fn constraints_survive_save_load() {
    let mut db = Db::new();
    db.execute("create table t (id integer primary key, e text unique)")
        .unwrap();
    db.execute("insert into t values (1, 'a')").unwrap();
    let mut path = std::env::temp_dir();
    path.push(format!("mirim-con-{}.mrm", std::process::id()));
    mirim::vault::save(&db, &path, &mirim::vault::Secret::RawKey(&[5u8; 32])).unwrap();
    let mut back = mirim::vault::load(&path, &mirim::vault::Secret::RawKey(&[5u8; 32])).unwrap();
    std::fs::remove_file(&path).unwrap();
    assert!(matches!(
        back.execute("insert into t values (1, 'b')"),
        Err(Error::Exec(_))
    ));
    assert!(matches!(
        back.execute("insert into t values (2, 'a')"),
        Err(Error::Exec(_))
    ));
    back.execute("insert into t values (2, 'b')").unwrap();
}

#[test]
fn index_point_lookup_correct_after_mutations() {
    let mut db = Db::new();
    db.execute("create table t (id integer primary key, v text)")
        .unwrap();
    for i in 0..50 {
        db.execute_params(
            "insert into t values (?, ?)",
            &[Value::Int(i), Value::Text(format!("v{i}"))],
        )
        .unwrap();
    }
    // Point lookup via the PK index.
    let r = rows(db.execute("select v from t where id = 25").unwrap());
    assert_eq!(r, vec![vec![Value::Text("v25".into())]]);

    // Update a row's PK; the index must follow.
    db.execute("update t set id = 1000 where id = 25").unwrap();
    assert!(rows(db.execute("select v from t where id = 25").unwrap()).is_empty());
    assert_eq!(
        rows(db.execute("select v from t where id = 1000").unwrap()),
        vec![vec![Value::Text("v25".into())]]
    );

    // Delete shifts positions; index rebuild keeps lookups correct.
    db.execute("delete from t where id = 0").unwrap();
    assert_eq!(
        rows(db.execute("select v from t where id = 49").unwrap()),
        vec![vec![Value::Text("v49".into())]]
    );
    assert!(rows(db.execute("select v from t where id = 0").unwrap()).is_empty());

    // A freed PK value can be reused after the holder is deleted.
    db.execute("delete from t where id = 1000").unwrap();
    db.execute("insert into t values (1000, 'reused')").unwrap();
    assert_eq!(
        rows(db.execute("select v from t where id = 1000").unwrap()),
        vec![vec![Value::Text("reused".into())]]
    );
}

#[test]
fn index_lookup_with_additional_predicate() {
    let mut db = Db::new();
    db.execute("create table t (id integer primary key, k integer)")
        .unwrap();
    db.execute("insert into t values (1, 10)").unwrap();
    db.execute("insert into t values (2, 20)").unwrap();
    // Indexed equality narrows to one row; the extra predicate still applies.
    assert_eq!(
        rows(
            db.execute("select k from t where id = 1 and k = 10")
                .unwrap()
        ),
        vec![vec![Value::Int(10)]]
    );
    assert!(rows(
        db.execute("select k from t where id = 1 and k = 99")
            .unwrap()
    )
    .is_empty());
    // Type-mismatched equality on an indexed column matches nothing.
    assert!(rows(db.execute("select k from t where id = 'x'").unwrap()).is_empty());
}

#[test]
fn unique_index_duplicate_detection_survives_load() {
    let mut db = Db::new();
    db.execute("create table t (id integer primary key, email text unique)")
        .unwrap();
    db.execute("insert into t values (1, 'a@x')").unwrap();
    let mut path = std::env::temp_dir();
    path.push(format!("mirim-idx-{}.mrm", std::process::id()));
    mirim::vault::save(&db, &path, &mirim::vault::Secret::RawKey(&[9u8; 32])).unwrap();
    let mut back = mirim::vault::load(&path, &mirim::vault::Secret::RawKey(&[9u8; 32])).unwrap();
    std::fs::remove_file(&path).unwrap();
    // The index was rebuilt on load, so the UNIQUE check still fires.
    assert!(matches!(
        back.execute("insert into t values (2, 'a@x')"),
        Err(Error::Exec(_))
    ));
    back.execute("insert into t values (2, 'b@x')").unwrap();
}

#[test]
fn oversized_schema_is_rejected_before_it_can_corrupt_a_snapshot() {
    let mut db = Db::new();
    let columns = (0..=u16::MAX)
        .map(|n| format!("c{n} integer"))
        .collect::<Vec<_>>()
        .join(", ");
    let result = db.execute(&format!("create table too_wide ({columns})"));
    assert!(matches!(result, Err(Error::Exec(message)) if message.contains("65535")));
    assert!(db.table_names().is_empty());
}
