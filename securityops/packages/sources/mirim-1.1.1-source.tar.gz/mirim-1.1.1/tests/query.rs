// Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial

//! Integration tests for the query-shaping additions (v0.3 grammar):
//! SQL comments, `ORDER BY`, `LIMIT`/`OFFSET`, and `COUNT(*)`. These are
//! query-only features — they never touch the on-disk formats — so the
//! tests exercise them purely through the in-memory engine.

use mirim::{Db, Output, Value};

/// Run a SELECT and return its rows, failing loudly on anything else.
fn rows(db: &mut Db, sql: &str) -> Vec<Vec<Value>> {
    match db.execute(sql) {
        Ok(Output::Rows { rows, .. }) => rows,
        other => panic!("expected rows from {sql:?}, got {other:?}"),
    }
}

fn int_col(db: &mut Db, sql: &str) -> Vec<i64> {
    rows(db, sql)
        .into_iter()
        .map(|r| match r.as_slice() {
            [Value::Int(i)] => *i,
            other => panic!("expected a single integer column, got {other:?}"),
        })
        .collect()
}

fn seed() -> Db {
    let mut db = Db::new();
    db.execute("CREATE TABLE t (id INTEGER PRIMARY KEY, a INTEGER, b TEXT)")
        .unwrap();
    // Deliberately inserted out of key order to prove ORDER BY sorts and
    // the default preserves insertion order.
    for (id, a, b) in [
        (3, Some(10), Some("gamma")),
        (1, Some(30), Some("alpha")),
        (2, Some(20), Some("beta")),
        (5, None, Some("epsilon")),
        (4, Some(20), None),
    ] {
        let params = [
            Value::Int(id),
            a.map(Value::Int).unwrap_or(Value::Null),
            b.map(|s| Value::Text(s.into())).unwrap_or(Value::Null),
        ];
        db.execute_params("INSERT INTO t VALUES (?, ?, ?)", &params)
            .unwrap();
    }
    db
}

#[test]
fn default_order_is_insertion_order() {
    let mut db = seed();
    assert_eq!(int_col(&mut db, "SELECT id FROM t"), vec![3, 1, 2, 5, 4]);
}

#[test]
fn order_by_ascending_is_default() {
    let mut db = seed();
    assert_eq!(
        int_col(&mut db, "SELECT id FROM t ORDER BY id"),
        vec![1, 2, 3, 4, 5]
    );
    assert_eq!(
        int_col(&mut db, "SELECT id FROM t ORDER BY id ASC"),
        vec![1, 2, 3, 4, 5]
    );
}

#[test]
fn order_by_descending() {
    let mut db = seed();
    assert_eq!(
        int_col(&mut db, "SELECT id FROM t ORDER BY id DESC"),
        vec![5, 4, 3, 2, 1]
    );
}

#[test]
fn order_by_is_case_insensitive() {
    let mut db = seed();
    assert_eq!(
        int_col(&mut db, "select id from t OrDeR bY id desc"),
        vec![5, 4, 3, 2, 1]
    );
}

#[test]
fn order_by_nulls_sort_first_ascending_last_descending() {
    let mut db = seed();
    // Column `a` has a NULL (id=5). Under ASC, NULL sorts first.
    let asc = rows(&mut db, "SELECT id, a FROM t ORDER BY a ASC, id ASC");
    assert_eq!(asc[0], vec![Value::Int(5), Value::Null]);
    // Under DESC, NULL sorts last.
    let desc = rows(&mut db, "SELECT id, a FROM t ORDER BY a DESC, id ASC");
    assert_eq!(desc.last().unwrap(), &vec![Value::Int(5), Value::Null]);
}

#[test]
fn order_by_multi_key_is_stable_on_ties() {
    let mut db = seed();
    // a=20 for ids 2 and 4. Sorting by `a` alone must keep insertion order
    // (2 before 4) among the tie, because the sort is stable.
    let got = int_col(&mut db, "SELECT id FROM t ORDER BY a");
    // a: 5(NULL) first, then 10(id3), 20(id2), 20(id4), 30(id1)
    assert_eq!(got, vec![5, 3, 2, 4, 1]);
    // Explicit secondary key flips the tie order.
    let got2 = int_col(&mut db, "SELECT id FROM t ORDER BY a, id DESC");
    assert_eq!(got2, vec![5, 3, 4, 2, 1]);
}

#[test]
fn order_by_text_column() {
    let mut db = seed();
    let got: Vec<String> = rows(&mut db, "SELECT b FROM t WHERE b IS NOT NULL ORDER BY b")
        .into_iter()
        .map(|r| match r.as_slice() {
            [Value::Text(s)] => s.clone(),
            other => panic!("{other:?}"),
        })
        .collect();
    assert_eq!(got, vec!["alpha", "beta", "epsilon", "gamma"]);
}

#[test]
fn order_by_a_non_projected_column() {
    let mut db = seed();
    // Project only id, but order by a (which is not selected).
    assert_eq!(
        int_col(
            &mut db,
            "SELECT id FROM t WHERE a IS NOT NULL ORDER BY a DESC"
        ),
        vec![1, 2, 4, 3]
    );
}

#[test]
fn limit_and_offset() {
    let mut db = seed();
    assert_eq!(
        int_col(&mut db, "SELECT id FROM t ORDER BY id LIMIT 2"),
        vec![1, 2]
    );
    assert_eq!(
        int_col(&mut db, "SELECT id FROM t ORDER BY id LIMIT 2 OFFSET 1"),
        vec![2, 3]
    );
    // Offset past the end yields nothing; limit zero yields nothing.
    assert!(int_col(&mut db, "SELECT id FROM t ORDER BY id LIMIT 5 OFFSET 99").is_empty());
    assert!(int_col(&mut db, "SELECT id FROM t LIMIT 0").is_empty());
    // Limit larger than the set returns the whole (ordered) set.
    assert_eq!(
        int_col(&mut db, "SELECT id FROM t ORDER BY id LIMIT 100"),
        vec![1, 2, 3, 4, 5]
    );
}

#[test]
fn limit_without_order_by_uses_insertion_order() {
    let mut db = seed();
    assert_eq!(int_col(&mut db, "SELECT id FROM t LIMIT 3"), vec![3, 1, 2]);
}

#[test]
fn count_star() {
    let mut db = seed();
    assert_eq!(int_col(&mut db, "SELECT COUNT(*) FROM t"), vec![5]);
    assert_eq!(
        int_col(&mut db, "SELECT count(*) FROM t WHERE a = 20"),
        vec![2]
    );
    assert_eq!(
        int_col(&mut db, "SELECT COUNT(*) FROM t WHERE a IS NULL"),
        vec![1]
    );
    // Empty match still returns a single row holding zero.
    assert_eq!(
        int_col(&mut db, "SELECT COUNT(*) FROM t WHERE id = 999"),
        vec![0]
    );
}

#[test]
fn count_star_column_name() {
    let mut db = seed();
    match db.execute("SELECT COUNT(*) FROM t").unwrap() {
        Output::Rows { columns, .. } => assert_eq!(columns, vec!["count(*)".to_string()]),
        other => panic!("{other:?}"),
    }
}

#[test]
fn count_respects_limit_offset() {
    let mut db = seed();
    // COUNT(*) is one row; LIMIT 0 removes it, OFFSET 1 removes it.
    assert!(int_col(&mut db, "SELECT COUNT(*) FROM t LIMIT 0").is_empty());
    assert!(int_col(&mut db, "SELECT COUNT(*) FROM t LIMIT 1 OFFSET 1").is_empty());
}

// ---- comments ----

#[test]
fn line_comments_are_ignored() {
    let mut db = Db::new();
    db.execute("CREATE TABLE t (id INTEGER) -- trailing comment")
        .unwrap();
    db.execute("INSERT INTO t VALUES (1) -- another").unwrap();
    assert_eq!(int_col(&mut db, "SELECT id FROM t -- pick all"), vec![1]);
}

#[test]
fn block_comments_are_ignored() {
    let mut db = Db::new();
    db.execute("CREATE TABLE /* inline */ t (id INTEGER, v TEXT)")
        .unwrap();
    db.execute("INSERT INTO t VALUES (1, /* skip me */ 'x')")
        .unwrap();
    assert_eq!(int_col(&mut db, "SELECT id FROM t"), vec![1]);
}

#[test]
fn execute_script_ignores_comment_only_segments() {
    // A trailing comment after the final ';' must not be treated as an empty
    // statement and rejected.
    let mut db = Db::new();
    let n = db
        .execute_script("CREATE TABLE t (a INTEGER);\n-- done\n")
        .unwrap();
    assert_eq!(n, 1);

    // Leading, interleaved, and trailing comment-only segments are all skipped.
    let mut db2 = Db::new();
    let n2 = db2
        .execute_script(
            "/* header */\n\
             CREATE TABLE t (a INTEGER);\n\
             -- a note\n\
             INSERT INTO t VALUES (1);\n\
             /* trailing block */",
        )
        .unwrap();
    assert_eq!(n2, 2);
    assert_eq!(int_col(&mut db2, "SELECT COUNT(*) FROM t"), vec![1]);

    // split_statements itself drops comment-only chunks.
    assert_eq!(mirim::split_statements("SELECT 1 FROM t; -- tail").len(), 1);
}

#[test]
fn unterminated_block_comment_is_rejected() {
    let mut db = Db::new();
    assert!(db.execute("CREATE TABLE t (id INTEGER) /* oops").is_err());
}

#[test]
fn lone_slash_is_rejected() {
    let mut db = Db::new();
    assert!(db.execute("SELECT / FROM t").is_err());
}

// ---- backward compatibility: contextual keywords are not reserved ----

#[test]
fn contextual_keywords_are_valid_identifiers() {
    let mut db = Db::new();
    // A table and columns named after the new contextual keywords.
    db.execute("CREATE TABLE orders (id INTEGER, count INTEGER, offset INTEGER)")
        .unwrap();
    db.execute("INSERT INTO orders VALUES (1, 7, 100)").unwrap();
    db.execute("INSERT INTO orders VALUES (2, 3, 200)").unwrap();
    // `count` here is a plain column, not the aggregate (no following `(`).
    assert_eq!(
        int_col(&mut db, "SELECT count FROM orders ORDER BY count"),
        vec![3, 7]
    );
    // `offset` as a column, ordered descending, with a real LIMIT after.
    assert_eq!(
        int_col(
            &mut db,
            "SELECT id FROM orders ORDER BY offset DESC LIMIT 1"
        ),
        vec![2]
    );
}

#[test]
fn count_column_versus_count_aggregate() {
    let mut db = Db::new();
    db.execute("CREATE TABLE t (count INTEGER)").unwrap();
    db.execute("INSERT INTO t VALUES (41)").unwrap();
    db.execute("INSERT INTO t VALUES (42)").unwrap();
    // Bare `count` is the column.
    assert_eq!(
        int_col(&mut db, "SELECT count FROM t ORDER BY count"),
        vec![41, 42]
    );
    // `count(*)` is the aggregate.
    assert_eq!(int_col(&mut db, "SELECT count(*) FROM t"), vec![2]);
}

// ---- error paths ----

#[test]
fn order_by_unknown_column_errors() {
    let mut db = seed();
    assert!(db.execute("SELECT id FROM t ORDER BY nope").is_err());
}

#[test]
fn negative_limit_is_rejected() {
    let mut db = seed();
    assert!(db.execute("SELECT id FROM t LIMIT -1").is_err());
}

#[test]
fn non_integer_limit_is_rejected() {
    let mut db = seed();
    assert!(db.execute("SELECT id FROM t LIMIT 'x'").is_err());
}

#[test]
fn order_by_and_limit_bind_with_parameters() {
    let mut db = seed();
    // Parameter binding still works alongside ORDER BY / LIMIT.
    let out = db
        .execute_params(
            "SELECT id FROM t WHERE a = ? ORDER BY id DESC LIMIT 1",
            &[Value::Int(20)],
        )
        .unwrap();
    match out {
        Output::Rows { rows, .. } => assert_eq!(rows, vec![vec![Value::Int(4)]]),
        other => panic!("{other:?}"),
    }
}
