#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
# Build the complete Linux release. Missing tools or artifacts are fatal.
# Usage: scripts/package-linux.sh [version] [outdir]
set -euo pipefail
cd "$(dirname "$0")/.."

manifest_version="$(sed -nE 's/^version = "([^"]+)"/\1/p' Cargo.toml | head -n1)"
version="${1:-$manifest_version}"
[[ "$version" == "$manifest_version" ]] || { echo "Version differs from Cargo.toml" >&2; exit 1; }
arch="$(uname -m)"
target="${arch}-unknown-linux-gnu"
dist="${2:-dist}"
mkdir -p "$dist"
[[ -z "$(ls -A "$dist")" ]] || { echo "Output directory must be empty: $dist" >&2; exit 1; }
for tool in cargo-deb cargo-generate-rpm; do
  command -v "$tool" >/dev/null || { echo "Missing $tool" >&2; exit 1; }
done

export SOURCE_DATE_EPOCH="${SOURCE_DATE_EPOCH:-1}" CARGO_INCREMENTAL=0
export RUSTFLAGS="${RUSTFLAGS:-} --remap-path-prefix=$PWD=/build --remap-path-prefix=${CARGO_HOME:-$HOME/.cargo}=/cargo"
core_target="$(cargo metadata --no-deps --locked --format-version 1 | python3 -c 'import json,sys; print(json.load(sys.stdin)["target_directory"])')"
gui_target="$(cargo metadata --no-deps --locked --format-version 1 --manifest-path gui/Cargo.toml | python3 -c 'import json,sys; print(json.load(sys.stdin)["target_directory"])')"
core_bin="$core_target/$target/release"
gui_bin="$gui_target/$target/release"
cargo build --release --locked --features sign --target "$target"
cargo build --release --locked --manifest-path gui/Cargo.toml --target "$target"

d="mirim-${version}-${arch}-linux"
stage="$(mktemp -d)"
trap 'rm -rf "$stage"' EXIT
mkdir -p "$stage/$d"
cp "$core_bin/mirim" "$core_bin/mirim-sign" "$gui_bin/mirim-gui" "$stage/$d/"
cp README.md README.pt-BR.md LICENSE LICENSE-AGPL-3.0 LICENSE-COMMERCIAL NOTICE LICENSING.md LICENSING.pt-BR.md SECURITY.md "$stage/$d/"
cp -R docs samples "$stage/$d/"
cp gui/FONT_LICENSES.txt "$stage/$d/"
tar --sort=name --mtime="@$SOURCE_DATE_EPOCH" --owner=0 --group=0 --numeric-owner \
  -C "$stage" -cf - "$d" | gzip -n > "$dist/$d.tar.gz"
cp "$gui_bin/mirim-gui" "$dist/mirim-gui-${version}-${arch}-linux"
cp gui/FONT_LICENSES.txt "$dist/mirim-gui-font-licenses-${version}.txt"
cargo deb --no-build --target "$target" --output "$dist/"
cargo generate-rpm --target "$target" --target-dir "$core_target" --output "$dist/"
bash scripts/build-appimage.sh "$arch" "$dist" "$version" "$core_bin"
cp sbom.cdx.json "$dist/"
# SHA256SUMS is explicitly excluded from the files being read.
# shellcheck disable=SC2094
(cd "$dist" && find . -maxdepth 1 -type f ! -name SHA256SUMS -printf '%f\0' | sort -z | xargs -0 sha256sum > SHA256SUMS)
echo "Complete Linux artifacts: $dist"
