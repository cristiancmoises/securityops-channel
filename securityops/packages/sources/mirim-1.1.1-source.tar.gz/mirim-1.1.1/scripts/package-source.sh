#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
# Generate source and vendored Rust dependencies from the exact release tag.
# Usage: scripts/package-source.sh <vX.Y.Z> [outdir] [source-ref]
set -euo pipefail
cd "$(dirname "$0")/.."
tag="${1:?Usage: package-source.sh <vX.Y.Z> [outdir]}"
[[ "$tag" =~ ^v[0-9]+\.[0-9]+\.[0-9]+$ ]] || { echo "Expected a release tag" >&2; exit 1; }
version="${tag#v}"
source_ref="${3:-$tag}"
outdir="${2:-dist}"
mkdir -p "$outdir"
outdir="$(cd "$outdir" && pwd)"
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
git archive --format=tar --prefix="mirim-$version/" "$source_ref" | tar -xf - -C "$work"
manifest_version="$(sed -nE 's/^version = "([^"]+)"/\1/p' "$work/mirim-$version/Cargo.toml" | head -n1)"
[[ "$version" == "$manifest_version" ]] || { echo "Tag differs from package version" >&2; exit 1; }
git archive --format=tar --prefix="mirim-$version/" "$source_ref" | gzip -n > "$outdir/mirim-$version-source.tar.gz"
cd "$work/mirim-$version"
mkdir -p .cargo
cargo vendor --locked --versioned-dirs --sync ffi/Cargo.toml --sync gui/Cargo.toml vendor > .cargo/config.toml
tar --sort=name --mtime="@${SOURCE_DATE_EPOCH:-1}" --owner=0 --group=0 --numeric-owner \
  -cf - .cargo/config.toml vendor | gzip -n > "$outdir/mirim-$version-vendor.tar.gz"
echo "Source and vendor archives: $outdir"
