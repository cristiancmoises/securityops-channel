#!/usr/bin/env python3
# Copyright (c) 2026 Cristian Cezar Moisés — AGPL-3.0-only OR LicenseRef-Mirim-Commercial
"""Generate a deterministic CycloneDX 1.5 SBOM for the runtime dependency
closure of the mirim crate.

Scope: packages reachable from the root through *normal* dependency edges
with all cargo features enabled — i.e. what is actually linked into the
shipped `mirim`/`mirim-sign` binaries and the library. Dev-dependencies
(proptest, criterion, rusqlite/SQLite) and build-only dependencies are
deliberately excluded, because they are not part of the deployed artifact
and including them would overstate the trust base.

Determinism: no timestamp and no random serial number are emitted (both
optional in CycloneDX 1.5). The document is a pure function of Cargo.lock
and the enabled feature set, with components sorted by purl. This is what
makes the CI freshness check meaningful — drift means the dependency
closure changed, nothing else.

Data source is `cargo metadata`; only the Python standard library is used
to reshape it. Run from the crate root:

    python3 scripts/gen-sbom.py --all-features > sbom.cdx.json
"""

import json
import subprocess
import sys

SPEC_VERSION = "1.5"
GENERATOR = "scripts/gen-sbom.py"


def cargo_metadata(extra_args):
    out = subprocess.run(
        ["cargo", "metadata", "--format-version", "1", *extra_args],
        check=True,
        capture_output=True,
        text=True,
    )
    return json.loads(out.stdout)


def runtime_closure(meta):
    """Package ids reachable from the root through normal edges only."""
    nodes = {n["id"]: n for n in meta["resolve"]["nodes"]}
    root = meta["resolve"]["root"]
    if root is None:
        sys.exit("no resolve root; run inside a package, not a virtual workspace")
    seen = set()
    stack = [root]
    while stack:
        cur = stack.pop()
        if cur in seen:
            continue
        seen.add(cur)
        for dep in nodes.get(cur, {}).get("deps", []):
            # kind == None is a normal (runtime) dependency edge.
            if any(k.get("kind") is None for k in dep.get("dep_kinds", [])):
                stack.append(dep["pkg"])
    return root, seen


def licenses_field(pkg):
    expr = pkg.get("license")
    if expr:
        if any(op in expr for op in (" OR ", " AND ", " WITH ", "/")):
            return [{"expression": expr.replace("/", " OR ")}]
        return [{"license": {"id": expr}}]
    if pkg.get("license_file"):
        return [{"license": {"name": "see " + pkg["license_file"]}}]
    return []


def component(pkg, is_root=False):
    purl = f"pkg:cargo/{pkg['name']}@{pkg['version']}"
    comp = {
        "type": "application" if is_root else "library",
        "bom-ref": purl,
        "name": pkg["name"],
        "version": pkg["version"],
        "purl": purl,
    }
    lic = licenses_field(pkg)
    if lic:
        comp["licenses"] = lic
    repo = pkg.get("repository")
    if repo:
        comp["externalReferences"] = [{"type": "vcs", "url": repo}]
    return comp


def main():
    extra = sys.argv[1:] or ["--all-features"]
    meta = cargo_metadata(extra)
    pkgs = {p["id"]: p for p in meta["packages"]}
    root_id, closure = runtime_closure(meta)

    root_pkg = pkgs[root_id]
    deps = sorted(
        (component(pkgs[i]) for i in closure if i != root_id),
        key=lambda c: c["purl"],
    )

    bom = {
        "bomFormat": "CycloneDX",
        "specVersion": SPEC_VERSION,
        "version": 1,
        "metadata": {
            "tools": [{"vendor": "Security Ops", "name": GENERATOR}],
            "component": component(root_pkg, is_root=True),
        },
        "components": deps,
    }
    # Sorted keys + trailing newline => byte-stable output.
    json.dump(bom, sys.stdout, indent=2, sort_keys=True)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
