#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
# Sign and verify every artifact before producing checksums.
# Usage: MIRIM_SIGN_SEED_HEX=... MIRIM_SIGN_COUNTER=... scripts/sign-release.sh [directory]
set -euo pipefail
cd "$(dirname "$0")/.."
dist="${1:-dist}"
: "${MIRIM_SIGN_SEED_HEX:?The existing release signing seed is required}"
: "${MIRIM_SIGN_COUNTER:?Set a release ordinal greater than the previous release}"
[[ "$MIRIM_SIGN_COUNTER" =~ ^[1-9][0-9]*$ ]] || { echo "Invalid release counter" >&2; exit 1; }
[[ "$MIRIM_SIGN_SEED_HEX" =~ ^[0-9a-fA-F]{64}$ ]] || { echo "Signing seed must be 32 bytes" >&2; exit 1; }
signer="${MIRIM_SIGN_BIN:-${CARGO_TARGET_DIR:-target}/release/mirim-sign}"
test -x "$signer"
test -d "$dist"
[[ -n "$(find "$dist" -maxdepth 1 -type f ! -name '*.mf' ! -name SHA256SUMS ! -name mirim-release.pub -print -quit)" ]] || {
  echo "No release artifacts found" >&2; exit 1;
}
umask 077
seed="$(mktemp)"
trap 'rm -f "$seed"' EXIT
python3 - "$seed" <<'PY'
import os, pathlib, sys
pathlib.Path(sys.argv[1]).write_bytes(bytes.fromhex(os.environ["MIRIM_SIGN_SEED_HEX"]))
PY
unset MIRIM_SIGN_SEED_HEX
cp keys/mirim-release.pub "$dist/"
for artifact in "$dist"/*; do
  [[ -f "$artifact" ]] || { echo "Unexpected artifact directory: $artifact" >&2; exit 1; }
  case "$artifact" in *.mf|*/SHA256SUMS|*/mirim-release.pub) continue ;; esac
  "$signer" sign "$artifact" "$seed" --counter "$MIRIM_SIGN_COUNTER" -o "$artifact.mf"
  "$signer" verify "$artifact" "$artifact.mf" keys/mirim-release.pub
done
rm -f "$seed"
umask 022
# SHA256SUMS is explicitly excluded from the files being read.
# shellcheck disable=SC2094
(cd "$dist" && find . -maxdepth 1 -type f ! -name SHA256SUMS -printf '%f\0' | sort -z | xargs -0 sha256sum > SHA256SUMS)
chmod 644 "$dist"/*.mf "$dist/SHA256SUMS" "$dist/mirim-release.pub"
