#!/usr/bin/env bash
# Copyright (c) 2026 Cristian Cezar Moisés — MIT
#
# Build a macOS flat installer package (.pkg) that installs mirim and
# mirim-sign into /usr/local/bin. macOS-only (uses pkgbuild); driven by the
# release workflow's macos jobs.
#
# Usage: scripts/build-macpkg.sh <rust-target> <arch> [outdir]
set -euo pipefail

target="$1"
target_dir="${CARGO_TARGET_DIR:-target}"
arch="$2"
outdir="${3:-dist}"
manifest_version="$(sed -nE 's/^version = "([^"]+)"/\1/p' Cargo.toml | head -n1)"
version="${RELEASE_VERSION:-${GITHUB_REF_NAME:-$manifest_version}}"
version="${version#v}"
[[ "$version" == "$manifest_version" ]] || { echo "Version differs from Cargo.toml" >&2; exit 1; }
mkdir -p "$outdir"

work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
root="$work/pkgroot"
mkdir -p "$root/usr/local/bin"
cp "$target_dir/$target/release/mirim" "$root/usr/local/bin/mirim"
cp "$target_dir/$target/release/mirim-sign" "$root/usr/local/bin/mirim-sign"
chmod 755 "$root/usr/local/bin/mirim" "$root/usr/local/bin/mirim-sign"
doc="$root/usr/local/share/doc/mirim"
mkdir -p "$doc"
cp README.md README.pt-BR.md LICENSE LICENSE-AGPL-3.0 LICENSE-COMMERCIAL NOTICE LICENSING.md LICENSING.pt-BR.md SECURITY.md "$doc/"
cp -R docs samples "$doc/"

pkgbuild \
  --identifier co.securityops.mirim \
  --version "$version" \
  --install-location / \
  --root "$root" \
  "$outdir/mirim-${version}-${arch}-macos.pkg"

echo "wrote $outdir/mirim-${version}-${arch}-macos.pkg"
