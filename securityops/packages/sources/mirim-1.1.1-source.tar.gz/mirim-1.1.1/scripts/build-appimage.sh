#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
# Usage: scripts/build-appimage.sh [arch] [outdir] [version] [binary-directory]
# The AppImage contains the CLI and signing tool; GUI binaries ship separately.
set -euo pipefail
cd "$(dirname "$0")/.."
arch="${1:-x86_64}"
outdir="${2:-dist}"
manifest_version="$(sed -nE 's/^version = "([^"]+)"/\1/p' Cargo.toml | head -n1)"
version="${3:-${GITHUB_REF_NAME:-$manifest_version}}"
version="${version#v}"
bin_dir="${4:-${CARGO_TARGET_DIR:-target}/release}"
[[ "$version" == "$manifest_version" ]] || { echo "Version differs from Cargo.toml" >&2; exit 1; }
mkdir -p "$outdir"
outdir="$(cd "$outdir" && pwd)"
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
appdir="$work/mirim.AppDir"
mkdir -p "$appdir/usr/bin" "$appdir/usr/share/applications" \
  "$appdir/usr/share/icons/hicolor/256x256/apps" "$appdir/usr/share/doc/mirim"
cp "$bin_dir/mirim" "$bin_dir/mirim-sign" "$appdir/usr/bin/"
cp LICENSE LICENSE-AGPL-3.0 LICENSE-COMMERCIAL NOTICE LICENSING.md LICENSING.pt-BR.md README.md README.pt-BR.md "$appdir/usr/share/doc/mirim/"
cp -R docs "$appdir/usr/share/doc/mirim/"
cat > "$appdir/mirim.desktop" <<'EOF'
[Desktop Entry]
Type=Application
Name=mirim
Comment=Encrypted embedded SQL database
Exec=mirim
Icon=mirim
Categories=Development;Database;
Terminal=true
EOF
cp "$appdir/mirim.desktop" "$appdir/usr/share/applications/mirim.desktop"
cp gui/mirim.png "$appdir/usr/share/icons/hicolor/256x256/apps/mirim.png"
cp gui/mirim.png "$appdir/mirim.png"
cp gui/mirim.png "$appdir/.DirIcon"
cat > "$appdir/AppRun" <<'EOF'
#!/bin/sh
HERE="$(dirname "$(readlink -f "$0")")"
exec "$HERE/usr/bin/mirim" "$@"
EOF
chmod +x "$appdir/AppRun"

# Pin both the tool release and its digest; never execute an unchecked download.
tool_version=1.9.1
case "$arch" in
  x86_64) digest=ed4ce84f0d9caff66f50bcca6ff6f35aae54ce8135408b3fa33abfc3cb384eb0 ;;
  aarch64) digest=f0837e7448a0c1e4e650a93bb3e85802546e60654ef287576f46c71c126a9158 ;;
  *) echo "Unsupported AppImage architecture: $arch" >&2; exit 1 ;;
esac
tool="$work/appimagetool.AppImage"
curl --fail --location --retry 3 --proto '=https' --tlsv1.2 \
  "https://github.com/AppImage/appimagetool/releases/download/$tool_version/appimagetool-$arch.AppImage" -o "$tool"
printf '%s  %s\n' "$digest" "$tool" | sha256sum --check --status
chmod +x "$tool"
out="$outdir/mirim-${version}-${arch}.AppImage"
ARCH="$arch" "$tool" --appimage-extract-and-run --no-appstream "$appdir" "$out"
test -s "$out"
echo "wrote $out"
