# Release engineering

## Release contract

Mirim uses semantic versions and immutable `vX.Y.Z` tags. Keep the versions in
`Cargo.toml`, `ffi/Cargo.toml`, `gui/Cargo.toml`, all four lockfiles and the
changelog consistent. `rust-toolchain.toml` pins the release compiler; a pinned
compiler is not itself a claim that every older compiler is unsupported.

A release is complete only when its validation record, intended binaries,
checksums and signatures are available. A workflow definition or an upstream
package request does not establish platform support or distribution acceptance.
Never relabel an earlier binary with a new version, silently omit a failed
platform, or replace an already published tag.

## Validation

Run these checks on the candidate with the pinned toolchain:

```sh
cargo fmt --all --check
cargo clippy --locked --all-features --all-targets -- -D warnings
cargo build --locked --no-default-features
cargo build --locked
cargo build --locked --all-features
cargo test --locked
cargo test --locked --all-features
cargo test --locked --test powercut  # 12 SIGKILL iterations per invocation

for manifest in gui/Cargo.toml ffi/Cargo.toml; do
  cargo fmt --manifest-path "$manifest" --all --check
  cargo clippy --locked --manifest-path "$manifest" --all-targets -- -D warnings
  cargo test --locked --manifest-path "$manifest"
done

cargo audit
cargo audit --file gui/Cargo.lock
cargo audit --file ffi/Cargo.lock
cargo audit --file fuzz/Cargo.lock
cargo deny --all-features check
for manifest in gui/Cargo.toml ffi/Cargo.toml fuzz/Cargo.toml; do
  cargo deny --manifest-path "$manifest" --all-features check
done
python3 scripts/gen-sbom.py --all-features > sbom.new.json
diff -u sbom.cdx.json sbom.new.json
rm sbom.new.json
```

Install the desktop development libraries listed in CI before building the GUI.
Run `bash ffi/tests/run-sanitizers.sh` from the repository root with Clang, nightly Rust and
`rust-src`; it checks the C boundary with ASan and UBSan. Keep build output on
a filesystem with enough space, particularly when `/tmp` is a small tmpfs.

Generate fuzz corpora and exercise all five targets:

```sh
cargo run --locked --example gen_fuzz_corpus --features fuzzing,sign
for target in fuzz_wire fuzz_sql fuzz_manifest fuzz_wal fuzz_seal; do
  cargo +nightly fuzz run "$target" -- -max_total_time=60 -rss_limit_mb=4096
done
```

The 60-second runs are smoke tests. The existing pre-release assurance target
is **24 CPU hours per fuzz target**; the nightly Forgejo job runs one hour per
target. Record actual duration, executions, findings and exceptions in the
release validation record. Do not report either CI smoke or a scheduled job
as a completed 24-hour soak. Record sanitizer instrumentation boundaries and
any remaining advisory warnings rather than hiding them.

## SBOM and source archives

`sbom.cdx.json` describes the core runtime dependency closure with all features;
it is not a complete inventory of the separate desktop crate. Regenerate it
when a version or dependency changes:

```sh
python3 scripts/gen-sbom.py --all-features > sbom.cdx.json
```

After tagging, `scripts/package-source.sh vX.Y.Z dist/` archives the exact tag
and generates a separate archive of vendored core, FFI and GUI dependencies.
The vendor archive supplies `.cargo/config.toml` for offline packaging. Both
archives are signed with the other release artifacts. No credentials, working
prompts, build caches or untracked local files belong in the source archive.

## Build and package

The GitHub release workflow uses native Linux, macOS and Windows runners.
A manual run with `publish=false` builds candidate artifacts from the selected
commit without signing or publishing. Tag pushes, or `publish=true` on a
matching tag, require signing and create a draft for final asset verification.
Linux produces CLI and signing tools, a desktop GUI, `.tar.gz`, `.deb`, `.rpm`
and AppImage. macOS produces CLI/signing `.tar.gz`, `.pkg` and `.dmg` for Intel
and Apple silicon. Windows produces CLI/signing `.exe` files and a `.zip`.
The workflow does not promise a Windows MSI or a macOS/Windows GUI.

For Linux, install `cargo-deb`, `cargo-generate-rpm` and the GUI build libraries,
then use an empty output directory:

```sh
bash scripts/package-linux.sh X.Y.Z dist/
```

The packaging helpers fail when a required build or artifact is missing.
Review dynamically linked libraries and minimum platform versions on native
runners. A binary linked to a local Guix store is not a portable Linux release.

## Reproducibility

The Forgejo workflow builds CLI and signer twice in separate target directories
with `SOURCE_DATE_EPOCH=1`, incremental compilation disabled, the pinned
compiler, locked dependencies and remapped checkout/Cargo paths. It compares
both executables byte for byte. Removing only a copied executable and invoking
Cargo again is insufficient: Cargo can restore its cached artifact.

This proves repeatability for those binaries and those build inputs. It does
not prove that native installers or every platform are bit-identical. Record
which artifacts were actually compared in the release notes.

## Signing and verification

The trusted ML-DSA-87 public key is `keys/mirim-release.pub`. Keep its matching
32-byte seed outside the repository; never generate a replacement just because
the current seed is unavailable. GitHub/Forgejo use the Actions secret
`MIRIM_SIGN_SEED_HEX`. Set the `MIRIM_SIGN_COUNTER` Actions variable to a positive
release ordinal greater than every previously published manifest counter.
The 1.1.0 artifacts used counter 0; the next ordinal is 1.

Supply both values through the environment, without putting the seed into
command history, then run:

```sh
bash scripts/sign-release.sh dist/
```

The helper validates inputs, signs every artifact, verifies each signature
against the committed public key, and generates `SHA256SUMS`. A missing seed,
wrong key or verification error blocks publication. Checksums detect byte
changes; authenticity depends on trusting the verification key separately.

Consumers can check an artifact with:

```sh
sha256sum -c SHA256SUMS
mirim-sign verify ARTIFACT ARTIFACT.mf mirim-release.pub
# Optional local rollback enforcement:
mirim-sign verify ARTIFACT ARTIFACT.mf mirim-release.pub --enforce ~/.mirim-ARTIFACT.trust
```

Keep a separate trust file per artifact: two different artifact digests with the
same counter are rejected. Protect each trust file against rollback or deletion.

## Publish and mirror

1. Review the final diff, validation evidence, changelog and English/pt-BR docs.
2. Build and validate the release on each advertised platform; inspect package
   contents, version output, dependencies and installation behavior.
3. Complete the release assurance record and resolve publication blockers.
4. Commit product changes and create the immutable version tag. Working prompts
   and secrets stay outside Git.
5. Push the branch and tag to all four repositories:
   - `git.securityops.co/cristiancmoises/mirim`
   - `git.securityops.com.br/cristiancmoises/mirim`
   - `github.com/cristiancmoises/mirim`
   - `codeberg.org/berkeley/mirim`
6. Collect native artifacts, SBOM and source/vendor archives; sign and verify
   them. Publish identical assets and release notes on all four forges.
7. Compare remote tag commit IDs, asset inventories and downloaded SHA-256
   checksums. A draft release or failed upload is not a published release.
8. Submit validated distribution packages through each upstream's accepted
   process. Include exact source hashes, dependencies and test evidence.
9. Back up the IONOS site through `ev shell`, deploy `website/` with its English
   and pt-BR pages, then check public language links and every download link.
   Advertise the new version as released only after its downloads are verified.

Keep detailed transient logs and operator working notes outside the repository;
include a concise, factual validation record with the published release.
