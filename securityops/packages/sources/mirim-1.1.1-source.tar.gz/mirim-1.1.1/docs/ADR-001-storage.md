# ADR-001 — In-memory engine, no out-of-core paging

Status: accepted (0.6.x). Supersedes the Sprint 3 "paged B-tree" plan.

## Context
mirim holds the whole database in memory and persists it as one
encrypted snapshot plus an encrypted write-ahead log. Sprint 3 originally
proposed a paged B-tree with per-page AEAD for out-of-core storage. That
plan was deferred then; this record makes the deferral a decision.

## Decision
Keep the in-memory engine. Do not build paged on-disk storage until a
concrete requirement for datasets larger than RAM exists.

## Rationale
- The target use is small, encrypted, durable data: keys, secrets,
  capability records, config, modest application state. These fit in RAM
  with wide margin.
- A paged store with per-page authenticated encryption is a large,
  security-sensitive subsystem (page cache, tree balancing, per-page
  nonce management, crash-consistent page writes, encrypted free-list).
  Building it speculatively spends the project's size and audit budget on
  machinery no current user exercises — and every unexercised crypto path
  is latent risk, not latent value.
- The working set and indexes remain bounded by available RAM. Queries
  without a usable PRIMARY KEY / UNIQUE equality predicate scan rows;
  indexed equality lookups and uniqueness checks use expected O(1) hash
  probes. Benchmark results depend on the workload and platform; reproduce
  them with `cargo bench --locked --bench core` rather than relying on
  historical ratios from before the equality index was added.

## Consequences
- mirim is not a general database; "if your data exceeds RAM, use
  SQLite" stays in the README.
- PRIMARY KEY / UNIQUE columns carry an in-memory equality index (added
  in 0.14.0), so duplicate checks and point lookups on them are O(1);
  other queries remain linear in table size. This is an in-memory
  optimization and does not change the in-memory-engine decision above.
- If a real >RAM requirement appears, this ADR is reopened. A paged
  design would then need its own threat model (page-access pattern
  leakage, per-page nonce uniqueness, truncated-tree recovery) before any
  code — it is not assumed by the present design.

## Alternatives considered
- **Paged B-tree now:** rejected — adds complexity without a demonstrated requirement.
- **mmap the snapshot:** rejected — defeats at-rest encryption (plaintext
  pages would touch disk via the pager).
- **Spill to encrypted temp files above a threshold:** deferred — same
  per-page crypto problems in a less general form.
