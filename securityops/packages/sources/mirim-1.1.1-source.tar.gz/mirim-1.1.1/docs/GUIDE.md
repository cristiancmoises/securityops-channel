# mirim user guide

For mirim **1.1.1**. [Project overview](../README.md) ·
[Português do Brasil](GUIDE.pt-BR.md) · [Security model](../SECURITY.md)

## Contents

1. [Choose an interface](#choose-an-interface)
2. [Installation](#installation)
3. [Create and use a vault](#create-and-use-a-vault)
4. [SQL reference](#sql-reference)
5. [Sample databases](#sample-databases)
6. [Backups and recovery](#backups-and-recovery)
7. [Desktop GUI](#desktop-gui)
8. [Rust API](#rust-api)
9. [Sealed exports](#sealed-exports)
10. [Signatures and rollback checks](#signatures-and-rollback-checks)
11. [C API](#c-api)
12. [Troubleshooting](#troubleshooting)
13. [Development and audit](#development-and-audit)
14. [File formats](#file-formats)

## Choose an interface

| Interface | Persistence | Use |
|---|---|---|
| `mirim <path>` | Encrypted snapshot + WAL | Interactive SQL in a terminal |
| `mirim-gui` | Encrypted snapshot + WAL | Local desktop vault browser and editor |
| Rust `DurableDb` | Encrypted snapshot + WAL | Embedded application with durable mutations |
| Rust `Db` | Memory only until `vault::save` | Explicit snapshot management and exports |
| C `libmirim_ffi` | Encrypted snapshot + WAL | Embedding through `ffi/include/mirim.h` |
| `mirim-sign` | Detached signature files | Sign or verify an existing file |

All database rows and indexes must fit in memory. mirim is suited to small
application state, local secrets, or modest audit datasets. It does not have
joins, multi-statement transactions, a network server, or on-disk paging.

## Installation

### Release assets

Download from the [release mirrors](../README.md#install). Select the correct
version, architecture, and OS; the release's attachment list is authoritative.
Do not infer native package availability from a submitted recipe or PR.

| System | Matching artifact, when attached | Installation |
|---|---|---|
| Debian / Ubuntu | `.deb` | `sudo apt install ./<package>.deb` |
| Fedora / RHEL family | `.rpm` | `sudo dnf install ./<package>.rpm` |
| openSUSE | `.rpm` | `sudo zypper install ./<package>.rpm` |
| Other GNU/Linux | Linux `.tar.gz` or AppImage | Extract the archive, or make the AppImage executable |
| macOS | Matching architecture `.tar.gz`, `.pkg`, or `.dmg` | Extract or open the installer/disk image |
| Windows | Windows `.zip` or `.exe` | Extract the archive; run `mirim.exe <path>` in a terminal |
| FreeBSD / OpenBSD / NetBSD | Native artifact if listed; otherwise source | See source build instructions and platform limits below |
| GNU Guix | Repository recipe | `guix install -f mirim.scm` from the checkout |

The v1.1.1 prebuilt GNU/Linux `x86_64` CLI and signing tools, including the
CLI AppImage, require glibc 2.34 or newer. The prebuilt GUI requires glibc
2.39 or newer. These GNU binaries do not target musl systems such as Alpine;
use a native source build there or when your system has an older glibc.

For a `.tar.gz`, inspect the archive with `tar -tzf <archive>` and extract it
with `tar -xzf <archive>`. Run `./mirim notes.mrm` from the extracted directory.
Installing a standalone binary in a directory on `PATH` is optional.
A Linux binary cannot be assumed to run on BSD, and a successful cross-build
is not a substitute for testing on the target OS.

The local [Guix recipe](../mirim.scm) repackages an upstream binary and is
limited to `x86_64-linux`; it is not proof of inclusion in GNU Guix. Run it
from the repository because its desktop assets are local files. Inspect its
version and pinned hash when choosing a release.

### Verify downloads

Download the release's `SHA256SUMS` into the same directory as the artifacts.
On GNU/Linux:

```sh
sha256sum -c SHA256SUMS --ignore-missing
```

Require an `OK` for every artifact you will install. On macOS, compute
`shasum -a 256 <artifact>`; on Windows PowerShell, use
`Get-FileHash .\<artifact> -Algorithm SHA256`. Compare the result with the
corresponding entry in `SHA256SUMS`.

A checksum alone does not authenticate a publisher. If a detached `.mf`
manifest is attached, verify it with a trusted verifier and an authenticated
copy of the maintainer key:

```sh
mirim-sign verify <artifact> <artifact>.mf mirim-release.pub
```

The repository copy is [`keys/mirim-release.pub`](../keys/mirim-release.pub).
Downloading both an artifact and an untrusted key from one place does not
establish trust in that key. See [signature verification](#signatures-and-rollback-checks).

### Build from source

The checkout pins Rust 1.96.0. Install rustup and the C compiler/linker for
your OS, then build the version you intend to use:

```sh
git clone https://github.com/cristiancmoises/mirim.git
cd mirim
git checkout v1.1.1
cargo build --release --locked --features sign
```

Useful native prerequisites for the CLI:

```sh
# Debian/Ubuntu
sudo apt install build-essential pkg-config
# Fedora
sudo dnf install gcc pkgconf-pkg-config
# Arch Linux
sudo pacman -S base-devel
```

On macOS, install the Xcode command-line tools. On Windows, the MSVC target
needs Visual Studio Build Tools with C++ tools and the Windows SDK. On BSD,
use the system's Rust toolchain and compiler or a supported rustup toolchain;
check `rustc --version` against the pinned version before building. Build
and test natively before relying on a BSD deployment.

```sh
# Core library without the CLI dependency.
cargo build --release --locked --no-default-features
# Desktop GUI (separate crate and lockfile).
cargo build --release --locked --manifest-path gui/Cargo.toml
# C library (separate crate and lockfile).
cargo build --release --locked --manifest-path ffi/Cargo.toml
```

The CLI binaries land in `target/release`, the GUI in `gui/target/release`,
and C libraries in `ffi/target/release` (platform-specific suffixes apply).
For the GNU/Linux GUI, native graphics libraries are needed. Debian/Ubuntu
prerequisites used by the release workflow include:

```sh
sudo apt install libgl1-mesa-dev libx11-dev libxcursor-dev libxrandr-dev \
  libxi-dev libxkbcommon-dev libwayland-dev libssl-dev
```

A minimal Debian/Ubuntu X11 environment also needs runtime libraries such
as `libxcursor1`, `libxrandr2`, `libxinerama1`, `libxkbcommon-x11-0`, and Mesa.
Build packages pull in many of these, but a standalone GUI binary does not
install them automatically. Use a native desktop session to check rendering
and input on the target system.

## Create and use a vault

```text
$ mirim notes.mrm
creating new vault: notes.mrm
new passphrase:
repeat passphrase:
mirim 1.1.1 — .help for commands
mirim> CREATE TABLE notes (id INTEGER PRIMARY KEY, body TEXT);
ok
mirim> INSERT INTO notes VALUES (1, 'buy milk');
1 row(s)
mirim> INSERT INTO notes VALUES (2, 'call Ana');
1 row(s)
mirim> SELECT id, body FROM notes ORDER BY id;
mirim> .quit
```

Check the installed version with `mirim --version` (or `-V`), and show
invocation help with `mirim --help` (or `-h`). Both exit without opening a
vault. For a filename beginning with `-`, use `mirim -- -notes.mrm`.
Unknown options or invalid argument counts exit with status 2.

An existing file prompts for its current passphrase. SQL statements end in
`;` and can span lines. Enter one SQL statement per completed REPL entry.

| Command | Effect |
|---|---|
| `.help` | List commands |
| `.tables` | List tables |
| `.schema` | Show reconstructed `CREATE TABLE` statements |
| `.read <path>` | Execute statements from a UTF-8 SQL file |
| `.save` | Checkpoint the WAL into the snapshot |
| `.rotate` | Request and confirm a new passphrase, then re-encrypt |
| `.quit` | Checkpoint and exit |

Successful mutations are synced to the WAL before the CLI reports success.
`.save` is useful for reducing replay work and preparing a backup, but is
not required after every statement. `.read` is **not a transaction**: on the
first error it stops, and earlier successful statements remain applied.
A schema export contains the table definitions, not the rows.

## SQL reference

Keywords and unquoted identifiers are case-insensitive. Values have one of
three forms: `INTEGER` (signed 64-bit), `TEXT` (UTF-8), or `NULL`.
There is no implicit type coercion.

```sql
-- Line comments and /* block comments */ are supported.
CREATE TABLE users (
  id INTEGER PRIMARY KEY,
  email TEXT UNIQUE,
  age INTEGER
);

INSERT INTO users VALUES (1, 'ana@example.org', 30);
INSERT INTO users (id, email) VALUES (2, 'bia@example.org');
SELECT email, age FROM users WHERE age >= 18 AND email IS NOT NULL;
SELECT * FROM users ORDER BY age DESC;
SELECT id FROM users ORDER BY id LIMIT 10 OFFSET 20;
SELECT COUNT(*) FROM users WHERE age IS NULL;
UPDATE users SET age = 31 WHERE id = 1;
DELETE FROM users WHERE id = 2;
```

- `PRIMARY KEY` and `UNIQUE` are single-column constraints. A primary key
  rejects `NULL`; a unique column accepts multiple `NULL` values.
- An `INSERT` adds one row. Omitted columns become `NULL`.
- `WHERE` supports `=`, `!=`, `<>`, `<`, `<=`, `>`, `>=`, joined by `AND`,
  and `IS NULL` / `IS NOT NULL`. `NULL` never matches a comparison.
- `ORDER BY` accepts one or more columns, each with optional `ASC` or `DESC`. `NULL` sorts
  first ascending and last descending. `OFFSET` requires `LIMIT`. Use ordering when pagination needs
  a defined sort order.
- `COUNT(*)` counts rows after filtering. It is the only aggregate;
  `LIMIT` and `OFFSET` apply to its single result row.
- An `UPDATE` validates its changes before applying them; a constraint
  violation leaves the statement's changes unapplied.
- Use single quotes for text and double a quote inside a literal:
  `'Ana''s note'`. Prefer bound `?` parameters for application input.

Not supported: joins, subqueries, `OR`, `GROUP BY`, expressions/arithmetic,
`ALTER TABLE`, `DROP TABLE`, `FOREIGN KEY`, standalone `NOT NULL`, `DEFAULT`,
`CHECK`, composite constraints, or multi-row `VALUES`.
There are no `REAL`, `BLOB`, `DATE`, or `BOOLEAN` types. Represent timestamps
as integer epoch seconds and booleans as `0` / `1` by application convention.

## Sample databases

[`samples/README.md`](../samples/README.md) describes five commented datasets:
a service credential vault, CTF scoreboard, device fleet, audit trail, and
password-manager metadata. Load them into a new demo vault:

```text
mirim> .read samples/secrets_vault.sql
mirim> .tables
mirim> .schema
mirim> SELECT name, endpoint FROM services ORDER BY name LIMIT 3;
```

```sh
cargo run --locked --example quickstart
cargo run --locked --example sealed_export
cargo run --locked --example gen_samples ./out
```

The generator's `sample-pass` passphrase is public demo material. Replace it
before storing real data. Re-importing a sample into a populated vault may
fail on existing tables; previous statements are not rolled back.

## Backups and recovery

### Make a consistent backup

1. Stop application writes. In the CLI, use `.quit` and check that it exits
   successfully; this checkpoints and closes the vault.
2. With all users of that vault stopped, copy its `.mrm` file. If the session
   crashed or did not checkpoint successfully, keep the matching `.mrm.wal`
   beside it and copy both while no process can modify them.
3. Restore a copy in a separate directory and open it with the expected
   secret. Check representative rows before treating the backup as verified.

Do not copy a live snapshot and WAL at unrelated times: a checkpoint can
change their pairing. Do not delete a WAL to fix an error; it may contain
acknowledged writes missing from the snapshot. The `.lock` file holds no
rows or key material and is not needed for recovery. Keep an untouched copy
of damaged files before opening them, since recovery can truncate a torn
WAL tail.

### Protect secrets and rotate them

Use a strong unique passphrase. Argon2id uses 64 MiB, three passes, and four
lanes; it increases guessing cost without making weak passwords safe.
`.rotate` replaces current ciphertext under a new passphrase and rebinds
the WAL. Old backups and residual disk blocks remain encrypted with the old
secret; rotation does not erase them.

Durable sessions take an exclusive OS file lock on Unix and Windows using
Rust's `File::try_lock`. If the platform or filesystem does not support the
lock, opening fails with an I/O error instead of silently proceeding unlocked.
Direct `vault::save` calls do not take this lock on any platform. Use a stable
path for each vault; do not bypass coordination through aliases or other tools
that modify its files. The Unix lock is advisory, so cooperating access is
still required.

Durability depends on filesystem and storage sync behavior. The process-crash
harness does not simulate every filesystem, controller, or physical power
failure; directory syncing is best effort. Read the complete
[security model](../SECURITY.md) for rollback, memory, metadata, and host limits.

## Desktop GUI

Run `mirim-gui` and select or create a vault. It lists tables, accepts SQL
(`Ctrl+Enter`), displays results, and provides checkpoint and passphrase
rotation controls. Mutating SQL is blocked until **Allow writes** is enabled.
This is a query safeguard: opening a durable session can still create a WAL
or repair its tail, so it is not a forensic read-only file viewer.

The application works on local vaults. Its login input buffers are cleared
after use, but the durable session retains an owned secret for checkpoints
and rotation until it is dropped. Decrypted rows and query results remain
in ordinary process memory while open. GUI availability depends on the
release's actual platform attachments. The **Licenses** window displays
bundled font notices offline; their source is `gui/FONT_LICENSES.txt`.

## Rust API

Use a local path dependency when working from a checkout:

```toml
[dependencies]
mirim = { path = "../mirim", default-features = false }
```

Or use the published Git tag (Cargo fetches its commit):

```toml
[dependencies]
mirim = { git = "https://github.com/cristiancmoises/mirim.git", tag = "v1.1.1", default-features = false }
```

Do not infer crates.io availability from the Git release. For the signing
API, add `features = ["sign"]`.

```rust
use mirim::vault::Secret;
use mirim::{DurableDb, Output, Value};

fn run(passphrase: &str) -> mirim::Result<()> {
    let mut db = DurableDb::open("notes.mrm".as_ref(), &Secret::Passphrase(passphrase))?;
    // Run schema creation once when initializing a new database.
    if db.db().table_names().is_empty() {
        db.execute("CREATE TABLE notes (id INTEGER PRIMARY KEY, body TEXT)")?;
    }
    let out = db.execute_params(
        "SELECT body FROM notes WHERE id = ?",
        &[Value::Int(1)],
    )?;
    if let Output::Rows { rows, .. } = out {
        println!("{} matching row(s)", rows.len());
    }
    db.checkpoint()?;
    Ok(())
}
```

Use `execute_params` for untrusted values; placeholders bind values, not
identifiers or SQL keywords. `Statement::prepare` and `Db::run` support reuse
of a parsed statement. `Db::execute_script` runs a multi-statement script in
memory and leaves prior successful statements applied if a later one fails.
`vault::save` saves that `Db` as an encrypted snapshot; it does not give it a WAL.

Dropping `DurableDb` leaves its WAL recoverable and releases its lock; it
does not imply a checkpoint. Recover from an I/O failure by closing the
poisoned session and reopening the vault, preserving its files.

## Sealed exports

A recipient generates an ML-KEM-768 key pair, keeps the secret half, and
shares an authenticated public key. Sealing encrypts a snapshot for that key:

```rust
use mirim::{pq, Db};

fn export_example(db: &Db) -> mirim::Result<()> {
    let (secret, public) = pq::keygen();
    let sealed = pq::seal(db, &public)?;
    let _reopened = pq::open(&sealed, &secret)?;
    Ok(())
}
```

`pq::seal_multi` seals for several recipients. Its snapshot is encrypted
once under a random key, then that key is wrapped for each recipient.
See [`examples/sealed_export.rs`](../examples/sealed_export.rs) for a complete
runnable example. This API is separate from `mirim-sign`; the signing CLI
does not provide recipient key generation or sealed-export commands.

The formats use post-quantum ML-KEM-768 with XChaCha20-Poly1305 and HKDF-SHA256.
This is intended to resist known quantum attacks, not a guarantee against
future cryptanalysis. Anyone who has a recipient's public key can create an
export; authenticate the sender with a signature when needed. A lost secret
key cannot be recovered, and compromise of a recipient key exposes earlier
exports to that recipient.

## Signatures and rollback checks

Build `mirim-sign` with `--features sign`. It creates ML-DSA-87 detached
manifests binding a file hash, target kind, and counter:

```sh
# Create these once; protect the seed and authenticate distribution of the public key.
mirim-sign keygen release.seed release.pub
# Increase the counter for each successive version in one update stream.
mirim-sign sign artifact.bin release.seed --counter 1 -o artifact.bin.mf
mirim-sign verify artifact.bin artifact.bin.mf release.pub
mirim-sign verify artifact.bin artifact.bin.mf release.pub --enforce artifact.trust
```

`mirim-sign --help` and `mirim-sign --version` also work without accessing a
vault. `keygen` requires two new output paths and refuses existing files,
including symbolic links. On Unix it creates the secret seed with mode 0600
before writing any key bytes; protect it using the OS access controls elsewhere.

The default counter is zero; increment it explicitly for useful freshness
checks. `--enforce` stores the highest accepted counter and target hash.
It rejects lower counters and a different file at the same counter; repeating
verification of the same file is allowed. Use separate trust files for
independent artifact streams, serialize updates, and protect trust files
from modification or deletion. A replaced trust file defeats this check.

Plain verification establishes origin relative to a trusted public key,
not freshness. Signature checks do not automatically protect the database's
WAL or prevent rollback of vault files. A bundled public key still needs an
authenticated trust path; pin it independently of the file being verified.

## C API

Build with `cargo build --release --locked --manifest-path ffi/Cargo.toml`.
The [header](../ffi/include/mirim.h) is the contract; the
[C conformance harness](../ffi/tests/ffi_test.c) demonstrates calls and error
handling. Check `mirim_open*` and `mirim_execute*` for `NULL`, use
`mirim_last_error` for execution errors, and release results with
`mirim_result_free`. Check the status returned by `mirim_checkpoint`.

One handle belongs to one thread unless access is externally serialized.
Do not double-free, use handles after closing, or retain result pointers
after freeing their result. Text results are length-delimited UTF-8, not
NUL-terminated strings. `mirim_close` does not checkpoint.

The core forbids unsafe code. The FFI crate contains the unsafe C boundary
and enables panic unwinding so its `catch_unwind` wrappers can report
`MIRIM_E_PANIC`; this does not make invalid C pointers safe.

## Troubleshooting

| Symptom | What to check |
|---|---|
| `authentication failed` | Wrong secret or failed ciphertext authentication; preserve the files and check a known backup |
| `corrupt file` | Structural damage or an unsupported format; keep a copy before attempting recovery |
| `secret kind does not match` | Use a passphrase for a passphrase vault, a raw key for a raw-key vault |
| `database is locked` | Close the other writer; deleting a live `.lock` file is not a safe fix |
| `trailing tokens after statement` | Use one SQL statement per REPL entry, or `.read` for a file |
| `durable session poisoned` | An earlier I/O operation failed; close and reopen while retaining the WAL |
| Existing table while loading samples | Use a new demo vault; imports do not roll back earlier statements |
| No release asset for your platform | Build and test from source; check the release for supported architectures |

A lost passphrase or recipient secret key means lost access. There is no
reset or recovery mechanism. File size, times, WAL record sizes, process
memory, swap, and core dumps are not hidden by at-rest encryption.

## Development and audit

Run these from the repository root with the pinned toolchain:

```sh
cargo fmt --all --check
cargo clippy --locked --all-features --all-targets -- -D warnings
cargo build --locked --no-default-features
cargo build --locked
cargo build --locked --all-features
cargo test --locked
cargo test --locked --all-features
cargo test --locked --test powercut
cargo test --locked --manifest-path gui/Cargo.toml
cargo test --locked --manifest-path ffi/Cargo.toml
cargo fmt --manifest-path gui/Cargo.toml --check
cargo fmt --manifest-path ffi/Cargo.toml --check
cargo clippy --locked --manifest-path gui/Cargo.toml --all-targets -- -D warnings
cargo clippy --locked --manifest-path ffi/Cargo.toml --all-targets -- -D warnings
```

Install `cargo-audit` and `cargo-deny` to inspect dependency advisories and
the repository's dependency policy. The separate GUI and FFI lockfiles need
separate checks; the core SBOM is not a complete inventory of the GUI.

```sh
cargo audit
cargo audit --file gui/Cargo.lock
cargo audit --file ffi/Cargo.lock
cargo deny check
python3 scripts/gen-sbom.py --all-features > /tmp/mirim-sbom-check.json
diff -u sbom.cdx.json /tmp/mirim-sbom-check.json
```

The suite includes pinned cryptographic vectors, property-based round trips,
SQL differential tests, malformed-input checks, sample loading, and Unix
SIGKILL recovery. For the C sanitizer harness, install clang and nightly Rust
with `rust-src`, then run `bash ffi/tests/run-sanitizers.sh`.

For decoder fuzzing, install nightly Rust and `cargo-fuzz`, generate the
corpus, then run each target:

```sh
cargo run --locked --example gen_fuzz_corpus --features fuzzing,sign
for target in fuzz_wire fuzz_sql fuzz_manifest fuzz_wal fuzz_seal; do
  cargo +nightly fuzz run "$target" -- -max_total_time=60 -rss_limit_mb=4096
done
```

A finite fuzz run is not exhaustive. The current
[GitHub CI](../.github/workflows/ci.yml) and
[Forgejo CI](../.forgejo/workflows/ci.yaml) define automated checks;
[RELEASE.md](../RELEASE.md) records the release procedure. Report which
checks and platforms actually ran when publishing an audit result.

### Performance and storage tradeoffs

Run `cargo bench --locked --bench core` to reproduce the benchmark workloads.
They compare specific in-memory and durable operations with bundled SQLite;
results depend on hardware, storage, toolchain, and sync behavior. Do not
read a bulk-insert result as a general database performance claim. PRIMARY
KEY and UNIQUE equality indexes use expected constant-time hash lookups;
other predicates scan rows, and deletes rebuild affected indexes.
The [storage ADR](ADR-001-storage.md) explains why the engine stays in memory.

## File formats

The following reference consolidates the original README format notes.
The v1 vault, WAL, and manifest layouts and sealed-export v1 remain readable;
multi-recipient sealed exports use their separate v2 layout. A breaking
format change requires explicit versioning.

Vault `.mrm` — header is AEAD associated data:

    0   8   magic "MIRIM1\0\0"
    8   1   file version = 1
    9   1   kdf: 0 = raw 32-byte key, 1 = Argon2id
    10  16  salt (random; zero for raw keys)
    26  24  XChaCha20-Poly1305 nonce (random per save)
    50  ..  AEAD ciphertext of the snapshot

Sealed export — header is AEAD associated data:

    0     8     magic "MIRIMSL1"
    8     1     format version = 1
    9     1088  ML-KEM-768 ciphertext
    1097  24    XChaCha20-Poly1305 nonce
    1121  ..    AEAD ciphertext of the snapshot

AEAD key for sealed exports:
`HKDF-SHA256(ikm = ML-KEM shared secret, info = "mirim.v1.seal.mlkem768+xchacha20poly1305")`.

Write-ahead log (`<vault>.wal`) — header 41 bytes, then records:

    header: magic "MIRIMWL1" | version 1 | SHA-256 of the vault file
    record: seq u64 LE | nonce 24 | ct len u32 LE | ciphertext
    record key:  HKDF-SHA256(ikm = vault master key, salt = snapshot id,
                 info = "mirim.v1.wal.xchacha20poly1305")
    record AAD:  header || seq

Keying and AAD bind every record to the exact snapshot bytes it extends;
sequence numbers are authenticated and must be consecutive. A torn final
record (the only damage an honest crash can produce) is truncated on
open; a bad record anywhere else is reported as corruption.

Trust file (`verify_manifest_enforcing`) — 49 bytes:

    magic "MIRIMTS1" | version 1 | highest accepted counter (u64 LE)
    | SHA-256 of the last accepted target

Multi-recipient sealed export — format v2:

    magic "MIRIMSL1" | version 2 | recipient count u16 LE
    | per recipient: ML-KEM-768 ct (1088) | wrapped CEK (48)
    | nonce 24 | payload ciphertext
    wrap key: HKDF-SHA256(ikm = KEM shared secret,
              info = "mirim.v2.seal.wrap.mlkem768+xchacha20poly1305"),
    zero nonce (single-use key), AAD = magic|version|count;
    payload: XChaCha20-Poly1305 under the random CEK, AAD = full header

Signed manifest (`sign` feature) — 4677 bytes:

    0   8     magic "MIRIMMF1"
    8   1     manifest version = 1
    9   1     target kind: 0 = vault, 1 = sealed export
    10  8     counter (u64 LE, authenticated; enforced via trust file)
    18  32    SHA-256 of the target file
    50  4627  ML-DSA-87 signature over bytes 0..50,
              context "mirim.v1.manifest.mldsa87"

The plaintext snapshot wire format is documented in `src/wire.rs`; its
decoder treats input as attacker-controlled (bounds-checked before any
allocation, fails closed on every structural violation).
