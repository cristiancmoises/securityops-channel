# Guia do mirim

Documentação para o mirim **1.1.1** em português do Brasil.
[Visão geral](../README.pt-BR.md) · [English](GUIDE.md) ·
[Modelo de segurança completo, em inglês](../SECURITY.md)

## Sumário

1. [Escolher uma interface](#escolher-uma-interface)
2. [Instalação](#instalacao)
3. [Criar e usar um banco](#criar-e-usar-um-banco)
4. [Referência SQL](#referencia-sql)
5. [Bancos de exemplo](#bancos-de-exemplo)
6. [Backup e recuperação](#backup-e-recuperacao)
7. [Interface gráfica](#interface-grafica)
8. [API Rust](#api-rust)
9. [Exportações seladas](#exportacoes-seladas)
10. [Assinaturas e proteção contra versões antigas](#assinaturas)
11. [API C](#api-c)
12. [Segurança e limites](#seguranca-e-limites)
13. [Solução de problemas](#solucao-de-problemas)
14. [Desenvolvimento e auditoria](#desenvolvimento-e-auditoria)
15. [Formatos e arquitetura](#formatos-e-arquitetura)

## Escolher uma interface

| Interface | Persistência | Uso principal |
|---|---|---|
| `mirim <caminho>` | Arquivo criptografado + WAL | SQL interativo no terminal |
| `mirim-gui` | Arquivo criptografado + WAL | Consulta e edição pela interface gráfica |
| `DurableDb`, em Rust | Arquivo criptografado + WAL | Aplicações que precisam confirmar escritas duráveis |
| `Db`, em Rust | Memória, até chamar `vault::save` | Gerenciar snapshots e exportações explicitamente |
| `libmirim_ffi`, em C | Arquivo criptografado + WAL | Integração por `ffi/include/mirim.h` |
| `mirim-sign` | Manifestos de assinatura separados | Assinar ou verificar arquivos existentes |

Um **snapshot** é uma cópia completa do estado do banco. O **WAL**
(write-ahead log, registro de escrita antecipada) guarda comandos de
alteração criptografados até que um **checkpoint** os incorpore ao snapshot.
Todo o banco e seus índices ficam na RAM durante o uso.

Use o mirim para conjuntos pequenos de dados, como configurações, segredos
locais e estado de aplicações. Ele não oferece joins, transações que
abrangem vários comandos, servidor de rede ou armazenamento maior que a RAM.

<a id="instalacao"></a>
## Instalação

### Pacotes e binários

Escolha uma versão nos [espelhos de publicação](../README.pt-BR.md#instalação).
Confira a arquitetura e o sistema operacional de cada anexo. A presença
de uma receita ou de um PR não comprova disponibilidade em um repositório
oficial de pacotes.

| Sistema | Arquivo, quando anexado à versão | Como instalar |
|---|---|---|
| Debian / Ubuntu | `.deb` | `sudo apt install ./<pacote>.deb` |
| Fedora / família RHEL | `.rpm` | `sudo dnf install ./<pacote>.rpm` |
| openSUSE | `.rpm` | `sudo zypper install ./<pacote>.rpm` |
| Outros GNU/Linux | `.tar.gz` para Linux ou AppImage | Extrair o arquivo ou tornar a AppImage executável |
| macOS | `.tar.gz`, `.pkg` ou `.dmg` da arquitetura correta | Extrair ou abrir o instalador/imagem |
| Windows | `.zip` ou `.exe` para Windows | Extrair; executar `mirim.exe <caminho>` no terminal |
| FreeBSD / OpenBSD / NetBSD | Binário nativo, se disponível, ou código-fonte | Compilar e testar no sistema de destino |
| GNU Guix | Receita deste repositório | `guix install -f mirim.scm` na raiz do checkout |

Na versão 1.1.1, os binários prontos da CLI e da ferramenta de assinatura
para GNU/Linux `x86_64`, incluindo a AppImage da CLI, exigem glibc 2.34 ou
mais recente. A GUI pronta exige glibc 2.39 ou mais recente. Esses binários GNU
não são destinados a sistemas musl, como Alpine; nesses sistemas ou em
sistemas com glibc mais antiga, compile a partir do código-fonte.

Para arquivos `.tar.gz`, veja o conteúdo com `tar -tzf <arquivo>` e extraia
com `tar -xzf <arquivo>`. Execute `./mirim notas.mrm` no diretório extraído.
Opcionalmente, instale os executáveis em um diretório do `PATH`.
Não presuma que um binário GNU/Linux funciona em BSD. Compilação cruzada
bem-sucedida não substitui testes no sistema de destino.

A [receita local do Guix](../mirim.scm) reempacota um binário de lançamento
para `x86_64-linux`. Ela usa arquivos locais para o lançador da GUI e deve
ser executada a partir do checkout. Confira a versão e o hash fixados na
receita. Essa instalação local é distinta de inclusão no GNU Guix oficial.

### Verificar os downloads

Coloque `SHA256SUMS` no diretório dos arquivos baixados. No GNU/Linux:

```sh
sha256sum -c SHA256SUMS --ignore-missing
```

Cada arquivo a instalar precisa aparecer como `OK`. No macOS, use
`shasum -a 256 <arquivo>`; no PowerShell do Windows, use
`Get-FileHash .\<arquivo> -Algorithm SHA256` e compare com a entrada
correspondente em `SHA256SUMS`.

O checksum sozinho não autentica a origem. Se houver uma assinatura `.mf`,
verifique-a com um executável confiável e uma chave pública autenticada:

```sh
mirim-sign verify <artefato> <artefato>.mf mirim-release.pub
```

A cópia do repositório está em
[`keys/mirim-release.pub`](../keys/mirim-release.pub). Obter um arquivo e
uma chave ainda não confiável do mesmo local não estabelece confiança na
chave. Veja a [seção de assinaturas](#assinaturas).

### Compilar o código-fonte

O checkout fixa Rust 1.96.0 em `rust-toolchain.toml`. Instale rustup e um
compilador/linker C compatível com o sistema. Em seguida:

```sh
git clone https://github.com/cristiancmoises/mirim.git
cd mirim
git checkout v1.1.1
cargo build --release --locked --features sign
```

Exemplos de pré-requisitos nativos para a CLI:

```sh
# Debian/Ubuntu
sudo apt install build-essential pkg-config
# Fedora
sudo dnf install gcc pkgconf-pkg-config
# Arch Linux
sudo pacman -S base-devel
```

No macOS, instale as ferramentas de linha de comando do Xcode. No Windows,
o alvo MSVC precisa do Visual Studio Build Tools com ferramentas C++ e do
Windows SDK. Nos BSDs, use a distribuição de Rust do sistema ou um alvo
suportado pelo rustup; confira `rustc --version` e execute os testes
nativamente antes de depender da instalação.

```sh
# Somente a biblioteca central, sem a dependência da CLI.
cargo build --release --locked --no-default-features
# Interface gráfica.
cargo build --release --locked --manifest-path gui/Cargo.toml
# Bibliotecas para C.
cargo build --release --locked --manifest-path ffi/Cargo.toml
```

Os resultados ficam em `target/release`, `gui/target/release` e
`ffi/target/release`, respectivamente. As extensões variam por plataforma.
Para a GUI no Debian/Ubuntu, o fluxo de publicação utiliza bibliotecas
gráficas nativas como estas:

```sh
sudo apt install libgl1-mesa-dev libx11-dev libxcursor-dev libxrandr-dev \
  libxi-dev libxkbcommon-dev libwayland-dev libssl-dev
```

Um ambiente X11 mínimo no Debian/Ubuntu também precisa de bibliotecas de
execução como `libxcursor1`, `libxrandr2`, `libxinerama1`,
`libxkbcommon-x11-0` e Mesa. Os pacotes de desenvolvimento trazem várias
delas, mas um binário gráfico avulso não as instala automaticamente.
Verifique a renderização e a entrada em uma sessão gráfica nativa no destino.

## Criar e usar um banco

```text
$ mirim notas.mrm
creating new vault: notas.mrm
new passphrase:
repeat passphrase:
mirim 1.1.1 — .help for commands
mirim> CREATE TABLE notas (id INTEGER PRIMARY KEY, texto TEXT);
ok
mirim> INSERT INTO notas VALUES (1, 'comprar leite');
1 row(s)
mirim> INSERT INTO notas VALUES (2, 'ligar para Ana');
1 row(s)
mirim> SELECT id, texto FROM notas ORDER BY id;
mirim> .quit
```

Confira a versão com `mirim --version` (ou `-V`) e a ajuda com
`mirim --help` (ou `-h`). Ambos encerram sem abrir um banco. Para um nome
que começa com `-`, use `mirim -- -notas.mrm`. Opções desconhecidas ou
quantidade inválida de argumentos encerram com código 2.

A interface permanece em inglês. Ao abrir um arquivo existente, informe
sua frase-senha atual. Termine cada comando SQL com `;`; ele pode ocupar
várias linhas. Digite um comando por entrada completa do REPL.

| Comando | Função |
|---|---|
| `.help` | Exibir ajuda |
| `.tables` | Listar tabelas |
| `.schema` | Exibir comandos `CREATE TABLE` reconstruídos |
| `.read <caminho>` | Executar um arquivo SQL UTF-8 |
| `.save` | Incorporar o WAL ao snapshot |
| `.rotate` | Solicitar uma nova frase-senha e recriptografar |
| `.quit` | Fazer checkpoint e sair |

Cada alteração bem-sucedida é sincronizada no WAL antes da confirmação.
Não é necessário executar `.save` após cada comando. Um checkpoint reduz
o trabalho de recuperação e ajuda a preparar um backup.

`.read` **não é uma transação**: interrompe a execução no primeiro erro e
mantém os comandos anteriores que tiveram sucesso. `.schema` mostra as
definições das tabelas, não exporta suas linhas.

<a id="referencia-sql"></a>
## Referência SQL

Palavras-chave e identificadores sem aspas não diferenciam maiúsculas de
minúsculas. Os valores são `INTEGER` (inteiro de 64 bits com sinal), `TEXT`
(UTF-8) ou `NULL`. Não há conversão implícita entre tipos.

```sql
-- Comentários de linha e /* de bloco */ são aceitos.
CREATE TABLE pessoas (
  id INTEGER PRIMARY KEY,
  email TEXT UNIQUE,
  idade INTEGER
);

INSERT INTO pessoas VALUES (1, 'ana@example.org', 30);
INSERT INTO pessoas (id, email) VALUES (2, 'bia@example.org');
SELECT email, idade FROM pessoas WHERE idade >= 18 AND email IS NOT NULL;
SELECT * FROM pessoas ORDER BY idade DESC, id ASC;
SELECT id FROM pessoas ORDER BY id LIMIT 10 OFFSET 20;
SELECT COUNT(*) FROM pessoas WHERE idade IS NULL;
UPDATE pessoas SET idade = 31 WHERE id = 1;
DELETE FROM pessoas WHERE id = 2;
```

- `PRIMARY KEY` e `UNIQUE` são restrições por coluna. A chave primária
  recusa `NULL`; uma coluna `UNIQUE` aceita vários valores `NULL`.
- Cada `INSERT` inclui uma linha. Colunas omitidas recebem `NULL`.
- `WHERE` aceita `=`, `!=`, `<>`, `<`, `<=`, `>` e `>=`, unidos por `AND`,
  além de `IS NULL` e `IS NOT NULL`. Comparações comuns com `NULL` nunca
  selecionam uma linha.
- `ORDER BY` aceita uma ou mais colunas, cada uma com `ASC` ou `DESC`.
  `NULL` vem primeiro em ordem crescente e por último em ordem decrescente.
  Use uma ordenação definida para paginação previsível.
- `LIMIT n OFFSET m` limita a saída após descartar as primeiras `m` linhas.
  `OFFSET` só aparece junto de `LIMIT`.
- `COUNT(*)` conta as linhas após o filtro. É a única agregação; `LIMIT`
  e `OFFSET` se aplicam à linha de resultado da contagem.
- `UPDATE` valida as alterações antes de aplicá-las: uma violação de
  restrição não deixa parte do comando aplicada.
- Textos usam aspas simples; duplique uma aspa dentro de um literal:
  `'caixa d''água'`. Na aplicação, prefira parâmetros `?`.

Não há joins, subconsultas, `OR`, `GROUP BY`, expressões aritméticas,
`ALTER TABLE`, `DROP TABLE`, `FOREIGN KEY`, `NOT NULL` isolado, `DEFAULT`,
`CHECK`, chaves compostas ou `VALUES` com várias linhas. Também não há tipos
`REAL`, `BLOB`, `DATE` ou `BOOLEAN`. Por convenção da aplicação, horários
podem ser segundos Unix em `INTEGER` e booleanos podem ser `0` / `1`.

## Bancos de exemplo

O diretório [`samples/`](../samples/) inclui cinco bases comentadas:

| Arquivo | Modelo |
|---|---|
| `secrets_vault.sql` | Credenciais de serviços e registro de acessos |
| `ctf_scoreboard.sql` | Equipes, desafios e soluções de uma competição CTF |
| `device_fleet.sql` | Inventário de dispositivos, firmware e telemetria |
| `audit_trail.sql` | Identidades, políticas e eventos de auditoria |
| `password_manager.sql` | Metadados de cofres, entradas e etiquetas |

```text
mirim> .read samples/secrets_vault.sql
mirim> .tables
mirim> .schema
mirim> SELECT name, endpoint FROM services ORDER BY name LIMIT 3;
```

Também é possível executar os exemplos em Rust:

```sh
cargo run --locked --example quickstart
cargo run --locked --example sealed_export
cargo run --locked --example gen_samples ./out
```

O gerador usa a frase-senha pública `sample-pass` para demonstração.
Troque-a antes de armazenar informações reais. Reimportar uma base em um
banco já preenchido pode falhar por tabelas existentes, sem desfazer os
comandos anteriores.

<a id="backup-e-recuperacao"></a>
## Backup e recuperação

### Fazer um backup consistente

1. Interrompa as escritas. Na CLI, use `.quit` e confirme que a saída ocorreu
   sem erro; isso faz checkpoint e encerra a sessão.
2. Sem nenhum processo modificando o banco, copie o arquivo `.mrm`. Se
   houve uma queda ou o checkpoint não foi concluído, preserve também o
   arquivo `.mrm.wal` correspondente e copie os dois juntos, com o banco parado.
3. Restaure uma cópia em outro diretório, abra com o segredo esperado e
   confira dados representativos antes de considerar o backup validado.

Não copie um snapshot em uso e seu WAL em momentos independentes: um
checkpoint pode alterar o par. Não apague o WAL para contornar um erro,
pois ele pode conter escritas já confirmadas. O arquivo `.lock` não contém
linhas nem chaves e não é necessário para recuperar os dados.

Preserve uma cópia intacta de arquivos danificados antes de abri-los.
Durante a recuperação, o mirim pode truncar a parte incompleta do fim do WAL.
Copie sempre o par correspondente para um diretório limpo ao testar restauração.

### Alterar a frase-senha

Execute `.rotate`, digite e confirme a nova frase-senha. O banco atual é
recriptografado e o WAL passa a corresponder ao novo snapshot. Backups
antigos e blocos residuais continuam protegidos pelo segredo anterior;
a rotação não os apaga.

Sessões duráveis usam um bloqueio exclusivo do sistema em Unix e Windows
por meio de `File::try_lock` do Rust. Se a plataforma ou o sistema de arquivos
não oferecer esse bloqueio, a abertura falha com erro de E/S, em vez de
continuar sem proteção. A API `vault::save` não adquire esse bloqueio em
nenhuma plataforma. Use um caminho estável para o banco e não contorne a
coordenação com aliases ou ferramentas que alterem seus arquivos diretamente.
O bloqueio Unix é consultivo e depende de acesso cooperativo.

A durabilidade depende do comportamento de sincronização do sistema de
arquivos e do dispositivo. O harness de SIGKILL verifica quedas de processo,
mas não simula todos os controladores, sistemas de arquivos ou cortes
físicos de energia. A sincronização do diretório é uma tentativa sem falha
fatal; veja os limites no [modelo de segurança](../SECURITY.md).

<a id="interface-grafica"></a>
## Interface gráfica

Execute `mirim-gui` e selecione ou crie um banco. A aplicação lista tabelas,
executa SQL com `Ctrl+Enter`, mostra resultados e oferece controles de
checkpoint e alteração de frase-senha. Comandos que alteram dados ficam
bloqueados até habilitar **Allow writes**.

Esse controle protege consultas, mas não torna a abertura do arquivo
somente leitura: uma sessão durável pode criar um WAL ou reparar seu fim.
A GUI não é um visualizador forense de arquivos.

Os campos de entrada da frase-senha são limpos após o uso. A sessão
`DurableDb` mantém uma cópia própria do segredo para checkpoints até ser
encerrada. Linhas descriptografadas e resultados ficam na memória normal
do processo enquanto o banco está aberto. Confira os anexos da versão para
saber em quais plataformas há um binário gráfico disponível. A janela
**Licenses** exibe avisos das fontes empacotadas sem acessar a rede; o texto
original está em `gui/FONT_LICENSES.txt`.

## API Rust

Para usar um checkout local:

```toml
[dependencies]
mirim = { path = "../mirim", default-features = false }
```

Para usar uma tag publicada no Git:

```toml
[dependencies]
mirim = { git = "https://github.com/cristiancmoises/mirim.git", tag = "v1.1.1", default-features = false }
```

Uma versão no Git não comprova publicação no crates.io. Adicione
`features = ["sign"]` para usar a API de manifestos assinados.

```rust
use mirim::vault::Secret;
use mirim::{DurableDb, Output, Value};

fn consultar(frase_senha: &str) -> mirim::Result<()> {
    let mut db = DurableDb::open("notas.mrm".as_ref(), &Secret::Passphrase(frase_senha))?;
    if db.db().table_names().is_empty() {
        db.execute("CREATE TABLE notas (id INTEGER PRIMARY KEY, texto TEXT)")?;
    }
    let resultado = db.execute_params(
        "SELECT texto FROM notas WHERE id = ?",
        &[Value::Int(1)],
    )?;
    if let Output::Rows { rows, .. } = resultado {
        println!("{} linha(s) encontrada(s)", rows.len());
    }
    db.checkpoint()?;
    Ok(())
}
```

Vincule valores externos com `execute_params`. Parâmetros são dados, não
nomes de tabelas, colunas ou trechos de SQL. Não concatene entrada não
confiável em comandos. `Statement::prepare` e `Db::run` permitem reutilizar
comandos já analisados.

`Db::execute_script` executa um script em memória; um erro posterior mantém
os comandos anteriores. `vault::save` grava um snapshot criptografado desse
`Db`, mas não adiciona um WAL a ele. Destruir um `DurableDb` libera o bloqueio
e deixa o WAL recuperável; não implica checkpoint. Após uma falha de E/S,
encerre e reabra a sessão preservando os arquivos.

<a id="exportacoes-seladas"></a>
## Exportações seladas

O destinatário gera um par de chaves ML-KEM-768, guarda a chave secreta e
compartilha uma chave pública autenticada. A exportação é criptografada
para essa chave:

```rust
use mirim::{pq, Db};

fn demonstrar_exportacao(db: &Db) -> mirim::Result<()> {
    let (secreta, publica) = pq::keygen();
    let selado = pq::seal(db, &publica)?;
    let _reaberto = pq::open(&selado, &secreta)?;
    Ok(())
}
```

`pq::seal_multi` aceita vários destinatários: criptografa o snapshot uma vez
com uma chave aleatória e protege essa chave para cada destinatário.
Veja [`examples/sealed_export.rs`](../examples/sealed_export.rs).
Essas operações pertencem à API Rust; `mirim-sign` não gera chaves de
destinatários nem fornece comandos de exportação selada.

ML-KEM-768, XChaCha20-Poly1305 e HKDF-SHA256 compõem o formato, projetado para
resistir a ataques quânticos conhecidos. Isso não garante resistência a toda
criptoanálise futura. Qualquer pessoa com a chave pública de um destinatário
pode gerar uma exportação; use uma assinatura quando precisar autenticar o
remetente. Comprometer a chave secreta do destinatário também expõe suas
exportações antigas.

<a id="assinaturas"></a>
## Assinaturas e proteção contra versões antigas

Compile com `--features sign` para obter `mirim-sign`. Ele cria manifestos
ML-DSA-87 separados, que vinculam o hash de um arquivo, seu tipo e um contador.

```sh
# Gere uma vez. Proteja a semente e autentique a distribuição da chave pública.
mirim-sign keygen release.seed release.pub
# Aumente o contador para cada nova versão de uma mesma sequência de atualizações.
mirim-sign sign artefato.bin release.seed --counter 1 -o artefato.bin.mf
mirim-sign verify artefato.bin artefato.bin.mf release.pub
mirim-sign verify artefato.bin artefato.bin.mf release.pub --enforce artefato.trust
```

`mirim-sign --help` e `mirim-sign --version` também funcionam sem acessar
um banco. `keygen` exige dois caminhos novos e recusa arquivos existentes,
inclusive links simbólicos. Em Unix, cria a semente secreta com modo 0600
antes de escrever as chaves; em outros sistemas, proteja-a com os controles
de acesso do sistema operacional.

O contador padrão é zero. Incremente-o explicitamente para verificar avanço
de versões. `--enforce` guarda o maior contador aceito e o hash do arquivo;
recusa contadores menores ou um arquivo diferente com o mesmo contador.
Verificar novamente o mesmo arquivo é permitido.

Use um arquivo de confiança separado para cada sequência independente de
artefatos, serialize suas atualizações e proteja-o contra substituição ou
exclusão. Sem esse estado íntegro, o teste de regressão pode ser contornado.
A verificação simples comprova origem em relação à chave confiável, não
atualidade. Essas verificações não protegem automaticamente o WAL e não
impedem substituir o banco por uma cópia antiga.

## API C

Compile com `cargo build --release --locked --manifest-path ffi/Cargo.toml`.
O [cabeçalho](../ffi/include/mirim.h) define o contrato. O
[harness de conformidade](../ffi/tests/ffi_test.c) mostra chamadas e
tratamento de erros.

Confira se `mirim_open*` e `mirim_execute*` retornam `NULL`. Use
`mirim_last_error` para erros de execução, libere resultados com
`mirim_result_free` e verifique o retorno de `mirim_checkpoint`.
`mirim_close` não faz checkpoint automaticamente.

Cada identificador de sessão deve pertencer a uma thread, salvo se o
acesso for serializado externamente. Não libere duas vezes, não use após
fechar e não mantenha ponteiros de resultados já liberados. Textos de saída
são UTF-8 com tamanho explícito, não strings terminadas em NUL.

O núcleo proíbe código inseguro. O crate FFI contém a fronteira insegura C
e habilita unwinding para que `catch_unwind` reporte `MIRIM_E_PANIC`.
Isso não torna ponteiros inválidos de C seguros.

<a id="seguranca-e-limites"></a>
## Segurança e limites

- **Disco e backups:** o conteúdo de snapshots e registros do WAL é
  criptografado e autenticado. Tamanho, existência, horários dos arquivos e
  tamanho/quantidade de registros do WAL continuam visíveis.
- **Frase-senha:** Argon2id usa 64 MiB, três passagens e quatro lanes.
  Uma frase-senha fraca continua sujeita a adivinhação. Não há recuperação
  de segredo perdido.
- **Autenticação:** chave incorreta e falha de autenticação do ciphertext
  retornam `Error::Crypto`. Erros de estrutura, versão, tipo de segredo e
  E/S podem ter mensagens diferentes.
- **Máquina comprometida:** malware, administrador hostil ou depurador
  podem obter dados e segredos durante o uso. Swap e core dumps não são
  protegidos pelo mirim; dados abertos ficam na memória do processo.
- **Regressão e truncamento:** um invasor com escrita nos arquivos pode
  restaurar cópias antigas ou truncar o WAL. Reparo de cauda incompleta não
  distingue todos os truncamentos maliciosos de quedas reais.
- **Concorrência:** sessões duráveis adquirem bloqueio exclusivo em Unix
  e Windows; a abertura falha se o bloqueio não estiver disponível. Isso
  não coordena `vault::save` direto, aliases de caminho ou ferramentas que
  ignoram o protocolo. Em Unix o bloqueio é consultivo.
- **Rotação:** trocar o segredo atual não apaga backups ou ciphertext
  residual, nem oferece sigilo futuro para cópias sob o segredo antigo.
- **Recursos:** mesmo um arquivo estruturalmente válido pode exigir muita
  memória. O banco inteiro precisa caber na RAM.

O [modelo de segurança em inglês](../SECURITY.md) é a referência completa,
incluindo considerações sobre dependências criptográficas e a interface C.

<a id="solucao-de-problemas"></a>
## Solução de problemas

| Mensagem ou situação | Verificação |
|---|---|
| `authentication failed` | Segredo incorreto ou autenticação inválida; preserve os arquivos e confira um backup conhecido |
| `corrupt file` | Estrutura danificada ou formato não suportado; faça uma cópia antes de tentar recuperar |
| `secret kind does not match` | Use frase-senha para arquivo derivado de frase-senha, ou chave bruta para arquivo de chave bruta |
| `database is locked` | Encerre o outro escritor; apagar um `.lock` em uso não é uma solução segura |
| `trailing tokens after statement` | Digite um comando por entrada do REPL ou use `.read` |
| `durable session poisoned` | Houve falha de E/S; encerre e reabra preservando o WAL |
| Tabela existente ao importar exemplo | Use um banco novo; a importação não desfaz comandos anteriores |
| Sem anexo para sua plataforma | Compile e teste o código-fonte no destino; confira a arquitetura dos anexos |

<a id="desenvolvimento-e-auditoria"></a>
## Desenvolvimento e auditoria

Na raiz do repositório, com a toolchain fixada:

```sh
cargo fmt --all --check
cargo clippy --locked --all-features --all-targets -- -D warnings
cargo build --locked --no-default-features
cargo build --locked
cargo build --locked --all-features
cargo test --locked
cargo test --locked --all-features
cargo test --locked --test powercut
cargo test --locked --manifest-path gui/Cargo.toml
cargo test --locked --manifest-path ffi/Cargo.toml
cargo fmt --manifest-path gui/Cargo.toml --check
cargo fmt --manifest-path ffi/Cargo.toml --check
cargo clippy --locked --manifest-path gui/Cargo.toml --all-targets -- -D warnings
cargo clippy --locked --manifest-path ffi/Cargo.toml --all-targets -- -D warnings
```

Instale `cargo-audit` e `cargo-deny` para verificar avisos de dependências e
a política do projeto. GUI e FFI têm lockfiles separados; o SBOM do núcleo
não descreve todas as dependências da interface gráfica.

```sh
cargo audit
cargo audit --file gui/Cargo.lock
cargo audit --file ffi/Cargo.lock
cargo deny check
python3 scripts/gen-sbom.py --all-features > /tmp/mirim-sbom-check.json
diff -u sbom.cdx.json /tmp/mirim-sbom-check.json
```

A suíte contém vetores criptográficos fixados, testes de propriedades,
comparação do avaliador SQL com um modelo independente, decodificação
malformada, importação dos exemplos e recuperação após SIGKILL em Unix.
O harness C precisa de clang e Rust nightly com `rust-src`:

```sh
bash ffi/tests/run-sanitizers.sh
```

Para fuzzing, instale nightly e `cargo-fuzz`, gere os corpus e execute:

```sh
cargo run --locked --example gen_fuzz_corpus --features fuzzing,sign
for target in fuzz_wire fuzz_sql fuzz_manifest fuzz_wal fuzz_seal; do
  cargo +nightly fuzz run "$target" -- -max_total_time=60 -rss_limit_mb=4096
done
```

Uma execução finita de fuzzing não cobre todas as entradas. Os fluxos de
[CI do GitHub](../.github/workflows/ci.yml) e
[CI do Forgejo](../.forgejo/workflows/ci.yaml) definem as verificações
automáticas. Ao relatar uma auditoria, informe os comandos e as plataformas
realmente testados, bem como eventuais limitações. Esses testes não são uma
certificação externa de segurança.

Para benchmarks, execute `cargo bench --locked --bench core`. Os resultados
variam com hardware, armazenamento e toolchain; uma comparação de inserção
em lote não estabelece superioridade geral entre bancos. Índices de igualdade
em `PRIMARY KEY` e `UNIQUE` usam buscas hash com custo esperado constante;
outros predicados percorrem as linhas.

## Formatos e arquitetura

| Arquivo/formato | Conteúdo |
|---|---|
| `.mrm`, versão 1 | Cabeçalho autenticado e snapshot XChaCha20-Poly1305 |
| `.mrm.wal`, versão 1 | Identificação do snapshot e registros criptografados sequenciais |
| Exportação selada, versão 1 | Um destinatário ML-KEM-768 |
| Exportação selada, versão 2 | Vários destinatários e uma chave de conteúdo compartilhada |
| `.mf`, versão 1 | Hash SHA-256, contador, tipo e assinatura ML-DSA-87 |
| Arquivo de confiança, versão 1 | Maior contador aceito e hash do artefato correspondente |

Os layouts binários e seus tamanhos ficam centralizados na
[referência de formatos em inglês](GUIDE.md#file-formats), para evitar duas
especificações divergentes. O código em `src/wire.rs`, `src/vault.rs`,
`src/durable.rs`, `src/pq.rs` e `src/manifest.rs` implementa esses formatos.
A [ADR de armazenamento](ADR-001-storage.md) registra a decisão de manter
o banco em memória. O [histórico](../CHANGELOG.md) e o
[processo de publicação](../RELEASE.md) acompanham a evolução do projeto.
