# Licensing

Mirim engine, CLI, FFI, GUI, tests, and other first-party files identified by

`AGPL-3.0-only OR LicenseRef-Mirim-Commercial`

are available under GNU Affero General Public License version 3 only, or a
separate written commercial agreement signed by the applicable copyright
holder and licensee.

The complete public option is in `LICENSE` and `LICENSE-AGPL-3.0`.
`LICENSE-COMMERCIAL` is an inquiry and scope notice, not a public commercial
grant. Without an executed agreement, AGPL-3.0-only governs those files. The
AGPL permits commercial use when its conditions are met.

Files explicitly marked MIT—including selected packaging, build, toolchain,
and policy configuration—remain MIT. Dependencies, test vectors, generated
artifacts, and separately noticed files retain their own licenses. A private
agreement can cover only rights owned or controlled by its licensor.

Contributors retain copyright unless a separate agreement says otherwise. A
DCO or ordinary code submission under AGPL does not automatically authorize
commercial relicensing. Do not include third-party contributions under a
commercial option without an adequate explicit grant.

Commercial licensing inquiries: `sac@securityops.co`. This is a repository
policy summary, not legal advice.
