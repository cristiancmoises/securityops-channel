# Evelin architecture

This document describes how the Evelin workspace is organized, how the layers
fit together, what happens between a TCP accept and channel traffic, where
protocol v1 and v2 diverge, and how trust is established. It is grounded in
the crate manifests, the module documentation of each crate, and
[`docs/PROTOCOL.md`](../PROTOCOL.md) (the wire specification for protocol v1,
written against wire version `0x01`).

## Workspace layout

The Cargo workspace has 20 member crates under `crates/`:

| Crate | Role |
|---|---|
| `evelin-core` | Protocol core types and constants (magic bytes, protocol versions, frame limits, transcript hashing, error types). No cryptographic operations of its own. |
| `evelin-crypto` | Post-quantum cryptographic primitives: a thin, opinionated layer over RustCrypto — ML-KEM-1024 (FIPS 203), ML-DSA-87 (FIPS 204), ChaCha20-Poly1305 (RFC 8439), HKDF-SHA-512 (RFC 5869). |
| `evelin-keys` | Key storage and loading: identity-key files, `authorized_keys`, `known_hosts`, passphrase wrapping, constant-time fingerprint matching. |
| `evelin-config` | Server and client TOML configuration (`server.toml`, `client.toml`), with `deny_unknown_fields`. |
| `evelin-handshake` | The 3-message authenticated key-exchange state machine (transport-agnostic: bytes in, bytes out). |
| `evelin-negotiation` | v4 transcript-bound capability negotiation for protocol v2 (downgrade-resistant by construction). |
| `evelin-record` | Record layer: length-prefixed framing over an authenticated AEAD, with forward-secret key ratcheting. |
| `evelin-channel` | Channel multiplexing layer: sessions, port forwarding, agent forwarding over one record stream. |
| `evelin-session` | Session/exec/PTY/forward/filecopy/fixed-export channel handlers built on `evelin-channel`. |
| `evelin-ext` | Pure-data wire primitives for the v1.5+ extension bitfield and session-resumption ticket plaintext. No I/O, no crypto — split out so fuzz harnesses and formal-model tooling can depend on them without pulling in `evelin-server`. |
| `evelin-ticket` | Session-resumption ticket sealing/opening: XChaCha20-Poly1305 over `evelin_ext::TicketPlaintext`, with rotation-tolerant decryption. |
| `evelin-agent` | Agent daemon: holds unlocked identity keys in memory and signs over a Unix socket; exposes its wire protocol as a library. |
| `evelin-server` | Server binary. Also builds `evelin-keygen`, `evelin-keyscan`, `evelin-multisig-verify`, `evelin-sandbox-probe`, and `evelin-seccomp-probe`. |
| `evelin-client` | Client binary: `exec`, `shell`, `cp`, `forward`, `reverse-forward`, `socks`, `pipe`, jump hosts, proxy-command, `trust` / known-hosts management. |
| `evelin-metrics` | Prometheus exposition: atomic counters, gauges, and histograms with a `/metrics` text encoder; no external metrics library dependency. |
| `evelin-platform` | Platform-abstraction layer (sandboxing, IPC, file-beneath operations) — full Linux implementation, Windows skeleton, macOS/BSD stubs. |
| `evelin-hsm` | PKCS#11 HSM backend for release-signing keys. |
| `evelin-capi` | C ABI wrapper (`libevelin`); foundation for the language SDKs. |
| `evelin-loom-tests` | Loom-based interleaving tests for concurrency primitives (built with `RUSTFLAGS='--cfg loom'`). |
| `evelin-cell` | Separately versioned post-handshake cell context binding and delegated identity primitives. |

## Layering

The protocol stack is a strict progression; each layer consumes only the one
below it:

1. **Core types** (`evelin-core`) — constants and shared types: the `EVLN`
   magic bytes, `PROTOCOL_V1`/`PROTOCOL_V2`, the 16 KiB base frame size
   (`MAX_FRAME_LEN`) and the 1 MiB ceiling (`MAX_FRAME_LEN_BIG`), the
   domain-separation transcript labels (`evelin/1/*`, `evelin/2/*`), the HKDF
   info strings, and the `Direction` nonce tags.
2. **Crypto primitives** (`evelin-crypto`) — narrow wrappers over the
   RustCrypto implementations, enforcing zeroization and constant-time
   comparison where appropriate, so there is one place to audit when an
   upstream advisory lands.
3. **Keys and identity** (`evelin-keys`, `evelin-config`) — on-disk key
   formats, the `authorized_keys` and `known_hosts` trust files, Argon2id
   passphrase wrapping, and the TOML configuration both binaries read.
4. **Handshake** (`evelin-handshake`) — the 3-message authenticated key
   exchange. Transport-agnostic: it consumes byte slices and produces byte
   vectors; the owner of the state machine does the I/O.
5. **Negotiation** (`evelin-negotiation`) — protocol-v2 capability blocks,
   embedded in the signed handshake body. `evelin-handshake` re-exports the
   negotiation surface (`Capabilities`, `Negotiated`, `cap`, `log2_for_kib`)
   so transport code does not depend on `evelin-negotiation` directly.
6. **Record layer** (`evelin-record`) — frames application bytes into
   length-prefixed AEAD-sealed records over the raw stream.
7. **Channel mux** (`evelin-channel`) — multiplexes named channels
   (`session`, `direct-tcpip`, `forwarded-tcpip`, agent channels) over the
   record stream.
8. **Session features** (`evelin-session`) — the things you actually use:
   exec, PTY, port forwarding in both directions, agent forwarding, and
   SCP-style filecopy with an end-to-end SHA-256 integrity check.
9. **Binaries** (`evelin-server`, `evelin-client`, `evelin-agent`) — policy,
   configuration, rate limiting, sandboxing, audit logging, and the CLI
   surface.

Two side branches sit next to the stack rather than in it: `evelin-ext` and
`evelin-ticket` hold the v1.5-era extension bitfield and resumption-ticket
machinery (see the honesty note under "Trust and key model"), and
`evelin-metrics` / `evelin-platform` / `evelin-hsm` / `evelin-capi` serve the
binaries and the release process.

## Connection lifecycle

What happens on the server between `accept()` and channel traffic, as
implemented in `crates/evelin-server/src/main.rs`:

1. **Accept.** One or more accept loops (optional `SO_REUSEPORT` multi-acceptor
   fan-out) take connections from the listener. A semaphore sized by
   `[limits] max_connections` bounds concurrent connections. The socket gets
   `TCP_NODELAY`, and the accept is recorded in the audit log. On Linux, the
   Landlock filesystem sandbox is installed before the server starts
   accepting.
2. **Handshake — 3 fixed-size messages.**
   - Client → server: `HelloClient` — wire version, a random nonce, a fresh
     *ephemeral* ML-KEM-1024 encapsulation key generated for this connection,
     and the client's *long-term* ML-DSA-87 identity public key.
   - Server → client: `HelloServer` — the server's random nonce, an ML-KEM
     ciphertext encapsulated to the client's ephemeral key, the server's
     identity public key, and an ML-DSA-87 signature over the transcript so
     far. Before responding, the server looks up the client key's fingerprint
     in `authorized_keys` (via a caller-provided authorization closure); an
     unknown client fails authorization.
   - Client → server: `Finish` — the client's ML-DSA-87 signature over the
     full transcript.
   Transcript hashing is domain-separated per message with the
   `evelin/1/*` (or, on v2, `evelin/2/*`) labels from `evelin-core`.
3. **Key schedule.** Both sides now hold the ML-KEM shared secret and the
   64-byte SHA-512 transcript hash. `evelin_crypto::derive_session_keys` runs
   HKDF (extract with the transcript hash as salt over the shared secret,
   then expand with the info strings `"evelin v1 c2s key"` and
   `"evelin v1 s2c key"`) to produce one 32-byte ChaCha20-Poly1305 key per
   direction. The shared secret and the client's KEM secret are zeroized
   after derivation. The handshake returns a `HandshakeOutput`: the verified
   peer identity, an outbound and an inbound AEAD codec, the transcript hash
   (usable for channel binding), and the negotiated capability outcome
   (default-empty on v1).
4. **Post-handshake admission.** The server enforces a per-identity
   concurrent-session cap and per-session rate buckets for channel-open
   kinds (exec / forward / filecopy); violations are audit-logged and the
   open is rejected without killing the connection.
5. **Record layer.** The socket is split; the write half becomes a
   `RecordSender`, the read half a `RecordReceiver`, each owning one AEAD
   codec. Every record on the wire is
   `u32 length (BE) || ciphertext (incl. 16-byte tag)`. The 12-byte nonce is
   `direction tag (0x01 c2s / 0x02 s2c) || 3 zero bytes || u64 counter (BE)`;
   each direction counts its own records. Any AEAD verification failure tears
   down the whole connection — loud failure beats silent desync. After 1 GiB
   per direction (default), the direction key is ratcheted forward via HKDF
   with the salt `evelin-ratchet-v1`, the old key is zeroized, and the
   counter resets. On a v2 connection, the negotiated maximum frame size is
   applied to both sender and receiver at this point.
6. **Channel mux.** `Mux::spawn(sender, receiver)` starts the reader/writer
   tasks and yields a handle plus a stream of inbound channel opens. All
   channel messages travel as record plaintext, first byte = message type:
   `OPEN`, `OPEN_OK`, `OPEN_FAIL`, `DATA`, `EOF`, `CLOSE`, `REQUEST`,
   `REPLY_OK`, `REPLY_FAIL` (`0x01`–`0x09`). Each side allocates channel ids
   from its own 32-bit space. There are no explicit flow-control windows in
   the v1 spec; backpressure is provided by the bounded per-channel mpsc
   between the demux and each channel's consumer, backing up into TCP.
7. **Channel traffic.** The server dispatches each inbound open by channel
   type:
   - `session` — `exec`, `pty-req`/`shell` (requires the `pty-shell` build
     feature and `[shell]` config), `window-change`, agent-forward requests;
     the server sends `exit-status` back.
   - `direct-tcpip` — local port forwarding (`-L`) and the inner hop of
     ProxyJump; policy-checked against `[forward] allow`.
   - `forwarded-tcpip` — server-initiated channels for reverse forwarding
     (`-R`); the client asks for the remote bind via the
     `reverse-forward@evelin.securityops.co` control channel, checked against
     `[reverse_forward] allow`.
   - `auth-agent@evelin.securityops.co` — server-initiated channels for agent
     forwarding, routed by the client to the local agent socket.
   - `filecopy@evelin.securityops.co` — upload/download/resume with a final
     `sha256` channel request; the server compares digests in constant time
     and commits via `rename(2)` or deletes the partial file.
   Unknown channel types are rejected.

The client side mirrors this: it validates its protocol settings, resolves
the expected server fingerprint (config pin or `known_hosts`), runs
`ClientHandshake`, applies the same negotiated frame size, spawns the same
mux, and then drives whichever subcommand you invoked. Nested tunnels
(ProxyJump) work because the mux's `ChannelStream` implements the same
byte-stream interface the handshake and record layer run over, so a whole
Evelin connection can ride inside a single channel of another one.

## Protocol v1 vs v2: capability negotiation

Protocol v1 is the default and remains byte-identical on the wire. Protocol
v2 is strictly opt-in: both ends must set `max_protocol_version = 2`. A v2
server still accepts v1 clients, and v1 clients negotiate v1 — which is why
the recommended migration order is servers first.

Where they diverge:

- **What's in the Hello bodies.** v2 appends a canonical capability block to
  the `HelloClient` and `HelloServer` *bodies*. The wire format is a `u16`
  count followed by `(u16 id, u16 value_len, value)` entries in strictly
  ascending id order, no duplicates — a deterministic encoding, so both
  peers hash identical bytes. Bounds: at most 64 capabilities, values at
  most 256 bytes.
- **Why it is downgrade-resistant.** The message *header*
  (`magic || version || msg_type || reserved`) is not fed into the
  transcript hash — only the body is. So the capability block lives in the
  signed body, and the v2 transcript uses distinct domain-separation labels
  (`evelin/2/*`). Stripping, altering, or injecting the block — or rewriting
  the version — changes the transcript and breaks the ML-DSA-87 signatures;
  the handshake aborts. A v1 transcript can never collide with a v2 one.
- **What is negotiated.** Two capabilities are defined:
  - `MAX_FRAME_LOG2` (`0x0001`) — the largest record frame this side will
    accept, as a base-2 log (one byte). Negotiated to the **minimum** of the
    two advertisements. The advertised value comes from the `max_frame_kib`
    config key (a power of two in [16, 1024] KiB, validated at startup —
    default 1024). An advertisement below 2^14 (the 16 KiB v1 base every
    implementation must accept) is a protocol violation and aborts the
    handshake, as does a malformed value shape; since v4.1 both ends compute
    the identical error and abort coherently rather than silently clamping.
  - `REKEY` (`0x0002`) — a presence-only flag, negotiated as logical AND.
    It is negotiated and exposed but reserved for a future asymmetric
    ML-KEM rekey; it is not wired to the always-on record-layer ratchet.
- **Effect on the record layer.** On v2, the negotiated minimum gates both
  `RecordSender` and `RecordReceiver` (clamped into [16 KiB, 1 MiB]). The mux
  fragments channel data to the live frame budget, and a channel `REQUEST`
  too large for the negotiated frame fails its own call (`RequestTooLarge`)
  instead of killing the connection. On v1 nothing is negotiated and the
  defaults apply.
- **Negotiation is authenticated and symmetric.** `negotiate` uses only
  commutative/associative reductions (min, AND), both peers call it with the
  same transcript-bound inputs in the same argument order, so both compute
  the same outcome — and because each offer is signed into the transcript, a
  man-in-the-middle cannot alter either input without aborting the
  handshake.

## Trust and key model

- **Identity keys.** Long-term identities are ML-DSA-87 keypairs, stored as
  a file whose first line is `evelin-identity v1` and whose second line is
  the hex-encoded 32-byte seed. `evelin-keygen` creates them (mode `0o600`
  on Unix, refusing to overwrite). Keys can be passphrase-wrapped with
  Argon2id-derived wrapping keys (`load_identity_file_passphrase` /
  `write_identity_file_passphrase` in `evelin-keys`). The per-connection
  ML-KEM-1024 keypair is ephemeral and never touches disk.
- **Fingerprints.** A key's fingerprint is the SHA-256 of its public-key
  encoding — 32 bytes, rendered as 64 hex characters. Fingerprints, not raw
  keys, are what the trust files store.
- **Server-side trust: `authorized_keys`.** One fingerprint per line under
  the mandatory header `# evelin-authorized-keys v1`; comments are ignored
  and never trusted. An empty or missing file means no client is accepted.
  During the handshake the server authorizes the client's identity
  fingerprint against this set via a closure passed into
  `ServerHandshake::respond`.
- **Client-side trust: pin or `known_hosts`.** If `client.toml` sets
  `server_fingerprint`, that pin always wins. Otherwise the client consults
  the `known_hosts` file (`host:port  evelin-pk  <64-hex>  [comment]` lines
  under the mandatory header `# evelin-known-hosts v1`; a file without the
  header is refused, an absent file is treated as empty). The fingerprint
  comparison is constant-time. You add entries explicitly with
  `evelin-client trust --addr ... --fingerprint ...`, after obtaining the
  fingerprint out-of-band; `evelin-keyscan` can discover what a server
  presents. Jump hosts are looked up in the same `known_hosts` — there is no
  separate trust store for them.
- **Agent.** `evelin-agent` holds unlocked identity keys in memory and signs
  over a Unix socket, exposing its wire protocol as a library so the client
  uses the same encoders/decoders the daemon does. With agent forwarding,
  the client sends a `forward-agent@evelin.securityops.co` request and then
  services server-initiated `auth-agent@evelin.securityops.co` channels —
  each one representing a connection a server-side process made to the
  per-session `EVELIN_AUTH_SOCK` socket — by routing it to the local agent.
- **Resumption tickets — honest status.** The machinery exists as tested
  code: `evelin-ext` defines the fixed 97-byte `TicketPlaintext`,
  `evelin-ticket` seals it into a 137-byte XChaCha20-Poly1305 blob with
  rotation-tolerant decryption (current-or-previous server ticket key), and
  `evelin-server` carries the ticket keyring and a replay guard. Activation,
  however, was designed around the v1.5 `EVLN-EXT-1.5` `RESUME` extension
  bit — and the v3.4 audit found that extension primitive was never wired
  into the live handshake. The live, transcript-bound negotiation mechanism
  is protocol v2's capability block, which does not define a resumption
  capability. Treat tickets as dormant machinery, not a live wire feature.

## Data flow at a glance

```text
 CLIENT HOST                                        SERVER HOST
 -----------                                        -----------
 evelin-client (CLI)          evelin-agent          evelin-server (daemon)
  exec/shell/cp/forward  <--- unix socket            policy, limits, audit,
  socks/jump/trust            (sign, forward)        sandbox
        |                                                 |
 evelin-session  . . . . . . channel semantics . . .  evelin-session
  (exec, pty, filecopy,                                (handlers behind
   forward, agent)                                      config allow-lists)
        |                                                 |
 evelin-channel  . . . . . . OPEN/DATA/REQUEST . . .  evelin-channel
  (mux over one stream)                                (demux, backpressure)
        |                                                 |
 evelin-record   . . . . . . AEAD frames . . . . . .  evelin-record
  (len || ciphertext,                                  (verify, ratchet)
   nonce = dir || counter)
        |                                                 |
        +==================== TCP ========================+

 Once per connection, before any record:

   ClientHandshake                          ServerHandshake
        | -------------- HelloClient -------------> |   (authorized_keys
        | <------------- HelloServer -------------- |    lookup, sign)
        | -------------- Finish ------------------> |
        |                                           |
   verify server fp                            verify client sig
   (pin / known_hosts)                              |
        |                                           |
   [v2 only] evelin-negotiation: signed offers -> Negotiated (min/AND)
        |                                           |
   evelin-crypto: HKDF(transcript, ML-KEM secret) -> c2s + s2c AEAD keys
        |                                           |
        +----> record layer + mux start on both sides <----+
```

## Fixed-export lifecycle (v4.4.0)

The Linux fixed-export client prepares pinned identity/trust files and a private
destination before installing Landlock and creating the async runtime. A
dedicated server admits the named exporter using its identity allowlist,
definition hash, expected format and concurrency budget, then connects to a
pinned local AF_UNIX producer. The receiver validates the streamed bytes and
format, fsyncs its staging inode, and exchanges a fresh challenge-bound commit
acknowledgement before no-overwrite publication. See [fixed exports](fixed-export.md).

Mux shutdown closes channel receivers and pending opens; canceled opens are
closed after late replies. Session cleanup owns its PTY process group and
forwarded-agent listener/connections so transport cancellation propagates to
those resources. These lifecycle changes apply to ordinary sessions as well.
