> Tradução para pt-BR de `docs/en/examples.md`. Em caso de divergência, a versão em inglês prevalece.

# Exemplos e livro de receitas do Evelin

Receitas práticas e prontas para copiar e colar para a cadeia de ferramentas do
Evelin, construídas em torno dos arquivos de exemplo distribuídos e das páginas
de manual.

O Evelin é um túnel seguro pós-quântico: ML-KEM-1024 para encapsulamento de
chaves, ML-DSA-87 para assinaturas, ChaCha20-Poly1305 para a camada de registro.
Os comandos voltados ao usuário têm o formato dos do OpenSSH, mas o protocolo de
transmissão não é compatível com SSH.

Uma breve nota sobre como esta página está fundamentada: cada flag, valor padrão
e chave de configuração abaixo foi conferido contra um arquivo neste
repositório. Onde a sintaxe exata de um comando vem de uma página de manual, ela
é apresentada como verificada. Onde ela vem apenas do quickstart do `README.md`
(porque a página de manual não enumera aquele subcomando), ela é marcada com
**(README)** para que você saiba a fonte. Qualquer coisa que o repositório não
documenta é deixada de fora em vez de ser adivinhada — veja
[Fontes e omissões](#fontes-e-omissões) no final.

## A cadeia de ferramentas

A partir da tabela da cadeia de ferramentas do `README.md`, os binários que você
usará aqui:

| Binário | Análogo no OpenSSH | O que faz |
|---|---|---|
| `evelin-server` | `sshd` | daemon do servidor |
| `evelin-client` | `ssh` | cliente (exec, shell, cópia de arquivos, encaminhamento de portas, SOCKS, jump, proxy-command) |
| `evelin-keygen` | `ssh-keygen` | gera chaves de identidade |
| `evelin-agent` | `ssh-agent` | mantém chaves destravadas em memória |
| `evelin-keyscan` | `ssh-keyscan` | descobre fingerprints de servidores |

## Antes de começar

Alguns fatos que vão poupar seu tempo, todos extraídos da documentação do
repositório:

- **Caminhos dentro de arquivos `.toml` não sofrem expansão pelo shell.** O TOML
  não avalia `$HOME` nem `~`. Use caminhos absolutos dentro de `client.toml` e
  `server.toml` (`/home/you/.config/evelin/id.evelin`, não
  `~/.config/evelin/id.evelin`). Na linha de comando, `~` funciona porque seu
  shell o expande ali.
- **Valide uma configuração de servidor antes de depender dela.**
  `evelin-server --check` carrega e faz o parse do TOML, verifica o caminho da
  chave de identidade e o endereço de bind, e confirma que o arquivo
  `authorized_keys` pode ser carregado, então encerra com `0` (válido) ou `1`
  (inválido) sem vincular a rede. Use-o após cada edição de configuração.
- **O parser da configuração do servidor é estrito.** Conforme
  `evelin.conf(5)`, chaves desconhecidas causam falha na inicialização —
  "erros de digitação em configurações relevantes para a segurança não podem
  ampliar a política silenciosamente." Isso importa abaixo, porque o
  `examples/server.toml` distribuído e o `evelin.conf(5)` discordam em alguns
  nomes de chave de `[ratelimit]`. O crate de configuração
  (`crates/evelin-config/src/lib.rs`) é a autoridade sobre o que o parser
  aceita, e ele corresponde aos nomes do arquivo de exemplo — os nomes do
  `evelin.conf(5)` estão desatualizados. Execute `--check` após qualquer edição
  para confirmar que seu arquivo passa no parse.
- **Não existe flag `--log-level`.** O cliente usa `-v`/`-vv`/`-vvv` para
  detalhes e `-q` para somente erros; `RUST_LOG` substitui o filtro. O
  `log_level` do cliente é mantido por compatibilidade, mas não controla o
  console. O servidor ainda usa `log_level` configurado ou `RUST_LOG`.

---

## Passo a passo: `examples/server.toml`

Este é o exemplo de servidor distribuído. Cada chave que ele contém é explicada
abaixo, com a semântica cruzada com o crate de configuração
(`crates/evelin-config/src/lib.rs`) e o `evelin.conf(5)` — onde os dois
discordam, o crate é a autoridade.

```toml
bind            = "0.0.0.0:2200"
identity_key    = "/etc/evelin/server.key"
authorized_keys = "/etc/evelin/authorized_keys"

log_format = "json"
log_level  = "info"
```

### Chaves de nível superior

- **`bind`** — endereço TCP de escuta, `host:port`. Opcional no crate de
  configuração (`crates/evelin-config/src/lib.rs` usa `0.0.0.0:2200` como
  padrão), embora na prática você deva defini-lo explicitamente. Use
  `127.0.0.1` para escuta apenas local, `0.0.0.0` para escutar em todas as
  interfaces. (O `evelin.conf(5)` o chama de "Obrigatório", mas o código
  fornece um padrão.)
- **`identity_key`** — caminho para a chave de identidade ML-DSA-87 de longo
  prazo do servidor. Obrigatório. Seu modo de arquivo deve ser `0600` ou mais
  restrito, ou o daemon se recusa a iniciar.
- **`authorized_keys`** — caminho para a lista de permissões, por servidor, de
  fingerprints de identidade de clientes (formato no
  [passo a passo de authorized_keys](#passo-a-passo-examplesauthorized_keys)
  abaixo).
- **`log_format`** — `text` ou `json`. O crate de configuração
  (`crates/evelin-config/src/lib.rs`) usa `json` como padrão, que o arquivo de
  exemplo recomenda para produção; `text` é a alternativa legível por humanos.
  (O `evelin.conf(5)` afirma que o padrão é `text`, mas isso está desatualizado
  em relação ao código.)
- **`log_level`** — um de `trace`, `debug`, `info`, `warn`, `error`. Padrão
  `info`. O filtro segue a sintaxe do `tracing-subscriber`, então valores como
  `evelin=debug,hyper=warn` também funcionam.

### `[ratelimit]`

```toml
[ratelimit]
per_ip_connect_per_sec            = 5
per_ip_handshake_failures_per_min = 10
ban_duration_seconds              = 300
max_tracked_ips                   = 65536
handshake_timeout_seconds         = 10
```

Limitação de conexões por IP e banimento por falha de handshake. Os comentários
do exemplo afirmam que esses valores são os padrões, mas o crate de configuração
(`crates/evelin-config/src/lib.rs`) define padrões mais frouxos —
`per_ip_connect_per_sec = 50`, `per_ip_handshake_failures_per_min = 100`,
`ban_duration_seconds = 60`, `handshake_timeout_seconds = 30` e
`max_tracked_ips = 65536`. Omitir a seção dá esses valores mais frouxos, não os
mais restritos mostrados aqui.

> **Discrepância de nomenclatura — o arquivo de exemplo está correto.** O
> exemplo usa `per_ip_connect_per_sec`, `per_ip_handshake_failures_per_min`,
> `ban_duration_seconds`, `max_tracked_ips` e `handshake_timeout_seconds`.
> O crate de configuração (`crates/evelin-config/src/lib.rs`, `RateLimitCfg` com
> `deny_unknown_fields`) aceita exatamente essas cinco chaves, então o arquivo
> de exemplo passa no parse. O `evelin.conf(5)`, em vez disso, documenta
> `per_ip_cps` e `per_ip_max_failures_per_min` e omite `max_tracked_ips` e
> `handshake_timeout_seconds` — esses nomes da página de manual estão
> desatualizados e **não** são aceitos pelo parser. Execute
> `evelin-server --config … --check` após qualquer edição para confirmar que
> seu arquivo passa no parse.

Para desabilitar a limitação de taxa, o exemplo observa que você define as
camadas de conexões-por-segundo e de falhas-por-minuto como `0` (ambas em `0`
desabilitam completamente).

### `[network_acl]`

```toml
[network_acl]
deny  = []
allow = []
```

Permissão/negação de CIDR pré-handshake, avaliada antes do limitador de taxa.

- **`deny`** — blocos CIDR na lista de negação. Padrão vazio.
- **`allow`** — blocos CIDR na lista de permissão. Quando não vazia, um par deve
  corresponder a um deles ou é rejeitado. Padrão vazio (permissivo).

Semântica de `evelin.conf(5)` e dos próprios comentários do arquivo: `deny`
prevalece sobre `allow`; o parser é estrito e rejeita um CIDR com bits de host
não nulos (uma entrada ruim falha no momento do carregamento da configuração com
seu índice nomeado); e um endereço IPv6 mapeado em IPv4 (`::ffff:1.2.3.4`) só
corresponde a entradas IPv6, então liste ambas as formas se você quiser bloquear
um endereço em ambos os espaços.

### `[identity_limits]`

```toml
[identity_limits]
max_sessions_per_identity = 8
```

- **`max_sessions_per_identity`** — limite de sessões concorrentes por
  fingerprint de cliente, contadas após o handshake. Padrão `8`; `0` desabilita
  o limite.

### `[session_rate]`

```toml
[session_rate]
exec_per_sec     = 10
filecopy_per_sec = 5
forward_per_sec  = 20
burst_multiplier = 3
```

Limites token-bucket por sessão sobre quão rápido um par autenticado pode abrir
canais de cada tipo. Todos os quatro valores aqui são os padrões do
`evelin.conf(5)`.

- **`exec_per_sec`** — aberturas de canal exec por segundo. Padrão `10`.
- **`filecopy_per_sec`** — aberturas de canal filecopy por segundo. Padrão `5`.
- **`forward_per_sec`** — aberturas de canal forward por segundo. Padrão `20`.
- **`burst_multiplier`** — a capacidade do bucket é `rate * burst_multiplier`.
  Padrão `3`. Definir uma taxa como `0` desabilita aquele bucket.

### `[audit_log]`

```toml
[audit_log]
# path         = "/var/log/evelin/audit.log"
max_bytes     = 52428800   # 50 MiB
keep_rotated  = 7
honeypot      = false
```

Um log de auditoria somente-anexação, independente do journald.

- **`path`** — arquivo do log de auditoria. Comentado aqui, e um `path`
  vazio/não definido é o padrão, o que significa que **nenhum log de auditoria é
  escrito**. Descomente e defina um caminho para habilitá-lo.
- **`max_bytes`** — rotaciona o arquivo ativo assim que ele excede esse tamanho.
  O exemplo usa `52428800` (50 MiB), que é exatamente o padrão do crate de
  configuração (`crates/evelin-config/src/lib.rs`, `default_audit_max_bytes` =
  50 MiB). (O `evelin.conf(5)` dá o padrão como `1 MiB`, mas isso está
  desatualizado em relação ao código.) Na rotação, o arquivo ativo se torna
  `<path>.1`, os arquivos mais antigos sobem, e o mais antigo é deletado.
- **`keep_rotated`** — número de arquivos rotacionados a reter. `7` aqui, que é
  também o padrão documentado.
- **`honeypot`** — quando `true`, eventos `handshake_fail` incluem o fingerprint
  do cliente apresentado pelo atacante (que é redigido por padrão). Padrão
  `false`. Útil para inteligência de ameaças em um nó honeypot; imprudente em
  uma implantação de produção.

---

## Passo a passo: `examples/client.toml`

```toml
server_addr        = "evelin.example.com:2200"
identity_key       = "/home/you/.config/evelin/id.evelin"
server_fingerprint = "0000000000000000000000000000000000000000000000000000000000000000"

log_format = "text"
log_level  = "info"
```

As chaves de configuração do cliente são descritas aqui a partir dos próprios
comentários do arquivo de exemplo (o `evelin.conf(5)` documenta
especificamente a configuração do servidor).

- **`server_addr`** — o `host:port` do servidor. A página de manual do cliente
  confirma essa chave: `--addr <ADDR>` na linha de comando "Override server_addr
  from config."
- **`identity_key`** — caminho para sua chave de identidade de cliente. Use um
  caminho absoluto (caminhos no TOML não sofrem expansão pelo shell).
- **`server_fingerprint`** — o fingerprint de identidade do servidor, 64
  caracteres hexadecimais (o valor todo-zeros mostrado é um marcador de posição
  a ser substituído). O comentário do exemplo o descreve como "o SHA-256 da
  chave de verificação ML-DSA-87 codificada do servidor." O comentário sugere
  duas formas de obtê-lo: lê-lo do log de inicialização do servidor (o campo
  `server_fingerprint` na linha "evelin server listening"), ou da chave de
  identidade do lado do servidor. Para descobrir o fingerprint de um servidor
  pela rede, `evelin-keyscan` é a ferramenta documentada — veja
  [Descobrir o fingerprint de um servidor](#descobrir-o-fingerprint-de-um-servidor).
- **`log_format`** — `text` por padrão no cliente; logs sempre vão para stderr.
- **`log_level`** — mantido no cliente por compatibilidade; use `-v`/`-q` ou
  `RUST_LOG` para selecionar o nível do console.

Fingerprints de identidade são SHA-256 da chave pública ML-DSA-87 codificada,
resultando em 32 bytes / 64 caracteres hexadecimais. Transfira-os por um canal
independente confiável antes de fixá-los no cliente.

---

## Passo a passo: `examples/authorized_keys`

```
# evelin-authorized-keys v1
# One non-comment line per authorized peer:
#   <hex SHA-256 fingerprint>  <comment>
# 0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef  alice@workstation
```

Esta é a lista de permissões, do lado do servidor, de identidades de clientes.
Formato, conforme `evelin.conf(5)`:

- A **primeira linha não vazia e não comentada deve ser o cabeçalho literal**
  `# evelin-authorized-keys v1`. Um arquivo sem ele é rejeitado no momento do
  parse.
- Cada linha não comentada subsequente é um par autorizado: um **fingerprint de
  64 caracteres hexadecimais**, então espaço em branco opcional e um comentário
  opcional (por exemplo `alice@workstation`).
- O `evelin.conf(5)` afirma que o **modo do arquivo deve ser `0600`**, mas o
  carregador (`crates/evelin-keys/src/lib.rs`, `AuthorizedKeys::load`) **não**
  força nenhum modo — ele lê o arquivo quaisquer que sejam suas permissões,
  diferentemente da chave de identidade, cujos bits de grupo/outros são um erro
  rígido de inicialização. As notas de implantação do `README.md` chegam a fazer
  `chmod 644` neste arquivo. Trate o modo como higiene do operador, não como um
  requisito forçado, mas mantenha o acesso de escrita restrito para que um
  atacante não possa adicionar fingerprints.

Linhas começando com `#` são comentários. No exemplo distribuído, cada linha de
par está comentada, então ele não autoriza ninguém até você adicionar uma linha
de fingerprint real sob o cabeçalho.

---

## Receitas

### Gerar uma chave de identidade

O `evelin-keygen` escreve uma nova chave de identidade em `--out`. Sem opção de
passphrase, a chave é escrita sem criptografia (formato v1).

```sh
# Unencrypted key:
evelin-keygen --out ~/.config/evelin/id.evelin

# Passphrase-wrapped, reading the passphrase from an environment variable:
EVELIN_PASS='correct horse battery staple' \
  evelin-keygen --out ~/.config/evelin/id.evelin --passphrase-from-env EVELIN_PASS

# Passphrase from a file descriptor (0 = stdin):
evelin-keygen --out ~/.config/evelin/id.evelin --passphrase-from-fd 0
```

Os parâmetros do Argon2id para o envelopamento por passphrase são ajustáveis,
com estes padrões documentados:

```sh
# Defaults are: --argon2-m 65536 (KiB = 64 MiB), --argon2-t 3, --argon2-p 1
EVELIN_PASS='…' \
  evelin-keygen --out ~/.config/evelin/id.evelin \
    --passphrase-from-env EVELIN_PASS \
    --argon2-m 131072 --argon2-t 4 --argon2-p 1
```

Todas as flags acima são de `evelin-keygen(1)`. Após gerar uma chave, restrinja
seu modo: `chmod 600 ~/.config/evelin/id.evelin`.

### Descobrir o fingerprint de um servidor

O `evelin-keyscan` se conecta a um servidor e reporta sua chave de host. O
endereço é um argumento posicional `host:port`.

```sh
# Default (text) output:
evelin-keyscan evelin.example.com:2200

# Human-friendly output:
evelin-keyscan --format pretty evelin.example.com:2200

# known-hosts format:
evelin-keyscan --format known-hosts evelin.example.com:2200

# Longer connect + read timeout (default is 10 seconds):
evelin-keyscan --timeout 30 evelin.example.com:2200
```

Flags de `evelin-keyscan(1)`: `--format <FORMAT>` aceita `text` (o padrão),
`pretty` e `known-hosts`; `--timeout <TIMEOUT>` é o timeout de conexão + leitura
em segundos (padrão `10`).

> **Ressalva de segurança.** Um fingerprint obtido por varredura pela rede é
> apenas tão confiável quanto o caminho de rede até o servidor — o keyscan lhe
> dá a chave que o par *apresenta*, não uma prova de quem ele é. O repositório
> aconselha consistentemente obter o fingerprint do servidor fora de banda
> (telefone, papel, e-mail assinado) e compará-lo com o que você escaneia antes
> de confiar nele.

### Executar um comando remoto

> **Invocação do cliente, e de onde vem sua sintaxe.** O `evelin-client(1)`
> documenta as opções de nível superior `--config <CONFIG>` (obrigatória),
> `--addr <ADDR>`, `--connect-timeout <CONNECT_TIMEOUT>` e
> `--proxy-command <PROXY_COMMAND>`, além de um `[COMMAND]` no final. Ele **não**
> enumera os subcomandos de ação (`exec`, `shell`, `cp`, `forward`, `socks`,
> `jump`). A sintaxe exata dos subcomandos nas próximas receitas é tirada do
> quickstart "Client side — first connection" do `README.md` e é marcada com
> **(README)**; a tabela da cadeia de ferramentas do `README.md` confirma que
> essas capacidades do cliente existem (exec, shell, cópia de arquivos,
> encaminhamento de portas, SOCKS, jump, proxy-command).

Executar um único comando no servidor **(README)**:

```sh
evelin-client --config ~/.config/evelin/client.toml exec uname -a
```

O servidor deve permitir o comando. `[exec] allow` é uma lista de permissões de
strings `argv0` exatas (o primeiro token separado por espaço em branco do
comando): o servidor executa uma requisição somente quando seu `argv0` é
exatamente igual a uma entrada listada
(`crates/evelin-session/src/exec.rs`). Uma lista vazia desabilita o exec
inteiramente. (O `evelin.conf(5)` chama esses de "padrões glob" com um exemplo
`echo *`, mas o código distribuído faz correspondência exata de `argv0`, não
globbing, então uma entrada com curinga nunca corresponderia.)

Você pode combinar a chamada de exec com as opções de nível superior
documentadas na página de manual — por exemplo, um timeout de conexão mais
curto, ou sobrescrever o endereço do servidor a partir da configuração:

```sh
# --connect-timeout and --addr are documented in evelin-client(1):
evelin-client --config ~/.config/evelin/client.toml \
  --connect-timeout 5 --addr evelin.example.com:2200 exec uname -a
```

### Shell interativo

Abrir uma sessão interativa **(README)**:

```sh
evelin-client --config ~/.config/evelin/client.toml shell
```

> **O shell interativo precisa de uma feature de build.** As notas de implantação
> do `README.md` afirmam que `[shell]` requer a feature Cargo `pty-shell` no
> momento do build, e o tarball musl distribuído é construído sem ela. O campo
> de configuração é aceito pelo parser de qualquer forma, mas um servidor
> compilado sem `pty-shell` recusa `pty-req` em tempo de execução. Use um build
> com a feature (reconstrua com
> `cargo build --release --features pty-shell -p evelin-server`, ou o binário
> `pty-shell` publicado) se você precisar de shells com PTY.

### Copiar arquivos (ambas as direções)

Copiar um arquivo local para cima, para o servidor **(README)** — o lado remoto
é escrito com um prefixo `remote:`:

```sh
evelin-client --config ~/.config/evelin/client.toml cp ./local.txt remote:/tmp/
```

A direção de download usa o mesmo prefixo `remote:` na *origem*:

```sh
evelin-client --config ~/.config/evelin/client.toml cp remote:/tmp/report.txt ./
```

Em um TTY, o `cp` mostra uma barra de progresso estilo scp no **stderr** —
porcentagem, transferido/total, taxa e ETA — seguida de um resumo de uma
linha (`… SHA-256 verified · Quantum-secured!`). Ele respeita a verbosidade:
`-q` silencia a barra e o resumo por completo (apenas erros, como
`scp -q`), e `-v` adiciona detalhe por arquivo. Como o progresso e os logs
vão para o stderr, os bytes transferidos no stdout ficam limpos.

```sh
# silencioso: sem barra, sem resumo — apenas erros
evelin-client -q --config ~/.config/evelin/client.toml cp ./big.iso remote:/srv/
```

> **Nota de fundamentação.** O quickstart do `README.md` mostra a forma de
> upload (`cp ./local.txt remote:/tmp/`) literalmente; a forma de download acima
> aplica a mesma convenção de prefixo `remote:` à origem e não é mostrada
> literalmente no quickstart. As flags `-q`/`-v` e o formato da barra de
> progresso seguem `crates/evelin-client/src/progress.rs`.

O filecopy deve estar habilitado no lado do servidor. Conforme o crate de
configuração (`crates/evelin-config/src/lib.rs`, `FileCopyPolicyCfg` com
`deny_unknown_fields`), a seção `[filecopy]` recebe `roots` (uma lista de
prefixos de caminho sob os quais as transferências devem canonicalizar — vazia,
o padrão, nega o filecopy inteiramente), `allow_upload` e `allow_download`
(ambos `bool`, padrão `false`) e `max_file_size` (um limite por transferência;
`0`, o padrão, significa nenhum limite de política). Isso corresponde às notas
de implantação do `README.md`. Não há chave `enabled` nem `chroot` — o parser
estrito as rejeita — então o `evelin.conf(5)`, que documenta
`enabled` + `chroot` + `max_file_size`, está desatualizado aqui. Confirme que
seu arquivo passa no parse com `evelin-server --check`.

### Encaminhamento de porta local

Encaminhar uma porta TCP local para um destino alcançável a partir do servidor
**(README)**:

```sh
# Listen locally on 8080, forward to internal.example:80 via the server:
evelin-client --config ~/.config/evelin/client.toml forward -L 8080:internal.example:80
```

O servidor deve permitir o destino. Conforme o crate de configuração
(`crates/evelin-config/src/lib.rs`, `ForwardPolicyCfg`), `[forward] allow` é a
lista de destinos `host:port` para os quais um cliente pode encaminhar TCP (o
padrão é vazio, o que desabilita o encaminhamento), e `wildcards` (`bool`,
padrão `false`) permite que uma entrada de host `"*"` corresponda a qualquer
coisa. Isso corresponde ao trecho de configuração do servidor do `README.md`.

> **Nota sobre chave de configuração.** O `evelin.conf(5)` nomeia esta chave
> como `[forward] allow_dst`, mas o código distribuído aceita `[forward] allow`
> (mais `wildcards`); o nome da página de manual está desatualizado. Confirme
> que seu arquivo passa no parse com `evelin-server --check`.

A flag `-L` em si vem do quickstart do `README.md`, não da página de manual do
cliente.

### Proxy SOCKS

Executar um encaminhamento dinâmico SOCKS5 local **(README)**:

```sh
# Local SOCKS5 proxy on port 1080, tunneled through the server:
evelin-client --config ~/.config/evelin/client.toml socks -D 1080
```

Aponte um navegador ou `curl --socks5 127.0.0.1:1080 …` para ele. Como com `-L`,
cada `CONNECT` do SOCKS abre um canal `direct-tcpip` no servidor, então o lado
do servidor deve permitir os destinos de saída
([`[forward] allow`](#encaminhamento-de-porta-local), mais `wildcards`). A flag `-D` vem do
quickstart do `README.md`.

### Host de salto (jump) e proxy-command

`--proxy-command` é a forma documentada na página de manual de alcançar um
servidor por meio de um intermediário. De `evelin-client(1)`:

> `--proxy-command <PROXY_COMMAND>` — External proxy command — equivalent of
> OpenSSH's `ProxyCommand`. The given shell command is launched and its
> stdin/stdout become the transport for the Evelin handshake. Use this for HTTP
> CONNECT proxies, jumphosts via SSH, corporate-network tunneling tools, or
> anything else that gives you a byte-pipe to the server.

Portanto, qualquer comando que produz um byte-pipe para o servidor funciona como
transporte:

```sh
# Reach the server through a corporate HTTP CONNECT proxy (from README):
evelin-client --config ~/.config/evelin/client.toml \
  --proxy-command 'corkscrew proxy.corp 8080 $EVELIN_HOST $EVELIN_PORT' \
  exec hostname
```

> A flag `--proxy-command` e sua descrição são verificadas em
> `evelin-client(1)`. Os marcadores de posição `$EVELIN_HOST` / `$EVELIN_PORT`
> no exemplo do `corkscrew` são mostrados no quickstart do `README.md`, mas
> **não** são descritos na página de manual, então trate essas substituições
> específicas como provenientes do README.

O quickstart do `README.md` também mostra uma flag dedicada `--jump` como
conveniência:

```sh
# --jump is shown in the README quickstart, not in evelin-client(1):
evelin-client --config ~/.config/evelin/client.toml \
  --jump bastion.example:2200 exec hostname
```

Como `--jump` não está na página de manual, prefira `--proxy-command` (que é
documentada) se você quiser depender apenas de flags verificadas na página de
manual.

### Usar o agente

O `evelin-agent` mantém chaves de identidade destravadas em memória e as expõe
por um socket Unix. Pelo menos um `--identity` é obrigatório, e a flag pode ser
repetida.

```sh
# Load a single key:
evelin-agent --identity ~/.config/evelin/id.evelin

# Load several keys:
evelin-agent --identity ~/.config/evelin/work.evelin \
             --identity ~/.config/evelin/home.evelin

# Unlock passphrase-wrapped identities from an environment variable:
EVELIN_PASS='…' \
  evelin-agent --identity ~/.config/evelin/id.evelin --passphrase-from-env EVELIN_PASS

# Bind the socket somewhere explicit (default is $XDG_RUNTIME_DIR/evelin-agent.sock):
evelin-agent --identity ~/.config/evelin/id.evelin \
  --socket /run/user/1000/evelin-agent.sock

# Cap concurrent client connections (default 32):
evelin-agent --identity ~/.config/evelin/id.evelin --max-connections 8
```

Todas as flags acima são de `evelin-agent(1)`: `--identity <IDENTITY>`
(obrigatória, repetível), `--passphrase-from-env <VAR>` (usada se qualquer
identidade carregada estiver envelopada), `--socket <SOCKET>` (padrão
`$XDG_RUNTIME_DIR/evelin-agent.sock`) e `--max-connections <MAX_CONNECTIONS>`
(padrão `32`).

> **O que a página de manual não cobre.** O `evelin-agent(1)` documenta as
> opções do próprio agente, mas não como o `evelin-client` é informado a
> consumir o socket do agente (não há flag de cliente nem variável de ambiente
> documentada para isso nas páginas de manual). Em vez de inventar uma, esta
> receita para em iniciar o agente e carregar as chaves.

### Operações do servidor

Iniciar e validar o daemon, tudo de `evelin-server(8)`:

```sh
# Start the server:
evelin-server --config /etc/evelin/server.toml

# Validate the config and exit (0 = valid, 1 = invalid); does not bind or listen.
# Good for systemd ExecStartPre, CI, or checking an edit before a reload:
evelin-server --config /etc/evelin/server.toml --check

# Generate a new identity key on startup if the configured path does not exist:
evelin-server --config /etc/evelin/server.toml --init

# -c is the short form of --config:
evelin-server -c /etc/evelin/server.toml --check
```

---

## Fontes e omissões

Tudo acima foi verificado contra um arquivo neste repositório:
`examples/server.toml`, `examples/client.toml`, `examples/authorized_keys`,
`crates/evelin-config/src/lib.rs` e `crates/evelin-session/src/exec.rs`
(o schema de configuração autoritativo e a fonte da correspondência de exec),
`man/evelin.conf.5`, `man/evelin-client.1`, `man/evelin-server.8`,
`man/evelin-keygen.1`, `man/evelin-keyscan.1`, `man/evelin-agent.1`, e a tabela
da cadeia de ferramentas e o quickstart do `README.md`. Onde o `evelin.conf(5)`
discordou do crate de configuração, o crate (o que o parser de fato aceita)
prevalece.

Deliberadamente deixado de fora ou explicitamente atribuído por falta de
fundamentação na página de manual:

- Os subcomandos de ação do cliente (`exec`, `shell`, `cp`, `forward -L`,
  `socks -D`, `--jump`) **não** são enumerados em `evelin-client(1)`; sua
  sintaxe exata é marcada com **(README)** porque vem do quickstart do
  `README.md`.
- O encaminhamento reverso de porta (`reverse-forward -R`) não está no conjunto
  de receitas solicitado e não é coberto aqui.
- Os marcadores de posição `$EVELIN_HOST` / `$EVELIN_PORT` do proxy-command são
  mostrados como provenientes do README, já que a página de manual não os
  descreve.
- O mecanismo pelo qual o `evelin-client` consome o socket do `evelin-agent` não
  está documentado nas páginas de manual, então não é afirmado.
- Várias diretivas do `evelin.conf(5)` estão desatualizadas em relação ao crate
  de configuração distribuído (`crates/evelin-config/src/lib.rs`), e os passos a
  passo acima estão corrigidos conforme o código: os nomes e padrões de chave de
  `[ratelimit]`, a chave de `[forward]` (`allow`, não `allow_dst`), o schema de
  `[filecopy]` (`roots` + `allow_upload` + `allow_download` + `max_file_size`,
  não `enabled` + `chroot`), a correspondência de `[exec] allow` (exata por
  `argv0`, não glob), e os padrões de `log_format` e de `max_bytes` da
  auditoria. Confirme que seu arquivo passa no parse com `evelin-server --check`.

## Receber uma exportação definida pelo servidor (Linux, v4.4.0)

Use `evelin-client fixed-export` com um serviço de exportação dedicado para
receber um dump PostgreSQL custom ou arquivo pax restrito do Forgejo. O cliente
fornece ID, hash da definição, formato esperado e limite de bytes, e grava um
novo destino local privado. Leia [exportações fixas](fixed-export.md) para a
política completa do servidor e a receita do receptor: este modo exige Landlock
antes do runtime e recusa descritores herdados de terminal, comandos remotos
genéricos e caminhos remotos.
