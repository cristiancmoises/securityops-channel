> Tradução para pt-BR de `docs/en/faq.md`. Em caso de divergência, a versão em inglês prevalece.

# Perguntas frequentes

As respostas refletem o Evelin v4.4.0 (2026-09-06). Toda resposta abaixo se
baseia em um arquivo deste repositório — a fonte é indicada ao final de cada
resposta. Quando a resposta honesta é "não" ou "ainda não", é isso que você vai
ler.

## Geral

### O que é o Evelin?

Um túnel seguro pós-quântico escrito em Rust. O handshake usa ML-KEM-1024
(FIPS 203) para encapsulamento de chaves e ML-DSA-87 (FIPS 204) para assinaturas
— ambos na categoria de segurança 5 do NIST — e a camada de registro é
ChaCha20-Poly1305 com um KDF HKDF-SHA-512. O formato da toolchain é
deliberadamente inspirado no OpenSSH (`evelin-server` ≈ `sshd`, `evelin-client` ≈
`ssh`, `evelin-keygen` ≈ `ssh-keygen`, `evelin-agent` ≈ `ssh-agent`), de modo
que operadores não precisam reaprender nada. (Fonte: `README.md`.)

### Por que não simplesmente usar o OpenSSH?

Para a maioria dos usuários, você deveria — o próprio documento de comparação do
projeto diz isso. O OpenSSH é o padrão certo para acesso remoto de propósito
geral: ~30 anos de implantação, múltiplas implementações interoperáveis, um
ecossistema de ferramentas enorme e (desde a 10.0) troca de chaves híbrida
pós-quântica por padrão. O Evelin é para o caso mais restrito em que você
especificamente deseja *autenticação* pós-quântica (não apenas troca de chaves
PQ — o OpenSSH não fornece nenhuma assinatura PQ até a 10.2), uma implementação
com segurança de memória e uma base de código pequena o bastante para de fato
ser lida — e você aceita as concessões de maturidade de um transporte jovem, de
implementação única, sem nenhuma auditoria externa concluída. (Fonte:
`COMPARISON.md`.)

### O Evelin é compatível no nível de fio (wire-compatible) com o SSH?

Não, e nunca será — isso é uma decisão de design, não uma lacuna do roadmap.
Apenas o formato da toolchain voltada ao usuário é emprestado do OpenSSH; o
protocolo de fio é próprio do Evelin. (Fonte: `README.md`.)

### Por que pós-quântico agora, se os computadores quânticos ainda não conseguem quebrar nada?

Por causa do "colher agora, decifrar depois" (harvest now, decrypt later): um
adversário que grava seu tráfego hoje pode decifrá-lo daqui a anos, assim que um
computador quântico suficientemente grande existir. A troca de chaves clássica
gravada hoje é quebrável retroativamente; o acordo de chaves ML-KEM-1024 não é —
um futuro computador quântico executando o algoritmo de Shor não consegue
recuperar as chaves de sessão a partir de uma transcrição gravada. Se você grava
tráfego hoje e precisa que ele permaneça confidencial daqui a dez ou vinte anos,
os padrões clássicos do SSH não bastam. Esse caso é exatamente para o que o
Evelin serve. (Fontes: `README.md`, `docs/THREAT-MODEL.md` §1.1 e §1.6.)

### Por que pós-quântico puro em vez de um híbrido, como o OpenSSH usa?

A KEX híbrida do OpenSSH mantém um respaldo (backstop) X25519: se o ML-KEM cair
por criptanálise, as sessões ainda se apoiam em um problema difícil clássico. O
ML-KEM-1024 puro do Evelin não tem respaldo clássico. Essa é uma posição de
design deliberada (e em uma categoria mais alta do que o ML-KEM-768 do OpenSSH),
mas o próprio documento de comparação do projeto chama isso pelo que é: uma
concessão real de ponto único de falha, não uma vitória absoluta. (Fonte:
`COMPARISON.md`.)

## Protocolo

### Por que o handshake tem ~17,6 KB — tão maior que o do SSH?

O handshake tem 3 mensagens totalizando 17.662 bytes (1,5 RTT): HelloClient
4.200 B, HelloServer 8.827 B, Finish 4.635 B. O grosso é material de chave
pós-quântica — só uma assinatura ML-DSA-87 tem 4.627 bytes e uma chave pública
tem 2.592 bytes. Um handshake padrão do OpenSSH 10.2 fica na ordem de 3–4 KB
(estimado a partir dos tamanhos de objeto dos algoritmos, não capturado em
pacotes), de modo que o do Evelin é cerca de 4–5× maior no fio. Esse é o preço
das assinaturas PQ na categoria 5; em qualquer enlace onde 17 KB importam (alta
latência, restrito), o SSH vence essa dimensão sem discussão. (Fonte:
`COMPARISON.md`.)

### O que são os protocolos v1 e v2?

O v1 é o protocolo de fio original. O v2, que atingiu GA na v4.0.0, adiciona
negociação de capacidades opt-in, vinculada à transcrição e resistente a
downgrade: o bloco de capacidades vive no corpo do handshake assinado, de modo
que remover, alterar ou injetá-lo — ou reescrever a versão — quebra a assinatura
ML-DSA-87 e aborta o handshake. O v2 atualmente negocia o tamanho do frame de
registro (a camada de registro o limita ao intervalo [16 KiB, 1 MiB]; o v1 é
fixo em 16 KiB); uma capacidade `REKEY` é negociada, mas reservada para uma
futura rechaveação (rekey) assimétrica ML-KEM. O v2 é estritamente opt-in:
defina `max_protocol_version = 2` em ambas as pontas. Com o padrão (`1`, ou não
definido), as implantações são idênticas byte a byte ao v1 no fio. Atualize os
servidores primeiro — um servidor com suporte a v2 ainda aceita clientes v1, mas
um cliente v2 contra um servidor somente v1 é rejeitado. Nenhum formato de
chave, identidade ou ticket mudou. (Fontes: `CHANGELOG.md` v4.0.0, `README.md`,
`SECURITY.md`.)

### O Evelin tem sigilo futuro (forward secrecy)?

A camada de registro executa um ratchet de chaves HKDF unidirecional sempre
ativo: quando uma direção ultrapassa 1 GiB desde o último ratchet, uma nova
chave ChaCha20-Poly1305 é derivada e os bytes da chave antiga são zerados, de
modo que um comprometimento de chave no meio da sessão não expõe o tráfego
anterior ao último ponto de ratchet. A ressalva declarada: este é um ratchet
simétrico unidirecional, não uma rechaveação ML-KEM completa — o PFS vale para
frente a partir de cada ponto de ratchet, não para trás. A capacidade `REKEY` do
v2 está reservada para uma futura rechaveação assimétrica ML-KEM. (Fontes:
`docs/THREAT-MODEL.md` §3.5, `CHANGELOG.md` v4.0.0.)

### Qual é a história de retomada de sessão / 0-RTT?

O Evelin tem tickets de retomada de sessão: uma reconexão a quente apresenta um
ticket e pula o encapsulamento ML-KEM, mas o handshake retomado ainda exige uma
troca de confirmação do servidor antes que o cliente possa enviar bytes de
aplicação. Os tickets são selados com XChaCha20-Poly1305 sob um keyring rotativo
do lado do servidor (keyring de N gerações desde a v1.9, padrão de 4 gerações
com rotação de 24 horas), e o `max_age_secs` padrão do ticket é 172800 (48
horas, reduzido de 7 dias na v1.8).

Dados de aplicação em 0-RTT verdadeiro — enviar bytes da aplicação no primeiro
voo (first flight) — foram explicitamente avaliados e rejeitados. O
`docs/THREAT_MODEL_0RTT.md` enumera oito ameaças (replay dentro da janela,
replay entre reinícios, perda de sigilo futuro, reutilização de ticket entre
modos, vazamento de identidade de protocolo, amplificação, DoS por tempestade de
replays e efeitos colaterais antes da confirmação de identidade) e audita cada
protocolo de aplicação embutido contra elas: zero dos cinco se qualificam em uma
configuração padrão. A decisão foi NO-GO; o próprio modelo de ameaças foi
publicado em vez do recurso. (Fontes: `docs/THREAT_MODEL_0RTT.md`,
`CHANGELOG.md` v1.8.0, v1.9.0.)

### Existe confiança no primeiro uso (trust-on-first-use), como o prompt de chave de host do SSH?

Não. Não há confiança automática no primeiro uso: o cliente se recusa a conectar
a menos que a impressão digital de identidade do servidor corresponda ao que
está fixado (pinned) em `client.toml` ou `known_hosts`, e espera-se que você
obtenha a impressão digital do servidor por um canal externo (telefone, papel,
e-mail assinado) e a adicione com o subcomando `trust` do cliente. Do lado do
servidor, os clientes são verificados contra `authorized_keys`. As impressões
digitais são SHA-256 da chave pública ML-DSA-87 codificada, representado como
64 caracteres hexadecimais. (Fontes: `docs/THREAT-MODEL.md` §1.3, `README.md`.)

## Postura de segurança

### O Evelin foi auditado por terceiros?

Não. O Evelin é autopublicado; não houve nenhuma auditoria criptográfica paga de
terceiros. O autor recebe bem a revisão da comunidade e pretende encomendar uma
auditoria paga depois de acumular experiência operacional. O próprio documento
de comparação do projeto é direto sobre o que isso significa: um transporte
jovem, de implementação única, sem nenhuma auditoria externa concluída carrega
um risco que nenhuma lista de recursos compensa — as mitigações (base de código
pequena e auditável, segurança de memória, lemas centrais verificados por
máquina, artefatos reprodutíveis) reduzem esse risco, mas não o eliminam.
(Fontes: `SECURITY.md`, `COMPARISON.md`, `docs/THREAT-MODEL.md` §6.)

### O Evelin é formalmente verificado?

Parcialmente, e o projeto se recusa a arredondar isso para cima. Para o handshake
primário, 5 lemas Tamarin e 8 consultas ProVerif foram verificados por máquina
na cerimônia de prova v0.1 (sigilo central, autenticação mútua, sigilo futuro
perfeito). Lemas adicionais — incluindo os modelos de negociação v2 adicionados
na v4.0.0 — estão DECLARADOS, mas não verificados por máquina. Nas próprias
palavras do README: **não** "totalmente verificado formalmente". O status por
lema fica em `verification/VERIFICATION_STATUS.md`. (Fontes: `README.md`,
`COMPARISON.md`, `CHANGELOG.md` v4.0.0.)

### Contra o que o Evelin *não* protege?

O modelo de ameaças é explícito sobre suas lacunas:

- **Análise de tráfego.** Os registros revelam o comprimento e o tempo do texto
  plano; não há preenchimento (padding) nem tráfego de cobertura. Se isso está
  no seu modelo de ameaças, execute o Evelin dentro de uma sobreposição
  (overlay) que resista a isso.
- **Comprometimento de endpoint.** Um laptop com keylogger derrota tudo.
- **Um atacante root que permaneça residente** pode assinar handshakes com a
  identidade do servidor até você rotacionar a chave (chaves protegidas por
  frase-senha protegem apenas a cópia em repouso).
- **Negação de serviço** por um atacante determinado; existe `[limits]
  max_connections` e limites por frame, mas o listener pode ser saturado.
- **Canais laterais de hardware** — as primitivas vêm de implementações de
  biblioteca em tempo constante, mas o próprio Evelin não foi auditado contra
  vazamento por canal lateral.

(Fonte: `docs/THREAT-MODEL.md` §2.)

### Como reporto uma vulnerabilidade?

Envie e-mail para `sac@securityops.co` com o prefixo de assunto `[SECURITY]`. Não
abra issues públicas — não há rastreador público de issues; o repositório
primário é uma instância privada do Forgejo com mirrors públicos somente
leitura. E-mail em texto plano é aceitável para o contato inicial; uma chave PGP
temporária para detalhes de exploit será fornecida em até 72 horas (uma
impressão digital de chave está publicada em
`https://securityops.co/.well-known/pgp/security.asc`). A janela de divulgação
padrão é de 90 dias a partir do reconhecimento. Não há recompensa monetária; os
reportadores são creditados no CHANGELOG com a permissão deles. (Fonte:
`SECURITY.md`.)

## Desempenho e plataformas

### O desempenho é comparável ao do OpenSSH?

Desconhecido, e o projeto se recusa a chutar. O OpenSSH não foi avaliado no mesmo
hardware, então nenhuma afirmação comparativa de vazão ou latência é feita — o
documento de comparação chama supor que o Evelin é mais rápido de "exatamente o
tipo de afirmação que este projeto recusa". O que foi medido para o próprio
Evelin (container de 1 core, loopback; métodos em `docs/BENCHMARKS.md`): teto
AEAD de 1,13 GiB/s ao selar (seal) / 924 MiB/s ao abrir (open) em blocos de
1 MiB; cópia de arquivo em massa de ~50–75 MiB/s em núcleo único; e, para os
binários v4.1.1 em execução, uma mediana de conexão completa + handshake + exec
+ encerramento de 11,7 ms sobre loopback. (Fonte: `COMPARISON.md`.)

### Quais plataformas são suportadas?

Somente Linux, no lançamento atual. O lançamento v4.0.0 empacotou 3× `.deb`
Debian (musl-static amd64), 3× RPM (x86_64), um `.deb` Termux aarch64, tarballs
aarch64 e x86_64-musl, e um tarball de fonte. macOS, Windows e os BSDs não são
suportados: a base de código depende de primitivas específicas do Linux
(Landlock, seccomp-bpf, `openat2` com `RESOLVE_BENEATH`, IPC de agente por socket
de domínio Unix), e o projeto optou por não distribuir binários multiplataforma
que careçam dessas defesas. A v1.9 introduziu o crate de abstração
`evelin-platform` como a fronteira de portabilidade — sua implementação Linux
está completa, o backend Windows é um esqueleto que compila com testes de tempo
de execução pendentes, e os backends macOS/FreeBSD/OpenBSD são stubs que retornam
`Unimplemented`. O caminho documentado para usuários de Windows hoje é o WSL2 com
uma distro Debian/Ubuntu/Fedora. (Fontes: `CHANGELOG.md` v4.0.0 e v1.9.0,
`crates/evelin-platform/`, `docs/PLATFORM_BUILDS.md`.)

### Como faço a migração a partir do OpenSSH?

Incrementalmente, lado a lado — nada no Evelin conflita com um `sshd` residente,
e o documento de comparação chama rodar os dois (o Evelin na sua própria porta ao
lado do sshd) de uma postura de migração razoável. A toolchain mapeia um para um
(`evelin-server`/`sshd`, `evelin-client`/`ssh`, `evelin-keygen`/`ssh-keygen`,
`evelin-agent`/`ssh-agent`, `evelin-keyscan`/`ssh-keyscan`), de modo que o fluxo
de trabalho é preservado. Você não pode reutilizar chaves do OpenSSH: as
identidades do Evelin são pares de chaves ML-DSA-87, então você gera novas com
`evelin-keygen` e inscreve as impressões digitais delas em `authorized_keys`
(lado do servidor) e no armazenamento de confiança do cliente. Configuração do
servidor, configuração do cliente e a primeira conexão são detalhadas passo a
passo no `README.md`. Quem tem um fluxo de trabalho que depende de SFTP,
certificados, PAM ou clientes SSH de terceiros deve permanecer no OpenSSH.
(Fontes: `COMPARISON.md`, `README.md`.)

### Quais recursos do SSH estão faltando?

Presentes: exec, shell PTY interativo, cópia de arquivos (`cp`, o próprio
protocolo do Evelin com raiz em política), encaminhamento local/reverso/SOCKS
(-L/-R/-D), agente e encaminhamento de agente, ProxyJump, tickets de retomada de
sessão, um exportador de métricas Prometheus. Ausentes: compatibilidade com o
protocolo SFTP, encaminhamento X11, certificados assinados por CA,
PAM/GSSAPI/Kerberos, o ecossistema `ssh_config` e o compartilhamento
ControlMaster — e há apenas uma implementação do protocolo, contra as muitas do
OpenSSH. (Fonte: `COMPARISON.md`.)

## Chaves e hardware

### O Evelin suporta chaves de hardware ou HSMs?

Não para o handshake de transporte, e o código diz isso claramente: até o momento
em que o crate `evelin-hsm` foi escrito, nenhum HSM comercial expõe assinatura
ML-DSA por PKCS#11 (os IDs de mecanismo do FIPS 204 ainda estão sendo
padronizados no PKCS#11 v3.2), então o crate atualmente não assina handshakes de
transporte do Evelin a partir de um HSM. O que ele de fato valida de ponta a
ponta contra uma implementação real de PKCS#11 (SoftHSM2) é a assinatura Ed25519
de *manifesto de lançamento* (release-manifest) — carregamento do módulo,
abertura de sessão, login por PIN, geração de chave no token, assinatura,
verificação, exportação de chave pública — de modo que, quando os mecanismos
ML-DSA chegarem, trocar o mecanismo seja uma mudança de uma linha em `sign()`.
Para proteção de chave em repouso hoje, as chaves de identidade podem ser
protegidas por frase-senha com Argon2id (m=64 MiB, t=3, p=1). (Fontes:
`crates/evelin-hsm/src/lib.rs`, `README.md`.)

## SDKs e integração

### Existem SDKs para linguagens além do Rust?

O diretório `sdk/` contém SDKs de cliente para 12 linguagens: C, Rust, Python,
Go, Node.js, Ruby, Java, Swift, .NET, Elixir, OCaml e Guile. O SDK Rust é o único
nativo — ele consome os crates do workspace diretamente; os outros são bindings
de linguagem sobre a ABI C do `libevelin` (o SDK Python, por exemplo, usa
`ctypes` da stdlib contra `libevelin.so`; o SDK Elixir é uma NIF Rustler que faz
link com o `libevelin`). Uma ressalva ao ler a árvore: o diretório Swift
atualmente contém apenas um manifesto de pacote e um shim de módulo C
(`Package.swift`, `shim.h`, `module.modulemap`) sem nenhum arquivo de fonte
Swift, então trate-o como um esqueleto de empacotamento e não como um SDK
funcional. (Fontes: árvore `sdk/`, `sdk/rust/src/lib.rs`,
`sdk/python/evelin/__init__.py`, `sdk/elixir/native/evelin_nif/Cargo.toml`.)

## Licenciamento

### Qual é a licença — minha empresa pode usar o Evelin?

O Evelin tem licença dupla: AGPL-3.0-or-later (o padrão) ou uma licença
comercial. Sob a AGPL você pode executar o Evelin para qualquer finalidade,
incluindo uso comercial — indivíduos, pesquisadores, educadores, estudantes,
hobbyistas, organizações sem fins lucrativos e qualquer pessoa que execute o
Evelin para uso próprio sem modificação ou provisão de serviço estão totalmente
cobertos e nada devem. A cláusula de uso em rede da AGPL significa que, se você
modificar o Evelin e executar a versão modificada como um serviço de rede, você
deve disponibilizar sua fonte modificada aos usuários dela. A licença comercial
existe para usos incompatíveis com isso: incorporação de código fechado,
execução de um Evelin modificado como serviço sem liberar as modificações, ou
organizações cujas políticas proíbem software AGPL. Consultas:
`sac@securityops.co` (de um a dois dias úteis é o tempo normal de resposta).
(Fontes: `NOTICE`, `README.md`.)

### Posso contribuir e o que acontece com a licença da minha contribuição?

Ao contribuir com código você concorda que ele é licenciado sob os mesmos termos
de licença dupla que o restante do projeto. O detentor dos direitos autorais
reserva-se o direito de relicenciar a obra combinada sob termos de código aberto
diferentes no futuro, desde que esses termos permaneçam ao menos tão copyleft
quanto a AGPL atual. (Fonte: `NOTICE`.)

## Posso receber uma exportação fixa sem permitir exec remoto?

Sim. A versão 4.4.0 adiciona `fixed-export`, exclusivo do Linux, desabilitado por
padrão e servido por uma instância dedicada. Suporta dumps PostgreSQL custom e
um arquivo pax restrito do Forgejo. As duas pontas exigem Landlock totalmente
aplicado antes do runtime; o receptor valida e confirma um arquivo parcial
privado antes de publicá-lo. Veja [exportações fixas](fixed-export.md) para
configuração, regras de descritores sem terminal, limites e recuperação. Um
arquivo de dados Forgejo sozinho não é um backup completo.
