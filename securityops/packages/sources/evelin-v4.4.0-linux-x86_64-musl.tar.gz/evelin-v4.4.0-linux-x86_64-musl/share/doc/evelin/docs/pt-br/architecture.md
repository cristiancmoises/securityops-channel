> Tradução para pt-BR de `docs/en/architecture.md`. Em caso de divergência, a versão em inglês prevalece.

# Arquitetura do Evelin

Este documento descreve como o workspace do Evelin é organizado, como as
camadas se encaixam, o que acontece entre um accept TCP e o tráfego de canais,
onde os protocolos v1 e v2 divergem e como a confiança é estabelecida. Ele se
baseia nos manifestos das crates, na documentação de módulo de cada crate e em
[`docs/PROTOCOL.md`](../PROTOCOL.md) (a especificação de fio para o protocolo
v1, escrita contra a versão de fio `0x01`).

## Layout do workspace

O workspace Cargo tem 20 crates membros sob `crates/`:

| Crate | Papel |
|---|---|
| `evelin-core` | Tipos e constantes centrais do protocolo (magic bytes, versões de protocolo, limites de frame, hashing de transcript, tipos de erro). Não possui operações criptográficas próprias. |
| `evelin-crypto` | Primitivas criptográficas pós-quânticas: uma camada fina e opinativa sobre o RustCrypto — ML-KEM-1024 (FIPS 203), ML-DSA-87 (FIPS 204), ChaCha20-Poly1305 (RFC 8439), HKDF-SHA-512 (RFC 5869). |
| `evelin-keys` | Armazenamento e carregamento de chaves: arquivos de chave de identidade, `authorized_keys`, `known_hosts`, encapsulamento por passphrase, correspondência de fingerprint em tempo constante. |
| `evelin-config` | Configuração TOML de servidor e cliente (`server.toml`, `client.toml`), com `deny_unknown_fields`. |
| `evelin-handshake` | A máquina de estados de troca de chaves autenticada em 3 mensagens (agnóstica de transporte: bytes de entrada, bytes de saída). |
| `evelin-negotiation` | Negociação de capacidades v4 vinculada ao transcript para o protocolo v2 (resistente a downgrade por construção). |
| `evelin-record` | Camada de record: enquadramento com prefixo de comprimento sobre um AEAD autenticado, com ratcheting de chaves com forward secrecy. |
| `evelin-channel` | Camada de multiplexação de canais: sessões, encaminhamento de portas, encaminhamento de agente sobre um único fluxo de record. |
| `evelin-session` | Handlers de canal de sessão/exec/PTY/forward/filecopy/fixed-export construídos sobre `evelin-channel`. |
| `evelin-ext` | Primitivas de fio puramente de dados para o bitfield de extensão v1.5+ e o texto puro do ticket de retomada de sessão. Sem I/O, sem cripto — separadas para que harnesses de fuzz e ferramentas de modelo formal possam depender delas sem puxar o `evelin-server`. |
| `evelin-ticket` | Selagem/abertura de ticket de retomada de sessão: XChaCha20-Poly1305 sobre `evelin_ext::TicketPlaintext`, com descriptografia tolerante a rotação. |
| `evelin-agent` | Daemon de agente: mantém chaves de identidade desbloqueadas em memória e assina sobre um socket Unix; expõe seu protocolo de fio como uma biblioteca. |
| `evelin-server` | Binário do servidor. Também compila `evelin-keygen`, `evelin-keyscan`, `evelin-multisig-verify`, `evelin-sandbox-probe` e `evelin-seccomp-probe`. |
| `evelin-client` | Binário do cliente: `exec`, `shell`, `cp`, `forward`, `reverse-forward`, `socks`, `pipe`, jump hosts, proxy-command, gerenciamento de `trust` / known-hosts. |
| `evelin-metrics` | Exposição Prometheus: contadores atômicos, gauges e histogramas com um codificador de texto `/metrics`; sem dependência de biblioteca externa de métricas. |
| `evelin-platform` | Camada de abstração de plataforma (sandboxing, IPC, operações file-beneath) — implementação Linux completa, esqueleto para Windows, stubs para macOS/BSD. |
| `evelin-hsm` | Backend HSM PKCS#11 para chaves de assinatura de release. |
| `evelin-capi` | Wrapper de C ABI (`libevelin`); base para os SDKs de linguagem. |
| `evelin-loom-tests` | Testes de intercalação baseados em Loom para primitivas de concorrência (compilados com `RUSTFLAGS='--cfg loom'`). |
| `evelin-cell` | Primitivas de vínculo de contexto de célula pós-handshake e identidade delegada, com versão independente. |

## Camadas

A pilha de protocolo é uma progressão estrita; cada camada consome apenas a
camada imediatamente abaixo:

1. **Tipos centrais** (`evelin-core`) — constantes e tipos compartilhados: os
   magic bytes `EVLN`, `PROTOCOL_V1`/`PROTOCOL_V2`, o tamanho de frame base de
   16 KiB (`MAX_FRAME_LEN`) e o teto de 1 MiB (`MAX_FRAME_LEN_BIG`), os rótulos
   de transcript de separação de domínio (`evelin/1/*`, `evelin/2/*`), as
   strings de info do HKDF e as tags de nonce `Direction`.
2. **Primitivas criptográficas** (`evelin-crypto`) — wrappers estreitos sobre
   as implementações do RustCrypto, impondo zeroização e comparação em tempo
   constante onde apropriado, de modo que haja um único lugar a auditar quando
   um aviso upstream surgir.
3. **Chaves e identidade** (`evelin-keys`, `evelin-config`) — formatos de chave
   em disco, os arquivos de confiança `authorized_keys` e `known_hosts`, o
   encapsulamento de passphrase com Argon2id e a configuração TOML que ambos os
   binários leem.
4. **Handshake** (`evelin-handshake`) — a troca de chaves autenticada em 3
   mensagens. Agnóstica de transporte: consome fatias de bytes e produz vetores
   de bytes; o dono da máquina de estados faz o I/O.
5. **Negociação** (`evelin-negotiation`) — blocos de capacidades do protocolo
   v2, embutidos no corpo assinado do handshake. `evelin-handshake` reexporta a
   superfície de negociação (`Capabilities`, `Negotiated`, `cap`,
   `log2_for_kib`) para que o código de transporte não dependa diretamente do
   `evelin-negotiation`.
6. **Camada de record** (`evelin-record`) — enquadra bytes de aplicação em
   records selados com AEAD e prefixados por comprimento sobre o fluxo bruto.
7. **Mux de canais** (`evelin-channel`) — multiplexa canais nomeados
   (`session`, `direct-tcpip`, `forwarded-tcpip`, canais de agente) sobre o
   fluxo de record.
8. **Recursos de sessão** (`evelin-session`) — as coisas que você realmente
   usa: exec, PTY, encaminhamento de portas em ambas as direções,
   encaminhamento de agente e filecopy no estilo SCP com uma verificação de
   integridade SHA-256 ponta a ponta.
9. **Binários** (`evelin-server`, `evelin-client`, `evelin-agent`) — política,
   configuração, limitação de taxa, sandboxing, log de auditoria e a superfície
   de CLI.

Dois ramos laterais ficam ao lado da pilha em vez de dentro dela: `evelin-ext`
e `evelin-ticket` contêm o bitfield de extensão da era v1.5 e a maquinaria de
ticket de retomada (veja a nota de honestidade em "Modelo de confiança e
chaves"), e `evelin-metrics` / `evelin-platform` / `evelin-hsm` / `evelin-capi`
servem os binários e o processo de release.

## Ciclo de vida da conexão

O que acontece no servidor entre `accept()` e o tráfego de canais, conforme
implementado em `crates/evelin-server/src/main.rs`:

1. **Accept.** Um ou mais loops de accept (fan-out multi-acceptor opcional com
   `SO_REUSEPORT`) recebem conexões do listener. Um semáforo dimensionado por
   `[limits] max_connections` limita as conexões concorrentes. O socket recebe
   `TCP_NODELAY`, e o accept é registrado no log de auditoria. No Linux, o
   sandbox de sistema de arquivos Landlock é instalado antes de o servidor
   começar a aceitar.
2. **Handshake — 3 mensagens de tamanho fixo.**
   - Cliente → servidor: `HelloClient` — versão de fio, um nonce aleatório, uma
     chave de encapsulamento ML-KEM-1024 *efêmera* recém-gerada para esta
     conexão e a chave pública de identidade *de longo prazo* ML-DSA-87 do
     cliente.
   - Servidor → cliente: `HelloServer` — o nonce aleatório do servidor, um
     ciphertext ML-KEM encapsulado para a chave efêmera do cliente, a chave
     pública de identidade do servidor e uma assinatura ML-DSA-87 sobre o
     transcript até então. Antes de responder, o servidor procura o fingerprint
     da chave do cliente em `authorized_keys` (via uma closure de autorização
     fornecida pelo chamador); um cliente desconhecido falha na autorização.
   - Cliente → servidor: `Finish` — a assinatura ML-DSA-87 do cliente sobre o
     transcript completo.
   O hashing do transcript é separado por domínio por mensagem com os rótulos
   `evelin/1/*` (ou, na v2, `evelin/2/*`) do `evelin-core`.
3. **Key schedule.** Ambos os lados agora possuem o segredo compartilhado
   ML-KEM e o hash de transcript SHA-512 de 64 bytes.
   `evelin_crypto::derive_session_keys` executa o HKDF (extract com o hash de
   transcript como salt sobre o segredo compartilhado, depois expand com as
   strings de info `"evelin v1 c2s key"` e `"evelin v1 s2c key"`) para produzir
   uma chave ChaCha20-Poly1305 de 32 bytes por direção. O segredo compartilhado
   e o segredo KEM do cliente são zeroizados após a derivação. O handshake
   retorna um `HandshakeOutput`: a identidade verificada do peer, um codec AEAD
   de saída e um de entrada, o hash de transcript (utilizável para channel
   binding) e o resultado de capacidades negociado (vazio por padrão na v1).
4. **Admissão pós-handshake.** O servidor impõe um limite de sessões
   concorrentes por identidade e buckets de taxa por sessão para os tipos de
   abertura de canal (exec / forward / filecopy); violações são registradas no
   log de auditoria e a abertura é rejeitada sem derrubar a conexão.
5. **Camada de record.** O socket é dividido; a metade de escrita torna-se um
   `RecordSender`, a metade de leitura um `RecordReceiver`, cada uma possuindo
   um codec AEAD. Cada record no fio é
   `u32 length (BE) || ciphertext (incl. 16-byte tag)`. O nonce de 12 bytes
   é `direction tag (0x01 c2s / 0x02 s2c) || 3 zero bytes || u64 counter (BE)`;
   cada direção conta seus próprios records. Qualquer falha de verificação AEAD
   derruba a conexão inteira — falhar ruidosamente é melhor do que
   dessincronizar em silêncio. Após 1 GiB por direção (padrão), a chave da
   direção sofre ratchet para frente via HKDF com o salt `evelin-ratchet-v1`, a
   chave antiga é zeroizada e o contador é reiniciado. Em uma conexão v2, o
   tamanho máximo de frame negociado é aplicado tanto ao sender quanto ao
   receiver neste ponto.
6. **Mux de canais.** `Mux::spawn(sender, receiver)` inicia as tasks de
   leitor/escritor e produz um handle mais um fluxo de aberturas de canal de
   entrada. Todas as mensagens de canal viajam como texto puro de record,
   primeiro byte = tipo de mensagem: `OPEN`, `OPEN_OK`, `OPEN_FAIL`, `DATA`,
   `EOF`, `CLOSE`, `REQUEST`, `REPLY_OK`, `REPLY_FAIL` (`0x01`–`0x09`). Cada
   lado aloca ids de canal a partir do seu próprio espaço de 32 bits. Não há
   janelas explícitas de controle de fluxo na especificação v1; a
   contrapressão é fornecida pelo mpsc limitado por canal entre o demux e o
   consumidor de cada canal, acumulando-se de volta no TCP.
7. **Tráfego de canais.** O servidor despacha cada abertura de entrada por tipo
   de canal:
   - `session` — `exec`, `pty-req`/`shell` (requer a feature de build
     `pty-shell` e a configuração `[shell]`), `window-change`, requisições de
     agent-forward; o servidor envia `exit-status` de volta.
   - `direct-tcpip` — encaminhamento de porta local (`-L`) e o salto interno do
     ProxyJump; verificado por política contra `[forward] allow`.
   - `forwarded-tcpip` — canais iniciados pelo servidor para encaminhamento
     reverso (`-R`); o cliente solicita o bind remoto via o canal de controle
     `reverse-forward@evelin.securityops.co`, verificado contra
     `[reverse_forward] allow`.
   - `auth-agent@evelin.securityops.co` — canais iniciados pelo servidor para
     encaminhamento de agente, roteados pelo cliente até o socket de agente
     local.
   - `filecopy@evelin.securityops.co` — upload/download/retomada com uma
     requisição final de canal `sha256`; o servidor compara digests em tempo
     constante e efetiva via `rename(2)` ou deleta o arquivo parcial.
   Tipos de canal desconhecidos são rejeitados.

O lado do cliente espelha isso: ele valida suas configurações de protocolo,
resolve o fingerprint esperado do servidor (pin de configuração ou
`known_hosts`), executa o `ClientHandshake`, aplica o mesmo tamanho de frame
negociado, spawna o mesmo mux e então conduz qualquer subcomando que você
tenha invocado. Túneis aninhados (ProxyJump) funcionam porque o `ChannelStream`
do mux implementa a mesma interface de fluxo de bytes sobre a qual o handshake
e a camada de record operam, de modo que uma conexão Evelin inteira pode
trafegar dentro de um único canal de outra.

## Protocolo v1 vs v2: negociação de capacidades

O protocolo v1 é o padrão e permanece idêntico byte a byte no fio. O protocolo
v2 é estritamente opt-in: ambas as pontas devem definir
`max_protocol_version = 2`. Um servidor v2 ainda aceita clientes v1, e clientes
v1 negociam v1 — razão pela qual a ordem de migração recomendada é servidores
primeiro.

Onde eles divergem:

- **O que está nos corpos do Hello.** A v2 anexa um bloco canônico de
  capacidades aos *corpos* do `HelloClient` e do `HelloServer`. O formato de
  fio é uma contagem `u16` seguida de entradas `(u16 id, u16 value_len, value)`
  em ordem estritamente ascendente de id, sem duplicatas — uma codificação
  determinística, de modo que ambos os peers façam hash de bytes idênticos.
  Limites: no máximo 64 capacidades, valores de no máximo 256 bytes.
- **Por que é resistente a downgrade.** O *cabeçalho* da mensagem
  (`magic || version || msg_type || reserved`) não é alimentado no hash do
  transcript — apenas o corpo é. Assim, o bloco de capacidades vive no corpo
  assinado, e o transcript v2 usa rótulos de separação de domínio distintos
  (`evelin/2/*`). Remover, alterar ou injetar o bloco — ou reescrever a versão
  — muda o transcript e quebra as assinaturas ML-DSA-87; o handshake aborta. Um
  transcript v1 nunca pode colidir com um v2.
- **O que é negociado.** Duas capacidades são definidas:
  - `MAX_FRAME_LOG2` (`0x0001`) — o maior frame de record que este lado
    aceitará, como um log de base 2 (um byte). Negociado para o **mínimo** das
    duas ofertas. O valor anunciado vem da chave de configuração `max_frame_kib`
    (uma potência de dois em [16, 1024] KiB, validada na inicialização — padrão
    1024). Uma oferta abaixo de 2^14 (a base v1 de 16 KiB que toda
    implementação deve aceitar) é uma violação de protocolo e aborta o
    handshake, assim como um formato de valor malformado; desde a v4.1 ambas as
    pontas calculam o mesmo erro e abortam coerentemente em vez de silenciosamente
    fazerem clamp.
  - `REKEY` (`0x0002`) — um flag apenas de presença, negociado como AND lógico.
    Ele é negociado e exposto, mas reservado para um futuro rekey ML-KEM
    assimétrico; não está conectado ao ratchet sempre-ativo da camada de record.
- **Efeito na camada de record.** Na v2, o mínimo negociado limita tanto o
  `RecordSender` quanto o `RecordReceiver` (com clamp em [16 KiB, 1 MiB]). O mux
  fragmenta os dados de canal para o orçamento de frame vigente, e um `REQUEST`
  de canal grande demais para o frame negociado falha em sua própria chamada
  (`RequestTooLarge`) em vez de matar a conexão. Na v1 nada é negociado e os
  padrões se aplicam.
- **A negociação é autenticada e simétrica.** `negotiate` usa apenas reduções
  comutativas/associativas (min, AND), ambos os peers a chamam com as mesmas
  entradas vinculadas ao transcript na mesma ordem de argumentos, de modo que
  ambos calculam o mesmo resultado — e porque cada oferta é assinada no
  transcript, um man-in-the-middle não pode alterar nenhuma das entradas sem
  abortar o handshake.

## Modelo de confiança e chaves

- **Chaves de identidade.** Identidades de longo prazo são pares de chaves
  ML-DSA-87, armazenados como um arquivo cuja primeira linha é
  `evelin-identity v1` e cuja segunda linha é a seed de 32 bytes codificada em
  hex. O `evelin-keygen` as cria (modo `0o600` no Unix, recusando-se a
  sobrescrever). As chaves podem ser encapsuladas por passphrase com chaves de
  encapsulamento derivadas por Argon2id (`load_identity_file_passphrase` /
  `write_identity_file_passphrase` em `evelin-keys`). O par de chaves
  ML-KEM-1024 por conexão é efêmero e nunca toca o disco.
- **Fingerprints.** O fingerprint de uma chave é o SHA-256 da codificação de
  sua chave pública — 32 bytes, renderizados como 64 caracteres hex. São os
  fingerprints, não as chaves brutas, que os arquivos de confiança armazenam.
- **Confiança no lado do servidor: `authorized_keys`.** Um fingerprint por
  linha sob o cabeçalho obrigatório `# evelin-authorized-keys v1`; comentários
  são ignorados e nunca confiáveis. Um arquivo vazio ou ausente significa que
  nenhum cliente é aceito. Durante o handshake, o servidor autoriza o
  fingerprint de identidade do cliente contra esse conjunto via uma closure
  passada para `ServerHandshake::respond`.
- **Confiança no lado do cliente: pin ou `known_hosts`.** Se o `client.toml`
  definir `server_fingerprint`, esse pin sempre vence. Caso contrário, o
  cliente consulta o arquivo `known_hosts` (linhas
  `host:port  evelin-pk  <64-hex>  [comment]` sob o cabeçalho obrigatório
  `# evelin-known-hosts v1`; um arquivo sem o cabeçalho é recusado, um arquivo
  ausente é tratado como vazio). A comparação de fingerprint é em tempo
  constante. Você adiciona entradas explicitamente com
  `evelin-client trust --addr ... --fingerprint ...`, após obter o fingerprint
  fora de banda; o `evelin-keyscan` pode descobrir o que um servidor apresenta.
  Jump hosts são consultados no mesmo `known_hosts` — não há um armazenamento
  de confiança separado para eles.
- **Agente.** O `evelin-agent` mantém chaves de identidade desbloqueadas em
  memória e assina sobre um socket Unix, expondo seu protocolo de fio como uma
  biblioteca para que o cliente use os mesmos encoders/decoders que o daemon
  usa. Com o encaminhamento de agente, o cliente envia uma requisição
  `forward-agent@evelin.securityops.co` e então atende canais
  `auth-agent@evelin.securityops.co` iniciados pelo servidor — cada um
  representando uma conexão que um processo do lado do servidor fez ao socket
  `EVELIN_AUTH_SOCK` por sessão — roteando-a para o agente local.
- **Tickets de retomada — status honesto.** A maquinaria existe como código
  testado: `evelin-ext` define o `TicketPlaintext` fixo de 97 bytes,
  `evelin-ticket` o sela em um blob XChaCha20-Poly1305 de 137 bytes com
  descriptografia tolerante a rotação (chave de ticket do servidor atual ou
  anterior), e `evelin-server` carrega o keyring de tickets e uma proteção
  contra replay. A ativação, no entanto, foi projetada em torno do bit de
  extensão `RESUME` do `EVLN-EXT-1.5` da v1.5 — e a auditoria da v3.4 constatou
  que essa primitiva de extensão nunca foi conectada ao handshake vivo. O
  mecanismo de negociação vivo e vinculado ao transcript é o bloco de
  capacidades do protocolo v2, que não define uma capacidade de retomada. Trate
  os tickets como maquinaria dormente, não como um recurso de fio vivo.

## Fluxo de dados em resumo

```text
 CLIENT HOST                                        SERVER HOST
 -----------                                        -----------
 evelin-client (CLI)          evelin-agent          evelin-server (daemon)
  exec/shell/cp/forward  <--- unix socket            policy, limits, audit,
  socks/jump/trust            (sign, forward)        sandbox
        |                                                 |
 evelin-session  . . . . . . channel semantics . . .  evelin-session
  (exec, pty, filecopy,                                (handlers behind
   forward, agent)                                      config allow-lists)
        |                                                 |
 evelin-channel  . . . . . . OPEN/DATA/REQUEST . . .  evelin-channel
  (mux over one stream)                                (demux, backpressure)
        |                                                 |
 evelin-record   . . . . . . AEAD frames . . . . . .  evelin-record
  (len || ciphertext,                                  (verify, ratchet)
   nonce = dir || counter)
        |                                                 |
        +==================== TCP ========================+

 Once per connection, before any record:

   ClientHandshake                          ServerHandshake
        | -------------- HelloClient -------------> |   (authorized_keys
        | <------------- HelloServer -------------- |    lookup, sign)
        | -------------- Finish ------------------> |
        |                                           |
   verify server fp                            verify client sig
   (pin / known_hosts)                              |
        |                                           |
   [v2 only] evelin-negotiation: signed offers -> Negotiated (min/AND)
        |                                           |
   evelin-crypto: HKDF(transcript, ML-KEM secret) -> c2s + s2c AEAD keys
        |                                           |
        +----> record layer + mux start on both sides <----+
```

## Ciclo de exportação fixa (v4.4.0)

O cliente Linux prepara arquivos de identidade/confiança fixados e um destino
privado antes de aplicar Landlock e criar o runtime assíncrono. Um servidor
dedicado admite o exportador identificado pela lista de identidades autorizadas,
hash da definição, formato esperado e limite de concorrência, depois conecta a
um produtor AF_UNIX local fixado. O receptor valida bytes e formato, sincroniza
o inode parcial e troca confirmação de commit vinculada a um novo desafio
antes de publicar sem substituição. Veja [exportações fixas](fixed-export.md).

O encerramento do mux fecha receptores de canais e aberturas pendentes;
aberturas canceladas são fechadas após respostas tardias. A limpeza da sessão
gerencia seu grupo de processos PTY e listener/conexões de agente encaminhado,
propagando o cancelamento do transporte a esses recursos. Essas mudanças de
ciclo de vida também se aplicam às sessões comuns.
