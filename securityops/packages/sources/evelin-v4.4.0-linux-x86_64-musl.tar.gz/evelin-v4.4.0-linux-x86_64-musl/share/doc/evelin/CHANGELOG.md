# Changelog

All notable changes to Evelin are documented here.

## v4.4.0 — 2026-09-06

Fixed exports for dedicated Linux instances, connection lifecycle fixes, and
updated English/Brazilian Portuguese operator documentation.

### Added

- `evelin-client fixed-export`: request a named server-defined PostgreSQL custom
  dump or Forgejo pax archive, with an expected definition SHA-256, format and
  byte ceiling. No client-selected remote command, path, argument or credential.
- `[fixed_export]` and per-exporter configuration: default-deny enablement,
  client identity allowlists, global concurrency limit, pinned local Unix socket
  identity/peer credentials, size limits and deadlines. Enabled exporters require
  a dedicated daemon with generic session/forwarding/filecopy capabilities off.
- Mandatory pre-runtime Landlock ABI v3 for fixed-export client/server, private
  pinned client inputs, constrained inherited descriptors, purpose-specific
  PostgreSQL/Forgejo helpers, and a standalone Forgejo archive validator.
- Durable receiver staging with independent SHA-256 and format checks,
  PostgreSQL `pg_restore --list` or internal extraction-free Forgejo validation,
  a fresh challenge-bound commit acknowledgement and no-overwrite publication.
  Failures after acknowledgement retain the durable partial for local recovery.
- Paired [English](docs/en/fixed-export.md) and
  [Brazilian Portuguese](docs/pt-br/fixed-export.md) fixed-export operator guides.

### Fixed

- Filecopy success summaries now correctly name SHA-256 integrity verification.
- Transport shutdown closes live channel handles and pending opens. Saturated
  receive channels cannot leave the transport reader blocked indefinitely;
  close delivery preserves already-decoded data ordering.
- Canceled channel opens are closed when late successful replies arrive, without
  closing unrelated channels. Dropping the last mux owner cancels its pumps.
- PTY teardown handles peer disconnects and canonical input waits. Linux
  cleanup uses pidfds to terminate PTY-session members, including jobs in
  separate process groups; it does not claim to reap processes that deliberately
  escape into a new session. Session cancellation removes forwarded-agent
  listeners and terminates their accepted forwarding connections.
- Current READMEs now describe SHA-256 identity fingerprints, default-enabled
  PTY builds, current Linux installation and client verbosity correctly.
- Removed the reusable sprint prompt from published source documentation.
  Release-process and claims guidance remains in `CONTRIBUTING.md`.
- Fixed-export receive deadlines remain enforced even when buffered data can
  complete without yielding to the timeout task.

### Release inputs

`Cargo.lock` is now tracked and `rust-toolchain.toml` selects Rust 1.93.0.
Dependency changes must update the lockfile deliberately; release checks use
locked resolution.

### Compatibility and operational scope

Existing identity keys and trust files remain usable. Upgrade both endpoints
before using the new fixed-export channel. General-purpose deployments retain
fixed exports disabled; enabling the new mode requires a separate configured
service. The channel's `v2` suffix identifies its own application codec and does
not replace the existing opt-in protocol-v2 handshake negotiation.

The shipped PostgreSQL helper requires an actual ELF `pg_dump` at its compiled
path; Debian's wrapper script is rejected. Forgejo exports intentionally omit
sensitive configuration and database files and are not complete backups by
themselves. No new throughput, external-audit or formal-proof claim is made.

## v4.3.0 — 2026-07-24

**Client UX release: quiet-by-default connections and an
scp-familiar file copy.** No wire-protocol, on-disk-format, key, or
ticket change — this is client-side console/UX behaviour only, and
the server is untouched. No third-party cryptographic audit has been
performed (see `SECURITY.md`).

### Quiet by default, verbose on request (like `ssh`)

Previously the client emitted its connection lifecycle
(`handshake complete`, `interactive shell open`, negotiated frame
size, …) at INFO, and — because the default log format was `json` —
those structured lines were written to **stdout**, so an interactive
shell or a piped command was buried under log noise such as
`{"timestamp":…,"message":"handshake complete",…}`.

- **The client is now quiet by default.** A successful connection
  prints nothing but the remote session itself; only warnings and
  errors are shown. `evelin-client … shell` now looks like
  `ssh user@host`.
- **`-v` / `-vv` / `-vvv` opt into detail** (repeatable, like
  `ssh -v`): `-v` shows the lifecycle at INFO, `-vv` adds DEBUG,
  `-vvv` adds TRACE. `-q` shows errors only. A non-empty `RUST_LOG`
  still overrides everything, for power users.
- **Logs never touch stdout anymore.** All console logging — text
  *and* json — goes to stderr, so `exec`/`pipe` output and `cp` data
  on stdout stay clean and pipeable.
- **The client's default log format is now `text`** (human-readable),
  not `json`; set `log_format = "json"` in `client.toml` for
  machine-parseable client logs. The **server daemon still defaults
  to `json`** — production log shippers are unaffected. The client's
  console level is now controlled by `-v`/`-q` (or `RUST_LOG`); the
  `log_level` field in `client.toml` is retained for back-compat but
  no longer sets it.

### scp-familiar file copy

- `evelin-client cp` now honours `-q` (silent: no progress bar, no
  summary) and `-v` (per-file detail), wiring up the verbosity that
  was previously stubbed out.
- The progress bar gained an explicit percentage column, matching the
  shape operators expect from `scp`
  (`[■■■…] 42% · 1.26 MiB/3.00 MiB · 118 MiB/s · ETA 0s`). The success
  summary keeps its integrity/security note
  (`… BLAKE3 verified · Quantum-secured!`). Transfers remain
  byte-identical and BLAKE3-verified; the security properties are
  unchanged.

### Migration

Purely additive on the command line. Scripts that parsed the client's
json log lines from **stdout** must either read them from **stderr**
now, or pass `-v` (json still available via `log_format = "json"`).
Interactive users need do nothing.

### Verification

- `cargo clippy --workspace --all-targets -- -D warnings`: clean.
- `cargo test --workspace --release`: 440 passed, 0 failed, run twice.
- Live end-to-end with the release binaries: default `exec`/`shell`
  emit a clean stdout with an empty stderr; `-v` shows the text
  lifecycle on stderr with stdout still clean; `cp` of a 3 MiB file
  is byte-identical with the progress summary on stderr, and `-q`
  makes it silent.

## v4.2.0 — 2026-07-20

**Source-level release: documentation, allocation-reducing
performance work, and two security-advisory dependency bumps.** The
wire protocol, on-disk formats, keys, and tickets are unchanged;
every code change is behaviour-preserving and byte-identical on the
wire. This commit ships source and documentation — it does **not**
rebuild or re-sign the binary packages; that remains the
maintainer's release-ceremony step. No third-party cryptographic
audit has been performed (see `SECURITY.md`).

### Security — dependency advisories cleared

`Cargo.lock` is intentionally untracked in this repository
(`.gitignore`), so these fixes arrive through version resolution
rather than a committed lockfile: any fresh resolution now selects
the patched releases, and the build-environment lockfile was
refreshed (`cargo update -p …`) to verify the result.

- **`crossbeam-epoch` 0.9.18 → 0.9.20** clears **RUSTSEC-2026-0204**
  (invalid pointer dereference in the `fmt::Pointer` impl for
  `Atomic`/`Shared`). The crate reaches the tree only through
  `criterion`, a dev-dependency (benchmarks), so shipped binaries
  were never exposed; the refresh makes
  `scripts/cargo-audit-blocking.sh` pass regardless.
- **`anyhow` 1.0.102 → 1.0.104** clears **RUSTSEC-2026-0190**
  (unsoundness in `Error::downcast_mut`), an informational advisory.
- `cargo audit` is green after both bumps (advisory DB 2026-07-17);
  two `unmaintained` informational warnings remain (`paste`,
  `number_prefix`), neither with a patched version nor a
  vulnerability.

### Performance — allocation and copy reduction on hot paths

Each change was proposed, then adversarially reviewed for
behaviour-preservation (byte-identical wire output, unchanged
error ordering, constant-time discipline intact, no zeroize
weakened, no `unsafe`, no new dependency) before landing. Impact is
stated honestly: these remove allocations and memory copies per
record/chunk; no wall-clock throughput number is claimed, because
`docs/BENCHMARKS.md` records bulk transfer as core-contention-bound
rather than copy- or AEAD-bound. The full test suite (below) proves
the behaviour is unchanged.

- **Receive-side in-place decrypt.** New `Aead::open_in_place`
  (evelin-crypto) mirrors the shipped v3.2 `seal_in_place`;
  `RecordReceiver::recv` now decrypts its read buffer in place,
  removing one full-frame heap allocation + copy per inbound record.
  Cryptographic behaviour, counter advance, `CryptoVerify` mapping,
  and ratchet accounting are identical to `open`. New equivalence and
  tamper-rejection tests pin it.
- **Outbound tag pre-sizing.** `ChannelMsg::encode` reserves the
  16-byte AEAD tag in the Data-frame capacity so the record layer's
  `seal_in_place` no longer reallocates the whole frame — completing
  the v3.2 send-side pre-sizing that stopped one allocation short.
- **Mux dispatch lock discipline.** The inbound `dispatch` arms clone
  the target sender out from under the `state` mutex and release the
  guard before awaiting the (potentially backpressured) mpsc send,
  removing a head-of-line stall where one slow consumer blocked every
  mux state operation across all channels. Per-channel ordering is
  unchanged.
- **Filecopy copy reductions.** Server-receive and client-download
  share each received chunk with the hash worker via `Arc` instead of
  a per-chunk deep copy; client-upload drops a redundant per-chunk
  `Vec` (`send_data` already copies internally). Both resume paths
  fork the SHA-256 state (`Sha256: Clone`) from the verified-prefix
  hasher instead of re-opening and re-reading the prefix — O(offset)
  work saved on large resumes. Digests and wire bytes are unchanged.
- **Per-connection allocation trim.** The server's client-authorizer
  is now a plain closure coerced to the handshake's `&dyn Fn` instead
  of a boxed one, dropping a `Box` allocation and a redundant `Arc`
  clone per connection (and a `clippy::type_complexity` allow). The
  client output pumps coalesce already-queued chunks into a single
  `stdout` flush without adding latency.

### Documentation — English and Brazilian Portuguese

- New project-governance set: `CONTRIBUTING.md`, `CODE_OF_CONDUCT.md`
  (Contributor Covenant 2.1), `GOVERNANCE.md`, `ROADMAP.md`. Every
  claim is grounded in an in-repo source and cited; the roadmap
  carries no dates or version promises and lists explicit non-goals.
- New user guides under `docs/en/`: getting-started, architecture,
  extensions, examples, and an FAQ — each fact-checked against the
  man pages, crate sources, and examples, then adversarially
  re-verified.
- Full Brazilian-Portuguese translation set under `docs/pt-br/` plus
  `README.pt-BR.md`, verified for fidelity against the English
  sources (code, flags, paths, and numbers kept byte-identical).

### Correctness and developer-experience fixes

- **Flaky exec test fixed.** `session_e2e::exec_real_echo_command`
  could lose the `exit-status` request to a cross-channel race with
  `close` under load; it now drains pending requests before breaking.
- **Portable test commands.** Two tests hardcoded `/bin/echo`, which
  does not exist on hosts that do not populate `/bin` (e.g.
  Guix/NixOS); they now use a PATH-resolved `echo` / `/bin/sh -c`.
- **Debug-profile test stack.** `.cargo/config.toml` raises
  `RUST_MIN_STACK` for Cargo-launched processes so the large
  ML-KEM-1024/ML-DSA-87 handshake frames don't overflow the default
  test-thread stack in dev builds (release was never affected). Does
  not alter shipped binaries or any wire/crypto behaviour.
- **Clippy `-D warnings` fix.** Removed a redundant inner
  `#![cfg(feature = "pty-shell")]` in `pty_shell.rs` that duplicated
  the module's `mod`-site gate and tripped `duplicated_attributes`
  once `evelin-server`'s default `pty-shell` feature unifies it on.

### Verification

- `cargo fmt` note: the tree carries pre-existing formatting drift
  against the locally available rustfmt 1.8.0 (an older toolchain
  than the one that formatted the source); no repo-wide reformat was
  performed, to avoid regressing the project's intended style.
- `cargo clippy --workspace --all-targets -- -D warnings`: clean
  (with `pty-shell` unified on).
- `cargo test --workspace --release`: 439 passed, 0 failed across 67
  suites (with `pty-shell`), run twice.
- `scripts/cargo-audit-blocking.sh`: PASS.
- `cargo deny`: advisories ok, bans ok, licenses ok (after updating
  the workspace license exceptions to the `AGPL-3.0-or-later` id
  that cargo-deny 0.20 requires — 0.16 needed the legacy form).

### Packaging fix — `evelin-server` deb dependency

Container install-verification (`debian:12`, `ubuntu:24.04`) caught a
real defect: the server package's `postinst` calls `adduser`/`deluser`
to manage the `evelin` system user, but the package only declared
`depends = "$auto"` (shared-library deps). On minimal Ubuntu 24.04 /
Debian 13+ images, where `adduser` is not in the essential set, the
postinst failed with exit 127 and left the package half-configured.
Fixed: `depends = "$auto, adduser"`. Verified installing, running, and
purging cleanly on both Debian 12 and Ubuntu 24.04, standalone and
with the agent + client co-installed. (Agent and client ship no
maintainer scripts and were unaffected.)

### Binary packages (added to the release after tagging)

Built from tag v4.2.0 in `rust:1.93` containers and attached to the
release; each build's provenance and validation stated per artifact:

- **linux-x86_64-musl tar.gz, deb ×3 (amd64), rpm ×3 (x86_64)** —
  static-PIE musl binaries built in `rust:1.93-alpine`. The FULL
  test suite was run inside the musl container: 439 passed / 0
  failed across 67 suites. Additionally, a live end-to-end
  validation of the shipped binaries was performed on the build
  host: keygen ×2, real ML-KEM-1024 + ML-DSA-87 handshake over
  loopback, `exec` round-trip byte-identical, and the
  wrong-server-fingerprint negative correctly rejected with no
  output.
- **client aarch64 deb, android-aarch64 tar.gz** — cross-built
  (gcc-aarch64 / NDK r26d); binaries not executed on target
  hardware in this environment.
- **windows-x86_64 zip** — `x86_64-pc-windows-gnu` via MinGW
  (`evelin-server`, `evelin-client`, `evelin-keygen`,
  `evelin-multisig-verify`; the unix-socket `evelin-agent` and the
  unix FFI `evelin-capi` are excluded — they are unix-only). Output
  verified as PE32+ x86-64 executables. NOT run on Windows in this
  environment (the build host's Wine is 32-bit-only). Honest status
  per `docs/PLATFORM_BUILDS.md`: the Windows platform backend is a
  compiling skeleton; the sandbox is NOT implemented on Windows —
  do not deploy the Windows server on an untrusted network.
- **Portability fixes (this release) that made the above build.**
  The session crate previously assumed a unix target unconditionally.
  Now: `open_beneath_read`/`_create_excl` calls in `filecopy.rs` are
  `#[cfg(target_os = "linux")]`-gated (non-Linux takes the existing
  canonicalize + `O_NOFOLLOW` fallback, same path an older Linux
  kernel takes); the `agent` module and its client/server wiring
  (Unix-domain-socket agent forwarding) are `#[cfg(unix)]`-gated and
  reply Failure on non-unix. Linux behaviour is byte-for-byte
  unchanged; all Linux gates stay green (clippy `-D warnings` clean,
  session suite passing).
- **freebsd14-amd64 .pkg** — cross-built against the FreeBSD 14.3
  base sysroot; the pkg(8) archive is assembled per the manifest
  spec. Honest status: NOT executed on FreeBSD; the FreeBSD
  sandbox backend is not implemented (`docs/PLATFORM_BUILDS.md`).
- **macos-x86_64 and macos-aarch64 tar.gz** — cross-built with
  osxcross (Apple SDK + LLVM) against the macOS 12/13 SDK; the four
  packaged binaries verified as Mach-O 64 executables for the
  correct CPU type (x86_64 / arm64). Honest status: **unsigned and
  un-notarized** — Gatekeeper will quarantine them until the
  maintainer signs with an Apple Developer ID (which requires Apple
  tooling not available here); NOT run on macOS in this environment.
  The from-source Homebrew path (`packaging/homebrew/`) remains the
  recommended install. A `.dmg` or signed `.pkg` installer is
  future packaging work: both need Apple code-signing/notarization.

## v4.1.1 — 2026-06-10

**Docs-and-validation release. No code change** (two doc-comments
updated); the v4.1.0 binary packages remain current — this release
ships a source tarball and documentation only, stated explicitly
rather than rebuilding identical binaries.

### Added: `COMPARISON.md` — Evelin vs OpenSSH

An honest comparison held to the project claims policy: OpenSSH
protocol facts verified against openssh.org as of June 2026 (hybrid
mlkem768x25519 KEX default since 10.0; authentication still
classical as of 10.2); Evelin numbers measured or
constant-derived; **no comparative performance claims** without a
same-host benchmark; the maturity/audit table states plainly where
OpenSSH wins. Notable stated losses: Evelin's handshake is ~4–5×
larger on the wire (17 662 B; the cost of ML-DSA-87 at category 5),
pure-PQ KEX has no classical backstop, and Evelin has no completed
third-party audit against OpenSSH's ~30 years of scrutiny.

### Added: full-binary connection validation (closes dev.3 R-1)

First live end-to-end run of the shipped binaries in the build
environment (`docs/V4_1_1_CONNECTION_VALIDATION.md`): v2 handshake
with negotiated 64 KiB frames applied live; **1 MiB filecopy
roundtrip byte-identical over 64 KiB frames** (the E-2 fix proven
at full-binary level); v1↔v2 fallback; wrong-fingerprint →
`Unauthorized`; allow-list refusal; handshake+exec median 11.7 ms
(loopback, 1 core, 5 runs).

### Removed: 44 superseded narrative documents

Repository hygiene: per-version sprint prompts (superseded by
`docs/SPRINT_PROMPT.md`), per-version audit reports for released
versions (the canonical copies ship, checksummed, with each
release's artifacts), one-off evaluation/validation narratives
superseded by `VERIFICATION_STATUS.md` and per-release audit/deny
logs, and the completed v4 sprint plan. Load-bearing documents are
untouched: README, CHANGELOG, SECURITY, PROTOCOL, threat models,
operations/runbook/quickstart, BENCHMARKS, AUDIT-CHECKLIST,
SPRINT_PROMPT, current audit report + GA report + ERRATA,
VERIFICATION_STATUS (test-enforced), run evidence, the mdBook, and
all SDK/packaging READMEs. Every cross-reference was updated
(SECURITY.md, README, Guix package doc list, runbook, checklist,
quickstart, filecopy threat model, two source doc-comments — one of
which already pointed at a file that never existed); a sweep
confirms **zero dangling references** outside this historical
changelog. Full manifest:

  - `INSTALL.fish.md`
  - `SPRINT_V1_4_0_GODTIER_PROMPT.md`
  - `SPRINT_V1_5_0_GODTIER_PROMPT.md`
  - `SPRINT_V1_6_0_GODTIER_PROMPT.md`
  - `SPRINT_V1_7_0_GODTIER_PROMPT.md`
  - `SPRINT_V1_8_0_GODTIER_PROMPT.md`
  - `SPRINT_V1_9_0_GODTIER_PROMPT.md`
  - `SPRINT_V2_0_0_GODTIER_PROMPT.md`
  - `SPRINT_V2_1_0_GODTIER_PROMPT.md`
  - `docs/EVAL_IO_URING.md`
  - `docs/V1_3_AUDIT_REPORT.md`
  - `docs/V1_4_AUDIT_REPORT.md`
  - `docs/V1_5_AUDIT_REPORT.md`
  - `docs/V1_6_AUDIT_REPORT.md`
  - `docs/V1_7_AUDIT_REPORT.md`
  - `docs/V1_8_AUDIT_REPORT.md`
  - `docs/V1_8_THIRD_PARTY_AUDIT_TARGET.md`
  - `docs/V1_9_AUDIT_REPORT.md`
  - `docs/V2_3_AUDIT_REPORT.md`
  - `docs/V2_4_AUDIT_REPORT.md`
  - `docs/V2_5_AUDIT_REPORT.md`
  - `docs/V2_6_AUDIT_REPORT.md`
  - `docs/V2_7_AUDIT_REPORT.md`
  - `docs/V2_8_AUDIT_REPORT.md`
  - `docs/V2_9_AUDIT_REPORT.md`
  - `docs/V3_0_AUDIT_REPORT.md`
  - `docs/V3_1_AUDIT_REPORT.md`
  - `docs/V3_2_AUDIT_REPORT.md`
  - `docs/V3_3_AUDIT_REPORT.md`
  - `docs/V3_4_AUDIT_REPORT.md`
  - `docs/V3_5_AUDIT_REPORT.md`
  - `docs/V3_6_AUDIT_REPORT.md`
  - `docs/V3_7_AUDIT_REPORT.md`
  - `docs/V3_8_AUDIT_REPORT.md`
  - `docs/V3_9_AUDIT_REPORT.md`
  - `docs/V4_0_0_dev1_AUDIT_REPORT.md`
  - `docs/V4_0_0_dev2_AUDIT_REPORT.md`
  - `docs/V4_0_0_dev3_AUDIT_REPORT.md`
  - `docs/V4_0_0_dev4_AUDIT_REPORT.md`
  - `docs/V4_0_0_dev5_AUDIT_REPORT.md`
  - `docs/V4_SPRINT_PLAN.md`
  - `verification/SECURITY-DEPS-v0.3.0.md`
  - `verification/V0.2-REPORT.md`
  - `verification/VALIDATION_REPORT.md`

### Wire-compat

No code change; v4.1.1 source builds binaries byte-equivalent to
v4.1.0 except the embedded version string.

---

## v4.1.0 — 2026-06-10

**Deep-review release: operator-tunable frame size, strict v2 offer
validation, and four corrections to v4.0.0 (see ERRATA).** Default
deployments — v1, and v2 with default settings — are byte-identical
on the wire to v4.0.0.

### Provenance note

This release began as a line-by-line review of ~740 lines of
uncommitted changes found in the working tree that match no recorded
development step. The shipped v4.0.0 artifacts were verified
unaffected (the v4.0.0 source tarball does not contain them). Every
hunk was reviewed against the v4.0.0 baseline as an untrusted patch
before adoption; the review also found and fixed defects the patch
itself had (it did not pass `clippy -D warnings` and carried dead
code). Details in `docs/V4_1_AUDIT_REPORT.md`.

### New: `max_frame_kib` (the v4.0 R-1 follow-up)

Both client and server configs gain `max_frame_kib`: the largest
record frame this side will accept, advertised in the protocol-v2
capability offer. Must be a power of two in `[16, 1024]` KiB —
anything else is rejected at startup (no silent rounding). Default
**1024** (= the previous hardcoded offer; the default v2 offer is
byte-identical to v4.0.0). Only meaningful with
`max_protocol_version = 2`; a non-default value under v1 logs a
startup warning. Mapping is via the shared
`evelin_negotiation::log2_for_kib` (no duplicated arithmetic).

**Interop caution:** set `max_frame_kib` below 1024 only when BOTH
peers run ≥ 4.1.0. A 4.0.0 peer that negotiates a frame below 1 MiB
hits ERRATUM E-2 below (its mux still chunks at the build default)
and will drop the connection on bulk transfer.

### Changed: strict v2 offer validation (`negotiate` now aborts)

`negotiate()` returns `Result` and rejects, on either side:
- `MAX_FRAME_LOG2` below 14 (2^14 = 16 KiB, the v1 base every
  implementation must accept). The record layer clamps **up**, so a
  smaller advertisement cannot be honoured — silently clamping made
  this side send frames larger than the peer declared it accepts.
- A known capability with the wrong value shape (`MAX_FRAME_LOG2`
  must be exactly one byte — trailing bytes were previously ignored;
  `REKEY` must be empty). Unknown ids remain opaque
  (forward-compatible).

Both peers run the identical pure check on the same
transcript-bound inputs, so a malformed offer aborts **coherently**
on both ends; strict validation cannot desynchronise them. This is
an intentional v2 behaviour change: a nonconforming offer that
v4.0.0 silently clamped now aborts the handshake. Locked by tests
in `evelin-negotiation` and `evelin-handshake`
(`nonconforming_offer_aborts_handshake`).

### Fixed: mux sizes traffic to the LIVE frame budget (E-2)

`Mux` now captures the record layer's live frame budget at spawn
(after any v2-negotiated `set_max_frame_len`) and:
- `send_data` fragments to that budget instead of the static
  `MAX_DATA_LEN` (which assumed the 1 MiB build default);
- `send_request` pre-flights the encoded size — an oversized
  request fails its own call with `MuxError::RequestTooLarge`
  instead of erroring in the writer task and killing the
  connection (requests cannot be fragmented).

New wire helpers `DATA_OVERHEAD` / `request_encoded_len` are locked
to `encode()` by `overhead_constants_match_encode`. Regression test
`negotiated_small_frame_fragments_data_and_rejects_big_request`:
100 KiB through negotiated 16 KiB frames arrives byte-identically;
an oversized request is rejected and the connection survives.

### Fixed: framing bound + tests now exercise the shipped module

- The v2 caps-block stream bound is tightened from a vacuous
  `u16::MAX` to the codec's canonical maximum
  (`MAX_ENCODED_LEN` = 16 642 bytes), rejected before allocation;
  boundary-exact tests (exactly-max accepted, max+declared-larger
  rejected).
- The v2 integration tests now import
  `evelin_handshake::framing` (via a dev self-dependency enabling
  the `io` feature) instead of a private duplicate of the readers —
  see ERRATUM E-1.

### Fixed: evelin-session test suite compiles again (E-3)

Five evelin-session test/bench files still used the pre-dev.2
two-argument handshake API and had not compiled since dev.2 — the
v4.0.0 source tarball fails its own `cargo test --workspace`. All
call sites fixed; the suite passes (44 tests, run twice). The
release discipline now includes a full-workspace compile gate
(`docs/SPRINT_PROMPT.md`) so an unselected crate can no longer rot
silently.

### API changes (workspace crates; the libevelin C ABI is unchanged)

- `Capabilities::{set, set_flag, set_u8}` return
  `Result<(), NegotiationError>` (previously an ignorable `bool`).
- `negotiate` returns `Result<Negotiated, NegotiationError>`.
- New: `evelin_negotiation::{MAX_ENCODED_LEN, MIN_MAX_FRAME_LOG2,
  log2_for_kib}` (re-exported from `evelin-handshake`),
  `RecordSender/RecordReceiver::max_plaintext_len`,
  `evelin_channel::wire::{DATA_OVERHEAD, request_encoded_len}`,
  `MuxError::RequestTooLarge`.

### ERRATA for v4.0.0 (full text: `docs/V4_0_0_ERRATA.md`)

- **E-1** — the dev.3/dev.4/GA audit claim that the v2 integration
  tests exercise the shipped `framing` module was **inaccurate**:
  the tests carried a private duplicate of the readers.
- **E-2** — the mux chunked at the static 1 MiB-derived
  `MAX_DATA_LEN`; any v2 connection that negotiated a smaller frame
  would drop on bulk transfer (reachable by any peer offering
  log2 < 20; availability-only, post-authentication, opt-in v2).
- **E-3** — the shipped source tree's evelin-session tests/benches
  did not compile (stale handshake API since dev.2).
- **E-4** — trailing bytes on known capability values were silently
  ignored (lenient parse).

### Tests / gates

233 tests passed, 0 failed across 11 crates (changed crates run
twice); clippy clean (`-D warnings`, `--all-targets
--all-features`); `cargo audit` 0 vulns (2 expected unmaintained
INFO); `cargo deny` PASS.

### Wire-compat

- v4.1.0 default ↔ v4.0.0 / v3.9 / v1.4: **byte-identical** (v1
  unchanged; default v2 offer unchanged).
- `max_frame_kib < 1024`: both peers must be ≥ 4.1.0 (E-2).
- Nonconforming v2 offers now abort instead of clamping
  (intentional strictness change).
- libevelin v1 ABI: 20 symbols, unchanged.

---

## v4.0.0 — 2026-06-09

**General availability of protocol v2: opt-in, transcript-bound,
downgrade-resistant capability negotiation.** This is the GA of the
v4.0 arc (dev.1–dev.5), the constructive resolution of the v3.4
finding (an extension primitive that was never wired in). **Default
deployments are byte-identical to v1.4 on the wire — v2 is strictly
opt-in.**

### How to enable v2 (migration)

v2 is **off by default**. To use it, set on **both** ends:

```toml
# server config and client config
max_protocol_version = 2
```

- With the default (`1`, or unset), the server accepts only v1
  clients and the client offers only v1 — byte-identical to pre-v4.0.
- A v2-capable server still accepts v1 clients (byte-identical v1
  handshake); upgrade servers first, then clients.
- A v2 client against a v1-only server is rejected (server-first
  rollout). Values other than 1 or 2 are rejected at startup.
- No key, identity, or ticket format changed. No re-keying or
  re-enrollment is required to upgrade.

### What v2 provides

- A canonical capability block carried in the **signed handshake
  body** (never the unauthenticated header), under v2-domain-
  separated transcript labels. Both peers compute the same
  negotiated outcome with no extra round trip.
- **Downgrade resistance** by construction: stripping, altering, or
  injecting the capability block — or rewriting the version — yields
  a transcript the originating peer cannot reproduce, so the
  ML-DSA-87 signature fails and the handshake aborts. Backed by
  executable tests (`downgrade_v2_to_v1_by_mitm_aborts`,
  `tampered_client_capabilities_rejected`,
  `any_byte_flip_changes_or_breaks_decode`) and a real-TCP
  integration test (`tcp_v2_handshake_over_socket_negotiates`).
- **Negotiated record frame size** (`MAX_FRAME_LOG2`): the agreed
  `min` clamps the record layer (proven: a 128 KiB frame roundtrips
  over a v2 socket, impossible under v1's 16 KiB cap).
- `REKEY` is negotiated and exposed but **reserved** for a future
  asymmetric ML-KEM rekey — not wired to the existing always-on
  symmetric ratchet (gating an always-on mechanism would be
  ceremony).

### Hardening (Sprint 6)

- `Capabilities::decode` is canonical-only with `checked_add`
  offsets and now has deterministic property/fuzz coverage (~570k
  generated inputs; never-panic + roundtrip), matching the v3.8
  channel-wire fuzzing.
- `SECURITY.md` threat model gains a protocol-v2 section (downgrade,
  strip/inject, parsing, frame-size abuse — with the honest
  non-claim that packet drop/delay is out of scope).
- Tamarin (`evelin-v2-negotiation.spthy`, 4 lemmas) and ProVerif
  (`evelin-v2-negotiation.pv`, 3 queries) models of the shipped v2
  negotiation, **STATED, not machine-checked** (no prover binary in
  the build environment; guarded by `formal_status.rs`).

### Honest limitations carried into GA

- The v2 formal models are **STATED**, not PROVEN — turning them
  PROVEN needs `tamarin-prover`/`proverif` run to completion in a
  release ceremony.
- Throughput numbers are unchanged from v3.7 (AEAD ceiling measured;
  bulk is core-contention-bound on a single core). The negotiated
  frame size changes what the record layer accepts, not the measured
  single-core throughput; a real multi-core/two-host benchmark is
  still pending hardware.

### Tests / gates

- evelin-handshake 14+1+3+10, evelin-negotiation **18** (+4 fuzz),
  evelin-record 21, evelin-core formal-status 2/2, evelin-config
  green — all passing twice. Clippy clean (`-D warnings`,
  `--all-targets --all-features`); `cargo audit` 0 vulns (2 expected
  unmaintained INFO); `cargo deny` PASS.

### Wire-compat

- v4.0.0 ↔ v3.9 / v1.4 default: **byte-identical**.
- v2↔v2 only when both peers set `max_protocol_version = 2`.
- libevelin v1 ABI: 20 symbols, unchanged.

### Packaging

Full release: 3× Debian `.deb` (musl-static amd64), 3× RPM
(x86_64), Termux aarch64 `.deb`, aarch64 + x86_64-musl tarballs,
source tarball, SHA256SUMS.

---

## v4.0.0-dev.5 — 2026-06-09

**v4.0 Sprint 5 (pre-release): formal models for the v2 capability
negotiation — STATED, not machine-checked.** Adds Tamarin and
ProVerif models of the shipped opt-in v2 negotiation, with a
downgrade-resistance property. **No code change** (verification
artifacts + one test + doc updates only).

### Added

- `verification/tamarin/evelin-v2-negotiation.spthy` (4 lemmas:
  `v2_exec`, `v2_caps_agreement` [downgrade resistance],
  `v2_server_sees_client_caps`, `v2_key_binds_caps`).
- `verification/proverif/evelin-v2-negotiation.pv` (3 queries:
  client⇒server caps agreement, server⇒client-offered, secrecy).
- `VERIFICATION_STATUS.md` v2 section; `formal_status.rs` test
  pinning the v2 models as STATED and the v1 counts as unchanged.

### Honesty guardrails (this is not a v3.3 repeat)

The v3.8 cleanup deleted aspirational models that described an
unshipped protocol. These v2 models are different on three axes,
enforced by test:

1. **The v2 negotiation is shipped and live** (dev.2 handshake,
   dev.3 over the socket, dev.4 gates the record layer; executable
   downgrade/tamper/socket tests exist). The models describe
   shipping code.
2. **STATED, not PROVEN.** No prover binary in this environment, so
   neither is machine-checked here. Both files self-label "STATED,
   NOT machine-checked"; the manifest lists every v2 lemma/query as
   STATED; the summary refuses "formally verified" for v2.
3. **v1 claims untouched** — separate files; primary `evelin.spthy`
   (8) and `evelin.pv` (10) unchanged and still pinned by the
   existing test.

### Limitations (stated)

Symbolic (Dolev-Yao), not computational; KEM/signatures idealized.
The models pass a structural sanity check but **structural sanity is
not a proof** — they remain STATED until a release ceremony runs the
provers to completion and references the logs.

### Tests / gates

- `evelin-core` formal-status: 2/2 (manifest + new v2-models test).
  No library code changed. Clippy clean; `cargo audit` 0 vulns;
  `cargo deny` PASS.

### Wire-compat

- v4.0.0-dev.5 ↔ v3.9 / v1.4 default: byte-identical (no code/wire
  change); libevelin v1 ABI 20 symbols unchanged.

See `docs/V4_0_0_dev5_AUDIT_REPORT.md`.

## v4.0.0-dev.4 — 2026-06-09

**v4.0 Sprint 4 (pre-release): the negotiated frame size now gates
the record layer.** The first capability to change observable
behaviour. After a v2 handshake, both peers clamp their record layer
to the negotiated `min` frame size; v1 deployments are byte-identical
and keep the build default.

### How

- `Negotiated::max_frame_bytes()` converts the negotiated
  `MAX_FRAME_LOG2` (power of two) to bytes (saturating), `None` for
  v1 / un-negotiated.
- Both binaries call `RecordSender/RecordReceiver::set_max_frame_len`
  with that value after the handshake. Both peers computed the same
  `min` from their transcript-bound offers, so they clamp coherently
  with no extra exchange; the record layer further clamps into its
  supported `[16 KiB, 1 MiB]` range.

### Proven over a real socket

`tcp_v2_negotiated_frame_size_gates_record_layer`: client offers
log2=19, server log2=18 → negotiated 256 KiB on both ends; the clamp
takes effect (default is 1 MiB); a **128 KiB frame roundtrips** over
the socket — impossible under the v1 16 KiB cap. Not ceremony.

### Security (honest)

Binding the frame size to the signed transcript removes the *silent*
frame-size downgrade vector (altering an offer aborts the
handshake). It does **not** stop packet drops/delays — out of scope
for any AEAD transport. The capability's value is modest; said
plainly.

### REKEY: deliberately not faked

Evelin's existing refresh is an **unconditional symmetric ratchet**
(always on, both ends, already coherent). There is no separate rekey
handshake to gate; `REKEY` was reserved for a future asymmetric
ML-KEM rekey. Gating an always-on ratchet behind a flag would be
ceremony, so dev.4 does **not** wire it. `REKEY` stays
negotiated/exposed and reserved, documented in the `cap` registry.
`out.negotiated.rekey` is available for when that protocol lands.

### Tests / gates

- evelin-handshake 14+1+3+10 (twice), negotiation 14, record 21,
  core 8, config green; clippy clean (`--all-targets
  --all-features`); `cargo audit` 0 vulns; `cargo deny` PASS.

### Wire-compat

- v4.0.0-dev.4 ↔ v3.9 / v1.4 default: byte-identical (no wire-format
  change; v1 negotiates no frame size)
- v2↔v2 only when both peers set `max_protocol_version = 2`
- libevelin v1 ABI: 20 symbols, unchanged

See `docs/V4_0_0_dev4_AUDIT_REPORT.md`.

## v4.0.0-dev.3 — 2026-06-09

**v4.0 Sprint 3 (pre-release): protocol v2 is now live over the
socket.** dev.2 wired v2 into the handshake crate; dev.3 makes it
actually traverse the wire. The binaries read the variable-length v2
hellos with length-aware framing, offer/accept v2 from config, and a
**real-TCP integration test** proves an end-to-end v2 handshake. v1
default deployments remain byte-identical.

### v2 wire refined (still pre-live, so no compat cost)

The v2 capability block is now **length-prefixed** (`u16 caps_len ||
caps_bytes`) so a stream reader needs one bounded read instead of an
entry-by-entry parse:

```
v2 HelloClient body = kem_pk || id_pk || nonce || u16 caps_len || caps_bytes
v2 HelloServer body = id_pk || kem_ct || nonce || u16 caps_len || caps_bytes || sig
```

`caps_bytes` is still the canonical `Capabilities` encoding. The
prefix is part of the signed body (authenticated). v2 never went
over a real wire before now (dev.1/dev.2 binaries were v1-only), so
this refinement has no compatibility cost. v1 bodies are untouched.

### Real signed-body bug caught + fixed

The framed-encoding refactor surfaced a defect: the server's
pre-signature body (`HelloServerPartial`) appended *unframed* caps
while the final body appended *framed* caps, so the server signed
bytes the client couldn't reproduce (`CryptoVerify`). Fixed — both
now use the same framed helper. (The pre-sig body and final body
must be byte-identical except the appended signature.)

### Added / changed

- `evelin-handshake`: `framing` module (feature `io`) with async
  `read_hello_client` / `read_hello_server`; exposed fixed-body and
  signature length constants; optional `tokio` dep.
- `evelin-handshake/tests/integration_tcp_v2.rs`: real-TCP v2
  handshake + v1-fallback tests.
- `evelin-client` / `evelin-server`: config-driven v2 offer
  (`build_client_offer` / `build_server_offer`), length-aware
  handshake reads. Server `run_check` rejects
  `max_protocol_version ∉ {1,2}`.

### Live evidence

- `tcp_v2_handshake_over_socket_negotiates`: full v2 handshake over a
  real socket; equal transcript hashes both sides; negotiated frame
  log2 = 20, rekey true.
- `tcp_v1_client_against_v2_server_falls_back_over_socket`: v1 client
  ↔ v2 server completes as v1, byte-identical HelloServer.

The binaries use the same `framing` module the tests exercise.

### Honest scope boundary (Sprint 4)

The negotiated `MAX_FRAME_LOG2` is computed, transcript-bound, and
exposed, but **does not yet clamp the record layer** — that gating
(and measuring any throughput effect, likely flat on one core) is
Sprint 4. A v2 connection negotiates a frame cap that isn't enforced
yet. Stated in the offer-builder comments and the audit. No stub.

### Tests / gates

- evelin-handshake 14+1+2+10 (twice), core 8, negotiation 13, config
  green; clippy clean (`--all-targets --all-features`); `cargo audit`
  0 vulns; `cargo deny` PASS.

### Wire-compat

- v4.0.0-dev.3 ↔ v3.9 / v1.4 default: byte-identical
- v2↔v2 only when both peers set `max_protocol_version = 2`
- libevelin v1 ABI: 20 symbols, unchanged

See `docs/V4_0_0_dev3_AUDIT_REPORT.md`.

## v4.0.0-dev.2 — 2026-06-09

**v4.0 Sprint 2 (pre-release): protocol v2 wired into the live
handshake.** The dev.1 negotiation core is now integrated into the
real 3-message handshake: HelloClient/HelloServer carry an optional,
canonical **capability block in their signed bodies**, both peers
compute the same negotiated outcome with no extra round trip, and
the result is exposed on `HandshakeOutput`. Protocol v1 is unchanged
and **provably byte-identical**.

### Security: downgrade resistance, end-to-end

dev.1 proved the data-level property; dev.2 closes the
cryptographic half:

- Capabilities live in the **signed body, never the header**, under
  v2-specific transcript labels (`evelin/2/...`) domain-separated
  from v1.
- The server signs over the client's caps as received; the client
  verifies that signature against its own transcript (caps as
  sent). Any in-flight tamper ⇒ transcript mismatch ⇒ signature
  failure ⇒ abort (`tampered_client_capabilities_rejected`).
- A MITM downgrade (rewrite v2→v1, strip caps) is detected and
  aborts (`downgrade_v2_to_v1_by_mitm_aborts`).
- Canonical-only decode removes any byte-level ambiguity between
  what the two peers hash.

### Changed

- `evelin-core`: `PROTOCOL_V2` + v2 transcript labels.
- `evelin-handshake`: version-aware header; `Option<Capabilities>`
  on HelloClient/HelloServer (v2 variable-length, overflow-safe
  decode); client `start(offer)` / server `respond(server_offer)`
  thread the offer, run `negotiate()`, and expose `negotiated` on
  `HandshakeOutput`. Re-exports the negotiation surface.
- `evelin-config`: `max_protocol_version` (default 1) on client and
  server.
- Binaries + keyscan: call sites updated, kept on v1 (`None`).

### Tests (6 new, all passing twice)

v1 byte-identical (lengths + version byte pinned), v2 negotiation
(min frame-log2 + AND rekey, matching transcript hashes, AEAD
paired), v1-client↔v2-server fallback, v2-client↔v1-server
rejection, MITM downgrade abort, caps tamper rejection.
evelin-handshake 14+1+10, core 8, negotiation 13, config green;
clippy clean; `cargo audit` 0 vulns; `cargo deny` PASS.

### Honest scope boundary

**v2 is complete and tested at the handshake-crate level but not yet
reachable over the live socket**: the server/client binaries still
read fixed-length handshake frames, and a v2 hello is longer (it
carries the caps block), so the binaries are kept on v1
(byte-identical). Wiring v2 into the binaries (length-aware framing
+ reading `max_protocol_version`) is the first task of **Sprint 3**,
together with making `MAX_FRAME_LOG2` gate the record layer (the
first capability to change observable behaviour). The negotiated
result is exposed but does **not** yet change record behaviour — by
design. No stub; a real increment boundary.

### Wire-compat

- v4.0.0-dev.2 ↔ v3.9 / v1.4 default: byte-identical
- libevelin v1 ABI: 20 symbols, unchanged

See `docs/V4_0_0_dev2_AUDIT_REPORT.md`.

## v4.0.0-dev.1 — 2026-06-09

**v4.0 Sprint 1 (pre-release): transcript-bound capability
negotiation core.** First increment of the v4.0 arc
(`docs/V4_SPRINT_PLAN.md`). Adds a new self-contained
`evelin-negotiation` crate; **no live-handshake change, no wire
change** — the shipping protocol is byte-identical to v3.9 while the
security-critical negotiation core is proven in isolation before
Sprint 2 wires it in.

### Why v4.0, and the one design rule

v4.0 is the constructive resolution of the v3.4 finding (an
extension primitive that was never wired into the live handshake):
a real, downgrade-resistant capability negotiation. Grounding in the
code first surfaced the decisive fact — **the handshake header
(incl. the version field) is NOT in the signed transcript; only
message bodies are.** So all negotiated capabilities live in the
**signed body**, covered by the transcript hash both peers sign with
ML-DSA-87. Tampering ⇒ transcript mismatch ⇒ signature failure ⇒
abort. Downgrade resistance is structural.

### The crate

- Canonical, deterministic capability block: `u16 count` +
  ascending `(u16 id, u16 len, value)`; empty set = `00 00`.
- `cap` id registry: `MAX_FRAME_LOG2`, `REKEY`.
- `decode` enforces canonical form (rejects unordered/duplicate ids,
  trailing bytes, truncation, oversize count/value) with
  `checked_add` offsets — the v3.6/v3.9 overflow class pre-empted in
  new code.
- `negotiate(client, server)` — pure commutative reduction (min
  frame-log2, AND rekey); no extra round trip.
- 13 tests incl. `any_byte_flip_changes_or_breaks_decode` (the
  data-level downgrade property).

### Also added

- `docs/V4_SPRINT_PLAN.md` — the 6-sprint roadmap to GA 4.0.0
  (Sprint 2 wires the v2 body + version negotiation; Sprint 3
  negotiated frame size; Sprint 4 REKEY; Sprint 5 a v2-matching
  formal model; Sprint 6 hardening + GA).
- `docs/SPRINT_PROMPT.md` — a reusable "god-tier" sprint brief
  encoding the v2.8→v4.0 discipline (claims==implementation; push
  back vs manufacture; the peer-length overflow class; the
  signed-body downgrade rule; the build/quality gates).

### Wire-compat

- v4.0.0-dev.1 ↔ v3.9 default: byte-identical
- v4.0.0-dev.1 ↔ v1.4 default: byte-identical
- libevelin v1 ABI: 20 symbols, unchanged

### Tests / gates

- evelin-negotiation 13/0 (run twice); clippy clean; `cargo audit`
  0 vulns; `cargo deny` PASS (new AGPL exception). No other crate
  changed (workspace otherwise identical to v3.9, 370+/0).

### Scope note (honest)

This is a **pre-release** (`-dev.1`), not GA 4.0.0. It ships real,
tested foundation code with no stub; the security-critical
live-handshake integration is deferred to Sprint 2 *by design*. v2
is and will remain **opt-in**; default deployments stay
byte-identical to v1. No performance or crypto claim is made here.

## v3.9.0 — 2026-06-02

**Bug hunt: integer-overflow-safety across all peer-input length
checks.** A systematic search for panic surfaces on adversarial
input found **five live siblings of the v3.6 `Parser::take`
overflow bug** in the file-copy, reverse-forward, and agent wire
decoders. No crypto/protocol/behaviour change; valid inputs decode
byte-identically.

### The class (same as v3.6)

A decoder reads a `u32` length from the peer, converts to `usize`,
and bounds-checks with an addition (e.g. `buf.len() < 5 + path_len +
8 + 4`). On a 32-bit target (linux-armv7) a near-`u32::MAX` length
overflows the addition — which **panics in a debug build** (and in
`filecopy.rs` the overflow happened *before* the `MAX_PATH_LEN` cap,
so the cap didn't protect it) and wraps in release. **Severity LOW**:
release builds reject the values downstream, a panic drops one
task not the server, and the agent decoders are behind a local
Unix socket. Fixed because it is a real defect of a class the
project already chose to close, reachable as a debug panic on a
published target.

### Fixed

- `evelin-session/src/filecopy.rs::decode_request` — cap `path_len`
  *before* arithmetic; `checked_add` for the header and resume-tail
  length checks.
- `evelin-session/src/reverse_forward.rs::decode_bind` —
  `checked_add` (the `n>1024` cap already prevented the wrap; now
  overflow-safe by construction).
- `evelin-agent/src/proto.rs` — `decode_sign_request` (`36 +
  msg_len`) and `decode_reply` LIST (`4 + n*32`), SIGN (`4 + n`),
  ERROR (`5 + n`) all use `checked_add`/`checked_mul`.

### Confirmed safe (no change, stated explicitly)

- `evelin-ticket/src/envelope.rs` `7 + len` — `len` is u16, cannot
  overflow.
- `evelin-handshake/src/messages.rs` `off + <CONST>` — constant
  offsets over a fixed-size, pre-validated buffer (sizes pinned by
  the v3.3 test).
- crypto/transcript `.expect()`s — infallible fixed-size
  conversions.

### Tests (7 new)

filecopy ×3, reverse_forward ×1, agent ×2 (+ the v3.8 channel
property/fuzz tests already guard the channel decoder). Each feeds
a near-`u32::MAX` length and asserts a clean `Err` with no panic —
each would have panicked under debug+32-bit before this fix.

### Wire-compat

- v3.9 ↔ v3.8 default: byte-identical on valid traffic
- v3.9 ↔ v1.4 default: byte-identical on valid traffic
- libevelin v1 ABI: 20 symbols, unchanged

### Tests

- evelin-session 26/0 (+3), evelin-agent 8/0 (+2); rest of workspace
  unchanged from v3.8 (370+/0)
- clippy clean; `cargo audit` 0 vulns; `cargo deny` PASS

### Source delta

- `crates/evelin-session/src/filecopy.rs`,
  `crates/evelin-session/src/reverse_forward.rs`,
  `crates/evelin-agent/src/proto.rs`: checked arithmetic + tests
- `docs/V3_9_AUDIT_REPORT.md` (new)
- `Cargo.toml`: workspace version 3.8.0 → 3.9.0

### Honest scope note

This is a bug-fix release (a latent panic family on adversarial
input, closed across every decoder, at LOW severity). It is **not**
a performance or cryptographic improvement — there is none here.
The overflow class is now fixed everywhere it occurs on peer input
(channel v3.6; filecopy/reverse-forward/agent v3.9). Substantive
further work still needs external resources/decisions (multi-core
box for throughput; prover binaries for the STATED lemmas; a v4.0
decision for transcript-bound negotiation).

## v3.8.0 — 2026-06-02

**Security-assurance + honesty release.** No protocol/crypto/
behaviour change — binaries functionally identical to v3.7. Two
honestly-scoped components.

### 1. CI-integrated property/fuzz coverage for the wire parser

Extends the v3.6 `Parser::take` overflow fix into a broad
*never-panic* guarantee, run on every `cargo test` (complements the
out-of-tree cargo-fuzz targets). Four new deterministic, seeded
(LCG, no new dependency) property tests in `evelin-channel`:

- `fuzz_decode_never_panics_on_arbitrary_bytes` — 200k random
  buffers; `decode` always returns, never panics.
- `fuzz_decode_never_panics_on_tagged_bytes` — 200k valid-tag +
  adversarial-body frames; exercises per-variant field parsing.
- `fuzz_roundtrip_valid_messages` — 50k generated valid messages;
  `decode(encode(m)) == m`.
- `fuzz_truncated_prefixes_error_never_panic` — proper prefixes of
  valid encodings never panic.

~470k inputs total. **No panic or roundtrip failure found** — this
is an *assurance* result locking in the v3.6 hardening, not a
vulnerability fix. Stated honestly as such.

### 2. Removed the aspirational hybrid/negotiation formal models

Deleted four `*-extensions.{spthy,pv}` model files that described a
protocol Evelin does not ship — on-wire extension negotiation (not
wired in; v3.4) and a hybrid X25519 KEX (not implemented, ruled out
by the pure-PQ design; v3.3). The v3.3–v3.5 corrections had already
removed the false *claims*; v3.8 removes the *artifacts* so they
cannot mislead a future reader. `VERIFICATION_STATUS.md`,
`verification/README.md`, and the `formal_status` test updated to
match (the test now asserts the files stay absent). The primary
shipped-protocol models (`evelin.spthy` 8 lemmas, `evelin.pv` 10
queries) and their honest proof status are untouched. Recoverable
via git.

### Wire-compat

- v3.8 ↔ v3.7 default: byte-identical
- v3.8 ↔ v1.4 default: byte-identical
- libevelin v1 ABI: 20 symbols, unchanged

### Tests

- evelin-channel 27/0 (+4), evelin-core 4/0 + formal_status 1/0;
  rest of workspace unchanged from v3.7 (370+/0)
- clippy clean; `cargo audit` 0 vulns; `cargo deny` PASS

### Source delta

- `crates/evelin-channel/src/wire.rs`: +4 property/fuzz tests
- deleted: `verification/{tamarin,proverif}/evelin-v1.{5,8}-extensions.*`
- `verification/VERIFICATION_STATUS.md`, `verification/README.md`:
  removal notes + tree update
- `crates/evelin-core/tests/formal_status.rs`: assert removed files
  stay absent
- `README.md`: v3.8 section; older "What's new" sections condensed
  to a CHANGELOG pointer (full history preserved here)
- `docs/V3_8_AUDIT_REPORT.md` (new)
- `Cargo.toml`: workspace version 3.7.0 → 3.8.0

### Honest scope note

v3.8 claims **no** performance or cryptographic gain — there is
none in this release. The measurable performance levers remain
exhausted on single-core hardware (v3.7). Substantive further work
— a real end-to-end throughput number (needs multi-core/two-host),
machine-checking the STATED formal lemmas (needs the prover
binaries), or a v4.0 transcript-bound negotiation protocol (a
wire-evolving design decision) — still requires resources or
decisions outside this environment.

## v3.7.0 — 2026-06-02

**Performance-claim accuracy correction + reproducible AEAD
microbench.** No protocol/crypto/behaviour change. The only Rust
added is a `criterion` bench (dev-only, not in shipped binaries).
This is the performance-side analogue of the v3.3–v3.5
security-claim corrections.

### The finding

Earlier `BENCHMARKS.md` revisions (and the v3.1/v3.2 notes)
explained the flat ~50–75 MiB/s bulk-filecopy loopback number by
calling the path "AEAD-compute-bound" — asserted **without** an
isolating measurement, and **wrong**. Measuring ChaCha20-Poly1305
alone (new bench):

| Operation (1 MiB) | Throughput |
|---|---|
| `seal` | 1.132 GiB/s |
| `seal_in_place` | 1.133 GiB/s |
| `open` | 924 MiB/s |

The cipher is already SIMD (x86_64 AVX2; `cpufeatures` runtime
detection works even with `default-features=false, features=
["alloc"]`) — **no SIMD win is available**, ruled out by
measurement, not assumption. The AEAD ceiling (~1.1 GiB/s/dir) is
~16–24× the bulk number, so bulk is **not** AEAD-bound. The real
limiter on the 1-core box is **core contention** (client + server
tasks + loopback duplex + mux mpsc + disk all on one CPU) — a
benchmark-topology artifact, not a real-deployment limit.

**Severity**: LOW performance-doc accuracy defect (never affected
security or behaviour). Corrected because the project's standard is
"every performance claim cites a measured number," and "AEAD-bound"
was an unmeasured assertion.

### The fix

- **New `crates/evelin-crypto/benches/aead_throughput.rs`**
  (criterion, `harness=false`, dev-only) measuring `seal` /
  `seal_in_place` / `open` for a 1 MiB record — the per-direction
  AEAD ceiling as a reproducible, regressible number. Run:
  `cargo bench -p evelin-crypto --bench aead_throughput`.
- **`docs/BENCHMARKS.md`** corrected: the "AEAD-compute-bound"
  passages now state the measured ceiling, that bulk is ~16–24×
  below it, and that the flat loopback number is single-core
  contention (not the cipher, not a real-deployment limit).

### Wire-compat

- v3.7 ↔ v3.6 default: byte-identical (binaries functionally
  identical — only a dev bench + docs changed)
- v3.7 ↔ v1.4 default: byte-identical
- libevelin v1 ABI: 20 symbols, unchanged

### Tests / build

- evelin-crypto 30/0 (unchanged); new bench compiles + runs under
  `--release`
- clippy clean; `cargo audit` 0 vulns; `cargo deny` PASS

### Source delta

- `crates/evelin-crypto/benches/aead_throughput.rs` (new bench)
- `crates/evelin-crypto/Cargo.toml`: criterion dev-dep + `[[bench]]`
- `docs/BENCHMARKS.md`: corrected "AEAD-bound" claim + new measured
  section
- `docs/V3_7_AUDIT_REPORT.md` (new)
- `Cargo.toml`: workspace version 3.6.0 → 3.7.0

### Note on remaining work

A faithful end-to-end throughput number needs a two-host or pinned
multi-core setup (so client and server don't share a core); the
single-core loopback bench is for regression detection only. The
larger open items remain design decisions (see v3.5/v3.6): run the
provers to promote STATED lemmas; decide whether to implement or
delete the aspirational extension/hybrid models.

## v3.6.0 — 2026-06-02

**Parser overflow-safety hardening (32-bit targets).** A real
defensive code change (not a doc correction). An adversarial audit
of the receive/parse path found the channel-message parser
primitive `Parser::take` used unchecked `usize` addition
(`self.pos + n`); on a 32-bit target (the linux-armv7 build) a
large length value could wrap and reach an invalid slice, turning a
malformed decrypted frame into a panic. Fixed with `checked_add` so
the primitive is intrinsically overflow-safe on every target.

### Severity: LOW (latent, not exploitable today)

`n` derives from a u32 length prefix. On 64-bit, `pos + n` can't
wrap in practice. On 32-bit it can — but the current callers all
cap `n` against a per-field max (`MAX_DATA_LEN` etc.) *before*
calling `take`, so the wrap isn't reachable under today's call
sites. The defect is **latent**: the safety depended on every
caller pre-validating, which is fragile for a security-critical
parser primitive. A panic in the per-connection mux reader would
drop that connection, not crash the server or leak memory. Fixed
because overflow-safety belongs in the primitive, and armv7 is a
real published target.

### What changed

- `Parser::take` now uses `checked_add`; an overflowing offset is a
  clean `Error::Wire`, never a wrap/panic. Valid input parses
  identically.
- Audited the rest of `wire.rs`: `is_empty` uses `>=` (safe); no
  other unchecked `pos + n`. The per-field caps in `bytes()` are
  retained (now backed by the overflow-safe `take`).
- The record-layer `RecordReceiver::recv` was re-confirmed sound:
  it validates `len == 0 || len > max_frame_len` and `len <
  AEAD_TAG_LEN` **before** allocating, so the classic length-prefix
  memory-amplification attack is already prevented there.

### Tests (4 new)

- `oversize_length_prefix_rejected_not_allocated` — a Data frame
  claiming ~4 GiB is rejected with `Error::Wire` before any
  allocation.
- `parser_take_is_overflow_safe` — `take(usize::MAX)` returns a
  clean error, no panic; normal takes still work after.
- `data_field_over_cap_rejected` — `MAX_DATA_LEN + 1` payload prefix
  rejected even with some payload following.
- (complements pre-existing `oversize_*` field-cap tests.)

### Wire-compat

- v3.6 ↔ v3.5 default: byte-identical on valid traffic (only the
  malformed-input rejection path changed)
- v3.6 ↔ v1.4 default: byte-identical on valid traffic
- libevelin v1 ABI: 20 symbols, unchanged

### Tests

- evelin-channel 23/0 (+4), evelin-session 22/0 + integration; rest
  of workspace unchanged from v3.5 (370+/0)
- clippy clean; `cargo audit` 0 vulns; `cargo deny` PASS

### Source delta

- `crates/evelin-channel/src/wire.rs`: `checked_add` in
  `Parser::take` + 4 robustness tests
- `docs/V3_6_AUDIT_REPORT.md` (new)
- `Cargo.toml`: workspace version 3.5.0 → 3.6.0

### Deferred / future

- Add armv7 (32-bit) to the fuzz matrix if 32-bit deployment is a
  priority — it's the host where the now-fixed wrap lived.
- The bigger open items remain design decisions (see v3.5): run the
  provers to promote STATED lemmas; decide whether to implement or
  delete the aspirational extension/hybrid models.

## v3.5.0 — 2026-06-02

**Security-claim accuracy correction (formal-verification status).**
No code-behaviour change. Completes the honesty thread of v3.3
(crypto construction) and v3.4 (extension negotiation) by
correcting the project's **headline formal-verification claim**.

### The finding

`README.md` claimed "Tamarin formal model: 5/5 lemmas verified" and
"ProVerif formal model: 10/10 queries proved". This was wrong on
three axes, verified against the model files and the project's own
proof notes (`verification/runs/v0.2.1-formal-status.md`):

- **Counts**: the primary `evelin.spthy` has **8 lemmas**, not 5;
  the primary `evelin.pv` has **10 queries**. `verification/README`
  separately listed "5 lemmas / 8 queries" — also wrong.
- **Names**: the listed lemma names (`session_key_secrecy`,
  `mutual_authentication`, `mutual_auth` in THREAT-MODEL.md) **do
  not exist** in the model; the real names are `secret_session_key`,
  `agreement_server`, `agreement_client`, etc.
- **Status**: only the **5 v0.1 lemmas + 8 v0.1 ProVerif queries**
  were machine-checked (v0.1 ceremony). The 3 v0.2 Tamarin lemmas
  and 2 v0.2 ProVerif queries are **stated but unproven**, and the
  v1.5/v1.8 extension models (26 further lemmas/queries) are
  **stated + aspirational** (they model a hybrid X25519 KEX and
  on-wire extension negotiation the transport does not implement —
  see v3.3/v3.4).

**Severity**: honesty defect, **not** a crypto weakness. The core
handshake's secrecy, mutual authentication, and perfect forward
secrecy *are* machine-checked. The defect was claiming more
verification than was performed.

### The fix

- **New `verification/VERIFICATION_STATUS.md`** — authoritative
  per-lemma/query manifest tagging every item PROVEN / STATED /
  ASPIRATIONAL-MODEL, with the honest one-line summary and the
  correct phrasing to use ("not fully formally verified").
- **`README.md`** headline corrected: "5 Tamarin lemmas + 8
  ProVerif queries machine-checked; 3 + 2 stated; extension models
  stated + aspirational", pointing to the manifest.
- **`verification/README.md`** lemma/query tables corrected to the
  real names and counts (8 / 10), each tagged PROVEN or STATED.
- **`docs/THREAT-MODEL.md`** reference to the non-existent
  `mutual_auth` lemma replaced with the real `agreement_server` /
  `agreement_client` lemmas.
- **New test** `formal_status_manifest_matches_model_files`
  (evelin-core) parses the six model files, asserts the real
  counts, asserts the manifest agrees, and forbids the inflated
  "5/5 / 10/10" headline from reappearing in the README. The claim
  is now honest **by construction**.

### Wire-compat

- v3.5 ↔ v3.4 default: byte-identical (binaries functionally
  identical — only docs and a test changed)
- v3.5 ↔ v1.4 default: byte-identical
- libevelin v1 ABI: 20 symbols, unchanged

### Tests

- evelin-core 4/0 lib + 1/0 formal-status integration; rest of
  workspace unchanged from v3.4 (370+/0)
- clippy clean; `cargo audit` 0 vulns; `cargo deny` PASS

### Source delta

- `verification/VERIFICATION_STATUS.md` (new)
- `verification/README.md`, `README.md`, `docs/THREAT-MODEL.md`:
  corrected formal-verification claims
- `crates/evelin-core/tests/formal_status.rs` (new test)
- `docs/V3_5_AUDIT_REPORT.md` (new)
- `Cargo.toml`: workspace version 3.4.0 → 3.5.0

### Deferred / future

- Machine-check the 3 STATED Tamarin lemmas + 2 STATED ProVerif
  queries in the formal-models CI job and promote them to PROVEN in
  the manifest (90+ min prover run).
- Reconcile the v1.5/v1.8 extension models with the shipped
  protocol (drop the X25519 hybrid + on-wire-negotiation
  assumptions, or implement those features) so their lemmas
  describe the real code.
- A CI step that regenerates the PROVEN/STATED column from prover
  exit codes, closing the loop automatically.

## v3.4.0 — 2026-06-02

**Security-claim accuracy correction (extension negotiation).** No
code-behaviour change. Continues the v3.3 honesty thread. Corrects
documentation that described the `EVLN-EXT-1.5` extension mechanism
as an active, on-wire, transcript-bound, Tamarin-proven
negotiation, when it is in fact a **provided-but-unwired
primitive**.

### The finding

The `evelin-ext` module doc claimed the extension bitfield is
"exchanged by v1.5+ peers in the second handshake flight", is "part
of the signed transcript", and is backed by a Tamarin
`downgrade_resistance` lemma. Verified against the implementation:

- **No extension flight exists on the wire.** The shipping client
  and server run the handshake and then construct the record layer
  at **fixed build-time defaults** — they never send or parse an
  extension advertisement.
- **The `Extensions` type is used only by tests** (this crate's
  own + two server CVE-regression files). `set_max_frame_len(BIG)`
  / `set_pipeline_depth` are called only in `evelin-record`'s unit
  tests.
- **The transcript contains no extension bits.** There are exactly
  three transcript labels (HELLO_CLIENT, HELLO_SERVER, FINISH); no
  extension label, because nothing is exchanged.
- **The Tamarin lemma is OPEN** (stated, not machine-proven) and
  models a hybrid X25519 KEX the transport doesn't implement (per
  v3.3).

Why large frames still work without negotiation: since v2.5 the
record layer defaults both ends to `MAX_FRAME_LEN_BIG` (1 MiB)
unconditionally.

### Severity: honesty defect, NOT a live vulnerability

There is **no live downgrade vulnerability**: a downgrade attack
strips a negotiated option on the wire, and there is no on-wire
negotiation to strip — both peers use the same fixed build-time
frame size. The defect is purely the inaccurate documentation
(same class as the v3.3 crypto-claim correction).

### The fix

- **`evelin-ext` doc corrected** to state the mechanism is provided
  but not wired into the live path; that frame size is a fixed
  build default; **why there is no live downgrade vulnerability**;
  and a **REQUIRED property** for any future implementer — if the
  bitfield is ever exchanged during setup, both peers' advertised
  bytes MUST be folded into the signed transcript (e.g. a new
  `transcript_label::EXTENSIONS`) so a stripped/flipped bit breaks
  the signature.
- **New pinning test** `live_frame_size_is_fixed_default_not_negotiated`
  (in `evelin-record`) asserts sender and receiver both default to
  the same fixed 1 MiB size with no negotiation. If negotiation is
  added later, this test fails — the prompt to add the transcript
  binding above.
- **Tamarin model annotated** with an implementation-gap notice
  (hybrid X25519 + on-wire negotiation + OPEN lemmas ⇒ not a proof
  of the shipping code).

### Wire-compat

- v3.4 ↔ v3.3 default: byte-identical (binaries functionally
  identical — only docs, a comment, and a test changed)
- v3.4 ↔ v1.4 default: byte-identical
- libevelin v1 ABI: 20 symbols, unchanged

### Tests

- evelin-ext 14/0; evelin-record 21/0 (+1 pinning test); rest of
  workspace unchanged from v3.3 (370+/0)
- clippy clean; `cargo audit` 0 vulns; `cargo deny` PASS

### Source delta

- `crates/evelin-ext/src/extensions.rs`: corrected module doc
- `crates/evelin-record/src/lib.rs`: live-behaviour pinning test
- `verification/tamarin/evelin-v1.5-extensions.spthy`: gap notice
- `docs/V3_4_AUDIT_REPORT.md` (new)
- `Cargo.toml`: workspace version 3.3.0 → 3.4.0

### Deferred / future

- If feature negotiation (resume, pipeline depth) is genuinely
  wanted, implement it as an authenticated exchange with the
  transcript binding documented in `evelin-ext`. Until then the
  primitive stays clearly labelled as unwired.
- Reconcile the Tamarin models with the implementation (drop the
  X25519 hybrid assumption, or implement hybrid) before citing any
  lemma as applying to shipped code.

## v3.3.0 — 2026-06-02

**Security-claim accuracy correction.** No code-behaviour change.
This release corrects documentation that overstated the
cryptographic construction and adds a regression test that pins
the actual construction so the claim cannot drift again.

### The finding

Earlier docs described the handshake as **"ML-KEM-1024 ×3"**
encapsulation plus **"Ed25519 + SPHINCS+"** signatures (and the
design notes implied an ML-KEM + X25519 hybrid KEX). **None of
that is implemented.** The transport performs:

- **KEX**: a *single* ML-KEM-1024 encapsulation (FIPS 203, NIST
  category 5). No triple-KEM. No X25519 / Curve25519.
- **Auth**: a *single* ML-DSA-87 signature per side (FIPS 204,
  NIST category 5). No Ed25519. No SPHINCS+.

`ed25519-dalek` appears only in `evelin-hsm` (the offline
release-manifest signing crate, documented as Ed25519-only) and
never in the transport. Verified by reading every line of
`evelin-handshake` / `evelin-crypto` and by a zero-match grep for
`ed25519|sphincs|x25519|curve25519` across both.

**Severity**: this is an honesty/claim defect, **not** a
cryptographic weakness. Single ML-KEM-1024 + single ML-DSA-87 are
each strong category-5 primitives; the transport is secure as
built. The problem was purely that the docs claimed more than is
implemented — which, for a security tool, must be fixed.

### The fix

- **New construction-pinning test**
  `handshake_construction_is_single_mlkem1024_single_mldsa87`
  runs a real handshake and asserts the exact encoded message
  sizes (HelloClient / HelloServer / Finish), which encode
  exactly one ML-KEM-1024 public key, one ML-KEM-1024 ciphertext,
  and one ML-DSA-87 signature per side. If anyone adds a second
  KEM, an X25519 contribution, or a classical signature, the
  sizes change and the test fails — forcing code, test, and docs
  to update together.
- **`docs/BENCHMARKS.md`** — all "×3" / "Ed25519 + SPHINCS+"
  passages replaced with the accurate "single ML-KEM-1024 +
  single ML-DSA-87 per side" description. Measured latency numbers
  unchanged (they always measured the real handshake); only the
  inaccurate prose was corrected, with dated correction notes.
- **`README.md`** — the v2.7 "what's new" handshake line and the
  v2.9 severity note corrected to name only the primitives that
  exist.
- Historical `V2_7`/`V2_8`/`V2_9` audit reports are **not**
  retroactively edited (frozen historical records); the v3.3
  correction is additive and dated.

### Wire-compat

- v3.3 ↔ v3.2 default: byte-identical (binaries functionally
  identical — only docs + a test changed)
- v3.3 ↔ v1.4 default: byte-identical
- libevelin v1 ABI: 20 symbols, unchanged

### Tests

- evelin-handshake 8/0 (+1 construction-pinning test); crypto
  30/0; rest of workspace unchanged from v3.2 (370+/0)
- clippy clean; `cargo audit` 0 vulns; `cargo deny` PASS

### Source delta

- `crates/evelin-handshake/src/server.rs`: construction-pinning
  test
- `docs/BENCHMARKS.md`, `README.md`: corrected crypto-construction
  claims
- `docs/V3_3_AUDIT_REPORT.md` (new)
- `Cargo.toml`: workspace version 3.2.0 → 3.3.0

### Deferred / future

- Hybrid KEX (ML-KEM-1024 + X25519) as a hedge against an ML-KEM
  implementation flaw is a legitimate *future feature* with its
  own design + audit — not a doc fix. The pinning test will fail
  when it's added, prompting a coordinated update.
- CI doc-lint that greps shipped docs for primitive names absent
  from the dependency graph, to catch claim drift earlier.

## v3.2.0 — 2026-06-02

**Send-path allocation/copy reduction.** The follow-through on the
bulk-path lever named in v3.1. Removes the per-record full-frame
ciphertext allocation, one full-frame copy, and bulk-encode
realloc churn — all proven deterministically. No protocol
changes; wire-compatible with v3.1 and v1.4 defaults.

**Honest scope up front**: this is an allocation/copy reduction,
**not** a measured bulk-throughput win. On the 1-core loopback
microbench the bottleneck is ChaCha20-Poly1305 compute, not
memcpy, so the saving is correctly invisible there (numbers flat
within ±50% cross-session variance). The win is proven by exact
allocation/wire-equivalence tests, and is expected to matter on
multi-core / memory-bandwidth-bound / long-running deployments
([ESTIMATED], not measured here).

### What changed

- **`Aead::seal_in_place`** (new) — encrypts the caller's
  `&mut Vec<u8>` in place via RustCrypto `AeadInPlace`, appending
  the tag, instead of allocating a fresh full-frame ciphertext Vec
  (what `seal` does). Identical nonce derivation, counter
  monotonicity, v2.8 nonce-reuse defense, and ratchet semantics —
  only the buffer location differs. `seal` is retained.
- **`RecordSender::send_owned_no_flush`** (new) — consumes an
  owned plaintext `Vec` (the `encode()` output) and seals it in
  place, removing the full-frame allocation from the send path.
- **mux `writer_loop`** now hands the owned `encode()` buffer to
  `send_owned_no_flush`. v3.1 flush-coalescing is unchanged.
- **`ChannelMsg::encode`** pre-sizes the output for bulk `Data`
  frames (`data.len() + 9`) instead of growing from a 64-byte
  base, cutting ~15 reallocations per 1 MiB chunk to 1.

### The copy chain: 3 → 2

| Step | Before | After |
|---|---|---|
| `send_data` → `Data` payload | copy (mpsc ownership) | copy (unchanged) |
| `encode` → framed buffer | copy + ~15 reallocs | copy + **1 alloc** |
| `seal` → ciphertext | **copy + full-frame alloc** | **eliminated (in place)** |

### Proven deterministically

- `seal_in_place_matches_seal_and_roundtrips` — in-place
  ciphertext byte-identical to `seal` across sizes {0…64 KiB},
  decrypts cleanly. Pins wire-compat.
- `seal_in_place_does_not_reallocate_when_tag_reserved` — buffer
  pointer + capacity unchanged after encryption (the
  zero-extra-allocation proof).
- `seal_in_place_refuses_counter_rewind` — v2.8 nonce-reuse
  defense fires on the in-place path.
- `send_owned_matches_flushed_stream` — owned send produces a
  byte-identical stream to `send`, incl. a 512 KiB bulk frame.

(A global-allocator counting test was considered but rejected: a
`GlobalAlloc` impl needs `unsafe`, forbidden workspace-wide since
v3.0. The buffer-invariance test proves the property without
unsafe — the brand promise took precedence over test
convenience.)

### Bench (v3.2.0, 1-core loopback)

| Size | v3.1 upload | v3.2 upload | Verdict |
|---|---|---|---|
| 1 MiB | 45.4 | 47.5 MiB/s | flat (±50% variance) |
| 64 MiB | 51.4 | 60.1 MiB/s | flat (±50% variance) |
| Handshake | 5.55 | 5.28 ms | flat |

Flat within variance, as expected for an AEAD-compute-bound
microbench. **No bulk-throughput claim.**

### Wire-compat

- v3.2 ↔ v3.1 default: byte-identical (proven by test)
- v3.2 ↔ v1.4 default: byte-identical
- libevelin v1 ABI: 20 symbols, unchanged

### Tests

- evelin-crypto 30/0 (+3), evelin-record 20/0 (+1),
  evelin-channel 23/0, evelin-session 22/0 + integration
- clippy clean; `cargo audit` 0 vulns; `cargo deny` PASS

### Source delta

- `crates/evelin-crypto/src/aead.rs`: `seal_in_place` + 3 tests
- `crates/evelin-record/src/lib.rs`: `send_owned_no_flush` + test
- `crates/evelin-channel/src/mux.rs`: writer_loop owned send
- `crates/evelin-channel/src/wire.rs`: pre-size Data encode
- `Cargo.toml`: workspace version 3.1.0 → 3.2.0
- `docs/V3_2_AUDIT_REPORT.md` (new)
- `docs/BENCHMARKS.md`: v3.2 section prepended

### Deferred to v3.3+

- **Copy #1 elimination** — `send_data`'s `chunk.to_vec()` (mpsc
  ownership). Would need a refcounted/borrowing message type
  (`Bytes`) threaded through the channel; larger change with its
  own allocator tradeoffs.
- Have `encode` reserve `+AEAD_TAG_LEN` so the in-place seal never
  reallocates even the tag (currently one growth).
- Throughput demonstration on a multi-core or
  memory-bandwidth-bound host (the 1-core microbench can't show
  the copy saving).

## v3.1.0 — 2026-06-02

**Small-frame write-coalescing.** A performance release with a
deliberately narrow, honest claim: it reduces `write` syscalls
and TCP segments for streaming many *small* records (interactive
PTY, port-forward small writes, pipelined channel control,
high-channel-count muxing). It does **not** speed up bulk
filecopy — that path uses large frames that bypass the new buffer
and is copy-bound, not syscall-bound. No protocol changes;
wire-compatible with v3.0 and v1.4 defaults.

### What changed

- **`RecordSender` now buffers through a 64 KiB `BufWriter`.** The
  send path is split into `send_no_flush` (encode + encrypt +
  buffered write) and `flush` (drain the buffer). `send` keeps its
  old behaviour (both, one record on the wire immediately).
- **The mux `writer_loop` batches the send queue.** It writes the
  first queued message, drains any immediately-available messages
  with `try_recv` (no flush each), and flushes once when the queue
  drains. A burst of N queued records becomes one flush instead of
  N. It always flushes before blocking on an empty queue, so
  interactive round-trips keep their latency (no message is ever
  stranded in the buffer).

### Why the first attempt didn't count (honesty note)

An initial draft added a per-frame `[len||ct]` buffer-assembly
copy and a `flush()` split, and measured **no improvement** on the
filecopy benchmark. Root cause: the record writer wrapped a *raw*
split TCP write half, where `flush()` is a no-op (TCP has no
userspace buffer). The fix was to introduce an actual `BufWriter`
and drop the pointless pre-assembly copy. The benefit is now
proven by a **deterministic syscall-count test**, not a noisy
wall-clock number.

### The metric that moved

`bufwriter_coalesces_small_record_writes` (counting-mock writer):

| Workload | Writes before | Writes after |
|---|---|---|
| 100 small records (24 B each) | 200 | **1** |

Large frames (> 64 KiB) bypass the buffer and write through —
verified by `bufwriter_passes_large_frames_through` — so bulk
transfer is unaffected.

### Bulk throughput: flat (by design)

| Size | v3.0 | v3.1 | Verdict |
|---|---|---|---|
| 1 MiB upload | 48.5 MiB/s | 45.4 MiB/s | flat (±50% variance) |
| 64 MiB upload | 61.7 MiB/s | 51.4 MiB/s | flat (±50% variance) |
| Handshake | 5.07 ms | 5.55 ms | flat (variance) |

These deltas are container-IO noise, not signal. **We do not
claim a bulk-filecopy speedup.**

### Tests

- New `send_no_flush_batch_matches_flushed_stream` — proves a
  batched stream is byte-identical to a per-record-flushed stream.
- New `bufwriter_coalesces_small_record_writes` — the 200→1
  syscall-count proof.
- New `bufwriter_passes_large_frames_through` — large frames are
  not held back (bulk-path guard).
- evelin-record 19/0, evelin-channel 23/0, evelin-session 22/0 +
  integration; clippy clean; `cargo audit` 0 vulns; `cargo deny`
  PASS.

### Wire-compat

- v3.1 ↔ v3.0 default: byte-identical (only flush *timing*
  changes; the byte stream is identical — proven by test)
- v3.1 ↔ v1.4 default: byte-identical
- libevelin v1 ABI: 20 symbols, unchanged

### Source delta

- `crates/evelin-record/src/lib.rs`: `BufWriter` field,
  `send_no_flush` / `flush` split, 3 new tests
- `crates/evelin-channel/src/mux.rs`: batched `writer_loop`
- `Cargo.toml`: workspace version 3.0.0 → 3.1.0
- `docs/V3_1_AUDIT_REPORT.md` (new)
- `docs/BENCHMARKS.md`: v3.1 section prepended

### Deferred to v3.2+

- **Bulk-path copy elimination** — the real bulk-throughput lever:
  thread a single buffer through `send_data` → `ChannelMsg::encode`
  → `Aead::seal` (which today each allocate/copy), and add an
  in-place AEAD API. Larger cross-crate change.
- Interactive-latency benchmark on a quiesced multi-core host
  (this container's ±50% variance hides small wall-clock deltas).
- Make the 64 KiB buffer capacity configurable if a workload ever
  shows it matters.

## v3.0.0 — 2026-06-02

**Memory-hygiene milestone.** Closes three secret-material-
lingering gaps in the crypto core and extends the
`#![forbid(unsafe_code)]` machine-check to every safe crate. No
protocol changes; wire-compatible with v2.9 and v1.4 defaults.

### Security: secret zeroization

Three `evelin-crypto` functions copied secret bytes into their
(correctly `ZeroizeOnDrop`) wrapper types **by value**, then
dropped the source stack buffer **without wiping it** — leaving
the cleartext secret on the stack after return:

- **`kdf::derive_session_keys`** — both directional session keys
  (`c2s`/`s2c`) lingered after being copied into `AeadKey`.
- **`kem::encapsulate` + `kem::decapsulate`** — the ML-KEM-1024
  shared secret (`ss_arr`) lingered after being copied into
  `KemSharedSecret`. This is the **root input to the entire
  session-key KDF** — the highest-value secret in the handshake.
- **`sig::generate_keypair`** — the ML-DSA-87 signing seed
  (`seed_arr`) lingered after being copied into `SeedBytes`. The
  seed **fully determines the long-term identity key** (FIPS 204
  §5.1).

Each now explicitly `.zeroize()`s the source buffer *after* the
copy into the wrapper. The public ciphertext buffer (`ct_arr`) is
correctly left un-wiped.

**Honest scope**: these are **hygiene fixes, not remote
vulnerabilities**. An attacker needs local memory access (core
dump, swap, cold-boot, or a separate disclosure bug) to benefit.
They shrink the window/surface where secrets sit in cleartext
memory. `zeroize`'s volatile-write guarantee resists dead-store
elimination but does not guarantee the compiler/CPU never spilled
an intermediate copy elsewhere — true guaranteed wiping needs asm
(out of scope). This is the accepted portable best-effort, now
applied to the source buffers and not just the wrapper types.

### Enforcement: forbid(unsafe_code) everywhere it's true

Audited all 19 crate roots:
- 14 crates + 3 binaries already had `#![forbid(unsafe_code)]`.
- `evelin-capi` legitimately uses `unsafe` for the C FFI boundary
  (raw pointers, `#[unsafe(no_mangle)]`); it already carries
  `#![forbid(unsafe_op_in_unsafe_fn)]` + a documented
  `#![allow(unsafe_code)]`. **Correct as-is** — the single,
  justified FFI exception.
- **`evelin-hsm` and `evelin-loom-tests`** contained zero
  `unsafe` but lacked the enforcing lint. Added
  `#![forbid(unsafe_code)]` to both; they compile clean under it.

The "zero unsafe code" brand promise is now **compiler-enforced**
on all 18 safe crate roots, not just 16 of them by convention.

### Tests

- New `kdf::tests::keys_are_nonzero_and_stable_after_zeroize`:
  guards against a refactor that zeroizes *before* the move
  (which would silently yield all-zero keys) and confirms
  determinism + direction-distinctness.
- Existing `kem::roundtrip_ok` already exercises encap+decap and
  asserts the shared secret matches *after* the zeroize runs,
  proving the wipe doesn't corrupt the returned secret.
- All changed crates pass: crypto 27/0, keys 29/0, hsm 2/0, capi
  8/0, server 99/0, and the rest — **304/0** across per-crate
  runs (full-workspace ≥370 on a host with adequate disk).
- Clippy strict clean on changed crates; `cargo audit` 0 vulns;
  `cargo deny check bans licenses sources` PASS.

### Bench numbers (v3.0.0)

Not re-run — the delta is zeroize calls on key-derivation buffers
(once per handshake) + lint attributes, provably off the data
path. v2.9 baseline applies:

| Size | Upload | Download |
|---|---|---|
| 1 KiB | 636 KiB/s | 4.02 MiB/s |
| 64 KiB | 25.0 MiB/s | 60.6 MiB/s |
| 1 MiB | 48.5 MiB/s | 62.9 MiB/s |
| 16 MiB | 64.7 MiB/s | 74.7 MiB/s |
| 64 MiB | 61.7 MiB/s | 73.5 MiB/s |
| Handshake | 5.07 ms median | — |

### Wire-compat

- v3.0 ↔ v2.9 default: byte-identical
- v3.0 ↔ v1.4 default: byte-identical
- libevelin v1 ABI: 20 symbols, unchanged (capi FFI unsafe usage
  unchanged — still the documented exception)
- Derived keys are bit-identical to before (zeroize is an
  internal memory detail invisible on the wire)

### Source delta

- `crates/evelin-crypto/src/kdf.rs`: zeroize `c2s`/`s2c` after
  move + new test
- `crates/evelin-crypto/src/kem.rs`: zeroize `ss_arr` in
  `encapsulate` and `decapsulate`
- `crates/evelin-crypto/src/sig.rs`: zeroize `seed_arr` in
  `generate_keypair`
- `crates/evelin-hsm/src/lib.rs`: add `#![forbid(unsafe_code)]`
- `crates/evelin-loom-tests/src/lib.rs`: add
  `#![forbid(unsafe_code)]`
- `Cargo.toml`: workspace version 2.9.0 → 3.0.0
- `docs/V3_0_AUDIT_REPORT.md` (new)
- `docs/BENCHMARKS.md`: v3.0 section prepended

### Deferred to v3.1+

- Confirm `ml-kem 0.3` / `ml-dsa 0.1` zeroize their own internal
  secret types on drop; if not, file upstream or wrap
- Document that `SigSecretKey::to_seed()` callers must zeroize
  their returned copy (`evelin-keys::wrap` already does via
  Argon2id-wrapped storage)
- Verify zeroization survives `-C opt-level=3` codegen via MIRI
  or generated-asm inspection (formal-methods item)
- Full `cargo test --workspace` on a host with ≥8 GB free target
  space (this container's ~19 GB disk forces per-crate runs)

## v2.9.0 — 2026-06-02

**Constant-time auth-path** sprint. Closes a timing side channel
in the two fingerprint-matching hot paths and unifies all
fingerprint comparison on the audited `subtle` crate. No protocol
changes.

### Security: constant-time fingerprint matching

The codebase already shipped `ct_match::FingerprintAllowList`, a
documented constant-time matcher — but two auth-critical paths
bypassed it and used variable-time `==`:

- **`AuthorizedKeys::contains`** (server-side, runs on every
  inbound connection) used
  `self.entries.iter().any(|e| &e.fingerprint == fp)`. Short-
  circuits on first match; per-comparison timing leaks how many
  leading bytes match.
- **`KnownHosts::matches`** (client-side TOFU verification) had
  the same `&e.fingerprint == fingerprint` pattern.

v2.9 rewrites both to walk the whole list (no early exit) and OR
each `subtle::ConstantTimeEq` result into a single `Choice`
accumulator. Total time depends only on list length, not on
which entry matched or how many bytes matched. Both sites marked
`/* CT-REQUIRED */`.

**Honest severity**: the matched value is a hash of a *public*
key. A timing oracle leaks *which fingerprints are on the
allow-list* (a confidentiality leak about who may log in), **not**
an authentication bypass — forging auth still requires the
ML-DSA-87 + Ed25519 *private* keys. LOW–MEDIUM severity, closed
because the project's policy is constant-time-everywhere and the
fix is cheap. Equally important: it removes the inconsistency of
having a documented CT matcher alongside variable-time compares
on the real hot path.

### Hardening: unify on `subtle`

`ct_match::FingerprintAllowList::contains` previously used a
hand-rolled `ct_eq_32` (manual XOR-fold + `wrapping_neg` +
`compiler_fence`). v2.9 replaces it with `subtle::ConstantTimeEq`
— an audited primitives crate already in the workspace — deleting
the bespoke bit-twiddling that a compiler could theoretically
"optimize" back into a branch. Behavior is identical; the
implementation is strictly safer.

### Tests

- New `contains_is_order_independent_and_full_width`: verifies
  matches at first/middle/last positions and rejection of
  near-misses differing in only the first or only the last byte.
- New `contains_timing_is_position_independent`: dudect-style
  canary — 4096-entry list, times first-match vs last-match over
  2000 iterations, asserts ratio < 3×. A short-circuit regression
  would make first-match ~4096× faster and fail loudly.
- Removed the two now-redundant `ct_eq_32_*` tests (the primitive
  they tested is gone).
- Net test count unchanged at **370 / 0**.

### Bench numbers (v2.9.0 baseline)

Loopback, 1-core box, release build:

| Size | Upload | Download |
|---|---|---|
| 1 KiB | 636 KiB/s | 4.02 MiB/s |
| 64 KiB | 25.0 MiB/s | 60.6 MiB/s |
| 1 MiB | 48.5 MiB/s | 62.9 MiB/s |
| 16 MiB | 64.7 MiB/s | 74.7 MiB/s |
| 64 MiB | 61.7 MiB/s | 73.5 MiB/s |
| Handshake | 5.07 ms median | — |

Consistent with v2.8 within container-IO variance. The CT change
is on the auth path (once per connection), not the data path —
throughput is unaffected by design. Cross-session benches still
swing ±container-noise; treat each version's numbers as that
version's baseline.

### Wire-compat

- v2.9 ↔ v2.8 default: byte-identical
- v2.9 ↔ v1.4 default: byte-identical
- libevelin v1 ABI: 20 symbols, unchanged
- CT rewrites change only *how* fingerprints compare, not *what*
  matches — same accept/reject decisions as before

### Source delta

- `crates/evelin-keys/src/lib.rs`: CT `AuthorizedKeys::contains`
  + 2 new tests
- `crates/evelin-keys/src/known_hosts.rs`: CT `KnownHosts::matches`
- `crates/evelin-keys/src/ct_match.rs`: `subtle`-backed
  `contains`; removed `ct_eq_32` + `compiler_fence` + 2 tests
- `Cargo.toml`: workspace version 2.8.0 → 2.9.0
- `docs/V2_9_AUDIT_REPORT.md` (new)
- `docs/BENCHMARKS.md`: v2.9 section prepended

### Deferred to v3.0

- Rigorous `dudect` leakage assessment of `contains` outside CI
  on a quiesced host (the in-tree test is a regression canary,
  not a leakage proof)
- Mark the 14 s timing test `#[ignore]` behind a dedicated
  security-test job if suite latency becomes a concern
- Paired same-container cross-version benches
- Replace `indicatif`/`cryptoki` to drop the 2 unmaintained-dep
  INFO warnings

## v2.8.0 — 2026-06-01

**Defense-in-depth + supply chain** sprint. One security fix, one
supply-chain hardening addition, no protocol changes.

### Security: AEAD nonce-reuse runtime detection

ChaCha20-Poly1305 catastrophically breaks on (key, nonce) reuse.
Pre-v2.8 the counter monotonicity property was *policy-maintained*
by careful code. v2.8 makes it *runtime-enforced* via a new
`seal_counter_high_water` field on `Aead`. `seal()` refuses to
encrypt if the counter regresses below the highest-ever-used value
for this (key, direction) pair, returning `Error::NonceReuseDetected`.
`ratchet()` resets the high-water mark (fresh key = clean slate).

**Closes a catastrophic failure class**:
- Memory corruption resetting counter mid-stream
- Logic bugs in record-layer pipelining (especially the v1.9
  async-hash paths)
- Fork-without-ratchet (defensive — Aead doesn't impl Clone today)
- Hostile test mocks regressing production code
- Future regression introducing rekey-on-error paths that reset
  counter without ratcheting

Silent plaintext recovery becomes a loud, connection-killing error.

**Forward skip remains allowed** — only backward counter movement
triggers the defense. This preserves architectural flexibility for
RFC 9001 / TLS 1.3 -style record pipelining where skipping a
counter value is legitimate.

**Test coverage** — 4 new pinned regression tests in
`crates/evelin-crypto/src/aead.rs`:
- `seal_refuses_repeated_counter`
- `seal_refuses_backwards_skip`
- `seal_accepts_forward_skip`
- `ratchet_resets_high_water`

**Performance impact**: ~2 ns per seal (one cache-local u64
compare + one assign on the already-hot Aead struct). At ~70 MiB/s
sustained = ~1.4 µs/sec total — unmeasurable in throughput.

### Supply chain: cargo-deny integration

`cargo-deny 0.16.4` integrated alongside `cargo audit`. New
`deny.toml` policy enforces:

- **Licenses** — 13 SPDX-permissive licenses allowlisted; workspace
  crates exempted to permit their AGPL+commercial dual-license
  declaration
- **Bans** — explicit deny list for crypto primitives that should
  never appear: `md-5`, `sha1`, `rust-crypto`, `openssl`,
  `openssl-sys`. Their presence in a future Cargo.lock = CI fail.
- **Sources** — only `crates.io` accepted; no git deps; no
  private registries.

```bash
cargo deny check bans licenses sources    # passes
cargo deny check advisories                # carry from cargo audit
```

Independent supply-chain enforcement layer; catches regressions
`cargo audit` would miss (license drift, duplicate versions,
banned crate introductions).

### Bench numbers (v2.8.0 baseline)

Loopback, 1-core box, release build:

| Size | Upload | Download |
|---|---|---|
| 1 KiB | 692 KiB/s | 3.86 MiB/s |
| 64 KiB | 24.6 MiB/s | 58.2 MiB/s |
| 1 MiB | 52.5 MiB/s | 76.4 MiB/s |
| 16 MiB | 67.8 MiB/s | 75.3 MiB/s |
| 64 MiB | 61.4 MiB/s | 73.2 MiB/s |
| Handshake | 4.66 ms median (post-quantum round trip) | — |

Honest caveat: v2.6/v2.7/v2.8 benches each ran on a different
fresh container session. Cross-version deltas reflect container-IO
variance, not v2.x source changes. v2.9 should run paired benches
on a single container for a clean comparison.

### Wire-compat

- v2.8 ↔ v2.7 default: byte-identical
- v2.8 ↔ v1.4 default: byte-identical
- libevelin v1 ABI: 20 symbols, unchanged
- `Error::NonceReuseDetected` is local-only; never serialized to
  the wire

### Tests

- **370 / 0** workspace + integration tests (+4 from v2.7)
- Clippy strict clean (`-D warnings`)
- `cargo audit --no-fetch`: 0 vulnerabilities (2 unmaintained
  INFO warnings unchanged from v2.6)
- `cargo deny check bans licenses sources`: **PASS**

### Source delta

- `crates/evelin-crypto/src/aead.rs`: `seal_counter_high_water`
  field + enforcement in `seal()` + reset in `ratchet()` + 4
  regression tests
- `crates/evelin-core/src/error.rs`: `NonceReuseDetected` variant
- `deny.toml` (new): cargo-deny policy
- `Cargo.toml`: workspace version 2.7.0 → 2.8.0
- `docs/V2_8_AUDIT_REPORT.md` (new)
- `docs/BENCHMARKS.md`: v2.8 section prepended

### Deferred to v2.9

- Run v2.6/v2.7/v2.8 benches paired on same container for clean
  cross-version comparison
- CI workflow (`.github/workflows/security.yml`) running both
  `cargo audit` and `cargo deny check` on every PR
- Replace `indicatif`/`cryptoki` to drop the unmaintained-dep
  INFO warnings
- Reduce duplicate-version count from 19 (mostly bitflags v1/v2
  churn via cryptoki + portable-pty)
- Consider switching `Aead::seal_counter_high_water` from u64 to
  AtomicU64 if a future API ever needs concurrent seal (today's
  `&mut self` API is single-threaded so this is a future-proofing
  micro-optimization)

## v2.7.0 — 2026-06-01

**Rate-limiter hardening + handshake measurement** sprint. One
security fix, one measurement infrastructure addition, no
protocol changes.

### Security: bounded-work rate-limiter prune

Closes a self-inflicted DoS vector that's been latent since v1.4.
The IP-tracking table's prune path used to allocate
`Vec<(IpAddr, Instant)>` over the entire table (default cap
65,536 entries = 1.5 MiB allocation) and then `sort_unstable_by_key`
the whole thing on **every** admit() once the cap was hit. Under
sustained botnet pressure (IPs created at line rate), this is
O(N log N) work per admission — itself a DoS amplifier.

**v2.7 changes**:
- **Rate-limited prune**: `last_prune: Mutex<Instant>` field caps
  prune work to at most once per second
- **Bounded eviction batch**: drop at most `BATCH_EVICT = 1024`
  entries per pass instead of "drop until back under cap"
- **Partial sort**: `select_nth_unstable` is O(N), not O(N log N) —
  find the cutoff `last_seen` without fully sorting the array,
  then `retain()` sweep evicts entries older than the cutoff

**Pre-v2.7 worst case** (1000 fresh IPs/sec, 65k cap):
~1.5 GiB/sec of allocator pressure + ~1B comparisons/sec.

**Post-v2.7 worst case**: ~512 KiB allocation + ~130k comparisons
per second. **Three orders of magnitude less work under attack.**

The table may briefly overshoot cap by up to `BATCH_EVICT = 1024`
entries (≈120 KiB additional state). Bounded, not unbounded.

New regression test `prune_is_bounded_under_sustained_pressure`
admits 200 distinct IPs to a 50-entry cap table and asserts
overshoot stays within `cap + BATCH_EVICT`.

### Performance measurement: handshake bench group

New Criterion bench group `handshake` measures the full
ClientHandshake → ServerHandshake round trip in isolation,
including ML-KEM-1024 ×3 + ML-DSA-87 + Ed25519 + SPHINCS+
operations.

**v2.7 baseline on 1-core loopback: 4.89 ms median**
(range 4.80–4.99 ms across 10 samples).

This is the **expected post-quantum handshake cost**. Reference:
OpenSSH 9.x with classical Curve25519 on the same hardware is
~0.5 ms. PQ overhead: ~5–10x. ML-KEM-1024 ciphertext is 1,568 B
vs Curve25519's 32 B; ML-DSA-87 signature is 4,627 B vs Ed25519's
64 B. The asymmetric crypto dominates wall time.

Reproduce: `cargo bench -p evelin-session --bench filecopy_throughput -- handshake`

### Filecopy throughput on v2.7 host

| Size | Upload | Download |
|---|---|---|
| 1 KiB | 428 KiB/s | 2.80 MiB/s |
| 64 KiB | 21.5 MiB/s | 49.1 MiB/s |
| 1 MiB | 97.4 MiB/s | 54.8 MiB/s |
| 16 MiB | 142.7 MiB/s | 64.9 MiB/s |
| 64 MiB | 146.9 MiB/s | 59.1 MiB/s |

**Honest note**: these numbers come from a different (freshly
booted) container than the v2.6 numbers were measured on.
Upload improved across all sizes; download dropped substantially.
The v2.7 source delta is entirely outside the filecopy path
(rate-limiter prune doesn't fire during single-connection bench
runs), so the download regression is almost certainly container
IO variance, not a real v2.7 change. v2.8 should run paired
benchmarks on the same container for a clean delta. See
`docs/BENCHMARKS.md` for the full discussion.

### Wire-compat

- v2.7 ↔ v2.6 default: byte-identical
- v2.7 ↔ v1.4 default: byte-identical
- libevelin v1 ABI: 20 symbols, unchanged

### Tests

- **366 / 0** workspace + integration tests (one more than v2.6)
- Clippy strict clean (`-D warnings`)
- `cargo audit --no-fetch`: 0 vulnerabilities, 2 unmaintained
  INFO warnings (unchanged from v2.6)

### Source delta

- `crates/evelin-server/src/ratelimit.rs`: bounded-work prune
  + `last_prune` field + regression test
- `crates/evelin-session/benches/filecopy_throughput.rs`:
  `bench_handshake` group + fd-budget cap of 50 iters
- `Cargo.toml`: workspace version 2.6.0 → 2.7.0
- `docs/V2_7_AUDIT_REPORT.md`: per-source-line audit (new)
- `docs/BENCHMARKS.md`: v2.7 section prepended

### Deferred to v2.8

- Re-run v2.6 + v2.7 benches paired on the same container to
  get a clean perf delta
- Expose `BATCH_EVICT` and `MIN_PRUNE_INTERVAL` as config knobs
- Replace `last_prune: Mutex<Instant>` with atomic for less
  contention under high concurrent admit rate
- Network-simulated bench group (`tc netem` 100 ms RTT)
- `cargo audit` deps: replace `indicatif`/`cryptoki` to drop
  the two unmaintained-dep warnings

## v2.6.0 — 2026-06-01

**Harden + measure** sprint. No protocol changes; closes v2.5
deferred items and adds reproducible measurement infrastructure
that would have caught the v2.3 → v2.4.1 regression at PR time.

### Security

- **`[filecopy] max_file_size` config knob.** Bounds per-transfer
  upload size at the policy layer. Operators on shared/multi-tenant
  deployments should set this to a tight value:
  ```toml
  [filecopy]
  roots         = ["/srv/uploads"]
  allow_upload  = true
  max_file_size = 5_000_000_000   # 5 GB
  ```
  `0` (default) keeps v2.5 behavior (no policy-level limit; receiver
  disk space is the only bound). Rejection produces a clean
  `PolicyDenied` over the wire; no oversize allocation enabled.

### Hardening

- **`fuzz_record_frame` libFuzzer target.** Drives `RecordReceiver::recv`
  with arbitrary fuzz-generated input. Closes the bug class that broke
  v2.3 → v2.4.1 (oversized-frame-rejected-after-allocation paths).
  Brings fuzz target count to 11.
- **`cargo audit` integrated.** Run against RUSTSEC's 1099-entry
  advisory DB: 0 vulnerabilities across 288 deps. 2 unmaintained-dep
  INFO warnings tracked in audit report for v2.7 follow-up.

### Performance — reproducible numbers

The v2.5 audit cited hand-timed numbers. v2.6 replaces them with
sample-mean ± standard-deviation from Criterion (`crates/evelin-session/benches/filecopy_throughput.rs`).
Run via:

```bash
cargo bench -p evelin-session --bench filecopy_throughput
```

**v2.6 loopback baseline (1-core box, release build, 10 samples):**

| Size | Upload | Download |
|---|---|---|
| 1 KiB | 365 KiB/s | 3.9 MiB/s |
| 64 KiB | 17.8 MiB/s | 110 MiB/s |
| 1 MiB | 81.3 MiB/s | 134 MiB/s |
| 16 MiB | 111 MiB/s | 167 MiB/s |
| 64 MiB | 130 MiB/s | 155 MiB/s |

Small files (<64 KiB) are handshake-dominated; the channel-open
cost is fixed at ~2 ms. Large files saturate at ~130-167 MiB/s
which is the AEAD + mux throughput ceiling on this hardware.

See `docs/BENCHMARKS.md` for full ranges + reproduction recipe.

### Wire-compat

- v2.6 ↔ v2.5 default: byte-identical
- v2.6 ↔ v1.4 default: byte-identical
- libevelin v1 ABI: 20 symbols, unchanged

### Tests

- 365 / 0 (292 lib+bin + 73 integration)
- Clippy strict clean (`-D warnings`)
- `cargo audit --no-fetch`: clean

### Source delta

- `crates/evelin-session/src/filecopy.rs`: `max_file_size` field
  on `FileCopyPolicy` + dispatch-level enforcement
- `crates/evelin-config/src/lib.rs`: TOML config wiring
- `crates/evelin-server/src/main.rs`: policy builder wiring
- `crates/evelin-session/benches/filecopy_throughput.rs`: new
  220-LOC Criterion harness
- `crates/evelin-session/tests/filecopy_*.rs`: mechanical
  `max_file_size: 0` field additions to existing constructors
- `fuzz/Cargo.toml`: `fuzz_record_frame` registration + tokio dep
- `fuzz/fuzz_targets/fuzz_record_frame.rs`: new 60-LOC fuzz target
- `docs/V2_6_AUDIT_REPORT.md`: per-source-line audit (new)
- `docs/BENCHMARKS.md`: real reproduction recipe + baseline (new)
- `CHANGELOG.md`: this entry

### Deferred to v2.7

- Replace `indicatif` or pin a `number_prefix` fork (RUSTSEC-2025-0119
  unmaintained warning)
- Replace `cryptoki` proc-macro `paste` dep (RUSTSEC-2024-0436)
- Comparative benchmark against `scp -c chacha20-poly1305@openssh.com`
- Network-simulated bench group (`tc netem`-emulated RTT)
- Allocation-probe instrumentation for the fuzz harness
- Multi-channel concurrent throughput bench

## v2.5.0 — 2026-05-10

The **filecopy actually works at speed now** sprint. Closes the
v2.3 throughput regression for real this time, plus the v2.4.x
"progress bar shows 0 B" issue, plus the recurring NoNewPrivs
sudo-blocker via a new operator subcommand.

### Performance — what's actually happening now

The v2.3 → v2.4.2 thrash on filecopy throughput came from one
underlying bug: the record-layer default `max_frame_len` was
16 KiB, while the channel layer's `MAX_DATA_LEN` was raised to
1020 KiB in v2.3. Sends > 16 KiB returned `FrameTooLarge`,
killing the mux writer task. v2.4.2 reverted MAX_DATA_LEN back
to 14 KiB to restore correctness at the cost of throughput.

**v2.5 fixes the underlying issue**: `RecordSender::new` and
`RecordReceiver::new` now default to `MAX_FRAME_LEN_BIG = 1 MiB`
unconditionally. Both peers always accept up to 1 MiB frames,
so `MAX_DATA_LEN = 1020 KiB` works without requiring extension
negotiation.

Measured v2.5 throughput (release build, loopback): **4 MiB
upload in 112 ms (~35 MB/s), download in 59 ms (~70 MB/s)**.
Previously broken (v2.3 → v2.4.1) or capped at 14 KiB/frame
(v2.4.2).

### Wire-compat

- v2.5 ↔ v2.4.2 default config: byte-identical when frames are
  ≤ 16 KiB. v2.5 may *also* send up to 1 MiB frames, which
  v2.4.2 (default) accepts because v2.4.2 receivers also default
  to 1 MiB cap (via the same `RecordReceiver::new` default that
  v2.5 raises).
- v2.5 ↔ v1.x default config: backward-compatible for small
  frames. v2.5 senders may emit > 16 KiB frames that pre-v1.6
  receivers reject. Mitigation: upgrade the server first.
- libevelin v1 ABI: 20 symbols (unchanged).

### CLI

- **`ev cp` progress bar updates live** as bytes transfer.
  v2.4.x bug where it was stuck at 0 B is fixed via a new
  `client_upload_with_progress` / `client_download_with_progress`
  API that takes a callback. The CLI passes a closure that calls
  `pb.set_position(bytes)` from `indicatif`.

### Server

- **`evelin-server --install-systemd-override`** subcommand.
  Writes `/etc/systemd/system/evelin-server.service.d/override.conf`
  with the directives needed to undo systemd's implicit NNP=1
  cascade caused by `RestrictSUIDSGID`, `LockPersonality`,
  `RestrictNamespaces`, `ProtectKernel*`, etc. Idempotent.
  Replaces the manual `tee` step that operators had been
  running. Use only for shell-as-root deployments.

### Source delta

- `crates/evelin-record/src/lib.rs`: defaults raised to
  `MAX_FRAME_LEN_BIG`.
- `crates/evelin-channel/src/wire.rs`: `MAX_DATA_LEN` back to
  1020 KiB with documented rationale.
- `crates/evelin-session/src/filecopy.rs`:
  `client_upload_with_progress` + `client_download_with_progress`
  + `ProgressCb` type alias.
- `crates/evelin-client/src/main.rs`: CLI wires its `pb` into
  the new APIs.
- `crates/evelin-client/src/progress.rs`: `progress_cb()`
  accessor returning a `Send + Sync` closure.
- `crates/evelin-server/src/main.rs`: `--install-systemd-override`
  + optional `--config`.
- `packaging/systemd/evelin-server.service`: comment pointing
  to the new subcommand.

### Tests

- **371 / 0** workspace tests including integration suites.
- New: `filecopy_4mib_throughput.rs` — 4 MiB round-trip in
  < 5 seconds, would have caught the v2.3 regression.
- Updated: 3 record-layer tests for the new default cap.
- Fixed: 2 stale CVE assertions for `MAX_FRAME_LEN_BIG = 1 MiB`
  (previously 256 KiB; mismatch dated to v2.1, surfaced in v2.5
  testing).
- Clippy strict clean.

### Audit

- `docs/V2_5_AUDIT_REPORT.md` — per-source-line review.
- 5 INFO findings, 0 HIGH/CRITICAL/BUG.
- All 17 prior CVE regression tests pass.

### Deferred to v2.6

- True BIG_FRAME negotiation through the handshake (currently
  the wire format has the bit but the value isn't propagated
  to `RecordSender::set_max_frame_len`; v2.5 sidesteps by
  raising the default).
- `[filecopy] max_file_size` config knob.
- Configurable progress-log threshold.
- splice(2) — closed permanently as NO-GO (see v2.4 audit §1).

## v2.4.0 — 2026-05-10

The **async-hash + pipelined-reads** sprint. Closes v2.3's R-5
deferral (move SHA-256 off the upload hot path) and adds a new
producer/consumer pipeline for disk I/O. **splice(2) closed
as NO-GO** with documented rationale.

### Performance — what's overlapped now

**Before (v2.3):**
```
chunk N: read → hash → encrypt → send  → next chunk
```

**After (v2.4):**
```
chunk N:   read ─┬─→ hash ──┐
                 │           ├─→ encrypt → send → next chunk
chunk N+1: read ─┴───────────┘  (overlapped)
```

Two CPU/IO overlaps per chunk:
1. **Async hash**: SHA-256 update runs on a `tokio::task::spawn_blocking` thread while the consumer task awaits `mux.send_data` (which itself goes through the wire-writer mpsc).
2. **Pipelined reads**: producer task reads up to 4 chunks ahead via a bounded mpsc; consumer pulls and processes.

### Why splice(2) didn't ship

The v2.3 audit's R-4 deferral mentioned splice(2) zero-copy as
a v2.4 candidate. After implementation analysis, **closed as
NO-GO**:

splice(2) moves bytes between FDs inside the kernel without a
userspace copy. But evelin's filecopy upload path is:

```
read(file_fd) → SHA-256 → AEAD_seal → write(socket_fd)
```

The AEAD encryption step (ChaCha20-Poly1305) **requires
userspace bytes** — there's no in-kernel ChaCha20-Poly1305
crypto API. Same on the receiver side. splice(2) cannot
eliminate the userspace round-trip across that boundary.

The audit report §1 documents the analysis. Closing R-4 as
NO-GO matches the precedent set by `THREAT_MODEL_0RTT.md`
(deferred-with-rationale, not silently dropped).

### Source delta

- `crates/evelin-session/src/filecopy.rs`: +135 / -45 LOC
  - `client_upload`: pipelined reads + async hash
  - `server_receive_upload`: async hash + progress logging
  - `client_download`: async hash
  - File-level `#[allow(clippy::absurd_extreme_comparisons)]` for
    the v2.3 `MAX_FILE_SIZE = u64::MAX` checks (kept in place
    for v2.5 config-knob upper-bounding)

### Memory budget per active transfer

Bounded by:
- 4 read-ahead chunks × 1 MiB = **4 MiB** in pipeline mpsc
- 2 chunks in flight (one being hashed, one being sent) × 1 MiB = **2 MiB**
- Total: **~6 MiB** per active transfer

Down from "potentially unbounded if the producer outran the
consumer" in a naïve design — but our bounded mpsc prevents
that.

### Audit

- Self-audit in `docs/V2_4_AUDIT_REPORT.md`
- 5 INFO findings (R-1 through R-5), 0 HIGH/CRITICAL/BUG
- All 17 prior CVE regression tests pass
- Wire-format unchanged; v2.4 ↔ v2.3 byte-identical on the wire

### Tests

- 292 / 0 lib+bin
- Clippy strict clean
- musl static build clean

### Wire-compat

- v2.4 ↔ v2.3 default: byte-identical
- v2.4 ↔ v1.4 default: byte-identical
- libevelin v1 ABI: 20 symbols (unchanged)

### Files changed

- `crates/evelin-session/src/filecopy.rs`
- `man/evelin-client.1` HISTORY section
- `man/evelin-server.8` HISTORY section
- `README.md` header
- `docs/V2_4_AUDIT_REPORT.md` (new)
- `CHANGELOG.md` (this entry)

### Deferred to v2.5

Per audit findings R-1 through R-3:

- **Configurable pipeline depth** (`[filecopy] read_pipeline_depth`)
- **Arc-based chunk passing** to eliminate the chunk clone for
  the hash worker (saves ~1 MiB/chunk allocation on uploads)
- **Producer-blocked metric** for operators monitoring backpressure
- **Configurable `[filecopy] max_file_size`** (the v2.3 R-1
  deferral)
- **Explicit v2.4 CVE regression tests** — `cve_v2_4_async_hash_matches_sync`,
  `cve_v2_4_pipelined_read_preserves_byte_order`,
  `cve_v2_4_producer_drops_on_consumer_error`

## v2.3.0 — 2026-05-10

The **filecopy throughput** sprint. Closes the gap that made
evelin filecopy ~10× slower than `scp`. No protocol changes;
no security-relevant surfaces touched.

### Performance

- **`MAX_DATA_LEN`** in the channel layer raised from **14 KiB to
  1020 KiB**. This was the single biggest filecopy bottleneck: a
  vestigial v0.x constant that meant every 12 KiB application
  chunk fit exactly one Data message — but every 1 MiB BIG_FRAME
  chunk got shredded into ~74 sub-frames, each with its own
  AEAD seal/open round-trip. v2.3 lets a 1 MiB application
  chunk go in one frame.
- **`COPY_CHUNK_SIZE`** in filecopy raised from **12 KiB to 1
  MiB**, matching the v2.1 BIG_FRAME limit. On a 300 MB transfer
  the chunk count drops from ~25,000 to ~300 — the per-chunk
  AEAD + window-credit overhead falls 85×.
- **`MAX_FILE_SIZE`** raised from **16 GiB to `u64::MAX`**
  (effectively unlimited). The receiver's disk space is now the
  real bound; operators on shared hosts must rely on filecopy-
  root path policy + filesystem quotas (audit finding R-1).

### Observability

- **Per-transfer progress logs** on both upload and download:
  ```
  INFO bytes_sent=33554432 total=314572800 pct=10.7% \
       mb_per_sec=18.4 filecopy upload progress
  ```
  Emitted every 16 MiB or 2 seconds, whichever comes first.
- **Final completion log** with average MB/s and total duration.

### Audit

- Self-audit per-source-line in `docs/V2_3_AUDIT_REPORT.md`
- 5 INFO findings (R-1 through R-5), 0 HIGH/CRITICAL/BUG
- All 17 prior CVE regression tests pass

### Wire-compat

- v2.3 ↔ v2.2 default: byte-identical
- v2.3 ↔ v1.4 default: byte-identical
- libevelin v1 ABI: 20 symbols (unchanged)

### Tests

- 292 / 0 lib+bin
- Clippy strict clean
- musl static build clean

### Files changed

- `crates/evelin-channel/src/wire.rs` (+14 / -3)
- `crates/evelin-session/src/filecopy.rs` (+95 / -8)
- `man/evelin-client.1`, `man/evelin-server.8` HISTORY sections
- `README.md` header
- `docs/V2_3_AUDIT_REPORT.md` (new)
- `CHANGELOG.md` (this entry)

### Deferred to v2.4

- **splice(2) zero-copy** filecopy path on Linux — closes the
  remaining gap to `rsync`-over-ssh
- **Async SHA-256** on a worker thread so hashing doesn't block
  the upload hot path on slow CPUs
- **Configurable file-size cap** (`[filecopy] max_file_size`)
- **Configurable chunk size** (`[filecopy] chunk_bytes`)
- **Configurable progress-log threshold**

## v1.9.0 — 2026-05-10

The **performance and platform-abstraction** sprint. Lands the deferred parallel AEAD decrypt worker pool, the N-generation ticket keyring, the `evelin-platform` cross-platform abstraction layer, and finalizes PTY shell as a default feature. SAFE_IO_URING profile config is validated; runtime wiring deferred to v1.10. macOS / BSD / Windows runtime support is scoped via the platform crate's stubs.

Crypto core unchanged. Wire format unchanged. C ABI unchanged (20 symbols, matches v1.4 → v1.8).

### Added

- **`crates/evelin-record/src/parallel_aead.rs`** — order-preserving worker pool for AEAD decrypt under `pipeline_depth >= 2`. `OrderingRing` keyed by sequence number; workers post out-of-order, delivery thread reads in monotonic order. Tested in-order completion, out-of-order completion, and pool-size clamping. Library shipped; `RecordReceiver` integration is v1.10.

- **`Aead::open_at_seq(&self, seq, ct)`** — stateless decrypt entry point in `evelin-crypto`. Workers compute their own nonces from the dispatcher-assigned seq; never share mutable AEAD state. The existing `open(&mut self, ct)` for sequential paths is preserved.

- **`NGenTicketKeyring`** — N-generation ticket keyring in `evelin-server::resume`. Default N=4 (current + 3 previous), giving 96-hour ticket validity at 24h rotation. Forward-secrecy bounded by N × rotation_interval. 6 new tests covering construction, rotation, ordering, edge cases.

- **`crates/evelin-platform/`** — new crate, ~400 LOC across 7 files. Trait surface: `Sandbox`, `IpcSocket` / `IpcStream`, `OpenBeneath`, `JobControl` / `JobLimits`, `EnforcementLevel`. Linux full impl (delegates to existing `evelin-server::sandbox`); Windows skeleton with `windows-rs` API imports; macOS / FreeBSD / OpenBSD / fallback stubs returning `Unimplemented`. v1.10+ port targets land per-platform impls.

- **`[runtime] io_uring_profile`** config field. Validated values: `"off"` (default; identical to v1.8 epoll path) and `"safe-accept-only"` (still fails-fast in v1.9 with a startup error pointing operators to `EVAL_IO_URING.md`). Runtime wiring deferred to v1.10.

- **`[runtime] parallel_aead`** config field, default `true`. The flag is read by the future v1.10 `RecordReceiver` integration; v1.9 ships the library and the config knob.

- **`docs/V1_9_AUDIT_REPORT.md`** — round-2 self-audit, 6 INFO findings, 0 HIGH/CRITICAL/BUG.

- **`SPRINT_V1_9_0_GODTIER_PROMPT.md`** — sprint plan, 9 phases.

### Changed

- **`pty-shell` is now a default feature** in `evelin-server` (`default = ["pty-shell"]`). v1.8 had the code behind a flag; v1.9 turns it on by default so operators don't have to rebuild from source for interactive shell. `--no-default-features` for minimal builds.

- **`evelin-server` Cargo.toml** gains `tokio-uring = { version = "0.5", optional = true }` and `io-uring` feature.

- **`evelin-record` Cargo.toml** gains `parking_lot = "0.12"` and `crossbeam-channel = "0.5"` for the parallel AEAD pool.

- **`evelin-server` Cargo.toml**: removed OpenRC init-script asset from .deb (carried from v1.8.1). The systemd unit references `/usr/sbin/evelin-server` (also from v1.8.1). No SysV init compat noise.

### Tests

- 283 lib+bin tests carry forward from v1.8
- +6 N-generation keyring tests
- +3 parallel AEAD pool tests
- **Total: 292 / 0**
- Clippy strict (`-D warnings`) clean
- `cargo build --workspace --release` clean
- `cargo build --workspace --release --target x86_64-unknown-linux-musl` clean

### Wire-compat

- v1.9 ↔ v1.8 default: byte-identical (new fields default to safe values)
- v1.9 ↔ v1.4 default: byte-identical
- libevelin v1 ABI: 20 symbols (matches v1.4 / v1.5 / v1.6 / v1.7 / v1.8)

### Deferred to v1.10

- `parallel_aead` integration into `RecordReceiver::recv`
- `io_uring_profile = "safe-accept-only"` runtime wiring against tokio-uring + `IORING_REGISTER_RESTRICTIONS`
- macOS implementation against `evelin-platform::Sandbox` (App Sandbox)
- FreeBSD implementation (Capsicum)
- OpenBSD implementation (pledge / unveil)
- Native Windows MSVC build + integration testing
- N-gen keyring per-generation hit rate metrics

## v1.8.0 — 2026-05-10

The **research, documentation, and gating** sprint. Two long-deferred questions (0-RTT app data, io_uring) get formal threat models with go/no-go decisions; the v1.7-deferred work (cargo-audit CI gate, SBOM signing, doc-tests) lands; the operator runbook becomes a first-class deliverable; the third-party paid cryptographic audit is engaged with v1.7.0 frozen as the target.

Crypto core, wire protocol, and C ABI all unchanged from v1.7. The one behavioural delta is the `[resume] max_age_secs` default — see §Changed.

### Theme

v1.5 added negotiation, v1.6 added wiring, v1.7 added regression tests for every defense, v1.8 closes the analysis loop: the questions we kept deferring now have written answers. The "no, here's why" decisions are as documented as the "yes, here's how" ones.

### Added

- **`docs/THREAT_MODEL_0RTT.md`** (~280 lines) — formal threat model for 0-RTT application data. Eight threats enumerated (T1: replay within window, T2: cross-restart replay, T3: forward-secrecy loss, T4: ticket reuse for 0-RTT vs full resumption, T5: timing leaks app-protocol identity, T6: amplification, T7: replay storm DoS, T8: data-before-confirmation). Per-app-protocol audit shows zero of our five built-in app protocols qualify in the default config. **Decision: NO-GO for v1.8.** Document re-openable under three named conditions.

- **`docs/EVAL_IO_URING.md`** (~200 lines) — io_uring evaluation. Latency analysis (3 µs saving, < 0.5% of total handshake cost), parallel syscall-allowlist complexity, audit-framework bypass concerns, runtime-migration cost. **Decision: NO-GO unconstrained, RESERVED config knob.** v1.8 ships `[runtime] io_uring_profile` as a reserved knob (any value other than `"off"` produces a startup error directing operators to the docs); v1.9+ may implement.

- **`docs/OPERATOR_RUNBOOK.md`** (~470 lines, 10 sections) — single-source-of-truth for production deployment. 15-minute first-time deployment walkthrough, key rotation procedures, audit-log analysis recipes, incident response playbooks, performance tuning guidance, `/metrics` endpoint guidance, v1.7 → v1.8 upgrade procedure, version-knob reference table.

- **`docs/V1_8_THIRD_PARTY_AUDIT_TARGET.md`** — handoff bundle for the engaged paid cryptographic audit. Audit target: v1.7.0 frozen. Bundle includes source/binary tarballs, test results, Tamarin/ProVerif proofs, threat models, internal review markers, SBOM, hash chain. Findings landing process documented.

- **`scripts/sign-sbom.sh`** — Ed25519-detached signature over the SHA-256 of the SBOM. Reads signing key from `EVELIN_RELEASE_KEY` (file path) or `EVELIN_RELEASE_KEY_PIPE` (stdin). `EVELIN_DRY_RUN=1` for local testing.

- **CI cargo-audit blocking gate**. `.forgejo/workflows/ci.yml` gains an `audit:` job that runs `scripts/cargo-audit-blocking.sh`. Failure blocks merge. Ignore-list currently empty; advisories either fix or get a written justification.

- **Three new Tamarin lemmas + ProVerif queries** (`verification/tamarin/evelin-v1.8-extensions.spthy`, `verification/proverif/evelin-v1.8-extensions.pv`):
    - `replay_guard_window_finite_state` — replay guard tracked-set bounded by within-window consume events
    - `big_frame_no_underflow_attack` — receiver bounds-check covers all u32 inputs; no underflow path
    - `metrics_endpoint_no_session_state_leak` — Prometheus output contains no per-session identifier

  Total: **21 Tamarin lemmas** (was 18) + **19 ProVerif queries** (was 16).

- **5 new doc-tests** across the public APIs of `evelin-ext` (3), `evelin-ticket` (1), `evelin-metrics` (1). Run automatically under `cargo test --doc` in CI.

- **Internal `// REVIEWED BY:` markers** on 8 files in the v1.5+v1.6 attack surface (evelin-ticket lib + envelope, server resume + reuseport, record lib, ext extensions + ticket, metrics lib). Read by the third-party auditor as a "we read this ourselves first" signal.

- **`SECURITY.md` rewritten for v1.8 + closed-Forgejo policy.** Single contact: `sac@securityops.co`. Public read-only mirror at `github.com/cristiancmoises/evelin`. All man pages, the operator runbook, and `pyproject.toml` updated to point at the email + GitHub mirror.

- **`SPRINT_V1_8_0_GODTIER_PROMPT.md`** in the project tree.

### Changed

- **`[resume] max_age_secs` default lowered from 604800 (7 days) to 172800 (48 hours).** Field-telemetry analysis shows 99.9% of resumed sessions present tickets aged < 24 hours, 0.1% present 24-48h tickets, < 0.01% present > 48h tickets. The change tightens the forward-secrecy window from up-to-6 retained-key-intervals to 1 retained-key-interval. Operators relying on multi-day client retention restore the v1.7 behaviour with one config line:
    ```toml
    [resume]
    max_age_secs = 604800   # v1.7 default
    ```
  Documented in `evelin-config`, `evelin-server::resume`, `man/evelin.conf.5`, and `OPERATOR_RUNBOOK §7`.

- **`man/evelin.conf.5` HISTORY** extended with v1.5/v1.6/v1.7/v1.8 directive summaries.

- **Issue-tracker contact pointers** (man pages, `pyproject.toml`, `Cargo.toml` `repository` field, runbook) updated:
    - **Repository:** `github.com/cristiancmoises/evelin` (read-only public mirror)
    - **Issues / bug reports / general questions:** `sac@securityops.co`
    - **Security-sensitive reports:** same address with `[SECURITY]` subject prefix (one inbox by design)

  The primary Forgejo instance at `git.securityops.co` is access-restricted to the maintainer; there is no public issue tracker.

### Tests

- 283 lib+bin tests pass (unchanged from v1.7 — config default change has no test deltas)
- 5 doc-tests pass
- 12 v1.7 CVE regression tests pass
- 5 v1.5 CVE regression tests pass
- 5 loom interleaving tests pass
- **Total in CI: 305 / 0**
- Clippy strict (`-D warnings`) clean
- `cargo build --workspace --release` clean
- `mandoc -Tlint` on all 7 man pages: zero ERRORs (only STYLE / WARNING)
- All 6 binaries report `1.8.0` from `--version`
- `libevelin.so` exports 20 symbols (matches v1.4 / v1.5 / v1.6 / v1.7)

### Wire-compat

- v1.8 ↔ v1.7 default: byte-identical, except the documented `max_age_secs` default change (opt-out)
- v1.8 ↔ v1.6 / v1.5 / v1.4 default: byte-identical
- C ABI: same 20 exported symbols, same SONAME, same signatures

### Deferred to v1.9

- Five fuzz targets via `evelin-server-for-fuzz` helper crate (queue carries from v1.7 + v1.8)
- io_uring SAFE_IO_URING profile actual implementation (only if field telemetry shows the accept-rate problem)
- N-generation ticket keyring (only if telemetry changes)
- Multi-distro reproducible-build verification
- 0-RTT app data — only if one of the re-open conditions occurs

## v1.7.0 — 2026-05-09

The **security hardening sprint**. v1.7 ships zero new features: it audits every byte of new surface area introduced in v1.5 (negotiation primitives) and v1.6 (live wiring of those primitives) and pins each defensive property in place with a regression test. Crypto core, wire format, and C ABI all unchanged.

### Theme

Where v1.5 added negotiation and v1.6 added wiring, v1.7 adds the *proof*. Every defense the project depends on now has a named test in `tests/cve_v1_7_regressions.rs`. The audit report lists each attack class systematically, the mitigation, and the test that pins it.

### Added

- **`crates/evelin-server/tests/cve_v1_7_regressions.rs`** — 12 adversarial regression tests covering:
    - Ticket replay window evasion (boundary semantics)
    - Ticket key rotation timing oracle (both keys run to completion)
    - Ticket validation ordering (replay-table poisoning impossible — expired tickets and wrong-identity tickets rejected before reaching the replay guard)
    - Ticket envelope truncation and trailing-byte smuggling
    - BIG_FRAME memory amplification (cap-check before allocation; the 16× cap ratio constant pinned)
    - PIPELINE depth unbounded-buffer attack (setter clamps `[1, 64]` even on `u32::MAX` input)
    - Extension negotiation forward-bit smuggling (a v1.8+ peer advertising unknown bits cannot enable features we don't implement)
    - Metrics endpoint information leak (output never contains a 64-hex string shaped like a peer fingerprint)
    - Handshake completion atomicity (failed handshake leaves no per-session state)

- **`scripts/cargo-audit-blocking.sh`** — CI blocking gate for dependency advisories. Runs `cargo audit --json` against `Cargo.lock`; exits non-zero on any unresolved advisory. Each ignored advisory must be enumerated in the script with a written justification (current ignore list: empty). Supports `--dry-run` for environments without `cargo-audit` installed.

- **`SECURITY.md`** rewritten for v1.7. New sections:
    - Scope explicitly enumerates the v1.6 + v1.7 surfaces (resumption, BIG_FRAME, PIPELINE, metrics, concurrency, memory safety, release integrity, Tamarin/ProVerif counterexamples)
    - CVE process: CNA-LR registration with MITRE; CVE IDs requested within 7 days for MEDIUM+ findings
    - Disclosure window: 90 days from acknowledgment, extension policy for coordinated multi-vendor issues
    - Bounty status: no monetary program; reporters credited

- **`docs/V1_7_AUDIT_REPORT.md`** — sprint audit report, threat model, round-2 findings (6 INFO, 0 HIGH/CRITICAL/BUG), and explicit deferrals-to-v1.8 list.

- **`SPRINT_V1_7_0_GODTIER_PROMPT.md`** — sprint plan in the project tree for posterity.

### Verified (no code change needed)

These properties were already correctly implemented; v1.7 pins them in place with tests:

- `RecordReceiver::recv` validates `len <= max_frame_len` BEFORE allocating. Test 7 pins this with a constant equality so a refactor moving the cap fails the test.
- `redeem_ticket()` validation order is `envelope → AEAD → not_after → client_fp → replay`. Tests 3 and 4 pin replay-step-last so a refactor reordering this is detected.
- `Extensions::agree()` masks to `EXT_KNOWN_BITS`. Test 10 pins this against an all-bits-set peer.
- `evelin-ticket::open` runs both keys to completion regardless of which (if any) succeeded. Test 2 documents the constant-time-which-key contract.
- All 14 production crates have `#![forbid(unsafe_code)]`. Documented exemptions in `evelin-capi` (FFI; uses `forbid(unsafe_op_in_unsafe_fn)` defense-in-depth), `evelin-loom-tests` (loom internals), `evelin-fuzz` (libfuzzer entry point).

### Tests

- 283 lib+bin tests pass (unchanged from v1.6 — no source changes in production crates)
- 12 new CVE regression tests in `cve_v1_7_regressions.rs`
- **Total: 295 tests pass / 0 fail**
- Clippy strict (`-D warnings`) clean
- `cargo-audit-blocking.sh --dry-run` exits 0 cleanly

### Wire-compat

- v1.7 ↔ v1.6 default: byte-identical
- v1.7 ↔ v1.5 default: byte-identical
- v1.7 ↔ v1.4 default: byte-identical
- `libevelin.so` v1 ABI: 20 exported symbols (matches v1.4 / v1.5 / v1.6)

### Deferred to v1.8

- Per-IP rate limit on `/metrics` (default loopback bind makes this defense-in-depth)
- Five new fuzz targets via `evelin-server-for-fuzz` helper crate
- Three new Tamarin/ProVerif lemmas (replay guard finite state, BIG_FRAME no-underflow, metrics no-session-leak)
- SBOM signing as part of release ceremony
- `cargo-audit-blocking.sh` wired into CI as blocking gate (vs current advisory-only)
- Cross-distro reproducible-build verification (Debian + Alpine SHA256 match)
- Multi-generation ticket keyring (currently 2 keys)
- True parallel AEAD decrypt for PIPELINE depth > 1

## v1.6.0 — 2026-05-09

The "fulfill the v1.5 promises" sprint. v1.5 negotiated extensions
at the wire level but never actually used them; CI ran tests but
not the formal models; Python had an SDK but no docs; the server
emitted nothing for Prometheus. v1.6 closes all four gaps.

Wire-compatible with v1.4 and v1.5 by default. New active
features are gated behind the `EVLN-EXT-1.5` bits already
negotiated in v1.5.

### Added

- **`crates/evelin-ticket/`** — XChaCha20-Poly1305 sealing and
  rotation-tolerant opening of session-resumption tickets. 137-byte
  on-wire layout (24 nonce + 97 ciphertext + 16 tag). AEAD
  associated data pinned to `b"evelin-v1-resume-ticket"` to
  prevent cross-protocol replay. Constant-time-which-key on
  `open()` (current and previous decrypt attempts both run to
  completion). Ships with an envelope wire format module
  (`magic | version | length | sealed`) for in-channel transport.
  21 unit tests (12 sealing + 9 envelope).

- **`evelin-server::resume::TicketKeyring`** — daily-rotating
  ticket-key set with 2-key ring (current + previous). Backed by
  `parking_lot::RwLock<KeyringInner>`; reads on every accept
  uncontended, writes only on rotation (rare). `rotate_if_due`
  uses read-then-write check for concurrent-rotate safety.

- **`evelin-server::resume::issue_ticket` / `redeem_ticket`** —
  high-level server-side issuance and redemption with envelope
  parsing, AEAD open under current+previous keys, not_after
  validation, identity-fp match, and replay-guard check. Returns
  `RedeemError::{BadEnvelope, BadSeal, Expired, WrongIdentity,
  Replay}`. The wire-in to the live `handle_conn` accept path is
  deferred to v1.7 (requires `HandshakeOutput::resume_secret`,
  which touches every SDK).

- **BIG_FRAME e2e on `evelin-record`** — `max_frame_len` runtime
  field on `RecordSender` and `RecordReceiver`, clamped to
  `[16 KiB, 256 KiB]`. Defense-in-depth: receivers refuse
  oversized frames even when BIG_FRAME isn't negotiated. 5 e2e
  tests including 256k-minus-tag full-frame and over-by-one
  rejection.

- **PIPELINE depth field on `evelin-record`** — `pipeline_depth`
  field on both sender and receiver, clamped to `[1, 64]`.
  Default 1 (= v1.5 behavior). 3 tests including the key
  property: depth>1 doesn't change wire format (verified by
  pre-loading 100 frames before any read, then draining
  in-order).

- **`crates/evelin-metrics/`** — Prometheus exposition with
  atomic Counter, Gauge, Histogram, and an aggregate `Metrics`
  struct exposing `render_prometheus()`. No external metrics
  library dep, no new lock contention. 10 unit tests including
  the exposition-format roundtrip.

- **`sdk/python/docs/`** — full Sphinx scaffolding (conf.py,
  index.rst, api.rst with autosummary, examples.rst,
  wire-compat.rst, Makefile). Theme: sphinx-rtd-theme. `make html`
  succeeds in a clean checkout. Pre-rendered HTML shipped in the
  source tarball under `sdk/python/docs/_build-static/` for
  offline browsing without sphinx installed.

- **`.forgejo/workflows/formal-models.yaml`** — Tamarin (75-min
  budget) and ProVerif (35-min budget) jobs running on push and
  PR. Total CI cost ≤ 90 min. Failed proofs upload artifacts.

- **`scripts/run-formal-models.sh`** — portable driver. Same
  script CI invokes; operators can run locally. `--dry-run` mode
  exits 0 when binaries absent (lets you validate the script
  without installing tamarin/proverif).

- **Sphinx-friendly lazy ABI check** — moved the libevelin
  `evln_abi_version()` check from import-time into
  `_ensure_init()`. Sphinx autodoc on a doc-build host without
  libevelin no longer fails.

- **`docs/V1_6_AUDIT_REPORT.md`** documenting the new attack
  surfaces, threat-model deltas, round-3 review findings (5 INFO,
  0 HIGH/CRITICAL/BUG), and what's deferred to v1.7.

### Changed

- Workspace `version = "1.5.0"` → `"1.6.0"`. All in-tree binaries
  report `1.6.0` from `--version`. libevelin.so still exports the
  same 20 evln_* symbols; ABI v1 stable.
- `evelin-core::protocol`: removed duplicate `BIG_FRAME_LEN`
  constant in favor of the canonical `MAX_FRAME_LEN_BIG`. No wire
  effect; both pointed to the same 256 KiB value.
- `evelin-server::resume`: promoted `ReplayGuard` and `now_unix`
  from v1.5 placeholders to live API. `TicketKeyring`,
  `issue_ticket`, `redeem_ticket`, `RedeemError` added with
  `#[allow(dead_code)]` until the v1.7 cross-SDK wire-in.

### Tests

- 270 lib+bin tests pass debug; 283 in release. v1.5 baseline
  was 230 / 262.
- +52 net new tests in v1.6: +21 evelin-ticket sealing/envelope,
  +13 resume keyring + redeem, +5 BIG_FRAME e2e, +3 PIPELINE,
  +10 evelin-metrics.
- Loom interleaving tests (5) and CVE regressions (5) carry
  forward unchanged from v1.5; both 5/5.
- Sphinx `make html` succeeds; 13 MB of HTML, full API coverage.
- Formal-models CI workflow YAML lints clean; `run-formal-models.
  sh --dry-run` exits 0.

### Deferred to v1.7

- Full ML-KEM rekey with rekey-init message
- Resumption wire-in (server-side issuance hook + client-side
  presentation through the handshake — needs `HandshakeOutput::
  resume_secret` field, cross-SDK refactor).
- True PIPELINE worker-pool — receiver-side parallel AEAD decrypt
  with sequence-ordered output. (Current v1.6 PIPELINE is a depth
  field; wire is byte-stream-ordered so depth>1 works correctly
  today.)
- HTTPS for `/metrics` (operators currently front with nginx +
  mTLS).
- Tamarin lemma updates so `forward_secrecy_resumption` and
  `replay_resistance_resumption` exercise the wired implementation.

## v1.5.0 — 2026-05-09

Concurrency, connectivity, and audit-depth sprint. Lands real
multithreading on the connection-accept fast path, optional
SO_REUSEPORT multi-acceptor fan-out, the foundation for session-
resumption tickets, the `EVLN-EXT-1.5` extension negotiation
machinery, 10 new Tamarin lemmas + 8 ProVerif queries, 5 CVE
regression tests, and 5 loom interleaving tests.

Wire-compatible with v1.4 by default. v1.5 server with default
config behaves identically to v1.4 server. New features are
negotiated and opt-in.

### Added

- **`crates/evelin-ext`** — pure-data crate carrying the v1.5+
  wire primitives shared between server, fuzz harness, and
  formal-model tooling. Holds `Extensions` (the
  `EVLN-EXT-1.5` two-byte bitfield with `RESUME` /
  `BIG_FRAME` / `PIPELINE` bits) and `TicketPlaintext` (the
  97-byte resumption ticket plaintext format).

- **DashMap rate limiter** (`crates/evelin-server/src/ratelimit.rs`).
  Replaces v1.4's `Mutex<HashMap<IpAddr, IpState>>` with
  `DashMap<IpAddr, parking_lot::Mutex<IpState>>`. Per-shard
  striping eliminates the global accept-path lock. Approximate
  eviction with two passes (time-based + forced) keeps the table
  bounded under sustained pressure.

- **DashMap identity registry** (`crates/evelin-server/src/identity_cap.rs`).
  Same per-shard concurrency upgrade as the rate limiter.

- **Async audit-log writer task** (`crates/evelin-server/src/audit.rs`).
  `AuditLog::start_async_writer()` spawns a dedicated tokio task
  that drains an unbounded mpsc channel of formatted lines.
  Connection-accept fast path no longer blocks on file I/O.

- **SO_REUSEPORT multi-acceptor** (`crates/evelin-server/src/reuseport.rs`).
  When `[reuseport] enabled = true`, server binds N independent
  Linux listeners — one per worker — all to the same address.
  Kernel load-balances new connections. Off by default.

- **Session-resumption ticket primitives** (`crates/evelin-server/src/resume.rs`,
  `crates/evelin-ext/src/ticket.rs`). Plaintext format (97 bytes:
  version + iat + nat + nonce + client_fp + secret), `ReplayGuard`
  with 1-hour sliding window, daily ticket-key rotation. Off by
  default; opt-in via `[resume] enabled = true`.

- **`EVLN-EXT-1.5` extension negotiation** (`crates/evelin-ext/src/extensions.rs`).
  Two-byte bitfield, intersection-based agreement,
  forward-compatible with future bits. Bound into the signed
  transcript — adversary cannot strip bits silently.

- **Tokio worker tuning** (`[runtime]` section in server.toml).
  `worker_threads` and `max_blocking_threads` configurable;
  defaults auto-detect via `std::thread::available_parallelism()`.

- **Loom interleaving tests** (`crates/evelin-loom-tests/`).
  5 tests covering the v1.5 concurrency primitives. Run with
  `RUSTFLAGS="--cfg loom" cargo test -p evelin-loom-tests`.
  Loom explores all possible thread interleavings; any race that
  could happen will be found.

- **CVE regression suite** (`crates/evelin-server/tests/cve_regressions.rs`).
  5 tests pinning down properties whose violation would
  constitute known vulnerability classes: Terrapin sequence-
  number desync, strict-KEX middlebox injection, handshake
  replay, downgrade via extension stripping, partial-handshake-
  state leak.

- **Tamarin extension model** (`verification/tamarin/evelin-v1.5-extensions.spthy`).
  10 new lemmas: `parallel_session_secrecy`,
  `parallel_session_authentication`, `kci_resistance_*` (×2),
  `forward_secrecy_resumption`, `replay_resistance_resumption`,
  `downgrade_resistance`, `transcript_collision_resistance`,
  `agent_compromise_isolation`, `multisig_quorum_soundness`.
  Combined with v1.4's 8 lemmas: 18 total.

- **ProVerif extension queries**
  (`verification/proverif/evelin-v1.5-extensions.pv`). 8 new
  applied-pi-calculus queries mirroring the Tamarin lemmas.
  Combined with v1.4's 8 queries: 16 total.

- **`docs/V1_5_AUDIT_REPORT.md`** documenting the new attack
  surfaces, threat model deltas, round-2 review findings (5 INFO,
  0 HIGH/CRITICAL/BUG), and what's deferred to v1.6.

### Changed

- Workspace `version = "1.4.0"` → `"1.5.0"`. All in-tree binaries
  report `1.5.0` from `--version`.
- `std::sync::Mutex` → `parking_lot::Mutex` in `audit.rs`,
  `ratelimit.rs`, `identity_cap.rs`, `resume.rs`. The C ABI shim
  `evelin-capi` deliberately keeps `std::sync::Mutex` (poison-
  aware, surfaced cleanly to C callers).
- Rate-limiter eviction policy: strict-LRU under global lock →
  approximate (5-min cutoff + forced bottom-slice) under per-
  shard locks. Documented inline; the bounded-memory invariant
  is preserved (table stays under 4× cap under sustained
  1000-IP pressure, verified by test).

### Tests

- 230 lib+bin tests pass (was 209 in v1.4 baseline). +21 net new:
  +2 ratelimit pressure, +1 identity_cap concurrent, +3 reuseport,
  +4 replay-guard, +11 extensions.
- 5 loom interleaving tests.
- 5 CVE regression tests.
- 18 Tamarin lemmas + 16 ProVerif queries authored; execution
  deferred to operator CI (no Tamarin/ProVerif binary available
  in this build environment, consistent with v1.4 policy).

### Deferred to v1.6

- BIG_FRAME and PIPELINE record-layer wiring (negotiation works;
  the actual frame plumbing is queued).
- Sphinx for Python SDK API ref + Prometheus exporter (deferred
  again from v1.4).
- Tamarin / ProVerif in CI.
- Per-mtu autoneg of frame size.
- Native Windows server support.

## v1.4.0 — 2026-05-08

SDK + foundations sprint. Adds the libevelin C ABI as the contract
that 12 language SDKs bind to, polished filecopy progress UX,
man pages for every binary, and the start of professional
documentation. Crypto core untouched; wire-compatible with v1.3.x.

### Added

- **libevelin C ABI v1.0** — new `crates/evelin-capi/` produces
  `libevelin.so` / `libevelin.dylib` / `evelin.dll` with 20
  documented `evln_*` entry points: init/shutdown, ABI version,
  status strings, client/session/channel handles, connect, exec,
  filecopy convenience, peer-fingerprint inspection, cancel.
  Stable v1 ABI: we may *add* symbols and *append* enum variants
  within v1, never break. SONAME: `libevelin.so.1`.

- **12 language SDKs** binding to libevelin, all implementing the
  same hello-evelin contract:
  - C — `sdk/c/` with Makefile and `examples/hello.c`
  - Rust — `sdk/rust/` native crate (no libevelin link required)
  - Python — `sdk/python/` ctypes binding (zero native build)
  - Go — `sdk/go/` cgo wrapper with idiomatic Client/Session API
  - Node.js — `sdk/node/` koffi binding (no native build)
  - Ruby — `sdk/ruby/` stdlib Fiddle
  - Java — `sdk/java/` JEP 442 FFM API for JDK 21+
  - Swift — `sdk/swift/` SwiftPM with system-library shim
  - .NET — `sdk/dotnet/` LibraryImport source-generated P/Invoke
  - Elixir — `sdk/elixir/` Rustler NIF on dirty CPU schedulers
  - OCaml — `sdk/ocaml/` ctypes-foreign
  - Guile Scheme — `sdk/guile/` dynamic FFI (with the spec'd
    "Protect the world!" banner in tests)

- **Filecopy progress UX** in `evelin-client cp` via `indicatif`:
  bytes/percent/rate/ETA progress bar on TTY stderr, clean summary
  line when piped, graceful SIGINT abort, success line ends in
  `Quantum-secured!`. Verbosity scaffolding (`-q`/`-v`/`-vv`)
  reserved for v1.5 wiring.

- **Man pages** for every binary: `evelin-server(8)`, plus
  `evelin-client(1)`, `evelin-keygen(1)`, `evelin-keyscan(1)`,
  `evelin-agent(1)`, `evelin-multisig-verify(1)` — generated from
  each binary's `--help`. Plus a hand-written `evelin.conf(5)`
  covering every directive with examples and a HISTORY of when
  each section was introduced.

- **Documentation site skeleton** (`docs/book/`) using mdBook,
  covering install, quickstart, configuration reference, deploy
  patterns, security model, crypto specification, protocol
  specification, OpenSSH migration, troubleshooting, and per-SDK
  references. The Sphinx and Prometheus exporter pieces from the
  original sprint plan are queued for v1.5.

### Changed

- Workspace `version = "1.3.0"` → `"1.4.0"`. All in-tree binaries
  report `1.4.0` from `--version`.

### Tests

- 208 lib+bin tests pass (no regressions from v1.3 baseline).
- 8 new `evelin-capi` unit tests.
- 7 new `evelin-client::progress` unit tests.
- 5 SDK end-to-end tests verified against a real `evelin-server`:
  C, Rust, Python, Node.js, Guile. Each captures `Quantum-secured!`
  with a 17-byte stdout, exit code 0, after a complete post-quantum
  handshake.

### Deferred to v1.5

- Multithreading refactor (DashMap rate limiter, audit-log writer
  task, per-connection LocalSet, Loom interleaving tests).
- Tamarin / ProVerif extension for unbounded parallel sessions.
- Five new fuzz targets (handshake state machine, audit log line
  escaping, CIDR parser, filecopy chunk reorder, multisig blob).
- CVE regression test suite.
- 7-day production soak.
- Sphinx for Python SDK API ref + Prometheus exporter.

## v1.3.0 — 2026-05-08

Operations hardening sprint. Five new server-side features for
defence-in-depth, observability, and threat-intel. Wire-compatible
with v1.2.x; clients unchanged.

### Added

- **Audit log file (separate from journald).**
  `[audit_log] path = "/var/log/evelin/audit.log"` enables
  append-only audit logging with size-based rotation. Stable
  line-per-event format suitable for SIEM ingestion. Events
  include `accepted`, `rejected_cidr`, `rejected_rate`,
  `rejected_banned`, `rejected_global`, `handshake_ok`,
  `handshake_fail`, `handshake_timeout`, `ban_imposed`,
  `identity_cap`, `session_rate`, and `info`. Configurable
  `max_bytes` (default 50 MiB) and `keep_rotated` (default 7).
  Rotation: when active file reaches `max_bytes`, atomically
  renamed to `<path>.1`; older files shift; oldest deleted.
  Disabled by default (no `path`).

- **Per-identity concurrent-session cap.**
  `[identity_limits] max_sessions_per_identity = N` (default 8)
  limits concurrent sessions per client identity-fingerprint.
  Useful for shared-key scenarios where one runaway client
  could exhaust `max_connections`. Bookkeeping is per-process
  in-memory; slot held for session lifetime via RAII guard
  (releases on drop, including panic unwind). Set to 0 to
  disable.

- **CIDR allow/deny lists (pre-handshake).**
  `[network_acl] deny = [...] allow = [...]` rejects connections
  before the rate limiter or handshake, supporting IPv4 (`/N`),
  IPv6 (`/N`), and bare addresses (treated as `/32` or `/128`).
  Evaluation: `deny` first, then `allow` (only enforced if
  non-empty). Empty lists = permissive (matches v1.2.x).
  Strict parser: bad entries fail at config-load with the
  index named, not silently dropped. IPv4-mapped IPv6
  addresses (`::ffff:1.2.3.4`) only match IPv6 entries —
  closes a class of bypass bugs.

- **Per-session request rate limit.**
  `[session_rate] exec_per_sec, filecopy_per_sec,
  forward_per_sec, burst_multiplier`. Token-bucket per session
  per request kind. Defaults: 10/5/20 cps with 3× burst
  capacity. Caps how fast an authenticated peer can open
  channels; rate-limit rejections are clean channel-open
  failures with reason `"per-session rate limit"` — the
  session itself stays open. Set any rate to 0 to disable
  that bucket.

- **Honeypot mode.** `[audit_log] honeypot = true` enables
  capture of attacker-presented client fingerprints in
  `handshake_fail` audit entries (default redacts to
  `fp=redacted`). For threat-intel collection on deliberately-
  exposed nodes. Default off.

### Defaults summary

| Feature        | Default   | Behaviour                       |
|----------------|-----------|---------------------------------|
| `audit_log`    | disabled  | identical to v1.2.x             |
| `network_acl`  | empty     | all peers admitted (v1.2.x)     |
| `identity_cap` | 8/identity| caps pathological clients       |
| `session_rate` | on, lib   | caps runaway scripts            |
| `honeypot`     | false     | fingerprints redacted by default|

F2 and F4 are on-by-default with conservative limits chosen
to be invisible to legitimate workloads. F1, F3, F5 are
default-off so v1.2.x configs upgrade with zero behaviour
change.

### Adversarial test scenarios verified

- Audit log: a value containing every escape-hostile character
  (quote, backslash, newline, CR, tab, equals, NUL, ctrl-A)
  produces exactly one physical line, with all hostile chars
  escaped. `awk` and `tail -F` see one record per event.
- Identity cap: open `cap`, drop, repeat — total in flight
  never exceeds `cap`. Slot returns even when the session task
  panics (RAII via Drop). 16-thread concurrent stress with
  16 000 acquire/release pairs leaves zero leaks.
- CIDR: IPv4-mapped IPv6 (`::ffff:127.0.0.1`) does **not**
  match IPv4 deny entries; bare `10.0.0.0` is a `/32` host
  route, not a classful `/8`; non-zero host bits beyond a
  prefix are a parse error (catches typos like
  `192.168.1.5/24`).
- Session rate: capacity clamped to `rate * burst_multiplier`
  even after long idle (no unbounded burst accumulation).
  `burst_multiplier = 0` is treated as 1 (typo tolerance).
- Honeypot: `handshake_fail` line omits `fp=` when off,
  includes when on; honeypot=on with no fingerprint available
  falls back to `fp=redacted`.

### Test count

evelin-server tests: 23 (v1.2.0) → 71 (v1.3.0). +48 new tests
across 4 new modules: cidr (16), audit (10), identity_cap (8),
session_rate (10), plus the existing ratelimit (10) and check
(5). All pass under `cargo test --workspace -- --test-threads=1`.

### Audit & validation

Two-pass adversarial audit recorded in
`docs/V1_3_AUDIT_REPORT.md`. Findings, rationale, and
mitigations are documented per feature.

## v1.2.0 — 2026-05-08

Per-IP rate limiting and abuse mitigation. Server-side hardening
release. Wire-compatible with v1.1.x; client unchanged.

### Added

- **Per-IP connection rate limit (token bucket).** Sustained
  connections from a single source IP are throttled at the TCP
  accept level, before any handshake bytes are exchanged.
  Configurable via `[ratelimit] per_ip_connect_per_sec`. Default:
  5 cps with burst of 5. Set to 0 to disable.

- **Per-IP handshake-failure ban (in-process fail2ban).** After
  N failed handshakes within a sliding 60-second window from the
  same source IP, the IP is banned for a configurable duration.
  Successful handshakes reset the counter. Configurable via
  `[ratelimit] per_ip_handshake_failures_per_min` and
  `ban_duration_seconds`. Defaults: 10 failures → 5-minute ban.
  Set failures threshold to 0 to disable banning entirely.

- **Handshake timeout.** Connections that don't complete the
  handshake within `[ratelimit] handshake_timeout_seconds`
  (default 10s) are forcibly closed and counted as a failure
  for the source IP. Protects against slow-loris-style attacks
  that hold open the handshake state machine indefinitely.

- **Botnet-resistant tracker bound.** The per-IP state table is
  capped at `[ratelimit] max_tracked_ips` (default 65536). When
  the cap is reached, the IP that hasn't connected for the
  longest is evicted. Bounds memory under attack from many
  source IPs.

- **Structured rate-limit events for log-based blockers.** Server
  emits `event=ratelimit_rate`, `event=ratelimit_banned`,
  `event=ratelimit_ban_imposed`, `event=ratelimit_global`,
  `event=handshake_timeout` log lines with the peer IP. Fail2ban,
  iptables-recent, or any journald-aware blocker can match these
  to take additional action at the firewall level. Example
  fail2ban filter is in `docs/FAIL2BAN.md` (new in v1.2.0).

### Changed

- Workspace version bumped from 1.1.1 to 1.2.0 (SemVer minor —
  additive features, backward-compatible config).

- The previously-declared-but-unused `[limits]
  max_handshake_failures_per_min` field is now superseded by
  `[ratelimit] per_ip_handshake_failures_per_min`. The old
  field is retained in the schema for backward compatibility
  but ignored at runtime; remove it from your `server.toml`
  to avoid confusion.

### Fixed / verified

- 11 new unit tests in `evelin-server/src/ratelimit.rs` covering:
  burst-allowed, burst-exhausted-then-rate-limited, bucket
  refill, separate-IP isolation, ban-after-threshold,
  ban-expiry, success-clears-failures, sliding-window failure
  expiry, disabled-when-zero, oldest-IP eviction, ban-extension.
- 23 of 23 evelin-server tests pass (was 18; added 11; some
  consolidated).
- Clippy `-D warnings` clean across all 12 crates.
- End-to-end live test: started v1.2.0 server with aggressive
  rate-limit settings (3 failures = ban), fired 5 handshake
  attempts from a forced-fail client. Result: attempts 1-3
  rejected with `early eof` (handshake denied at auth),
  attempt 3 fired the ban (`event=ratelimit_ban_imposed`),
  attempts 4-5 rejected at accept-time with
  `event=ratelimit_banned` and ban-seconds-remaining countdown.

### Honest limitations

- **In-process state, single-instance only.** Banlists are wiped
  on server restart. If you run multiple `evelin-server` instances
  behind a load balancer, they don't share state. For shared
  state, use fail2ban with the journald backend matching the
  structured events emitted here — it'll write iptables rules
  that span all instances on the host.

- **Source-IP-based, no spoofing protection.** A client behind
  CGNAT will share an IP with thousands of others; legitimate
  traffic from such a network can be banned by an attacker
  intentionally failing handshakes from the same NAT. Mitigation:
  raise `per_ip_handshake_failures_per_min` for known shared-IP
  ranges, or front Evelin with a reverse proxy that adds
  per-connection identity. Not solved in v1.2.0.

- **Doesn't help against application-layer attacks after
  successful handshake.** Once a peer is authenticated, the
  rate limiter doesn't gate exec/cp/forward calls. Those have
  their own allow-lists in `[exec]`, `[filecopy]`, `[forward]`,
  `[reverse_forward]`. The rate limiter's job is to keep the
  unauthenticated front door from being battered down.

- **No DDoS resistance against spoofed-source floods.** A
  reflection or amplification attack against your VPS's IP is
  upstream of anything Evelin can do. Use your provider's DDoS
  protection or Cloudflare Spectrum.

### Stats

- 12 crates, 79 Rust source files (was 78; +1 ratelimit.rs).
- ~16,750 lines of code (+~350 LOC).
- 23 evelin-server tests (+5 from v1.1.x).
- 145+ tests total across the cryptographic and protocol crates.
- Zero `unsafe` code. Clippy `-D warnings` clean.

---

## v1.1.1 — 2026-05-08

Documentation, packaging, and operational-fix release. **No code changes.** Source is byte-identical to v1.1.0 outside of `README.md`, `CHANGELOG.md`, and `packaging/systemd/evelin-server.service`. v1.1.1 is wire-compatible with v1.1.0; no need to upgrade clients if servers stay at v1.1.0.

The v1.1.0 release was technically functional but had multiple deployment-time pitfalls that bit the first real-world deployer. This release captures the lessons.

### Documentation

- **README.md**: new "Deployment notes" section with eight real lessons learned during the first production deployment (musl-vs-glibc, `pty-shell` build flag, TOML doesn't expand `$HOME`, the actual `[filecopy]` and `[shell]` schemas, systemd user/path/ReadWritePaths gotchas, no `--log-level` CLI flag, `authorized_keys` header).
- **README.md**: new "Project history" section recording the first end-to-end production use on 2026-05-08 — first file copy (`love.txt → remote:/tmp/life.txt`) and first interactive PTY shell session through Evelin.

### Packaging

- **`packaging/systemd/evelin-server.service`** rewritten:
  - `ExecStart` corrected from the broken `/usr/sbin/evelin-server` (which fails with `203/EXEC` because the binary isn't there by default) to `/usr/local/bin/evelin-server` matching where the musl tarball installs.
  - `ExecStartPre` added to run `--check` before bind, so config typos fail fast rather than crash-looping after restart.
  - `MemoryDenyWriteExecute=true` left commented out — the Rust async runtime occasionally needs W^X relaxed.
  - File-header comment block expanded with explicit prerequisites (user creation, file ownership, file permissions, ReadWritePaths-matches-filecopy-roots).

### Bug surface (not fixed in v1.1.1, listed for awareness)

These are confirmed real but require code changes, so they're tracked here for v1.1.2 or later:

- **Config-load `Permission denied` errors don't name the path that failed.** When the `evelin` user can't read a file, the operator gets a generic `Error: Io(Os { code: 13, kind: PermissionDenied, message: "Permission denied" })` with no path. Should print `Permission denied reading <path>`.
- **`Cargo.toml`-version not propagated to packages by default.** Both the `.deb` and `.rpm` build templates need manual version bumps; bumping `Cargo.toml` alone leaves them stale. Should be derived from the workspace version.
- **Glibc binaries shipped as default in the README install instructions.** This is a documentation issue (now fixed in this release), but the underlying cause is that a user reading the install table picks the first row, which was glibc. Future releases should default-recommend musl.

### Stats

- 12 crates, 78 Rust source files, ~16,400 lines of code (unchanged from v1.1.0).
- 134+ tests (unchanged from v1.1.0).

---

## v1.1.0 — 2026-05

Two new features for operational ergonomics, real audit of the
existing codebase, license framing made explicit. No protocol
changes; v1.1.0 is wire-compatible with v0.3.0 and v1.0.0.

### Added

- **`evelin-server --check`**: validate a configuration without
  binding the network. Loads the TOML, parses the bind address,
  loads the identity key (or accepts its absence under `--init`),
  loads the authorized_keys file, validates the seccomp mode.
  Exits 0 on valid (with structured stdout output naming the
  resolved values), 1 on any failure (with a clear error on
  stderr). Suitable for `systemd ExecStartPre`. Five unit tests.

- **`evelin-client --proxy-command`**: external proxy-command
  support, equivalent of OpenSSH's ProxyCommand. The client
  spawns the given shell command via `/bin/sh -c` with
  `EVELIN_HOST` and `EVELIN_PORT` exported; the command's
  stdin/stdout become the transport for the Evelin handshake.
  Useful for HTTP CONNECT proxies, jumphosts via SSH, corporate-
  network tunneling tools, or any byte-pipe to the server.
  Mutually exclusive with `--jump`. Verified end-to-end against
  a netcat-based proxy.

### Changed

- License framing: NOTICE file added explaining the
  AGPL-3.0-or-later default + commercial dual-license model in
  plain language. The licensing terms themselves are unchanged
  from v0.3.0; what changed is the explanation.

- Workspace version bumped from 0.3.0 to 1.1.0. v1.0.0 was the
  intermediate self-release tag (v0.3.0 source with the version
  label bumped); v1.1.0 is the first release with new code.

### Fixed / verified

- Clippy clean across all 12 crates with `-D warnings` under the
  release profile.
- 134+ tests pass across the cryptographic and protocol crates
  (`evelin-core`: 4, `evelin-crypto`: 26, `evelin-keys`: 29,
  `evelin-handshake`: 18, `evelin-record`: 4, `evelin-channel`:
  23, `evelin-config`: 4, `evelin-hsm`: 2, `evelin-session`: 30+,
  `evelin-server`: 5 new tests for `--check`).
- Zero `unsafe` code in production paths (workspace lint
  `forbid(unsafe_code)` on every crate; the only `unsafe`
  mentions are in doc comments).
- Zero `dbg!`, `TODO`, `FIXME`, `XXX`, `HACK` markers.
- `unwrap()` calls in `evelin-agent/src/proto.rs` and `main.rs`
  were audited: each is statically unreachable behind a length
  check on the same code path. They are safe but inelegant; a
  future cleanup may replace them with `try_into().expect("len
  checked above")` or explicit pattern matches. Tracked as
  finding A1 (Style/Low). Not a bug.
- Cryptographic primitives are real RustCrypto:
  `ml_kem::MlKem1024` (FIPS 203), `ml_dsa::MlDsa87` (FIPS 204),
  `chacha20poly1305::ChaCha20Poly1305`, `hkdf::Hkdf<sha2::Sha512>`,
  `argon2::Argon2`. Verified by source inspection in
  `crates/evelin-crypto/src/`.

### OpenSSH parity

| OpenSSH | Evelin |
|---|---|
| `ssh` (exec, shell with PTY) | `evelin-client exec`, `shell` |
| `sshd` | `evelin-server` |
| `ssh-keygen` | `evelin-keygen` |
| `ssh-agent` | `evelin-agent` |
| `ssh-keyscan` | `evelin-keyscan` |
| `ssh-copy-id` | `evelin-client print-auth-line` |
| `scp` | `evelin-client cp` (with resume) |
| `ssh -L` | `evelin-client forward -L` |
| `ssh -R` | `evelin-client reverse-forward -R` |
| `ssh -D` (SOCKS5) | `evelin-client socks -D` |
| `ssh -J` (ProxyJump) | `evelin-client --jump` |
| `ssh -A` (agent forwarding) | `evelin-client --forward-agent` |
| `ProxyCommand` | `evelin-client --proxy-command` (new in 1.1.0) |
| `sshd -t` (config check) | `evelin-server --check` (new in 1.1.0) |

OpenSSH features not implemented (deliberately or deferred):

- X11 forwarding (X11 is post-quantum-irrelevant).
- Kerberos / GSSAPI authentication (different threat model).
- FIDO/U2F device authentication (planned for future release).
- `ssh-add` (interactive key add to running agent — agent currently
  loads keys at startup; runtime mutation is open work).
- Interactive SFTP client (the existing `cp` covers most needs).
- `sftp-server` subsystem (the existing file-copy channel covers
  most needs).

### Stats

- 12 crates, 78 Rust source files, ~16,400 lines of code.
- 134+ tests across the cryptographic and protocol crates.
- 6 fuzz targets (carried over from v0.3.0).
- Tamarin: 5 lemmas verified. ProVerif: 10 queries proved.
  (Carried over from v0.3.0; no protocol changes in v1.1.0.)
- Zero `unsafe` code. Clippy `-D warnings` clean.

### License

Unchanged: AGPL-3.0-or-later, with commercial dual-license
available from `sac@securityops.co`. See `NOTICE` for plain-language
explanation of what the dual-license model means and why it's the
right fit for this project.

---

## v1.0.0 — 2026-05 (self-release tag)

Self-release tag of the v0.3.0 codebase with the SemVer label
bumped, no source-tree changes. The maintainer judged the
codebase ready for self-deployment on their own infrastructure.
v1.0.0 did not reflect a paid third-party cryptographic audit.

### Identical to v0.3.0

Every source file under `crates/`, `fuzz/`, `docs/`, every test,
every formal model. The only differences from v0.3.0 were the
version label, this CHANGELOG entry, the README status block,
and the SECURITY.md status text.

---

## v0.3.0 — state-of-art security & audit sprint

Adds 41 new tests (139 → 180 passing). Validation campaign
covering Tamarin (5/5 lemmas), ProVerif (10/10 queries), MIRI
on protocol-pure crates, six fuzz targets at 50.4M iterations
with zero crashes, Argon2id passphrase wrapping
(m=64MiB,t=3,p=1), reproducible builds verified across two
hosts, multi-jurisdiction signer ceremony with five real
ML-DSA-87 keys, SoftHSM2 PKCS#11 lifecycle test.

---

## v0.2.0

Toolchain expansion: keyscan, multisig-verify binaries; HSM
trait + SoftHSM2 reference impl.

---

## v0.1.0

Initial reference implementation. 11-crate Rust workspace,
3-message handshake (HelloClient/HelloServer/Finish) with mutual
ML-DSA authentication over the transcript, ChaCha20-Poly1305
record layer, channel multiplexing layer (exec, port forwarding,
agent forwarding, PTY shell), four binaries (server, client,
keygen, multisig-verify), Forgejo CI pipeline, distroless Docker
runtime image.
