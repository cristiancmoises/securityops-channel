# Frequently asked questions

Answers reflect Evelin v4.4.0 (2026-09-06). Every answer below is grounded in a
file in this repository — the source is named at the end of each answer. Where
the honest answer is "no" or "not yet", that is what you will read.

## General

### What is Evelin?

A post-quantum secure tunnel written in Rust. The handshake uses ML-KEM-1024
(FIPS 203) for key encapsulation and ML-DSA-87 (FIPS 204) for signatures — both
NIST security category 5 — and the record layer is ChaCha20-Poly1305 with an
HKDF-SHA-512 KDF. The toolchain shape is deliberately borrowed from OpenSSH
(`evelin-server` ≈ `sshd`, `evelin-client` ≈ `ssh`, `evelin-keygen` ≈
`ssh-keygen`, `evelin-agent` ≈ `ssh-agent`), so operators don't need to relearn
anything. (Source: `README.md`.)

### Why not just use OpenSSH?

For most users, you should — the project's own comparison document says so.
OpenSSH is the right default for general-purpose remote access: ~30 years of
deployment, multiple interoperating implementations, an enormous tooling
ecosystem, and (since 10.0) hybrid post-quantum key exchange by default. Evelin
is for the narrower case where you specifically want post-quantum
*authentication* (not just PQ key exchange — OpenSSH ships no PQ signatures as
of 10.2), a memory-safe implementation, and a codebase small enough to actually
read — and you accept the maturity trade-offs of a young, single-implementation
transport with no completed external audit. (Source: `COMPARISON.md`.)

### Is Evelin wire-compatible with SSH?

No, and it never will be — that is a design decision, not a roadmap gap. Only
the user-facing toolchain shape is borrowed from OpenSSH; the wire protocol is
Evelin's own. (Source: `README.md`.)

### Why post-quantum now, when quantum computers can't break anything yet?

Because of "harvest now, decrypt later": an adversary who records your traffic
today can decrypt it years from now once a sufficiently large quantum computer
exists. Classical key exchange recorded today is retroactively breakable;
ML-KEM-1024 key agreement is not — a future quantum computer running Shor's
algorithm cannot recover session keys from a recorded transcript. If you record
traffic today and need it confidential ten or twenty years from now, classical
SSH defaults are not enough. That case is exactly what Evelin is for. (Sources:
`README.md`, `docs/THREAT-MODEL.md` §1.1 and §1.6.)

### Why pure post-quantum instead of a hybrid, like OpenSSH uses?

OpenSSH's hybrid KEX keeps an X25519 backstop: if ML-KEM falls to cryptanalysis,
sessions still rest on a classical hard problem. Evelin's pure ML-KEM-1024 has
no classical backstop. This is a deliberate design position (and at a higher
category than OpenSSH's ML-KEM-768), but the project's own comparison calls it
what it is: a real single-point-of-failure trade-off, not a strict win.
(Source: `COMPARISON.md`.)

## Protocol

### Why is the handshake ~17.6 KB — so much larger than SSH's?

The handshake is 3 messages totalling 17,662 bytes (1.5 RTT): HelloClient
4,200 B, HelloServer 8,827 B, Finish 4,635 B. The bulk is post-quantum key
material — an ML-DSA-87 signature alone is 4,627 bytes and a public key is
2,592 bytes. An OpenSSH 10.2 default handshake is on the order of 3–4 KB
(estimated from algorithm object sizes, not packet-captured), so Evelin's is
roughly 4–5× larger on the wire. That is the price of PQ signatures at
category 5; on any link where 17 KB matters (high-latency, constrained), SSH
wins this dimension outright. (Source: `COMPARISON.md`.)

### What are protocol v1 and v2?

v1 is the original wire protocol. v2, which reached GA in v4.0.0, adds opt-in,
transcript-bound, downgrade-resistant capability negotiation: the capability
block lives in the signed handshake body, so stripping, altering, or injecting
it — or rewriting the version — breaks the ML-DSA-87 signature and aborts the
handshake. v2 currently negotiates the record frame size (the record layer
clamps it into [16 KiB, 1 MiB]; v1 is fixed at 16 KiB); a `REKEY` capability is
negotiated but reserved for a future asymmetric ML-KEM rekey. v2 is strictly
opt-in: set `max_protocol_version = 2` on both ends. With the default (`1`, or
unset), deployments are byte-identical to v1 on the wire. Upgrade servers
first — a v2-capable server still accepts v1 clients, but a v2 client against a
v1-only server is rejected. No key, identity, or ticket format changed.
(Sources: `CHANGELOG.md` v4.0.0, `README.md`, `SECURITY.md`.)

### Does Evelin have forward secrecy?

The record layer runs an always-on one-way HKDF key ratchet: when a direction
crosses 1 GiB since the last ratchet, a fresh ChaCha20-Poly1305 key is derived
and the old key bytes are zeroized, so a mid-session key compromise does not
expose traffic from before the last ratchet point. The stated caveat: this is a
one-way symmetric ratchet, not a full ML-KEM rekey — PFS holds forward from
each ratchet point, not backward. The v2 `REKEY` capability is reserved for a
future asymmetric ML-KEM rekey. (Sources: `docs/THREAT-MODEL.md` §3.5,
`CHANGELOG.md` v4.0.0.)

### What is the session-resumption / 0-RTT story?

Evelin has session-resumption tickets: a warm reconnect presents a ticket and
skips the ML-KEM encapsulation, but the resumed handshake still requires a
server confirmation exchange before the client may send application bytes.
Tickets are sealed with XChaCha20-Poly1305 under a rotating server-side keyring
(N-generation keyring since v1.9, default 4 generations at 24-hour rotation),
and the default ticket `max_age_secs` is 172800 (48 hours, lowered from 7 days
in v1.8).

True 0-RTT application data — sending app bytes in the first flight — was
explicitly evaluated and rejected. `docs/THREAT_MODEL_0RTT.md` enumerates eight
threats (replay within the window, cross-restart replay, forward-secrecy loss,
cross-mode ticket reuse, protocol-identity leakage, amplification, replay-storm
DoS, and side effects before identity confirmation) and audits every built-in
application protocol against them: zero of the five qualify in a default
configuration. The decision was NO-GO; the threat model itself shipped instead
of the feature. (Sources: `docs/THREAT_MODEL_0RTT.md`, `CHANGELOG.md` v1.8.0,
v1.9.0.)

### Is there trust-on-first-use, like SSH's host-key prompt?

No. There is no automatic trust-on-first-use: the client refuses to connect
unless the server's identity fingerprint matches what is pinned in
`client.toml` or `known_hosts`, and you are expected to obtain the server's
fingerprint out-of-band (phone, paper, signed email) and add it with the
client's `trust` subcommand. On the server side, clients are checked against
`authorized_keys`. Fingerprints are SHA-256 of the encoded ML-DSA-87 public key, rendered as
64 hex characters. (Sources: `docs/THREAT-MODEL.md` §1.3, `README.md`.)

## Security posture

### Has Evelin been audited by a third party?

No. Evelin is self-released; there has been no paid third-party cryptographic
audit. The author welcomes community review and intends to commission a paid
audit after operational experience accumulates. The project's own comparison
document is blunt about what this means: a young single-implementation
transport with no completed external audit carries risk that no feature list
offsets — the mitigations (small auditable codebase, memory safety,
machine-checked core lemmas, reproducible artifacts) reduce that risk, they do
not eliminate it. (Sources: `SECURITY.md`, `COMPARISON.md`,
`docs/THREAT-MODEL.md` §6.)

### Is Evelin formally verified?

Partially, and the project refuses to round that up. For the primary handshake,
5 Tamarin lemmas and 8 ProVerif queries were machine-checked in the v0.1 proof
ceremony (core secrecy, mutual authentication, perfect forward secrecy).
Further lemmas — including the v2 negotiation models added in v4.0.0 — are
STATED but not machine-checked. The README's own words: **not** "fully formally
verified". The per-lemma status lives in `verification/VERIFICATION_STATUS.md`.
(Sources: `README.md`, `COMPARISON.md`, `CHANGELOG.md` v4.0.0.)

### What does Evelin *not* protect against?

The threat model is explicit about its gaps:

- **Traffic analysis.** Records reveal plaintext length and timing; there is no
  padding or cover traffic. If that is in your threat model, run Evelin inside
  an overlay that resists it.
- **Endpoint compromise.** A keylogged laptop defeats everything.
- **A root attacker who stays resident** can sign handshakes with the server
  identity until you rotate the key (passphrase-wrapped keys protect the
  at-rest copy only).
- **Denial of service** by a determined attacker; there is `[limits]
  max_connections` and per-frame limits, but the listener can be saturated.
- **Hardware side channels** — the primitives come from constant-time library
  implementations, but Evelin itself has not been audited against side-channel
  leakage.

(Source: `docs/THREAT-MODEL.md` §2.)

### How do I report a vulnerability?

Email `sac@securityops.co` with the subject prefix `[SECURITY]`. Do not open
public issues — there is no public issue tracker; the primary repository is a
private Forgejo instance with read-only public mirrors. Plaintext email is
acceptable for initial contact; a temporary PGP key for exploit details will be
provided within 72 hours (a key fingerprint is published at
`https://securityops.co/.well-known/pgp/security.asc`). The default disclosure
window is 90 days from acknowledgment. There is no monetary bounty; reporters
are credited in the CHANGELOG with their permission. (Source: `SECURITY.md`.)

## Performance and platforms

### Is performance comparable to OpenSSH?

Unknown, and the project refuses to guess. OpenSSH was not benchmarked on the
same hardware, so no comparative throughput or latency claim is made — the
comparison document calls assuming Evelin is faster "exactly the kind of claim
this project refuses". What has been measured for Evelin itself (1-core
container, loopback; methods in `docs/BENCHMARKS.md`): AEAD ceiling of
1.13 GiB/s seal / 924 MiB/s open on 1 MiB blocks; bulk filecopy ~50–75 MiB/s
single-core; and for the live v4.1.1 binaries, a full connect + handshake +
exec + teardown median of 11.7 ms over loopback. (Source: `COMPARISON.md`.)

### What platforms are supported?

Linux only, as of the current release. The v4.0.0 release packaged 3× Debian
`.deb` (musl-static amd64), 3× RPM (x86_64), a Termux aarch64 `.deb`, aarch64
and x86_64-musl tarballs, and a source tarball. macOS, Windows, and the BSDs are
not supported: the codebase depends on Linux-specific primitives (Landlock,
seccomp-bpf, `openat2` with `RESOLVE_BENEATH`, Unix-domain-socket agent IPC),
and the project chose not to ship cross-platform binaries that lack those
defenses. v1.9 introduced the `evelin-platform` abstraction crate as the
porting boundary — its Linux implementation is complete, the Windows backend is
a compiling skeleton with runtime tests pending, and the macOS/FreeBSD/OpenBSD
backends are stubs that return `Unimplemented`. The documented path for Windows
users today is WSL2 with a Debian/Ubuntu/Fedora distro. (Sources:
`CHANGELOG.md` v4.0.0 and v1.9.0, `crates/evelin-platform/`,
`docs/PLATFORM_BUILDS.md`.)

### How do I migrate from OpenSSH?

Incrementally, side by side — nothing in Evelin conflicts with a resident
`sshd`, and the comparison document calls running both (Evelin on its own port
alongside sshd) a reasonable migration posture. The toolchain maps one-to-one
(`evelin-server`/`sshd`, `evelin-client`/`ssh`, `evelin-keygen`/`ssh-keygen`,
`evelin-agent`/`ssh-agent`, `evelin-keyscan`/`ssh-keyscan`), so the workflow
carries over. You cannot reuse OpenSSH keys: Evelin identities are ML-DSA-87
keypairs, so you generate fresh ones with `evelin-keygen` and enroll their
fingerprints in `authorized_keys` (server side) and the client trust store.
Server setup, client setup, and first connection are walked through in
`README.md`. Anyone whose workflow depends on SFTP, certificates, PAM, or
third-party SSH clients should stay on OpenSSH. (Sources: `COMPARISON.md`,
`README.md`.)

### Which SSH features are missing?

Present: exec, interactive PTY shell, file copy (`cp`, Evelin's own
policy-rooted protocol), local/reverse/SOCKS forwarding (-L/-R/-D), agent and
agent forwarding, ProxyJump, session-resumption tickets, a Prometheus metrics
exporter. Absent: SFTP protocol compatibility, X11 forwarding, CA-signed
certificates, PAM/GSSAPI/Kerberos, the `ssh_config` ecosystem and
ControlMaster sharing — and there is only one implementation of the protocol,
versus OpenSSH's many. (Source: `COMPARISON.md`.)

## Keys and hardware

### Does Evelin support hardware keys or HSMs?

Not for the transport handshake, and the code says so plainly: as of the
`evelin-hsm` crate's writing, no commercial HSM exposes ML-DSA signing through
PKCS#11 (the FIPS 204 mechanism IDs are still being standardized in PKCS#11
v3.2), so the crate does not currently sign Evelin transport handshakes from an
HSM. What it does validate end-to-end against a real PKCS#11 implementation
(SoftHSM2) is Ed25519 *release-manifest* signing — module load, session open,
PIN login, on-token key generation, sign, verify, public-key export — so that
when ML-DSA mechanisms arrive, swapping the mechanism is a one-line change in
`sign()`. For key-at-rest protection today, identity keys can be
passphrase-wrapped with Argon2id (m=64 MiB, t=3, p=1). (Sources:
`crates/evelin-hsm/src/lib.rs`, `README.md`.)

## SDKs and integration

### Are there SDKs for languages other than Rust?

The `sdk/` directory contains client SDKs for 12 languages: C, Rust, Python,
Go, Node.js, Ruby, Java, Swift, .NET, Elixir, OCaml, and Guile. The Rust SDK is
the only native one — it consumes the workspace crates directly; the others are
language bindings over the `libevelin` C ABI (the Python SDK, for example, uses
stdlib `ctypes` against `libevelin.so`; the Elixir SDK is a Rustler NIF that
links `libevelin`). One caveat from reading the tree: the Swift directory
currently contains only a package manifest and a C-module shim (`Package.swift`,
`shim.h`, `module.modulemap`) with no Swift source files, so treat it as a
packaging skeleton rather than a working SDK. (Sources: `sdk/` tree,
`sdk/rust/src/lib.rs`, `sdk/python/evelin/__init__.py`,
`sdk/elixir/native/evelin_nif/Cargo.toml`.)

## Licensing

### What is the license — can my company use Evelin?

Evelin is dual-licensed: AGPL-3.0-or-later (the default) or a commercial
license. Under the AGPL you can run Evelin for any purpose, including
commercial use — individuals, researchers, educators, students, hobbyists,
non-profits, and anyone running Evelin for their own use without modification
or service-provision are fully covered and owe nothing. The AGPL's network-use
clause means that if you modify Evelin and run the modified version as a
network service, you must make your modified source available to its users. The
commercial license exists for uses incompatible with that: closed-source
embedding, running a modified Evelin as a service without releasing
modifications, or organizations whose policies forbid AGPL software. Inquiries:
`sac@securityops.co` (one to two business days is the normal response time).
(Sources: `NOTICE`, `README.md`.)

### Can I contribute, and what happens to my contribution's license?

By contributing code you agree it is licensed under the same dual-license terms
as the rest of the project. The copyright holder reserves the right to
relicense the combined work under different open-source terms in the future,
provided those terms remain at least as copyleft as the current AGPL.
(Source: `NOTICE`.)

## Can I receive a fixed backup export without allowing remote exec?

Yes. Version 4.4.0 adds Linux-only `fixed-export`, disabled by default and served
by a dedicated instance. It supports PostgreSQL custom dumps and a restricted
Forgejo pax archive. Both ends require fully enforced pre-runtime Landlock;
the receiver validates and commits a private staged file before publishing it.
See [fixed exports](fixed-export.md) for setup, non-terminal descriptor rules,
limits and recovery. A Forgejo data archive alone is not a complete backup.
