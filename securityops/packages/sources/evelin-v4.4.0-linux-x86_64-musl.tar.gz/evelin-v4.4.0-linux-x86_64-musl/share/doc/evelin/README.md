# Evelin

Post-quantum secure tunnel with commands, interactive shells, file copy and
port forwarding. Written in Rust; its wire protocol is independent of SSH.

**Version:** 4.4.0 · **License:** AGPL-3.0-or-later or commercial (see [NOTICE](NOTICE))

**Author:** Cristian Cezar Moisés / SecurityOps · `sac@securityops.co`

**Website:** <https://evelin.securityops.co> · **Português:** [README.pt-BR.md](README.pt-BR.md)

[Getting started](docs/en/getting-started.md) · [Examples](docs/en/examples.md) ·
[Fixed exports](docs/en/fixed-export.md) · [Architecture](docs/en/architecture.md) ·
[FAQ](docs/en/faq.md) · [Documentation index](docs/README.md)

## What's new in v4.4.0

- **Fixed exports on Linux:** `evelin-client fixed-export` receives a named,
  server-defined PostgreSQL custom dump or Forgejo pax archive. Each exporter
  has its own client allowlist, definition SHA-256, byte limit and deadlines.
  The feature is disabled by default.
- **Validate before publishing:** exports are staged in a private local file,
  checked for format, size and SHA-256, synchronized to disk, and published
  without overwriting an existing destination after a bound server commit
  acknowledgement. PostgreSQL uses a pinned local `pg_restore --list`;
  Forgejo uses an internal parser without extracting the archive.
- **Purpose-specific helpers:** Linux builds include
  `evelin-fixed-export-pg-dump`, `evelin-fixed-export-forgejo-tar` and
  `evelin-fixed-export-forgejo-tar-validator`. Export setup requires explicit local
  policy and supported Landlock enforcement; see the [operator guide](docs/en/fixed-export.md).
- **Connection cleanup:** transport shutdown closes waiting channels; canceled
  channel opens are cleaned up when their replies arrive. Shell teardown
  handles disconnected peers and process groups, and session cancellation
  removes forwarded-agent listeners.
- **Updated English and Brazilian Portuguese documentation**, including
  current installation, client verbosity and identity-fingerprint guidance.

See [CHANGELOG.md](CHANGELOG.md) for the release history. Existing identity
keys and trust files remain usable. Upgrade both endpoints before using fixed
exports; ordinary commands retain their existing configuration.

## Install

Download the archive matching your machine from the
[v4.4.0 release](https://github.com/cristiancmoises/evelin-mirror/releases/tag/v4.4.0).
Use the Linux musl build when you need binaries without a glibc dependency,
including on GNU Guix. The release asset list identifies the available targets
and package formats.

Verify the downloaded archive against its published checksum before unpacking:

```sh
sha256sum evelin-v4.4.0-linux-x86_64-musl.tar.gz
# Compare the result with the matching entry in SHA256SUMS-v4.4.0.
tar xzf evelin-v4.4.0-linux-x86_64-musl.tar.gz
```

On GNU Guix, use the package definition from a source checkout to install the
verified archive into a profile with normal Guix generations and rollback:

```sh
EVELIN_RELEASE_ARCHIVE=/absolute/path/evelin-v4.4.0-linux-x86_64-musl.tar.gz \
  guix package -f packaging/guix/evelin.scm
evelin-client --version
evelin-server --version
```

The package is named `evelin-bin` and includes binaries, C API outputs and
documentation; it does not configure or start a server. Omit
`EVELIN_RELEASE_ARCHIVE` to download the pinned release archive. For a manual
per-user installation, copy the extracted `bin/evelin-*` executables into
`~/.local/bin` and add that directory to `PATH`. Details are in
[packaging](packaging/README.md).

System services must use the actual installed binary path. Follow
[getting started](docs/en/getting-started.md) to create identities, configure
the daemon, authorize a client and pin the server fingerprint. Package and
service integration details are in [packaging/](packaging/README.md).

## First connection

Create your client identity and configuration before invoking client commands:

```sh
mkdir -p "$HOME/.evelin"
chmod 700 "$HOME/.evelin"
evelin-keygen --out "$HOME/.evelin/identity.key"
cat > "$HOME/.evelin/client.toml" <<TOML
server_addr = "server.example.com:7222"
identity_key = "$HOME/.evelin/identity.key"
TOML
chmod 600 "$HOME/.evelin/client.toml"
evelin-client --config "$HOME/.evelin/client.toml" print-auth-line
```

Add the printed fingerprint to the server's `authorized_keys` underneath its
required first line, `# evelin-authorized-keys v1`. Obtain the server's
fingerprint through a trusted independent channel, then pin it:

```sh
evelin-client --config "$HOME/.evelin/client.toml" trust \
  --addr server.example.com:7222 --fingerprint REPLACE_WITH_64_HEX_DIGITS

evelin-client --config "$HOME/.evelin/client.toml" exec uname -a
evelin-client --config "$HOME/.evelin/client.toml" shell
evelin-client --config "$HOME/.evelin/client.toml" cp ./local.txt remote:/srv/uploads/local.txt
```

The server must explicitly permit the requested command, shell or filecopy
root. There is no automatic trust on first use. TOML paths must be absolute;
`~` and `$HOME` inside a literal TOML value are not expanded. In the example
above, the shell expands `$HOME` while creating the file.

The client is quiet by default. Use `-v`, `-vv` or `-vvv` for more detail,
`-q` for errors only, and `RUST_LOG` to override the log filter. Logs and copy
progress go to stderr. The server defaults to JSON logging.

## Toolchain

| Binary | Purpose |
|---|---|
| `evelin-server` | Server daemon |
| `evelin-client` | Exec, shell, copy, fixed export, forwarding, SOCKS, jump and proxy-command |
| `evelin-keygen` | Generate identity keys |
| `evelin-agent` | Hold unlocked keys in memory |
| `evelin-keyscan` | Discover server fingerprints for independent verification |
| `evelin-multisig-verify` | Verify release signatures |
| `evelin-sandbox-probe` / `evelin-seccomp-probe` | Inspect host sandbox support |
| `evelin-fixed-export-pg-dump` | Linux PostgreSQL export backend |
| `evelin-fixed-export-forgejo-tar` | Linux Forgejo archive backend |
| `evelin-fixed-export-forgejo-tar-validator` | Validate a Forgejo archive from stdin without extraction |

## Build from source

```sh
git clone https://github.com/cristiancmoises/evelin-mirror
cd evelin-mirror
git checkout v4.4.0
cargo build --locked --release --workspace
cargo test --locked --release --workspace
```

`rust-toolchain.toml` selects Rust 1.93.0 with rustfmt and clippy; tracked
`Cargo.lock` pins dependency resolution. Interactive
shell support (`pty-shell`) is enabled by default in `evelin-server`; a build
with `--no-default-features` can omit it. Fixed export is Linux-only.

## Cryptography

| Layer | Algorithm |
|---|---|
| Key encapsulation | ML-KEM-1024 |
| Mutual authentication | ML-DSA-87 |
| Record encryption | ChaCha20-Poly1305 |
| Key derivation | HKDF-SHA-512 |
| Passphrase wrapping | Argon2id, 64 MiB memory, 3 iterations, 1 lane |
| Identity fingerprint | SHA-256 of the encoded ML-DSA-87 public key, 64 hex digits |

Protocol v2 capability negotiation remains opt-in through
`max_protocol_version = 2` on both endpoints. `max_frame_kib` controls the v2
frame advertisement; see [extensions](docs/en/extensions.md).

Evelin is self-released and has no completed paid third-party cryptographic
audit. Formal-model results apply to the specific lemmas and versions listed
in [verification status](verification/VERIFICATION_STATUS.md), not the entire
implementation. See [SECURITY.md](SECURITY.md) for the threat model and private
vulnerability-reporting process, and [benchmarks](docs/BENCHMARKS.md) for
measured performance and limitations.

## Project and license

[Contributing](CONTRIBUTING.md) · [Governance](GOVERNANCE.md) ·
[Roadmap](ROADMAP.md) · [Code of conduct](CODE_OF_CONDUCT.md)

Evelin is available under [AGPL-3.0-or-later](LICENSE-AGPL-3.0) or a separate
commercial agreement for eligible first-party code. [LICENSE-COMMERCIAL](LICENSE-COMMERCIAL)
is an inquiry and scope notice, not a public commercial license grant; it does
not relicense dependencies. Contact `sac@securityops.co` and see [NOTICE](NOTICE).
