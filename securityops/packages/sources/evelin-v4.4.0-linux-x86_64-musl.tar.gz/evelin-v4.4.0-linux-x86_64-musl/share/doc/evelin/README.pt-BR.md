# Evelin

Túnel seguro pós-quântico com comandos, shells interativos, cópia de arquivos e
encaminhamento de portas. Escrito em Rust; seu protocolo é independente do SSH.

**Versão:** 4.4.0 · **Licença:** AGPL-3.0-or-later ou comercial (veja [NOTICE](NOTICE))

**Autor:** Cristian Cezar Moisés / SecurityOps · `sac@securityops.co`

**Site:** <https://evelin.securityops.co> · **English:** [README.md](README.md)

[Primeiros passos](docs/pt-br/getting-started.md) · [Exemplos](docs/pt-br/examples.md) ·
[Exportações fixas](docs/pt-br/fixed-export.md) · [Arquitetura](docs/pt-br/architecture.md) ·
[FAQ](docs/pt-br/faq.md) · [Índice da documentação](docs/pt-br/README.md)

Esta é a tradução brasileira do README. Em caso de divergência, a versão em
inglês prevalece.

## Novidades da v4.4.0

- **Exportações fixas no Linux:** `evelin-client fixed-export` recebe um dump
  PostgreSQL custom ou arquivo pax do Forgejo identificado e definido pelo
  servidor. Cada exportador tem lista de clientes autorizados, SHA-256 da
  definição, limite de bytes e prazos próprios. O recurso vem desabilitado.
- **Validação antes da publicação:** a exportação é recebida em arquivo local
  privado, verificada quanto ao formato, tamanho e SHA-256, sincronizada em
  disco e publicada sem substituir um destino existente após a confirmação
  de commit vinculada pelo servidor. PostgreSQL usa um `pg_restore --list`
  local fixado; Forgejo usa um parser interno sem extrair o arquivo.
- **Auxiliares específicos:** builds Linux incluem
  `evelin-fixed-export-pg-dump`, `evelin-fixed-export-forgejo-tar` e
  `evelin-fixed-export-forgejo-tar-validator`. A configuração exige política local
  explícita e suporte à aplicação do Landlock; veja o [guia operacional](docs/pt-br/fixed-export.md).
- **Limpeza de conexões:** o encerramento do transporte fecha canais em espera;
  aberturas canceladas são encerradas quando suas respostas chegam. O término
  de shells trata desconexões e grupos de processos, e o cancelamento da sessão
  remove listeners de agente encaminhado.
- **Documentação atualizada em inglês e português brasileiro**, incluindo
  instalação, verbosidade do cliente e fingerprints de identidade.

Consulte [CHANGELOG.md](CHANGELOG.md) para o histórico de versões. As chaves
existentes e os arquivos de confiança continuam utilizáveis. Atualize as duas
pontas antes de usar exportações fixas; os comandos comuns mantêm sua
configuração existente.

## Instalação

Baixe o arquivo correspondente à sua máquina no
[lançamento v4.4.0](https://github.com/cristiancmoises/evelin-mirror/releases/tag/v4.4.0).
Use o build Linux musl quando precisar de binários sem dependência da glibc,
inclusive no GNU Guix. A lista de artefatos do lançamento identifica as
plataformas e os formatos de pacote disponíveis.

Confira o checksum publicado antes de extrair o arquivo:

```sh
sha256sum evelin-v4.4.0-linux-x86_64-musl.tar.gz
# Compare o resultado com a entrada correspondente em SHA256SUMS-v4.4.0.
tar xzf evelin-v4.4.0-linux-x86_64-musl.tar.gz
```

No GNU Guix, use a definição de pacote de um checkout do código-fonte para
instalar o arquivo verificado em um perfil com gerações e rollback do Guix:

```sh
EVELIN_RELEASE_ARCHIVE=/caminho/absoluto/evelin-v4.4.0-linux-x86_64-musl.tar.gz \
  guix package -f packaging/guix/evelin.scm
evelin-client --version
evelin-server --version
```

O pacote se chama `evelin-bin` e inclui binários, resultados da API C e docs;
não configura nem inicia servidor. Omita `EVELIN_RELEASE_ARCHIVE` para baixar
o arquivo fixado do lançamento. Para instalação manual por usuário, copie os
executáveis `bin/evelin-*` extraídos para `~/.local/bin` e adicione o diretório
ao `PATH`. Veja [empacotamento](packaging/README.pt-BR.md).

Serviços de sistema devem usar o caminho real do binário instalado. Siga
[primeiros passos](docs/pt-br/getting-started.md) para criar identidades,
configurar o daemon, autorizar um cliente e fixar o fingerprint do servidor.
Os detalhes de empacotamento e integração de serviços ficam em
[packaging/](packaging/README.pt-BR.md).

## Primeira conexão

Crie a identidade e a configuração antes de executar os comandos do cliente:

```sh
mkdir -p "$HOME/.evelin"
chmod 700 "$HOME/.evelin"
evelin-keygen --out "$HOME/.evelin/identity.key"
cat > "$HOME/.evelin/client.toml" <<TOML
server_addr = "server.example.com:7222"
identity_key = "$HOME/.evelin/identity.key"
TOML
chmod 600 "$HOME/.evelin/client.toml"
evelin-client --config "$HOME/.evelin/client.toml" print-auth-line
```

Adicione o fingerprint impresso ao `authorized_keys` do servidor abaixo da
primeira linha obrigatória, `# evelin-authorized-keys v1`. Obtenha o fingerprint
do servidor por um canal independente confiável e fixe-o:

```sh
evelin-client --config "$HOME/.evelin/client.toml" trust \
  --addr server.example.com:7222 --fingerprint SUBSTITUA_PELOS_64_DIGITOS_HEX

evelin-client --config "$HOME/.evelin/client.toml" exec uname -a
evelin-client --config "$HOME/.evelin/client.toml" shell
evelin-client --config "$HOME/.evelin/client.toml" cp ./local.txt remote:/srv/uploads/local.txt
```

O servidor precisa permitir explicitamente o comando, shell ou raiz de cópia
solicitados. Não há confiança automática no primeiro uso. Caminhos no TOML
devem ser absolutos; `~` e `$HOME` em um valor TOML literal não são expandidos.
No exemplo acima, o shell expande `$HOME` ao criar o arquivo.

O cliente é silencioso por padrão. Use `-v`, `-vv` ou `-vvv` para mais detalhes,
`-q` para somente erros e `RUST_LOG` para substituir o filtro de logs. Logs e
progresso de cópia vão para stderr. O servidor usa logs JSON por padrão.

## Ferramentas

| Binário | Finalidade |
|---|---|
| `evelin-server` | Daemon servidor |
| `evelin-client` | Exec, shell, cópia, exportação fixa, encaminhamento, SOCKS, jump e proxy-command |
| `evelin-keygen` | Geração de chaves de identidade |
| `evelin-agent` | Mantém chaves desbloqueadas na memória |
| `evelin-keyscan` | Descobre fingerprints para verificação independente |
| `evelin-multisig-verify` | Verifica assinaturas de lançamentos |
| `evelin-sandbox-probe` / `evelin-seccomp-probe` | Inspecionam o suporte ao sandbox do host |
| `evelin-fixed-export-pg-dump` | Backend Linux de exportação PostgreSQL |
| `evelin-fixed-export-forgejo-tar` | Backend Linux de arquivo Forgejo |
| `evelin-fixed-export-forgejo-tar-validator` | Valida arquivo Forgejo pela entrada padrão sem extração |

## Compilar a partir do código-fonte

```sh
git clone https://github.com/cristiancmoises/evelin-mirror
cd evelin-mirror
git checkout v4.4.0
cargo build --locked --release --workspace
cargo test --locked --release --workspace
```

`rust-toolchain.toml` seleciona Rust 1.93.0 com rustfmt e clippy; o
`Cargo.lock` versionado fixa as dependências. O suporte a
shell interativo (`pty-shell`) está habilitado por padrão em `evelin-server`;
um build com `--no-default-features` pode omiti-lo. A exportação fixa é
exclusiva do Linux.

## Criptografia

| Camada | Algoritmo |
|---|---|
| Encapsulamento de chave | ML-KEM-1024 |
| Autenticação mútua | ML-DSA-87 |
| Criptografia de registros | ChaCha20-Poly1305 |
| Derivação de chaves | HKDF-SHA-512 |
| Proteção por frase secreta | Argon2id, 64 MiB de memória, 3 iterações, 1 via |
| Fingerprint de identidade | SHA-256 da chave pública ML-DSA-87 codificada, 64 dígitos hexadecimais |

A negociação de capacidades do protocolo v2 continua opcional, com
`max_protocol_version = 2` nas duas pontas. `max_frame_kib` controla o anúncio
de tamanho de frame do v2; veja [extensões](docs/pt-br/extensions.md).

O Evelin é publicado pelo próprio projeto e não possui auditoria criptográfica
paga de terceiros concluída. Os resultados dos modelos formais se aplicam aos
lemas e versões em [status de verificação](verification/VERIFICATION_STATUS.md),
não à implementação inteira. Veja [SECURITY.md](SECURITY.md) para o modelo de
ameaças e o processo privado de relato de vulnerabilidades, e
[benchmarks](docs/BENCHMARKS.md) para desempenho medido e limitações.

## Projeto e licença

[Contribuições](docs/pt-br/CONTRIBUTING.md) · [Governança](docs/pt-br/GOVERNANCE.md) ·
[Roadmap](docs/pt-br/ROADMAP.md) · [Código de conduta](docs/pt-br/CODE_OF_CONDUCT.md)

O Evelin está disponível sob [AGPL-3.0-or-later](LICENSE-AGPL-3.0) ou acordo
comercial separado para código próprio elegível. [LICENSE-COMMERCIAL](LICENSE-COMMERCIAL)
é um aviso de consulta e escopo, não uma licença comercial pública; ele não
relicencia dependências. Contato: `sac@securityops.co`. Veja [NOTICE](NOTICE).
