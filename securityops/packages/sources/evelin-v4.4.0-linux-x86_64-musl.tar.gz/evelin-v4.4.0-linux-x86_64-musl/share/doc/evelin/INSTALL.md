<!-- SPDX-License-Identifier: AGPL-3.0-or-later OR LicenseRef-Evelin-Commercial -->

# Installing Evelin v0.1.0 on a self-hosted Forgejo instance

This document walks through deploying Evelin from a fresh git push to
your Forgejo instance through to a running server that authorized
clients can connect to.

## Prerequisites

- A self-hosted Forgejo instance (any 9.x or later) with Forgejo
  Actions enabled.
- One Forgejo Actions runner with Docker support. The CI matrix
  builds Linux + macOS + Windows binaries; if you only need Linux,
  one ubuntu-latest-equivalent runner is sufficient.
- A target host on which to run the Evelin server. This document
  assumes Linux/x86_64 with Docker installed.
- Out-of-band access to whatever client machines will connect (SSH,
  ansible, signed email — anything you trust enough to ship a
  fingerprint over).

## Step 1 — push the repository

```bash
# From the unpacked sprint package directory:
cd evelin
git init
git add .
git commit -m "evelin v0.1.0 initial import"

# Add your Forgejo remote and push:
git remote add origin https://forgejo.your-instance/you/evelin.git
git push -u origin main
```

Forgejo will pick up `.forgejo/workflows/ci.yml` automatically and
run fmt + clippy + test + build on the first push. The first run
takes ~5 minutes (mostly compiling RustCrypto crates); subsequent
runs are cached and run in ~1 minute.

## Step 2 — cut a release

```bash
git tag -a v0.1.0 -m "evelin v0.1.0"
git push origin v0.1.0
```

This triggers `.forgejo/workflows/release.yml`, which:

- builds the binaries for five targets (linux x86_64+aarch64 musl,
  macos x86_64+aarch64, windows x86_64);
- packages each as a tarball/zip with a sibling `.sha256` manifest;
- builds and pushes the Docker image
  `forgejo.your-instance/you/evelin:0.1.0` and `:latest`;
- creates a Forgejo release entry with all archives attached and a
  combined `SHA256SUMS` file.

You will need to set one repository secret beforehand for the Docker
push: `FORGEJO_TOKEN` with `write:packages` scope.

## Step 3 — generate the server identity

On the target host:

```bash
mkdir -p ./config
docker compose --profile init run --rm keygen
# → "wrote identity to /etc/evelin/server.key"
# → "fingerprint: 7f494dead0d59a99..."
```

**Note the fingerprint.** This is the value that goes into every
client's `server_fingerprint` field. There is no automated way for a
client to discover it; ship it through a channel you trust.

## Step 4 — configure authorized clients

Generate a client identity (on the client machine):

```bash
docker run --rm -v "$HOME/.config/evelin:/keys" \
    forgejo.your-instance/you/evelin:0.1.0 \
    --entrypoint /usr/local/bin/evelin-keygen \
    --out /keys/id.evelin
# → "fingerprint: 57a616ad35e8..."
```

On the server, add the client's fingerprint to the authorized list:

```bash
# ./config/authorized_keys
cat > ./config/authorized_keys <<'EOF'
# evelin-authorized-keys v1
57a616ad35e8779f7a5d7fc374858131d812f3387b3cf48c8182d156fb6ced62 alice@laptop
EOF
```

Each line is `<fingerprint hex> <comment>`. Comments are advisory
and not used for matching.

## Step 5 — configure and start the server

```bash
# ./config/server.toml
cat > ./config/server.toml <<'EOF'
bind            = "0.0.0.0:2200"
identity_key    = "/etc/evelin/server.key"
authorized_keys = "/etc/evelin/authorized_keys"
log_format      = "json"
log_level       = "info"
EOF

docker compose up -d evelin
docker compose logs -f evelin
# → {"timestamp":"...","level":"INFO","fields":{"message":"evelin server listening","bind":"0.0.0.0:2200","server_fingerprint":"..."}}
```

If the log shows `authorized-keys file ... is empty or missing — no
clients will be accepted`, you forgot step 4.

## Step 6 — connect a client

```bash
# ~/.config/evelin/client.toml
cat > ~/.config/evelin/client.toml <<'EOF'
server_addr        = "your-server.example.com:2200"
identity_key       = "/home/alice/.config/evelin/id.evelin"
server_fingerprint = "7f494dead0d59a99..."   # from Step 3
log_format         = "text"
log_level          = "info"
EOF

echo "hello server" | evelin-client --config ~/.config/evelin/client.toml
# → "hello server"   (v0.1 server echoes; this confirms the tunnel)
```

If the client logs `authorization denied`, the server didn't have
your fingerprint in `authorized_keys`. If the client logs
`cryptographic verification failed`, the `server_fingerprint` in
your config doesn't match the server's actual identity — verify it
matches step 3's output exactly, byte for byte.

## Operational notes

- **Logs are structured.** Use `log_format = "json"` in production
  and feed the stream to your log aggregator. Key fields:
  `peer`, `client_fingerprint`, `server_fingerprint`, `error`.
- **Restart cleanly.** `docker compose restart evelin`. v0.1 does
  not implement graceful reload (SIGHUP is ignored); restart drops
  in-flight connections.
- **Backups.** Back up `/etc/evelin/server.key` to a *separate*
  encrypted store. Losing it means re-keying every client; rotating
  it without distributing the new fingerprint locks every client out.
- **Monitoring.** v0.1 does not expose Prometheus metrics. The log
  stream is the monitoring surface. A simple liveness check is
  `nc -z server.host 2200`; a real authentication check requires a
  client connection.
- **Network.** Put the Evelin port behind whatever access controls
  you would put SSH behind: nftables/iptables, a service mesh, or
  a Tailscale-style overlay. v0.1 has no built-in rate limiting.

## Upgrading

Tag a new version, let the release workflow build it, then on the
target host:

```bash
docker compose pull
docker compose up -d evelin
```

Identity keys are preserved across the volume, so clients continue
to work without reconfiguration. If the server identity changed
(intentional rotation), every client's `server_fingerprint` must be
updated.

## Uninstalling

```bash
docker compose down
docker volume rm evelin-state    # destroys the server identity
rm -rf ./config
```
