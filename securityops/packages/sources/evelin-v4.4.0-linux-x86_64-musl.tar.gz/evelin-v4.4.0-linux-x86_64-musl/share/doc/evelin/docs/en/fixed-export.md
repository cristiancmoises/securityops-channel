# Fixed exports in Evelin 4.4.0

[Português brasileiro](../pt-br/fixed-export.md) · [Documentation index](../README.md)

`evelin-client fixed-export` receives one named export from a dedicated Evelin
server. The client supplies an exporter ID, expected format, definition SHA-256
and byte ceiling. The server chooses the local producer. No remote command,
path, argument vector, environment value or credential is accepted from the
client. Fixed exports are disabled by default and available only on Linux.

## Formats and limits

| CLI format | Server `format` | Producer | Local validation |
|---|---|---|---|
| `postgresql-custom` (default) | `1` | `evelin-fixed-export-pg-dump` | Pinned `pg_restore --list` |
| `forgejo-tar-pax` | `2` | `evelin-fixed-export-forgejo-tar` | Internal strict pax/ustar parser, no extraction |

The PostgreSQL helper uses a fixed local database socket and fixed producer
options. It accepts the database name and local database role from its own
operator-controlled arguments. Its compiled producer path is `/usr/bin/pg_dump`,
whose canonical target must be an ELF executable. Debian's `pg_wrapper` script
is rejected: deployment on such a system requires selecting and compiling in
the actual versioned `pg_dump` executable before computing the definition hash.
Use a dedicated database identity with the read permissions needed for the dump.

The Forgejo helper reads the compiled root `/var/lib/forgejo`. Its fixed path
policy includes supported repositories, attachments, avatars, LFS and package
data. It excludes configuration, credentials, hooks, temporary/session data,
SQLite database files and other sensitive paths; symbolic-link archive members
are disabled. Unknown namespaces or unexpected source changes can reject an
export. This archive alone is **not a complete Forgejo backup**: coordinate
application consistency and manage the database and excluded configuration
separately. The canonical policy is in
[`forgejo_policy.rs`](../../crates/evelin-session/src/fixed_export/forgejo_policy.rs).

An export succeeds only within both the client and server byte/time limits.
There is no resume option, remote file selector or client-chosen producer.

## Dedicated server

Run a separate Evelin instance and port for fixed exports. Enabling them on a
general-purpose shell/filecopy instance fails configuration validation.
Provision its identity and `authorized_keys` before startup; `--init` is refused
when fixed exports are enabled.

Both the server and receiving client require **fully enforced Landlock ABI v3**
before starting their async runtimes. Missing support is a startup error, not a
fallback. The dedicated server requires `seccomp.mode = "off"`: the ordinary
server's legacy seccomp installation does not filter all existing runtime
workers, so this mode does not claim process-wide seccomp enforcement.

The following is a configuration template. Replace every uppercase placeholder
and the illustrative UIDs/GIDs with verified local values. The socket must exist
before enabling the exporter or running `--check` with it enabled.

```toml
bind = "127.0.0.1:7223"
identity_key = "/etc/evelin-export/identity.key"
authorized_keys = "/etc/evelin-export/authorized_keys"

[shell]
enable = false
[exec]
allow = []
[forward]
allow = []
wildcards = false
[reverse_forward]
allow = []
[agent_forward]
enable = false
[filecopy]
roots = []
allow_upload = false
allow_download = false
max_file_size = 0
[seccomp]
mode = "off"

[fixed_export]
enabled = true
max_concurrent = 1

[[fixed_export.exporters]]
id = "forgejo-data"
socket_path = "/run/evelin-fixed-export/forgejo-data.sock"
socket_owner_uid = 991
socket_parent_uid = 0
backend_peer_uid = 0
backend_peer_gid = 0
format = 2
definition_sha256 = "REPLACE_WITH_64_HEX_DIGITS"
allowed_client_fingerprints = ["REPLACE_WITH_AUTHORIZED_CLIENT_FINGERPRINT"]
max_bytes = 42949672960
ready_timeout_seconds = 10
idle_timeout_seconds = 300
max_runtime_seconds = 21600
commit_timeout_seconds = 60
```

An exporter ID is 1–64 lowercase ASCII letters/digits with `.`, `_` and `-`
allowed after its initial letter/digit. IDs and socket paths must be unique.
The global concurrency limit is enforced without queuing excess requests.
Every exporter fingerprint must also appear in `authorized_keys`.

Sockets must have mode `0600`, one link, the configured owner, and an absolute,
canonical path. Their parent directory must have the configured owner and no
group/other write permission. The server pins inode identity and validates
`SO_PEERCRED`; `backend_peer_uid`/`backend_peer_gid` identify the socket activator
for a systemd `Accept=yes` listener and must be verified on the actual host.
Replacing the socket requires restarting the dedicated server to pin it again.

## Local backend service

Use a root-controlled AF_UNIX socket beneath `/run/evelin-fixed-export` and a
per-connection service. Both helpers verify their expected socket path and the
Evelin service UID. The service arguments, executable and socket directory must
not be writable by the Evelin account.

For systemd, the helper expects `Accept=yes`, `StandardInput=socket`,
`StandardOutput=socket` and `StandardError=null`. Use `KillMode=control-group`,
the default `ExitType=main`, a finite `TimeoutStopSec`, `SendSIGKILL=yes`, and a
`RuntimeMaxSec` covering the helper's wall timeout plus a short cleanup margin.
Verify that helper exit empties its per-connection cgroup. The PostgreSQL helper
also terminates its producer process group. Keep filesystem access read-only
and restricted to the selected producer's needs.

Compute the definition hash with the exact helper executable and arguments
that the service will use; for example:

```sh
evelin-fixed-export-forgejo-tar \
  --source-owner-uid 992 --allowed-peer-uid 991 \
  --expected-socket-path /run/evelin-fixed-export/forgejo-data.sock \
  --max-bytes 42949672960 --idle-timeout-seconds 300 \
  --wall-timeout-seconds 21600 --print-definition-sha256
```

The definition binds the helper implementation and fixed producer policy.
Recompute and distribute it to the server configuration and authorized clients
after changing the helper binary or its definition. The `--print-definition-sha256`
operation does not perform an export. Run the server's `--check` before starting
the dedicated service, using the same service account and environment.

## Receiver setup

The client configuration, identity and any existing `known_hosts` must be
absolute canonical paths, private regular files, owned by the receiving UID,
with one link and controlled ancestry. Use mode `0600`. The endpoint comes from
`server_addr`; its fingerprint must already be pinned in the config or trust
file. Fixed export rejects `--addr`, `--jump`, `--proxy-command` and agent
forwarding.

Create a separate destination directory owned by the receiving user with mode
`0700`. Its path must be absolute and canonical; it must not contain client
configuration, identity or trust files. The destination must not exist, even as
a symlink. A PostgreSQL validator must be outside this writable directory,
root-owned, executable, canonical, and not writable by group/other; its parent
chain must be root-controlled. Resolve distribution or Guix profile symlinks
to the real executable path before using `--validator-program`.

Inherited terminal or regular-file standard descriptors are refused. Use
`/dev/null` for stdin and pipes or service-manager logging sockets for output;
unexpected descriptors above 2 are also rejected. The Bash recipe below pipes
both outputs and preserves the client's exit status with `pipefail`:

```bash
set -o pipefail
mkdir -p "$HOME/evelin-exports"
chmod 700 "$HOME/evelin-exports"
evelin-client --config "$HOME/.evelin/export-client.toml" fixed-export \
  --producer-id forgejo-data --format forgejo-tar-pax \
  --definition-sha256 REPLACE_WITH_64_HEX_DIGITS \
  --max-bytes 42949672960 \
  --destination "$HOME/evelin-exports/forgejo-2026-09-06.tar" \
  </dev/null 2>&1 | cat
```

For PostgreSQL, select `--format postgresql-custom`, the configured database
exporter ID, and `--validator-program /ABSOLUTE/CANONICAL/PATH/pg_restore`.
The client fixes its arguments to `--list`; no restore is performed. Do not
supply `--validator-program` for `forgejo-tar-pax`.

| Client flag | Default (seconds) |
|---|---:|
| `--open-timeout-seconds` | 10 |
| `--idle-timeout-seconds` | 300 |
| `--max-runtime-seconds` | 21600 |
| `--validator-timeout-seconds` | 240 |
| `--commit-timeout-seconds` | 30 |

Set the server's `commit_timeout_seconds` long enough for local fsync,
validation and rehashing; large archives on slow storage may exceed its
60-second default. The client's commit timeout starts when it sends the commit.

## Completion and recovery

The receiver writes a random mode-`0600` partial in the destination directory.
It checks the producer result, format, size and SHA-256, synchronizes the file,
validates it, rereads its digest and synchronizes the directory. It then sends
a fresh challenge with the commit. Publication uses a no-overwrite link to the
pinned partial inode only after a matching acknowledgement binds the challenge,
size, digest and definition hash.

Failures before that acknowledgement remove the owned partial. A failure after
the acknowledgement preserves the durable partial and reports that local
recovery is required. Inspect that partial and the final destination before
retrying; never assume that a nonzero exit means no committed data remains.
Existing destinations are never overwritten.

The standalone `evelin-fixed-export-forgejo-tar-validator` reads an archive on
stdin and runs the same parser without extracting it:

```sh
evelin-fixed-export-forgejo-tar-validator < forgejo-2026-09-06.tar
```

Parser success establishes the supported archive structure, not application
consistency or a tested restore. An actual restoration drill remains separate
from export transport validation.
