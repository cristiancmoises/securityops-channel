# Builds por plataforma do Evelin 4.4.0

[English](../PLATFORM_BUILDS.md) · [Artefatos do lançamento](https://github.com/cristiancmoises/evelin-mirror/releases/tag/v4.4.0)

Disponibilidade do build, validação de execução e suporte ao sandbox são fatos
separados. O manifesto do lançamento e `BUILD-INFO.json` identificam os
artefatos exatos e a toolchain. Compilação cruzada não valida a execução no
sistema de destino. Consulte as notas do lançamento para os testes concluídos.

## Matriz de plataformas

| Alvo | Família de arquivo / pacote | Executáveis incluídos | Execução e escopo |
|---|---|---|---|
| Linux x86_64 musl | `linux-x86_64-musl.tar.gz`; pacotes Debian/RPM | 11 ferramentas Linux | Alvo principal; sem dependência da glibc. Exportações fixas exigem Landlock ABI v3 totalmente aplicado e política dedicada. |
| Android aarch64 | `android-aarch64.tar.gz` | 6 ferramentas Unix | Alvo de compilação cruzada NDK r26d/API 24; validação de execução é separada. O modo Linux de exportação fixa não está disponível. |
| FreeBSD 14 amd64 | `freebsd14-amd64.tar.gz`; `.pkg` | 6 ferramentas Unix | Alvo cruzado com sysroot FreeBSD 14.3; sem validação de execução no FreeBSD. Não há paridade com o sandbox Linux. |
| macOS x86_64 | `macos-x86_64.tar.gz` | 4 ferramentas centrais | Alvo cruzado com SDK MacOS 13.3; sem assinatura, notarização ou validação de execução no macOS. |
| macOS aarch64 | `macos-aarch64.tar.gz` | 4 ferramentas centrais | Mesmas limitações do macOS, para Apple Silicon. |
| Windows x86_64 | `windows-x86_64.zip` | 4 ferramentas centrais | Alvo cruzado MinGW; sem validação de execução no Windows. Não há paridade com o sandbox Linux; não exponha o servidor como se tivesse esse confinamento. |

Os nomes dos arquivos têm prefixo `evelin-v4.4.0-`.

As **4 ferramentas centrais** são `evelin-server`, `evelin-client`,
`evelin-keygen` e `evelin-multisig-verify`. As **6 ferramentas Unix** acrescentam
`evelin-agent` e `evelin-keyscan`. As **11 ferramentas Linux** também incluem
`evelin-sandbox-probe`, `evelin-seccomp-probe`, `evelin-fixed-export-pg-dump`,
`evelin-fixed-export-forgejo-tar` e `evelin-fixed-export-forgejo-tar-validator`.
Um binário compilado não significa que todos os comandos ou backends estão
implementados naquele sistema.

Os arquivos incluem man pages, guias em inglês/pt-BR, licenças e metadados de
build. Bibliotecas da API C são incluídas onde compiladas, com
`include/evelin.h`; confira os resultados estáticos/compartilhados reais no
manifesto. Arquivos não Windows oferecem `bin/ev` como link para `evelin-client`.

## Comandos de compilação

A árvore fixa Rust 1.93.0 e versiona `Cargo.lock`. Use resolução de dependências
travada. Desenvolvimento nativo Linux:

```sh
cargo build --locked --release --workspace
cargo test --locked --release --workspace
```

Linux x86_64 musl exige o alvo e um compilador/linker musl:

```sh
rustup target add x86_64-unknown-linux-musl
cargo build --locked --release --workspace --target x86_64-unknown-linux-musl
```

Para compilação cruzada das ferramentas centrais, instale primeiro o alvo Rust
e o SDK/linker real do sistema, depois configure o linker específico do alvo no
Cargo. Exemplo para um ambiente MinGW já configurado:

```sh
rustup target add x86_64-pc-windows-gnu
CARGO_TARGET_X86_64_PC_WINDOWS_GNU_LINKER=x86_64-w64-mingw32-gcc \
  cargo build --locked --release --target x86_64-pc-windows-gnu \
  -p evelin-client -p evelin-server --no-default-features \
  --bin evelin-client --bin evelin-server \
  --bin evelin-keygen --bin evelin-multisig-verify
```

Os demais alvos são `aarch64-linux-android`, `x86_64-unknown-freebsd`,
`x86_64-apple-darwin` e `aarch64-apple-darwin`. Android exige clang do NDK e nível
de API; FreeBSD exige sysroot compatível; macOS exige SDK Apple e linker
adequado. `rustup target add` sozinho não fornece essas dependências. Desabilite
features padrão do servidor quando o alvo não puder compilar o suporte a shell
PTY e selecione somente seus binários suportados.

Empacote os resultados concluídos com o empacotador do repositório:

```sh
python3 scripts/package-release.py \
  --bin-dir target/x86_64-unknown-linux-musl/release \
  --platform linux-x86_64-musl --out dist --toolchain rustc-1.93.0
```

Informe a toolchain real; o contêiner musl do lançamento pode usar a revisão
1.93.1 e a registra separadamente. O empacotador seleciona binários operacionais
e docs bilíngues, grava proveniência e checksum do arquivo e exclui relatórios
temporários e prompts do workspace.

## GNU Guix e atualização de servidores

GNU Guix executa diretamente o arquivo Linux musl. Instale em um prefixo do
usuário como `~/.local/bin` ou use a definição Guix conforme
[empacotamento](../../packaging/README.pt-BR.md). Não coloque arquivos manuais em
`/gnu/store`. Resolva caminhos de executáveis para seus alvos canônicos na store
ao configurar um validador PostgreSQL de exportação fixa.

Na atualização, guarde o binário e a configuração anteriores, valide o servidor
novo sob a conta real do serviço com `--check`, reinicie o serviço pretendido e
verifique um novo comando autenticado e uma transferência de arquivo. Uma
conexão existente não comprova o funcionamento do novo listener. Caminhos do
gerenciador de serviços e raízes permitidas devem refletir a instalação real.

## Restrições da exportação fixa

Exportações fixas são compiladas somente para Linux, não Android. Exigem
instância isolada com canais comuns de exec/shell/cópia/encaminhamento
desabilitados e Landlock antes do runtime nas duas pontas. Instâncias comuns
com shell pulam Landlock; seccomp legado pós-runtime não filtra todos os workers
assíncronos existentes. Uma partida comum bem-sucedida ou a presença de um probe
não comprova confinamento do processo inteiro.

O auxiliar PostgreSQL espera um produtor ELF no caminho compilado
`/usr/bin/pg_dump`. O wrapper Debian é recusado; uma implantação com executáveis
PostgreSQL versionados deve selecionar e compilar o caminho real e depois
gerar o hash da definição novamente. Veja o [guia de exportação fixa](fixed-export.md).
