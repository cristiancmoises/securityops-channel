# Evelin examples and cookbook

Practical, copy-pasteable recipes for the Evelin toolchain, built around the
shipped example files and the manual pages.

Evelin is a post-quantum secure tunnel: ML-KEM-1024 for key encapsulation,
ML-DSA-87 for signatures, ChaCha20-Poly1305 for the record layer. The
user-facing commands are shaped like OpenSSH's, but the wire protocol is not
SSH-compatible.

A short note on how this page is grounded: every flag, default, and config key
below was checked against a file in this repository. Where a command's exact
syntax comes from a manual page it is presented as verified. Where it comes only
from the `README.md` quickstart (because the manual page does not enumerate that
subcommand) it is tagged **(README)** so you know the source. Anything the repo
does not document is left out rather than guessed at — see
[Sources and omissions](#sources-and-omissions) at the end.

## The toolchain

From the `README.md` toolchain table, the binaries you will use here:

| Binary | OpenSSH analog | What it does |
|---|---|---|
| `evelin-server` | `sshd` | server daemon |
| `evelin-client` | `ssh` | client (exec, shell, file copy, port forward, SOCKS, jump, proxy-command) |
| `evelin-keygen` | `ssh-keygen` | generate identity keys |
| `evelin-agent` | `ssh-agent` | hold unlocked keys in memory |
| `evelin-keyscan` | `ssh-keyscan` | discover server fingerprints |

## Before you start

A few facts that will save you time, all drawn from the repo docs:

- **Paths inside `.toml` files are not shell-expanded.** TOML does not evaluate
  `$HOME` or `~`. Use absolute paths inside `client.toml` and `server.toml`
  (`/home/you/.config/evelin/id.evelin`, not `~/.config/evelin/id.evelin`). On
  the command line, `~` is fine because your shell expands it there.
- **Validate a server config before you rely on it.** `evelin-server --check`
  loads and parses the TOML, checks the identity-key path and bind address, and
  verifies the `authorized_keys` file is loadable, then exits `0` (valid) or `1`
  (invalid) without binding the network. Use it after every config edit.
- **The server config parser is strict.** Per `evelin.conf(5)`, unknown keys
  cause startup failure — "typos in security-relevant config must not silently
  widen policy." This matters below, because the shipped `examples/server.toml`
  and `evelin.conf(5)` disagree on some `[ratelimit]` key names. The config crate
  (`crates/evelin-config/src/lib.rs`) is authoritative for what the parser
  accepts, and it matches the example file's names — the `evelin.conf(5)` names
  are stale. Run `--check` after any edit to confirm your file parses.
- **There is no `--log-level` flag.** The client uses `-v`/`-vv`/`-vvv` for
  detail and `-q` for errors only; `RUST_LOG` overrides the filter. Client
  `log_level` is retained for compatibility but does not control console level.
  The server still uses its configured `log_level` or `RUST_LOG`.

---

## Walkthrough: `examples/server.toml`

This is the shipped server example. Every key it contains is explained below,
with the semantics cross-checked against the config crate
(`crates/evelin-config/src/lib.rs`) and `evelin.conf(5)` — where the two
disagree, the crate is authoritative.

```toml
bind            = "0.0.0.0:2200"
identity_key    = "/etc/evelin/server.key"
authorized_keys = "/etc/evelin/authorized_keys"

log_format = "json"
log_level  = "info"
```

### Top-level keys

- **`bind`** — TCP listen address, `host:port`. Optional in the config crate
  (`crates/evelin-config/src/lib.rs` defaults it to `0.0.0.0:2200`), though you
  should set it explicitly in practice. Use `127.0.0.1` for local-only,
  `0.0.0.0` to listen on all interfaces. (`evelin.conf(5)` calls it "Required",
  but the code supplies a default.)
- **`identity_key`** — path to the server's long-term ML-DSA-87 identity key.
  Required. Its file mode must be `0600` or stricter, or the daemon refuses to
  start.
- **`authorized_keys`** — path to the per-server allowlist of client identity
  fingerprints (format in the [authorized_keys walkthrough](#walkthrough-examplesauthorized_keys) below).
- **`log_format`** — `text` or `json`. The config crate
  (`crates/evelin-config/src/lib.rs`) defaults to `json`, which the example file
  recommends for production; `text` is the human-readable alternative.
  (`evelin.conf(5)` states the default as `text`, but that is stale relative to
  the code.)
- **`log_level`** — one of `trace`, `debug`, `info`, `warn`, `error`. Default
  `info`. The filter follows `tracing-subscriber` syntax, so values like
  `evelin=debug,hyper=warn` also work.

### `[ratelimit]`

```toml
[ratelimit]
per_ip_connect_per_sec            = 5
per_ip_handshake_failures_per_min = 10
ban_duration_seconds              = 300
max_tracked_ips                   = 65536
handshake_timeout_seconds         = 10
```

Per-IP connection throttling and handshake-failure banning. The example
comments claim these values are the defaults, but the config crate
(`crates/evelin-config/src/lib.rs`) sets looser defaults —
`per_ip_connect_per_sec = 50`, `per_ip_handshake_failures_per_min = 100`,
`ban_duration_seconds = 60`, `handshake_timeout_seconds = 30`, and
`max_tracked_ips = 65536`. Omitting the section gives those looser values, not
the tighter ones shown here.

> **Naming discrepancy — the example file is correct.** The example uses
> `per_ip_connect_per_sec`, `per_ip_handshake_failures_per_min`,
> `ban_duration_seconds`, `max_tracked_ips`, and `handshake_timeout_seconds`.
> The config crate (`crates/evelin-config/src/lib.rs`, `RateLimitCfg` with
> `deny_unknown_fields`) accepts exactly these five keys, so the example file
> parses. `evelin.conf(5)` instead documents `per_ip_cps` and
> `per_ip_max_failures_per_min` and omits `max_tracked_ips` and
> `handshake_timeout_seconds` — those man-page names are stale and are **not**
> accepted by the parser. Run `evelin-server --config … --check` after any edit
> to confirm your file parses.

To disable rate limiting, the example notes you set the connect-per-sec and the
failures-per-min layers to `0` (both `0` disables it entirely).

### `[network_acl]`

```toml
[network_acl]
deny  = []
allow = []
```

Pre-handshake CIDR allow/deny, evaluated before the rate limiter.

- **`deny`** — deny-listed CIDR blocks. Default empty.
- **`allow`** — allow-listed CIDR blocks. When non-empty, a peer must match one
  or it is rejected. Default empty (permissive).

Semantics from `evelin.conf(5)` and the file's own comments: `deny` wins over
`allow`; the parser is strict and rejects a CIDR with non-zero host bits (a bad
entry fails at config-load time with its index named); and an IPv4-mapped IPv6
address (`::ffff:1.2.3.4`) only matches IPv6 entries, so list both forms if you
want to block an address in both spaces.

### `[identity_limits]`

```toml
[identity_limits]
max_sessions_per_identity = 8
```

- **`max_sessions_per_identity`** — cap on concurrent sessions per client
  fingerprint, counted after the handshake. Default `8`; `0` disables the cap.

### `[session_rate]`

```toml
[session_rate]
exec_per_sec     = 10
filecopy_per_sec = 5
forward_per_sec  = 20
burst_multiplier = 3
```

Per-session token-bucket limits on how fast an authenticated peer may open
channels of each kind. All four values here are the `evelin.conf(5)` defaults.

- **`exec_per_sec`** — exec channel-opens per second. Default `10`.
- **`filecopy_per_sec`** — filecopy channel-opens per second. Default `5`.
- **`forward_per_sec`** — forward channel-opens per second. Default `20`.
- **`burst_multiplier`** — bucket capacity is `rate * burst_multiplier`.
  Default `3`. Setting a rate to `0` disables that bucket.

### `[audit_log]`

```toml
[audit_log]
# path         = "/var/log/evelin/audit.log"
max_bytes     = 52428800   # 50 MiB
keep_rotated  = 7
honeypot      = false
```

An append-only audit log, independent of journald.

- **`path`** — audit log file. Commented out here, and an empty/unset `path` is
  the default, which means **no audit log is written**. Uncomment and set a
  path to enable it.
- **`max_bytes`** — rotate the active file once it exceeds this size. The
  example uses `52428800` (50 MiB), which is exactly the config-crate default
  (`crates/evelin-config/src/lib.rs`, `default_audit_max_bytes` = 50 MiB).
  (`evelin.conf(5)` gives the default as `1 MiB`, but that is stale relative to
  the code.) On rotation the active file becomes `<path>.1`, older files shift
  up, and the oldest is deleted.
- **`keep_rotated`** — number of rotated files to retain. `7` here, which is
  also the documented default.
- **`honeypot`** — when `true`, `handshake_fail` events include the
  attacker-presented client fingerprint (which is redacted by default).
  Default `false`. Useful for threat-intel on a honeypot node; unwise on a
  production deployment.

---

## Walkthrough: `examples/client.toml`

```toml
server_addr        = "evelin.example.com:2200"
identity_key       = "/home/you/.config/evelin/id.evelin"
server_fingerprint = "0000000000000000000000000000000000000000000000000000000000000000"

log_format = "text"
log_level  = "info"
```

The client config keys are described here from the example file's own comments
(`evelin.conf(5)` documents the server's config specifically).

- **`server_addr`** — the server's `host:port`. The client man page confirms
  this key: `--addr <ADDR>` on the command line "Override server_addr from
  config."
- **`identity_key`** — path to your client identity key. Use an absolute path
  (paths in the TOML are not shell-expanded).
- **`server_fingerprint`** — the server's identity fingerprint, 64 hex
  characters (the all-zeros value shown is a placeholder to replace). The
  example comment describes it as "the SHA-256 of the server's encoded
  ML-DSA-87 verifying key." The comment suggests two ways to obtain it: read it
  from the server's startup log (the `server_fingerprint` field on the
  "evelin server listening" line), or from the server-side identity key. For
  discovering a server's fingerprint over the network, `evelin-keyscan` is the
  documented tool — see [Discover a server's fingerprint](#discover-a-servers-fingerprint).
- **`log_format`** — `text` by default for the client; logs always go to stderr.
- **`log_level`** — retained in client config for compatibility; use `-v`/`-q`
  or `RUST_LOG` to select the console level.

Identity fingerprints are SHA-256 of the encoded ML-DSA-87 public key,
yielding 32 bytes / 64 hex characters. Transfer them over a trusted independent
channel before pinning them in the client.

---

## Walkthrough: `examples/authorized_keys`

```
# evelin-authorized-keys v1
# One non-comment line per authorized peer:
#   <hex SHA-256 fingerprint>  <comment>
# 0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef  alice@workstation
```

This is the server-side allowlist of client identities. Format, per
`evelin.conf(5)`:

- The **first non-blank, non-comment line must be the literal header**
  `# evelin-authorized-keys v1`. A file without it is rejected at parse time.
- Each subsequent non-comment line is one authorized peer:
  a **64-hex-character fingerprint**, then optional whitespace and an optional
  comment (for example `alice@workstation`).
- `evelin.conf(5)` states the **file mode must be `0600`**, but the loader
  (`crates/evelin-keys/src/lib.rs`, `AuthorizedKeys::load`) does **not** enforce
  any mode — it reads the file whatever its permissions, unlike the identity
  key, whose group/other bits are a hard startup error. The `README.md`
  deployment notes even `chmod 644` this file. Treat the mode as operator
  hygiene, not an enforced requirement, but keep write access restricted so an
  attacker cannot add fingerprints.

Lines beginning with `#` are comments. In the shipped example every peer line is
commented out, so it authorizes nobody until you add a real fingerprint line
under the header.

---

## Recipes

### Generate an identity key

`evelin-keygen` writes a new identity key to `--out`. With no passphrase option
the key is written unencrypted (v1 format).

```sh
# Unencrypted key:
evelin-keygen --out ~/.config/evelin/id.evelin

# Passphrase-wrapped, reading the passphrase from an environment variable:
EVELIN_PASS='correct horse battery staple' \
  evelin-keygen --out ~/.config/evelin/id.evelin --passphrase-from-env EVELIN_PASS

# Passphrase from a file descriptor (0 = stdin):
evelin-keygen --out ~/.config/evelin/id.evelin --passphrase-from-fd 0
```

Argon2id parameters for the passphrase wrap are tunable, with these documented
defaults:

```sh
# Defaults are: --argon2-m 65536 (KiB = 64 MiB), --argon2-t 3, --argon2-p 1
EVELIN_PASS='…' \
  evelin-keygen --out ~/.config/evelin/id.evelin \
    --passphrase-from-env EVELIN_PASS \
    --argon2-m 131072 --argon2-t 4 --argon2-p 1
```

All flags above are from `evelin-keygen(1)`. After generating a key, tighten its
mode: `chmod 600 ~/.config/evelin/id.evelin`.

### Discover a server's fingerprint

`evelin-keyscan` connects to a server and reports its host key. The address is a
positional `host:port` argument.

```sh
# Default (text) output:
evelin-keyscan evelin.example.com:2200

# Human-friendly output:
evelin-keyscan --format pretty evelin.example.com:2200

# known-hosts format:
evelin-keyscan --format known-hosts evelin.example.com:2200

# Longer connect + read timeout (default is 10 seconds):
evelin-keyscan --timeout 30 evelin.example.com:2200
```

Flags from `evelin-keyscan(1)`: `--format <FORMAT>` accepts `text` (the
default), `pretty`, and `known-hosts`; `--timeout <TIMEOUT>` is the connect +
read timeout in seconds (default `10`).

> **Security caveat.** A fingerprint scanned over the network is only as
> trustworthy as the network path to the server — keyscan gives you the key the
> peer *presents*, not proof of who it is. The repo consistently advises
> obtaining the server fingerprint out-of-band (phone, paper, signed email) and
> comparing it to what you scan before you trust it.

### Run a remote command

> **Client invocation, and where its syntax comes from.** `evelin-client(1)`
> documents the top-level options `--config <CONFIG>` (required),
> `--addr <ADDR>`, `--connect-timeout <CONNECT_TIMEOUT>`, and
> `--proxy-command <PROXY_COMMAND>`, plus a trailing `[COMMAND]`. It does **not**
> enumerate the action subcommands (`exec`, `shell`, `cp`, `forward`, `socks`,
> `jump`). The exact subcommand syntax in the next few recipes is taken from the
> `README.md` "Client side — first connection" quickstart and is tagged
> **(README)**; the `README.md` toolchain table confirms these client
> capabilities exist (exec, shell, file copy, port forward, SOCKS, jump,
> proxy-command).

Run a single command on the server **(README)**:

```sh
evelin-client --config ~/.config/evelin/client.toml exec uname -a
```

The server must allow the command. `[exec] allow` is an allow-list of exact
`argv0` strings (the command's first whitespace-separated token): the server
runs a request only when its `argv0` exactly equals a listed entry
(`crates/evelin-session/src/exec.rs`). An empty list disables exec entirely.
(`evelin.conf(5)` calls these "glob patterns" with an `echo *` example, but the
shipping code does exact `argv0` matching, not globbing, so a wildcard entry
would never match.)

You can pair the exec call with the man-page-documented top-level options — for
example a shorter connection timeout, or overriding the server address from the
config:

```sh
# --connect-timeout and --addr are documented in evelin-client(1):
evelin-client --config ~/.config/evelin/client.toml \
  --connect-timeout 5 --addr evelin.example.com:2200 exec uname -a
```

### Interactive shell

Open an interactive session **(README)**:

```sh
evelin-client --config ~/.config/evelin/client.toml shell
```

> **Interactive shell needs a build feature.** The `README.md` deployment notes
> state that `[shell]` requires the `pty-shell` Cargo feature at build time, and
> the shipped musl tarball is built without it. The config field is accepted by
> the parser either way, but a server compiled without `pty-shell` refuses
> `pty-req` at runtime. Use a build with the feature (rebuild with
> `cargo build --release --features pty-shell -p evelin-server`, or the
> `pty-shell` published binary) if you need PTY shells.

### Copy files (both directions)

Copy a local file up to the server **(README)** — the remote side is written
with a `remote:` prefix:

```sh
evelin-client --config ~/.config/evelin/client.toml cp ./local.txt remote:/tmp/
```

The download direction uses the same `remote:` prefix on the *source*:

```sh
evelin-client --config ~/.config/evelin/client.toml cp remote:/tmp/report.txt ./
```

On a TTY, `cp` shows an scp-style progress bar on **stderr** — percentage,
transferred/total, rate, and ETA — then a one-line summary
(`… SHA-256 verified · Quantum-secured!`). It is verbosity-aware: `-q`
silences the bar and summary entirely (errors only, like `scp -q`), and
`-v` adds per-file detail. Because progress and logs go to stderr, the
transferred bytes on stdout stay clean.

```sh
# quiet: no bar, no summary — only errors
evelin-client -q --config ~/.config/evelin/client.toml cp ./big.iso remote:/srv/
```

> **Grounding note.** The `README.md` quickstart shows the upload form
> (`cp ./local.txt remote:/tmp/`) verbatim; the download form above applies the
> same `remote:`-prefix convention to the source and is not shown verbatim in
> the quickstart. The `-q`/`-v` flags and the progress-bar shape are per
> `crates/evelin-client/src/progress.rs`.

Filecopy must be enabled server-side. Per the config crate
(`crates/evelin-config/src/lib.rs`, `FileCopyPolicyCfg` with
`deny_unknown_fields`), the `[filecopy]` section takes `roots` (a list of path
prefixes under which transfers must canonicalise — empty, the default, denies
filecopy entirely), `allow_upload` and `allow_download` (both `bool`, default
`false`), and `max_file_size` (a per-transfer cap; `0`, the default, means no
policy limit). This matches the `README.md` deployment notes. There is no
`enabled` or `chroot` key — the strict parser rejects them — so `evelin.conf(5)`,
which documents `enabled` + `chroot` + `max_file_size`, is stale here. Confirm
your file parses with `evelin-server --check`.

### Local port forward

Forward a local TCP port to a destination reachable from the server **(README)**:

```sh
# Listen locally on 8080, forward to internal.example:80 via the server:
evelin-client --config ~/.config/evelin/client.toml forward -L 8080:internal.example:80
```

The server must permit the destination. Per the config crate
(`crates/evelin-config/src/lib.rs`, `ForwardPolicyCfg`), `[forward] allow` is the
list of `host:port` destinations a client may forward TCP to (the default is
empty, which disables forwarding), and `wildcards` (`bool`, default `false`)
lets a `"*"` host entry match anything. This matches the `README.md`
server-setup snippet.

> **Config-key note.** `evelin.conf(5)` names this key `[forward] allow_dst`,
> but the shipping code accepts `[forward] allow` (plus `wildcards`); the
> man-page name is stale. Confirm your file parses with `evelin-server --check`.

The `-L` flag itself is from the `README.md` quickstart, not the client man page.

### SOCKS proxy

Run a local SOCKS5 dynamic forward **(README)**:

```sh
# Local SOCKS5 proxy on port 1080, tunneled through the server:
evelin-client --config ~/.config/evelin/client.toml socks -D 1080
```

Point a browser or `curl --socks5 127.0.0.1:1080 …` at it. As with `-L`, each
SOCKS `CONNECT` opens a `direct-tcpip` channel on the server, so the server side
must permit the outbound destinations
([`[forward] allow`](#local-port-forward), plus `wildcards`). The `-D`
flag is from the `README.md` quickstart.

### Jump host and proxy-command

`--proxy-command` is the man-page-documented way to reach a server through an
intermediary. From `evelin-client(1)`:

> `--proxy-command <PROXY_COMMAND>` — External proxy command — equivalent of
> OpenSSH's `ProxyCommand`. The given shell command is launched and its
> stdin/stdout become the transport for the Evelin handshake. Use this for HTTP
> CONNECT proxies, jumphosts via SSH, corporate-network tunneling tools, or
> anything else that gives you a byte-pipe to the server.

So any command that produces a byte-pipe to the server works as the transport:

```sh
# Reach the server through a corporate HTTP CONNECT proxy (from README):
evelin-client --config ~/.config/evelin/client.toml \
  --proxy-command 'corkscrew proxy.corp 8080 $EVELIN_HOST $EVELIN_PORT' \
  exec hostname
```

> The `--proxy-command` flag and its description are verified in
> `evelin-client(1)`. The `$EVELIN_HOST` / `$EVELIN_PORT` placeholders in the
> `corkscrew` example are shown in the `README.md` quickstart but are **not**
> described in the man page, so treat those specific substitutions as
> README-sourced.

The `README.md` quickstart also shows a dedicated `--jump` flag as a
convenience:

```sh
# --jump is shown in the README quickstart, not in evelin-client(1):
evelin-client --config ~/.config/evelin/client.toml \
  --jump bastion.example:2200 exec hostname
```

Because `--jump` is not in the man page, prefer `--proxy-command` (which is
documented) if you want to rely only on man-page-verified flags.

### Use the agent

`evelin-agent` holds unlocked identity keys in memory and exposes them over a
Unix socket. At least one `--identity` is required, and the flag may be
repeated.

```sh
# Load a single key:
evelin-agent --identity ~/.config/evelin/id.evelin

# Load several keys:
evelin-agent --identity ~/.config/evelin/work.evelin \
             --identity ~/.config/evelin/home.evelin

# Unlock passphrase-wrapped identities from an environment variable:
EVELIN_PASS='…' \
  evelin-agent --identity ~/.config/evelin/id.evelin --passphrase-from-env EVELIN_PASS

# Bind the socket somewhere explicit (default is $XDG_RUNTIME_DIR/evelin-agent.sock):
evelin-agent --identity ~/.config/evelin/id.evelin \
  --socket /run/user/1000/evelin-agent.sock

# Cap concurrent client connections (default 32):
evelin-agent --identity ~/.config/evelin/id.evelin --max-connections 8
```

All flags above are from `evelin-agent(1)`: `--identity <IDENTITY>` (required,
repeatable), `--passphrase-from-env <VAR>` (used if any loaded identity is
wrapped), `--socket <SOCKET>` (default `$XDG_RUNTIME_DIR/evelin-agent.sock`),
and `--max-connections <MAX_CONNECTIONS>` (default `32`).

> **What the man page does not cover.** `evelin-agent(1)` documents the agent's
> own options but not how `evelin-client` is told to consume the agent socket
> (there is no documented client flag or environment variable for it in the man
> pages). Rather than invent one, this recipe stops at starting the agent and
> loading keys.

### Server operations

Starting and validating the daemon, all from `evelin-server(8)`:

```sh
# Start the server:
evelin-server --config /etc/evelin/server.toml

# Validate the config and exit (0 = valid, 1 = invalid); does not bind or listen.
# Good for systemd ExecStartPre, CI, or checking an edit before a reload:
evelin-server --config /etc/evelin/server.toml --check

# Generate a new identity key on startup if the configured path does not exist:
evelin-server --config /etc/evelin/server.toml --init

# -c is the short form of --config:
evelin-server -c /etc/evelin/server.toml --check
```

---

## Sources and omissions

Everything above was verified against a file in this repository:
`examples/server.toml`, `examples/client.toml`, `examples/authorized_keys`,
`crates/evelin-config/src/lib.rs` and `crates/evelin-session/src/exec.rs`
(the authoritative config schema and exec-matching source),
`man/evelin.conf.5`, `man/evelin-client.1`, `man/evelin-server.8`,
`man/evelin-keygen.1`, `man/evelin-keyscan.1`, `man/evelin-agent.1`, and the
`README.md` toolchain table and quickstart. Where `evelin.conf(5)` disagreed
with the config crate, the crate (what the parser actually accepts) wins.

Deliberately left out or explicitly attributed for lack of man-page grounding:

- The client action subcommands (`exec`, `shell`, `cp`, `forward -L`,
  `socks -D`, `--jump`) are **not** enumerated in `evelin-client(1)`; their
  exact syntax is tagged **(README)** because it comes from the `README.md`
  quickstart.
- Reverse port forwarding (`reverse-forward -R`) is not in the requested recipe
  set and is not covered here.
- The `$EVELIN_HOST` / `$EVELIN_PORT` proxy-command placeholders are shown as
  README-sourced, since the man page does not describe them.
- The mechanism by which `evelin-client` consumes the `evelin-agent` socket is
  not documented in the man pages, so it is not asserted.
- Several `evelin.conf(5)` directives are stale relative to the shipping config
  crate (`crates/evelin-config/src/lib.rs`), and the walkthroughs above are
  corrected to the code: the `[ratelimit]` key names and defaults, the
  `[forward]` key (`allow`, not `allow_dst`), the `[filecopy]` schema
  (`roots` + `allow_upload` + `allow_download` + `max_file_size`, not
  `enabled` + `chroot`), the `[exec] allow` matching (exact `argv0`, not glob),
  and the `log_format` and audit `max_bytes` defaults. Confirm your file parses
  with `evelin-server --check`.
```

## Receive a server-defined export (Linux, v4.4.0)

Use `evelin-client fixed-export` with a dedicated exporter service to receive a
PostgreSQL custom dump or restricted Forgejo pax archive. The client supplies an
ID, definition hash, expected format and byte ceiling, and writes a new private
local destination. Read [fixed exports](fixed-export.md) for the complete
server policy and receiver recipe: this mode requires pre-runtime Landlock and
refuses inherited terminal descriptors, generic remote commands and paths.
