> Tradução para pt-BR de `GOVERNANCE.md`. Em caso de divergência, a versão em inglês prevalece.

# Governança

Este documento descreve como o Evelin é conduzido e como as decisões são
tomadas. Ele é deliberadamente curto porque o modelo é simples.

## Modelo do projeto: mantenedor único (BDFL)

O Evelin foi fundado e é mantido por **Cristian Cezar Moisés / SecurityOps**
(`sac@securityops.co`), que é o único mantenedor e tem a palavra final em todas
as decisões do projeto: código, protocolo, lançamentos, licenciamento e este
documento.

O repositório de código-fonte primário fica em uma instância privada do Forgejo
(`git.securityops.co`), acessível apenas ao mantenedor. Um espelho público
somente-leitura é publicado em `https://github.com/cristiancmoises/evelin` para
revisão. Não há rastreador público de issues — todo contato passa por
`sac@securityops.co`.

## Como as decisões são tomadas

- O mantenedor revisa toda alteração proposta e decide o que é mesclado.
- Alterações sensíveis à segurança e que afetam o protocolo recebem a revisão
  mais rigorosa. O trabalho do protocolo v2 é a referência para esse padrão:
  alterações no formato de transmissão devem manter o material negociado dentro do
  transcript de handshake assinado, e mudanças de comportamento são travadas por
  testes antes do lançamento.
- Correções de segurança passam pelo mesmo processo de revisão de código e CI
  que qualquer outra alteração — não há atalho para hotfix (veja `SECURITY.md`).
- Quando um lançamento já publicado acaba contendo uma afirmação incorreta ou um
  defeito, a correção é publicada, não escondida — veja `docs/V4_0_0_ERRATA.md` e
  o histórico de correções em `CHANGELOG.md`.

## Relatando bugs

Envie um e-mail para `sac@securityops.co`. Não há rastreador público de issues,
então o e-mail é o caminho tanto para relatos de bugs quanto para perguntas
gerais. Inclua a versão que você executa, sua plataforma e o que você observou
em comparação com o que esperava.

## Relatando vulnerabilidades

Nunca relate problemas de segurança em qualquer canal público. Siga o
`SECURITY.md`:

- Envie um e-mail para `sac@securityops.co` com o prefixo de assunto
  `[SECURITY]`.
- Texto simples é aceitável para o contato inicial; uma impressão digital de
  chave PGP é publicada em
  `https://securityops.co/.well-known/pgp/security.asc`.
- O projeto adota uma janela de divulgação de 90 dias contada a partir do
  reconhecimento, credita quem relata a menos que a pessoa solicite anonimato,
  não exige NDA e não tomará medidas legais contra quem relata de boa-fé.

## Propondo funcionalidades

Descreva o problema antes de escrever código. Envie um e-mail para
`sac@securityops.co` com o que você está tentando fazer e por que o lançamento
atual não consegue fazê-lo. O mantenedor dirá se a direção se encaixa no projeto
antes de você investir em um patch — propostas que afetam o protocolo, em
particular, podem ser recusadas independentemente da qualidade da implementação.

Se você contribuir com código, os termos do `NOTICE` se aplicam: sua
contribuição é licenciada sob os mesmos termos de licença dupla que o restante
do projeto, e contribuições significativas podem ser reconhecidas no `CHANGELOG`
e na lista de contribuidores.

## Disciplina de lançamento

- Todo tarball de lançamento é distribuído com um arquivo `SHA256SUMS`;
  verifique com `sha256sum -c SHA256SUMS`.
- A assinatura de lançamento (PGP por uma chave de lançamento do projeto) está
  planejada, mas **ainda não implementada** no processo de lançamento do CI
  (`.forgejo/workflows/release.yml`); os lançamentos são atualmente verificados
  apenas pelos seus checksums `SHA256SUMS`.
- Relatórios de auditoria por lançamento são distribuídos, com checksum, junto
  aos artefatos de cada lançamento; o relatório atual fica em `docs/` (para a
  v4.1, `docs/V4_1_AUDIT_REPORT.md`).
- O histórico completo por versão está em `CHANGELOG.md`.

O Evelin é autolançado: não houve auditoria criptográfica paga de terceiros, e
as notas de lançamento declaram as limitações em vez de omiti-las. Essa política
de honestidade é uma regra de governança, não uma preferência de estilo — as
afirmações sobre o software devem ser verificáveis em relação ao código-fonte
distribuído e ao seu registro de auditoria.

## Caminho para mantenedores adicionais

Não há processo formal. Contribuições sustentadas e de alta qualidade — código,
revisão, achados de segurança — são como a confiança se acumula. Conceder
qualquer nível de acesso de mantenedor fica a critério exclusivo do mantenedor
atual, e o modelo de mantenedor único permanece até que isso mude
explicitamente.

## Alterações neste documento

O mantenedor pode alterar este documento a qualquer momento. A versão no
repositório é a autoritativa.
