> Tradução para pt-BR de `CODE_OF_CONDUCT.md`. Em caso de divergência, a versão em inglês prevalece.

# Código de Conduta do Contributor Covenant

## Nosso Compromisso

Nós, como membros, contribuidores e líderes, nos comprometemos a fazer da
participação em nossa comunidade uma experiência livre de assédio para todas as
pessoas, independentemente de idade, tamanho corporal, deficiência visível ou
invisível, etnia, características sexuais, identidade e expressão de gênero,
nível de experiência, escolaridade, condição socioeconômica, nacionalidade,
aparência pessoal, raça, casta, cor, religião ou identidade e orientação
sexual.

Comprometemo-nos a agir e interagir de maneiras que contribuam para uma
comunidade aberta, acolhedora, diversa, inclusiva e saudável.

## Nossos Padrões

Exemplos de comportamentos que contribuem para um ambiente positivo em nossa
comunidade incluem:

* Demonstrar empatia e gentileza com as outras pessoas
* Respeitar opiniões, pontos de vista e experiências diferentes
* Oferecer e aceitar de bom grado críticas construtivas
* Assumir a responsabilidade e pedir desculpas às pessoas afetadas por nossos
  erros, aprendendo com a experiência
* Focar no que é melhor não apenas para nós individualmente, mas para a
  comunidade como um todo

Exemplos de comportamentos inaceitáveis incluem:

* Uso de linguagem ou imagens sexualizadas e atenção ou investidas sexuais de
  qualquer tipo
* Provocações (trolling), comentários insultuosos ou depreciativos e ataques
  pessoais ou políticos
* Assédio público ou privado
* Publicar informações privadas de outras pessoas, como endereço físico ou de
  e-mail, sem sua permissão explícita
* Outras condutas que possam razoavelmente ser consideradas inadequadas em um
  ambiente profissional

## Responsabilidades de Aplicação

Os líderes da comunidade são responsáveis por esclarecer e fazer cumprir nossos
padrões de comportamento aceitável e tomarão medidas corretivas apropriadas e
justas em resposta a qualquer comportamento que considerem inadequado,
ameaçador, ofensivo ou nocivo.

Os líderes da comunidade têm o direito e a responsabilidade de remover, editar
ou rejeitar comentários, commits, código, edições em wiki, issues e outras
contribuições que não estejam alinhadas a este Código de Conduta e comunicarão
os motivos das decisões de moderação quando apropriado.

## Escopo

Este Código de Conduta se aplica a todos os espaços da comunidade e também se
aplica quando uma pessoa estiver representando oficialmente a comunidade em
espaços públicos. Exemplos de representação da nossa comunidade incluem usar um
endereço de e-mail oficial, publicar por meio de uma conta oficial em rede
social ou atuar como representante designado em um evento on-line ou
presencial.

## Aplicação

Casos de comportamento abusivo, de assédio ou de qualquer outra forma
inaceitável podem ser denunciados aos líderes da comunidade responsáveis pela
aplicação em
sac@securityops.co.
Todas as denúncias serão analisadas e investigadas de forma rápida e justa.

Todos os líderes da comunidade têm a obrigação de respeitar a privacidade e a
segurança de quem relatar qualquer incidente.

## Diretrizes de Aplicação

Os líderes da comunidade seguirão estas Diretrizes de Impacto na Comunidade ao
determinar as consequências de qualquer ação que considerem uma violação deste
Código de Conduta:

### 1. Correção

**Impacto na Comunidade**: Uso de linguagem inadequada ou outro comportamento
considerado não profissional ou indesejado na comunidade.

**Consequência**: Uma advertência privada, por escrito, dos líderes da
comunidade, esclarecendo a natureza da violação e explicando por que o
comportamento foi inadequado. Um pedido público de desculpas pode ser
solicitado.

### 2. Advertência

**Impacto na Comunidade**: Uma violação por meio de um incidente isolado ou de
uma série de ações.

**Consequência**: Uma advertência com consequências para comportamento
continuado. Nenhuma interação com as pessoas envolvidas, incluindo interação
não solicitada com quem estiver aplicando o Código de Conduta, por um período
determinado. Isso inclui evitar interações em espaços da comunidade, bem como
em canais externos, como redes sociais. A violação destes termos pode levar a
um banimento temporário ou permanente.

### 3. Banimento Temporário

**Impacto na Comunidade**: Uma violação grave dos padrões da comunidade,
incluindo comportamento inadequado continuado.

**Consequência**: Banimento temporário de qualquer tipo de interação ou
comunicação pública com a comunidade por um período determinado. Nenhuma
interação pública ou privada com as pessoas envolvidas, incluindo interação não
solicitada com quem estiver aplicando o Código de Conduta, é permitida durante
esse período. A violação destes termos pode levar a um banimento permanente.

### 4. Banimento Permanente

**Impacto na Comunidade**: Demonstrar um padrão de violação dos padrões da
comunidade, incluindo comportamento inadequado continuado, assédio a uma pessoa
ou agressão ou depreciação a classes de pessoas.

**Consequência**: Banimento permanente de qualquer tipo de interação pública
dentro da comunidade.

## Atribuição

Este Código de Conduta é adaptado do [Contributor Covenant][homepage],
versão 2.1, disponível em
[https://www.contributor-covenant.org/version/2/1/code_of_conduct.html][v2.1].

As Diretrizes de Impacto na Comunidade foram inspiradas na
[escada de aplicação do código de conduta da Mozilla][Mozilla CoC].

Para respostas a perguntas comuns sobre este código de conduta, consulte o FAQ
em [https://www.contributor-covenant.org/faq][FAQ]. Traduções estão disponíveis
em [https://www.contributor-covenant.org/translations][translations].

[homepage]: https://www.contributor-covenant.org
[v2.1]: https://www.contributor-covenant.org/version/2/1/code_of_conduct.html
[Mozilla CoC]: https://github.com/mozilla/inclusion
[FAQ]: https://www.contributor-covenant.org/faq
[translations]: https://www.contributor-covenant.org/translations
