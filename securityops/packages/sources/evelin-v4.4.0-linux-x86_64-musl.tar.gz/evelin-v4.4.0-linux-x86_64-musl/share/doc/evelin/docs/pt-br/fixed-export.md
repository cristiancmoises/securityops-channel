# Exportações fixas no Evelin 4.4.0

[English](../en/fixed-export.md) · [Índice da documentação](README.md)

`evelin-client fixed-export` recebe uma exportação identificada de um servidor
Evelin dedicado. O cliente informa ID do exportador, formato esperado, SHA-256
da definição e limite de bytes. O servidor escolhe o produtor local. O cliente
não pode fornecer comando remoto, caminho, argumentos, valores de ambiente ou
credenciais. O recurso vem desabilitado e está disponível somente no Linux.

## Formatos e limites

| Formato na CLI | `format` no servidor | Produtor | Validação local |
|---|---|---|---|
| `postgresql-custom` (padrão) | `1` | `evelin-fixed-export-pg-dump` | `pg_restore --list` fixado |
| `forgejo-tar-pax` | `2` | `evelin-fixed-export-forgejo-tar` | Parser interno estrito pax/ustar, sem extração |

O auxiliar PostgreSQL usa socket local de banco e opções de produção fixos.
Ele recebe nome do banco e papel local por seus próprios argumentos controlados
pelo operador. O caminho compilado do produtor é `/usr/bin/pg_dump`, cujo
alvo canônico precisa ser um executável ELF. O script `pg_wrapper` do Debian é
recusado: nesse sistema, a implantação exige selecionar e compilar o caminho do
executável `pg_dump` versionado antes de calcular o hash da definição. Use uma
identidade dedicada no banco com as permissões de leitura necessárias ao dump.

O auxiliar Forgejo lê a raiz compilada `/var/lib/forgejo`. Sua política fixa
inclui repositórios compatíveis, anexos, avatares, LFS e dados de pacotes.
Exclui configuração, credenciais, hooks, dados temporários/de sessão, arquivos
de banco SQLite e outros caminhos sensíveis; membros de arquivo que sejam links
simbólicos estão desabilitados. Namespaces desconhecidos ou mudanças inesperadas
na origem podem recusar a exportação. O arquivo sozinho **não é um backup
completo do Forgejo**: coordene a consistência da aplicação e gerencie o banco
e as configurações excluídas separadamente. A política canônica fica em
[`forgejo_policy.rs`](../../crates/evelin-session/src/fixed_export/forgejo_policy.rs).

A exportação só conclui dentro dos limites de bytes e tempo das duas pontas.
Não há retomada, seleção de arquivo remoto ou produtor escolhido pelo cliente.

## Servidor dedicado

Use uma instância e porta Evelin separadas para exportações fixas. Habilitar o
recurso em uma instância comum de shell/cópia falha na validação. Provisione sua
identidade e `authorized_keys` antes de iniciar; `--init` é recusado quando
exportações fixas estão habilitadas.

Servidor e cliente receptor exigem **Landlock ABI v3 totalmente aplicado** antes
de iniciar seus runtimes assíncronos. A falta de suporte causa erro na partida,
sem fallback. O servidor dedicado exige `seccomp.mode = "off"`: a instalação
legada do seccomp no servidor comum não filtra todos os workers já existentes,
portanto este modo não afirma aplicar seccomp ao processo inteiro.

Este é um modelo de configuração. Substitua todos os campos em maiúsculas e os
UIDs/GIDs ilustrativos pelos valores locais verificados. O socket deve existir
antes de habilitar o exportador ou executar `--check` com ele habilitado.

```toml
bind = "127.0.0.1:7223"
identity_key = "/etc/evelin-export/identity.key"
authorized_keys = "/etc/evelin-export/authorized_keys"

[shell]
enable = false
[exec]
allow = []
[forward]
allow = []
wildcards = false
[reverse_forward]
allow = []
[agent_forward]
enable = false
[filecopy]
roots = []
allow_upload = false
allow_download = false
max_file_size = 0
[seccomp]
mode = "off"

[fixed_export]
enabled = true
max_concurrent = 1

[[fixed_export.exporters]]
id = "forgejo-data"
socket_path = "/run/evelin-fixed-export/forgejo-data.sock"
socket_owner_uid = 991
socket_parent_uid = 0
backend_peer_uid = 0
backend_peer_gid = 0
format = 2
definition_sha256 = "SUBSTITUA_PELOS_64_DIGITOS_HEX"
allowed_client_fingerprints = ["SUBSTITUA_PELO_FINGERPRINT_DO_CLIENTE_AUTORIZADO"]
max_bytes = 42949672960
ready_timeout_seconds = 10
idle_timeout_seconds = 300
max_runtime_seconds = 21600
commit_timeout_seconds = 60
```

O ID tem de 1 a 64 letras ASCII minúsculas/dígitos, com `.`, `_` e `-` permitidos
após a letra/dígito inicial. IDs e caminhos de socket devem ser únicos. O limite
global de concorrência recusa o excesso sem enfileirá-lo. Todo fingerprint de
exportador também deve constar no `authorized_keys`.

Sockets devem ter modo `0600`, um link, proprietário configurado e caminho
absoluto e canônico. O diretório pai precisa ter o proprietário configurado e
não permitir escrita por grupo/outros. O servidor fixa a identidade do inode e
valida `SO_PEERCRED`; `backend_peer_uid`/`backend_peer_gid` identificam o ativador
do socket em um listener systemd `Accept=yes` e devem ser verificados no host
real. Substituir o socket exige reiniciar o servidor dedicado para fixá-lo de
novo.

## Serviço do backend local

Use um socket AF_UNIX controlado por root em `/run/evelin-fixed-export` e um
serviço por conexão. Ambos os auxiliares verificam o caminho esperado do socket
e o UID do serviço Evelin. A conta Evelin não pode escrever nos argumentos do
serviço, no executável nem no diretório do socket.

No systemd, o auxiliar espera `Accept=yes`, `StandardInput=socket`,
`StandardOutput=socket` e `StandardError=null`. Use `KillMode=control-group`, o
padrão `ExitType=main`, `TimeoutStopSec` finito, `SendSIGKILL=yes` e
`RuntimeMaxSec` cobrindo o prazo total do auxiliar mais uma pequena margem de
limpeza. Verifique se a saída do auxiliar esvazia seu cgroup por conexão. O
auxiliar PostgreSQL também encerra o grupo de processos do produtor. Mantenha
o acesso ao sistema de arquivos somente para leitura e restrito ao necessário.

Calcule o hash da definição com o executável e os argumentos exatos do serviço;
por exemplo:

```sh
evelin-fixed-export-forgejo-tar \
  --source-owner-uid 992 --allowed-peer-uid 991 \
  --expected-socket-path /run/evelin-fixed-export/forgejo-data.sock \
  --max-bytes 42949672960 --idle-timeout-seconds 300 \
  --wall-timeout-seconds 21600 --print-definition-sha256
```

A definição vincula a implementação do auxiliar e a política fixa do produtor.
Recalcule e distribua o hash à configuração do servidor e aos clientes
autorizados após mudar o binário ou sua definição. `--print-definition-sha256`
não realiza uma exportação. Execute `--check` antes de iniciar o servidor
dedicado, usando a mesma conta de serviço e o mesmo ambiente.

## Preparar o receptor

Configuração do cliente, identidade e qualquer `known_hosts` existente devem
usar caminhos absolutos canônicos, arquivos regulares privados, pertencentes
ao UID receptor, com um link e ancestrais controlados. Use modo `0600`. O
endpoint vem de `server_addr`; seu fingerprint já deve estar fixado na
configuração ou arquivo de confiança. A exportação fixa recusa `--addr`,
`--jump`, `--proxy-command` e encaminhamento de agente.

Crie um diretório de destino separado, do usuário receptor, com modo `0700`.
Seu caminho precisa ser absoluto e canônico; ele não pode conter configuração,
identidade ou arquivos de confiança do cliente. O destino não pode existir,
nem como link simbólico. O validador PostgreSQL deve ficar fora desse diretório
gravável, ser executável canônico de root sem escrita por grupo/outros, com
ancestrais controlados por root. Resolva links de perfis da distribuição ou do
Guix para o caminho real antes de usar `--validator-program`.

Descritores padrão herdados de terminal ou arquivos regulares são recusados.
Use `/dev/null` na entrada e pipes ou sockets de log do gerenciador de serviços
na saída; descritores inesperados acima de 2 também são recusados. Esta receita
Bash envia as duas saídas por pipe e preserva o status do cliente com `pipefail`:

```bash
set -o pipefail
mkdir -p "$HOME/evelin-exports"
chmod 700 "$HOME/evelin-exports"
evelin-client --config "$HOME/.evelin/export-client.toml" fixed-export \
  --producer-id forgejo-data --format forgejo-tar-pax \
  --definition-sha256 SUBSTITUA_PELOS_64_DIGITOS_HEX \
  --max-bytes 42949672960 \
  --destination "$HOME/evelin-exports/forgejo-2026-09-06.tar" \
  </dev/null 2>&1 | cat
```

Para PostgreSQL, escolha `--format postgresql-custom`, o ID do exportador de
banco configurado e `--validator-program /CAMINHO/ABSOLUTO/CANONICO/pg_restore`.
O cliente fixa os argumentos em `--list`; não há restauração. Não forneça
`--validator-program` para `forgejo-tar-pax`.

| Opção do cliente | Padrão (segundos) |
|---|---:|
| `--open-timeout-seconds` | 10 |
| `--idle-timeout-seconds` | 300 |
| `--max-runtime-seconds` | 21600 |
| `--validator-timeout-seconds` | 240 |
| `--commit-timeout-seconds` | 30 |

Defina `commit_timeout_seconds` no servidor com tempo suficiente para fsync,
validação e recálculo do hash locais; arquivos grandes em armazenamento lento
podem exceder o padrão de 60 segundos. O prazo de commit do cliente começa
quando ele envia o commit.

## Conclusão e recuperação

O receptor escreve um arquivo parcial aleatório de modo `0600` no diretório de
destino. Verifica resultado do produtor, formato, tamanho e SHA-256, sincroniza
o arquivo, valida-o, relê seu hash e sincroniza o diretório. Depois envia um
novo desafio no commit. A publicação usa um link sem substituição para o inode
parcial fixado, somente após a confirmação correspondente vincular desafio,
tamanho, hash e hash da definição.

Falhas antes dessa confirmação removem o parcial criado. Uma falha após a
confirmação preserva o parcial durável e informa que é necessária recuperação
local. Inspecione o parcial e o destino final antes de tentar novamente; não
presuma que um código de saída diferente de zero significa ausência de dados
já confirmados. Destinos existentes nunca são sobrescritos.

O executável independente `evelin-fixed-export-forgejo-tar-validator` lê um
arquivo pela entrada padrão e usa o mesmo parser sem extraí-lo:

```sh
evelin-fixed-export-forgejo-tar-validator < forgejo-2026-09-06.tar
```

A aprovação do parser confirma a estrutura suportada do arquivo, não a
consistência da aplicação nem uma restauração testada. Um exercício real de
restauração continua separado da validação do transporte da exportação.
