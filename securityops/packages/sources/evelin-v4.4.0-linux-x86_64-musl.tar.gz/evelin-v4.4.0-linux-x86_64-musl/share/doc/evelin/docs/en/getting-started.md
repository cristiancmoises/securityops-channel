# Getting started with Evelin

Evelin is a post-quantum secure tunnel: a self-hosted, SSH-style
service that carries commands, shells, and file copies over an
encrypted connection. Every handshake uses **ML-KEM-1024** for key
exchange and **ML-DSA-87** for mutual authentication — both NIST
level 5 post-quantum primitives — with **ChaCha20-Poly1305** as the
transport cipher.

This page takes you from a fresh install to your first authenticated
connection: generate an identity key, configure a server, authorize a
client, verify the server's fingerprint, and then run a command, open
a shell, and copy a file.

If you want the fuller conceptual walkthrough, read
[`docs/QUICKSTART.md`](../QUICKSTART.md). For a production Docker +
Forgejo deployment, read [`INSTALL.md`](../../INSTALL.md).

## The pieces

This guide uses three of Evelin's binaries:

- **`evelin-server`** — the daemon that listens for connections.
- **`evelin-client`** — the tool you use to connect.
- **`evelin-keygen`** — generates identity keys (run once per
  machine).

And four files you will create:

- An **identity key** for the server (`server.key`) and one per
  client (`id.evelin`). A long-lived ML-DSA-87 keypair, kept private,
  used to prove who you are on every handshake.
- A **fingerprint** for each identity — the SHA-256 of its public
  half, printed as 64 hex characters. Short enough to read aloud or
  paste into a chat.
- The server's **`authorized_keys`** file — the list of client
  fingerprints it will accept. Like `~/.ssh/authorized_keys`.
- The client's **`server_fingerprint`** pin in `client.toml` — the
  one server identity that client will trust. Like an entry in
  `~/.ssh/known_hosts`, but pinned explicitly before the first
  connection. There is no trust-on-first-use.

## Install

### Option A — build from source

You need a Rust toolchain (install from <https://rustup.rs>). From a
checkout of the repository:

```bash
cargo build --release \
    --bin evelin-server \
    --bin evelin-client \
    --bin evelin-keygen
```

This produces the three binaries under `target/release/`. Copy them
somewhere on your `PATH` (for example `/usr/local/bin` or
`~/.local/bin`). For a fully static Linux binary with no glibc
dependency, add `--target x86_64-unknown-linux-musl`.

### Option B — prebuilt release archives

Download the matching archive from the
[v4.4.0 release](https://github.com/cristiancmoises/evelin-mirror/releases/tag/v4.4.0).
The asset list records which targets and formats were built for this release.
Verify the download against its published SHA-256 manifest, unpack it and put
the binaries on your `PATH`. Linux musl builds avoid a glibc dependency and can
also be installed per-user under `~/.local/bin` on GNU Guix. A cross-compiled
artifact is not by itself evidence of a runtime test or equal sandbox support.

### Option C — Docker / Forgejo

For a container-based deployment driven by Forgejo Actions (build,
release, and a published Docker image), follow
[`INSTALL.md`](../../INSTALL.md) end to end.

## Step 1 — Generate the server identity

Pick a directory the server process can read but nothing else can. On
a personal setup `~/.config/evelin/` is fine; for a system service
use a root-owned `/etc/evelin/`.

```bash
evelin-keygen --out /etc/evelin/server.key
```

`evelin-keygen` prints where it wrote the key and the identity's
fingerprint:

```
wrote identity to /etc/evelin/server.key (unencrypted)
fingerprint: 7f494dead0d59a99c2f8b1e74c2a3c4f1e2d3a4b5c6d7e8f9012345678901234
```

**Write down that fingerprint.** It is the value each client pins as
its `server_fingerprint` (Step 5). You can also recover it later from
the server's startup log (Step 4).

Identity-key files must be mode `0600` — the loader refuses to read
anything broader:

```bash
chmod 600 /etc/evelin/server.key
```

`evelin-keygen` refuses to overwrite an existing file, so it will not
silently replace a key you already have.

### Optional: passphrase-protect a key

`evelin-keygen` can also write the identity file in a
passphrase-wrapped format (Argon2id + ChaCha20-Poly1305). Supply the
passphrase through an environment variable:

```bash
EVELIN_PASS='…' evelin-keygen --out /path/to/id \
    --passphrase-from-env EVELIN_PASS
```

You can also read the passphrase from a file descriptor with
`--passphrase-from-fd 0` (stdin). The Argon2id cost parameters default
to memory `--argon2-m 65536` (64 MiB), iterations `--argon2-t 3`, and
parallelism `--argon2-p 1`; pass those flags to change them.

Note, though, that `evelin-server` and `evelin-client` load only
unencrypted identity files — they take no passphrase — so keep the
server and client identity keys unencrypted. The passphrase-wrapped
format is consumed by `evelin-agent`, which reads the passphrase with
`--passphrase-from-env`.

## Step 2 — Write a minimal server config

The server reads a TOML file. A minimal config needs a bind address, a
path to the identity key, and a path to the authorized-keys file:

```toml
# /etc/evelin/server.toml
bind            = "0.0.0.0:2200"
identity_key    = "/etc/evelin/server.key"
authorized_keys = "/etc/evelin/authorized_keys"

log_format      = "text"   # "json" for production / log aggregators
log_level       = "info"
```

`identity_key` and `authorized_keys` are required; `bind` is
optional and defaults to `0.0.0.0:2200`. Bind to `127.0.0.1` for a
local-only server, or `0.0.0.0` for all interfaces. The config is
parsed strictly — an unknown key fails startup rather than silently
widening policy.

> **Paths are literal.** The TOML parser does not expand `~` or
> `$HOME`. Always write absolute paths, e.g.
> `/home/you/.config/evelin/server.key`, not `~/.config/...`.

## Step 3 — Authorize a client key

First, generate a client identity on the client machine, exactly as in
Step 1:

```bash
evelin-keygen --out ~/.config/evelin/id.evelin
```

```
wrote identity to /home/alice/.config/evelin/id.evelin (unencrypted)
fingerprint: 57a616ad35e8779f7a5d7fc374858131d812f3387b3cf48c8182d156fb6ced62
```

```bash
chmod 600 ~/.config/evelin/id.evelin
```

Send that client fingerprint to whoever runs the server. On the
server, list it in the `authorized_keys` file. The format is exact:

```
# evelin-authorized-keys v1
57a616ad35e8779f7a5d7fc374858131d812f3387b3cf48c8182d156fb6ced62  alice@laptop
```

- The first non-blank, non-comment line **must** be the literal
  header `# evelin-authorized-keys v1`.
- Each following line is one peer: a 64-hex-character fingerprint,
  then an optional comment. Comments are advisory — they help humans
  audit the file and are not used for matching.
- The file must be mode `0600`.

```bash
chmod 600 /etc/evelin/authorized_keys
```

## Step 4 — Start the server

```bash
evelin-server --config /etc/evelin/server.toml
```

You will see a startup line naming the bind address and the server's
own fingerprint:

```
INFO evelin server listening bind=0.0.0.0:2200 server_fingerprint=7f494dead0d59a99…
```

That `server_fingerprint` is the value clients pin in Step 5 — this is
a second place to read it, in case you did not note it during Step 1.

The server runs in the foreground; stop it with `Ctrl-C`. Two flags
help before and during startup:

- `evelin-server --config … --check` validates the config and exits
  without binding or listening — it parses the TOML, checks the
  identity-key path, the bind address, and that `authorized_keys`
  loads. Exit code `0` means valid. Good for a quick check after
  editing the config.
- `evelin-server --config … --init` generates a new identity key at
  the configured `identity_key` path if the file does not yet exist.

If the log warns that the authorized-keys file is empty or missing, no
clients will be accepted — revisit Step 3.

## Step 5 — Configure the client and pin the server fingerprint

On the client machine, write `client.toml`:

```toml
# ~/.config/evelin/client.toml
server_addr        = "server.example.com:2200"
identity_key       = "/home/alice/.config/evelin/id.evelin"

# The server's fingerprint from Step 1 / Step 4, pinned here.
server_fingerprint = "7f494dead0d59a99c2f8b1e74c2a3c4f1e2d3a4b5c6d7e8f9012345678901234"

log_format         = "text"
log_level          = "info"
```

The `server_fingerprint` is the host-key verification step. On every
connection the client compares the identity the server presents
against this pinned value. If they differ, the client refuses the
connection and aborts the handshake with `authorization denied` —
that either means you pinned the wrong fingerprint, or something is
impersonating the server. There is no trust-on-first-use; you obtain the fingerprint
out of band (from Step 1 or the Step 4 log, over a channel you trust)
and pin it before you connect.

As with the server, `identity_key` must be an absolute path, and the
key file must be mode `0600`.

## Step 6 — First connection: run a command

`evelin-client` connects and runs a subcommand over the same
post-quantum-authenticated session. The simplest is `exec`, which runs
one command on the server, streams its output back, and exits with the
remote process's exit code:

```bash
evelin-client --config ~/.config/evelin/client.toml exec uptime
```

For this to work the command must be on the server's exec allow list.
Add an `[exec]` section to `server.toml` and restart the server:

```toml
[exec]
allow = ["uptime"]
```

An empty or absent allow list denies exec entirely — that is the safe
default. The allow list matches the command's `argv0`.

By default the client is quiet, like `ssh`: a successful connection
prints only the command's own output, nothing about the handshake. To
see the connection lifecycle, add `-v` (repeatable):

```bash
evelin-client -v --config ~/.config/evelin/client.toml exec uptime
# stderr: ... INFO evelin_client: handshake complete endpoint=... server_fingerprint=...
```

`-v` is INFO, `-vv` DEBUG, `-vvv` TRACE; `-q` shows errors only. All
logs go to **stderr**, so the command's stdout stays clean for piping.
A non-empty `RUST_LOG` overrides these.

Two more client flags are useful here:

- `--addr host:port` overrides `server_addr` from the config for a
  single run.
- `--connect-timeout <seconds>` sets the connection timeout.

If the client's key is not in the server's `authorized_keys`, the
server closes the connection during the handshake — the client
reports a handshake failure (a `wire encoding error`) and the server
logs the rejection (Step 3). If the client logs `connection refused`,
the server is not running or a firewall is in the way.

## Open an interactive shell

```bash
evelin-client --config ~/.config/evelin/client.toml shell
```

This spawns a shell inside a PTY on the server and bridges your
terminal to it. The server side must be **built with the `pty-shell`
feature** and must enable shell sessions in `server.toml`:

```toml
[shell]
enable  = true
command = "/bin/sh"
```

`command` defaults to `/bin/sh`. The `shell` subcommand also accepts
`--term`, `--cols`, and `--rows` to set the initial terminal type and
size. Use `exit` or `Ctrl-D` to close the session.

## Copy a file

The `cp` subcommand copies a file in either direction. One side of the
copy must be a `remote:` path (an absolute path on the server); the
other is a local path.

```bash
# Upload: local → server
evelin-client --config ~/.config/evelin/client.toml \
    cp ./local-file.txt remote:/srv/uploads/local-file.txt

# Download: server → local
evelin-client --config ~/.config/evelin/client.toml \
    cp remote:/srv/data/report.pdf ./report.pdf
```

Enable file copy on the server by listing the roots under which remote
paths must fall, and by allowing the direction(s) you need:

```toml
[filecopy]
roots          = ["/srv/uploads", "/srv/data"]
allow_upload   = true
allow_download = true
```

An empty `roots` list denies file copy entirely. Both `allow_upload`
and `allow_download` default to off, so you must opt each direction in.

## When it does not connect

Read the client's error message; most first-time failures map to one
of these:

| Client says | Cause | Fix |
|---|---|---|
| `connection refused` | Server not running, or a firewall blocks the port | Confirm `evelin-server` is up; check the host firewall |
| `authorization denied` | Pinned `server_fingerprint` does not match the identity the server presented | Re-read the server fingerprint (Step 1 / Step 4) and correct `client.toml` |
| `wire encoding error` mid-handshake | Client fingerprint is not in the server's `authorized_keys`, so the server closed the connection | Add it and restart (Step 3); the server log records the rejection |
| `cryptographic verification failed` | The server's handshake signature did not verify — tampering in flight, or a corrupted server key | Investigate the network path; re-fetch the server identity |
| `insecure mode …; expected 0o600` | Identity-key file is broader than `0600` | `chmod 600` the key file |

For a verbose handshake trace, set `log_level = "debug"` in
`client.toml` (there is no `--log-level` flag; the client's verbosity
comes from the `log_level` in its config).

## Where to go next

- [`docs/QUICKSTART.md`](../QUICKSTART.md) — the same path in more
  depth, plus a systemd unit for running the server as a service and a
  fuller troubleshooting table.
- [`INSTALL.md`](../../INSTALL.md) — Docker and Forgejo Actions
  deployment.

For the exact set of flags and directives, the manual pages are
authoritative: `evelin-keygen(1)`, `evelin-client(1)`,
`evelin-server(8)`, and `evelin.conf(5)`.

## Fixed exports (v4.4.0, Linux)

For a server-defined PostgreSQL custom dump or restricted Forgejo data archive,
follow [fixed exports](fixed-export.md). This requires a separate dedicated
server, explicit exporter authorization, fully enforced pre-runtime Landlock
and a private destination. Do not enable it in the general-purpose instance
configured above. The new export channel does not change the key/trust setup
for ordinary exec, shell and file copy.
