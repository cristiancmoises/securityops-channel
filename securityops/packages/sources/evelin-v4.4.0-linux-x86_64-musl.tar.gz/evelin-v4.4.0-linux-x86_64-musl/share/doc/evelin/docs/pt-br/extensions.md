> Tradução para pt-BR de `docs/en/extensions.md`. Em caso de divergência, a versão em inglês prevalece.

# Extensões e negociação de capacidades

Esta página descreve a arquitetura de extensões do Evelin exatamente como
ela existe na árvore de código-fonte da v4.4.0. Duas coisas distintas na base
de código foram, em momentos diferentes, chamadas de "extensões"; este
documento as mantém separadas porque elas são conectadas de formas bem
diferentes:

1. **Negociação de capacidades do protocolo-v2** (`crates/evelin-negotiation`) —
   o mecanismo real, ativo e vinculado ao transcript pelo qual dois pares
   concordam sobre recursos opcionais por conexão. Este é o mecanismo de
   extensão que de fato roda hoje.
2. **O campo de bits de extensão `EVLN-EXT-1.5`** (`crates/evelin-ext`) — uma
   primitiva mais antiga, *fornecida-mas-nunca-conectada*. Ela é compilada e
   testada em testes unitários, mas nunca é enviada nem lida na rede. O
   release v3.4 corrigiu documentação anterior que havia afirmado o
   contrário; essa correção está descrita abaixo.

De início, o fato arquitetural mais importante: **o Evelin não tem nenhum
sistema dinâmico de plugins em tempo de execução.** Não há `dlopen`, não há
`libloading`, não há diretório de plugins, não há macro de registro. Toda
capacidade é compilada dentro do binário e negociada por conexão. O "porquê"
está em
[Não há carregamento dinâmico de plugins](#não-há-carregamento-dinâmico-de-plugins--e-por-quê).

## A versão curta

- Uma "extensão" que você pode ativar hoje é uma **capacidade do protocolo-v2**:
  uma pequena entrada `(id, value)` carregada dentro do corpo assinado do
  handshake.
- A negociação de capacidades é **opt-in**. Deployments padrão falam o
  protocolo v1 e são idênticos byte a byte na rede aos releases mais antigos.
  Você habilita o v2 definindo `max_protocol_version = 2` em **ambas** as
  pontas.
- O que é ativado é a **interseção** do que ambos os pares oferecem, reduzida
  por uma função pura. Nenhum par pode habilitar unilateralmente um recurso.
- Os bytes negociados ficam no transcript **assinado**, então removê-los ou
  alterá-los quebra a assinatura ML-DSA-87 e o handshake é abortado. É isso
  que torna a negociação resistente a downgrade.
- Exatamente duas capacidades estão definidas no registro hoje:
  `MAX_FRAME_LOG2` (ativa; controla o tamanho do frame de record) e `REKEY`
  (negociada e exposta, mas reservada — ainda não conectada a nenhum
  comportamento).

## O que é uma extensão na rede

O mecanismo ativo é definido em `crates/evelin-negotiation/src/lib.rs` e
carregado pelas mensagens de handshake em
`crates/evelin-handshake/src/messages.rs`.

Uma **capacidade** é um par `(id, value)`:

- `id` é um `u16` de um registro fixo (o módulo `cap` — veja abaixo).
- `value` tem de 0 a 256 bytes; seu significado é definido por id. Flags que
  são apenas de presença carregam um valor vazio.

Um **bloco de capacidades** é a codificação canônica de um conjunto de
capacidades:

```text
CapabilityBlock :=
    u16  count                 (number of capabilities, big-endian)
    Capability * count         (strictly ascending by id, no duplicates)

Capability :=
    u16  id                    (big-endian)
    u16  value_len             (big-endian, <= 256)
    u8   value[value_len]
```

A codificação é **canônica**: ids estritamente ascendentes, sem duplicatas,
comprimentos mínimos. Como o bloco de bytes é uma função determinística do
conjunto de capacidades, ambos os pares fazem hash de bytes idênticos e a
igualdade é inequívoca. O conjunto vazio codifica para exatamente os dois
bytes `00 00`.

Na rede do handshake o bloco é **prefixado por comprimento** para ser
autodelimitado dentro do stream:

```text
u16  caps_len || caps_bytes
```

Este bloco emoldurado é anexado ao **corpo** de `HelloClient` e `HelloServer`
no protocolo v2. O bloco do cliente fica após seu `kem_pk || id_pk || nonce`;
o do servidor fica após seu `id_pk || kem_ct || nonce` e antes da assinatura
ML-DSA-87 final. `Finish` não carrega bloco de capacidades.

Limites rígidos aplicados pelo decodificador (constantes em
`crates/evelin-negotiation/src/lib.rs`):

| Constante | Valor | Propósito |
|---|---|---|
| `MAX_CAPABILITIES` | 64 | Número máximo de entradas em um bloco. |
| `MAX_VALUE_LEN` | 256 | Número máximo de bytes em um valor de capacidade. |
| `MAX_ENCODED_LEN` | 16 642 | Maior bloco canônico possível (`2 + 64 × 260`); um bloco grande demais é rejeitado antes de ser lido do stream. |

`Capabilities::decode` é somente-canônico: ids desordenados ou duplicados,
bytes sobrando, valores grandes demais ou uma contagem grande demais são
todos rejeitados. Rejeitar entrada não canônica é deliberado — remove
qualquer margem de manobra que um adulterador pudesse usar para fazer dois
pares calcularem conjuntos de capacidades diferentes a partir de bytes
"equivalentes". O decodificador passa por fuzzing (um LCG semeado empurra
centenas de milhares de entradas por ele na CI) para garantias de nunca-panic
e roundtrip.

## Como a negociação decide o que fica ativo

### Opt-in pela versão do protocolo

A negociação só acontece no **protocolo v2**, e o v2 é estritamente opt-in.
O interruptor é a chave de config `max_protocol_version` (`crates/evelin-config`,
padrão `1`):

- Com `max_protocol_version = 1` (o padrão, seja na config do cliente ou na do
  servidor), nenhum bloco de capacidades é enviado. A rede é idêntica byte a
  byte ao protocolo v1 pré-v4.0.
- Com `max_protocol_version = 2` em **ambas** as pontas, cada lado monta uma
  oferta de capacidades e a conexão negocia o v2.
- Um servidor capaz de v2 ainda aceita clientes v1 (o handshake v1 permanece
  inalterado), então a ordem de migração suportada é servidores primeiro,
  depois clientes. Um cliente v2 contra um servidor somente-v1 é rejeitado.
- Valores diferentes de `1` ou `2` são rejeitados na inicialização (cliente:
  `validate_protocol_settings`; servidor: `run_check`).

O campo de versão fica no **cabeçalho** da mensagem
(`magic || version || msg_type || reserved`). O cabeçalho é **apenas uma dica
de parsing** — ele não é alimentado no hash do transcript. A autenticação do
que foi negociado vem inteiramente do bloco de capacidades estar no *corpo*
assinado, não do campo de versão.

### Ambos os pares oferecem; uma função pura decide

Cada lado constrói uma oferta `Capabilities` e a coloca em seu Hello. Depois
que o handshake autentica ambas as ofertas, cada lado calcula
independentemente o resultado com `negotiate(client, server)` em
`crates/evelin-negotiation/src/lib.rs`:

- A redução sobre cada capacidade compartilhada é **comutativa e associativa**
  (mínimo para `MAX_FRAME_LOG2`, AND lógico para `REKEY`), então
  `negotiate(c, s)` e `negotiate(s, c)` concordam nos campos compartilhados.
  Ambos os pares chegam ao mesmo resultado `Negotiated` **sem uma volta
  extra**.
- Uma capacidade só entra em vigor se **ambos** os pares a ofereceram. Nenhum
  par pode habilitar unilateralmente um recurso.
- O resultado é retornado como uma struct `Negotiated` em `HandshakeOutput`.
  O código de transporte a lê (por exemplo `out.negotiated.max_frame_bytes()`)
  e a aplica.

### Resistência a downgrade por construção

O bloco de capacidades está embutido no **corpo** da mensagem, que é coberto
pelo hash do transcript que cada lado assina com ML-DSA-87. O protocolo v2 usa
rótulos distintos de separação de domínio — `evelin/2/hello-client`,
`evelin/2/hello-server`, `evelin/2/finish` (veja
`crates/evelin-core/src/protocol.rs`), versus os rótulos `evelin/1/*` para o
v1. Consequências:

- Remover, alterar ou injetar o bloco de capacidades muda o transcript que o
  par originador produziu, então a assinatura não verifica mais e o handshake
  é abortado.
- Reescrever o campo de versão do cabeçalho não ajuda um atacante: um cliente
  v2 exige um `HelloServer` v2 e vice-versa (`client.rs` rejeita uma
  incompatibilidade de versão com `Error::Wire("protocol version mismatch")`),
  e um transcript v1 nunca pode colidir com um v2 porque os rótulos diferem.

Esta é toda a base da resistência a downgrade aqui: o resultado negociado é
autenticado porque suas entradas estão vinculadas ao transcript.

### Validação estrita de oferta (v4.1)

`negotiate` retorna um `Result`. Ele rejeita, em qualquer das ofertas:

- `MAX_FRAME_LOG2` abaixo de `MIN_MAX_FRAME_LOG2` = 14 (2^14 = 16 KiB, o
  tamanho de frame base do v1 que toda implementação deve aceitar). A camada
  de record faz clamp *para cima* até 16 KiB, então um anúncio menor não pode
  ser honrado, e fazer clamp silenciosamente faria o emissor exceder o que o
  par disse que aceita. Em vez disso, ele aborta.
- Uma capacidade **conhecida** com o formato de valor errado: `MAX_FRAME_LOG2`
  deve ter exatamente um byte; `REKEY` deve ser vazio. Ids desconhecidos
  permanecem opacos — a estritude se aplica apenas onde a semântica está
  definida.

Ambos os pares rodam o `negotiate` idêntico sobre as entradas idênticas
vinculadas ao transcript, então uma oferta malformada produz o mesmo erro nas
duas pontas e os dois lados abortam de forma coerente. No transporte isso
aparece como `Error::Wire("invalid capability offer")`.

## Extensões que existem hoje

Dois ids de capacidade estão definidos no módulo `cap` de
`crates/evelin-negotiation/src/lib.rs`. Ids nunca são reutilizados nem
renumerados.

| Id | Nome | Valor | Regra de negociação | Status |
|---|---|---|---|---|
| `0x0001` | `MAX_FRAME_LOG2` | 1 byte (log base 2 do frame máximo em bytes) | mínimo dos dois anúncios | **Ativa** — controla a camada de record. |
| `0x0002` | `REKEY` | vazio (flag de presença) | AND lógico | Negociada e exposta, mas **reservada** — não conectada a nenhum comportamento. |

### `MAX_FRAME_LOG2` (ativa)

Este é o maior frame de record que um lado está disposto a receber, como um
logaritmo base 2. O valor negociado é `min(client, server)`, e ambas as
pontas o aplicam: no v2 o transporte chama `set_max_frame_len` no
`RecordSender` e no `RecordReceiver` (veja os usos de `set_max_frame_len` nos
`main.rs` do cliente e do servidor), que faz clamp para dentro da faixa
suportada da camada de record `[16 KiB, 1 MiB]` (`MAX_FRAME_LEN` ..
`MAX_FRAME_LEN_BIG` em `crates/evelin-core/src/protocol.rs`).

Operadores controlam o valor anunciado através da chave de config
`max_frame_kib`: uma potência de dois em `[16, 1024]` KiB (padrão `1024`),
validada na inicialização sem arredondamento silencioso.
`evelin_negotiation::log2_for_kib` mapeia KiB para o expoente de rede
(`[14, 20]`); qualquer coisa fora do conjunto suportado retorna `None` e é
rejeitada. `max_frame_kib` só é significativo com `max_protocol_version = 2`;
ele é ignorado em conexões v1.

Em uma conexão **v1** nada é negociado e `set_max_frame_len` não é chamado,
então a camada de record mantém seu padrão de tempo de build de
`MAX_FRAME_LEN_BIG` (1 MiB) — veja a nota da v3.4 abaixo sobre por que frames
grandes funcionam sem negociação.

### `REKEY` (reservada)

`REKEY` é uma flag apenas de presença negociada como um AND lógico. Quando
ambos os pares a anunciam, `out.negotiated.rekey` é `true`. Ela é
deliberadamente **não conectada** a nenhum comportamento: foi reservada para
uma futura cerimônia de rekey, e controlar o ratchet simétrico sempre-ativo da
camada de record com base nela seria uma cerimônia inútil. Ela é mantida no
registro para que o id fique fixo para quando esse protocolo chegar.

## O campo de bits `EVLN-EXT-1.5` e a correção da v3.4

`crates/evelin-ext` é anterior ao crate de negociação da v4. Ele contém duas
primitivas de rede puramente de dados, sem I/O e sem cripto, separadas em seu
próprio crate para que o harness de fuzz e o ferramental de modelo formal
possam depender delas sem puxar `evelin-server`:

- `TicketPlaintext` — o texto claro de 97 bytes do ticket de retomada de
  sessão (seu selamento/abertura vive em `crates/evelin-ticket` e
  `crates/evelin-server/src/resume.rs`; o formato do texto claro *não* é um
  mecanismo de extensão, ele apenas compartilha este crate).
- `Extensions` — um campo de bits `u16` com lógica de combinação `agree()`.
  Bits definidos: `EXT_RESUME` (bit 0), `EXT_BIG_FRAME` (bit 1),
  `EXT_PIPELINE` (bit 2), com `EXT_KNOWN_BITS` mascarando o resto. `agree()`
  calcula `self AND peer` mascarado para bits conhecidos — o mesmo princípio
  de interseção que o negociador da v4 usa.

**Este campo de bits nunca é trocado na rede.** O release v3.4 corrigiu
documentação anterior que havia descrito `EVLN-EXT-1.5` como uma negociação
ativa, na rede, vinculada ao transcript e formalmente provada. Verificado
contra a implementação daquele momento:

- Nenhuma troca de extensão existia na rede; o cliente e o servidor em
  produção rodavam o handshake e então construíam a camada de record com
  padrões fixos de tempo de build.
- O tipo `Extensions` era usado apenas por testes (os próprios testes deste
  crate e os testes de regressão de CVE do servidor). Ainda é.
- O transcript v1 não continha nenhum bit de extensão — apenas os rótulos
  `HELLO_CLIENT` / `HELLO_SERVER` / `FINISH`, sem nada trocado.

O achado da v3.4 foi classificado como um **defeito de honestidade, não uma
vulnerabilidade ativa**: um ataque de downgrade remove uma opção negociada na
rede, e não havia negociação na rede para remover. Frames grandes funcionavam
mesmo assim porque, desde a v2.5, a camada de record faz padrão de ambas as
pontas em `MAX_FRAME_LEN_BIG` (1 MiB) incondicionalmente, então o bit
`BIG_FRAME` nunca foi necessário para desbloqueá-los.

A doc do módulo em `crates/evelin-ext/src/extensions.rs` também registra a
**propriedade obrigatória para qualquer implementador futuro**: se aquele
campo de bits for algum dia colocado na rede, os bytes anunciados por ambos os
pares devem ser incorporados ao transcript assinado. O crate
`evelin-negotiation` da v4 é a resolução construtiva do achado da v3.4 — ele
faz exatamente isso, no corpo assinado, desde o início.

Se você está adicionando um recurso hoje, adicione uma **capacidade do
protocolo-v2** (`evelin-negotiation`). Não estenda o campo de bits
`EVLN-EXT-1.5`; ele é legado e não conectado.

## Adicionando uma nova capacidade na árvore

Percorrido a partir do código-fonte real. Uma capacidade é adicionada
editando Rust compilado — não há arquivo de config nem manifesto de plugin que
introduza uma. Os passos a seguir levam você do registro ao comportamento
ativo.

1. **Reserve um id.** No módulo `cap` de
   `crates/evelin-negotiation/src/lib.rs`, adicione um novo `pub const` `u16`.
   Escolha o próximo id não usado; nunca reutilize nem renumere um existente.
   Documente seu formato de valor e sua regra de negociação no comentário de
   doc.

2. **Adicione o campo de resultado.** Adicione um campo à struct `Negotiated`
   no mesmo arquivo para guardar o resultado acordado (por exemplo
   `Option<u8>` para um valor, `bool` para uma flag de presença). `Negotiated`
   deriva `Default`; garanta que o default signifique "não negociado" (é isso
   que o v1 e o caso um-lado-ausente produzem).

3. **Valide o formato** (apenas se seu id tem semântica definida). Em
   `validate_offer`, adicione uma verificação de que uma capacidade *conhecida*
   carrega um valor bem formado, retornando
   `NegotiationError::MalformedValue(id)` (ou uma variante mais específica que
   você adicione) caso contrário. Ids desconhecidos devem permanecer opacos —
   valide apenas onde você definiu o significado.

4. **Reduza em `negotiate`.** Adicione a redução que combina os valores das
   duas ofertas no seu campo `Negotiated`. Ela **deve** ser comutativa e
   associativa (mínimo, máximo, AND lógico, interseção de conjuntos, …) para
   que ambos os pares calculem o mesmo resultado independentemente da ordem dos
   argumentos. Isto é um requisito de correção, não uma preferência de estilo —
   todo o design sem-volta-extra depende disso.

5. **Exponha uma visão em bytes se necessário.** Se os chamadores precisam de
   um valor derivado (como `MAX_FRAME_LOG2` expõe
   `Negotiated::max_frame_bytes()`), adicione um acessor em `Negotiated`.

6. **Monte a oferta a partir da config.** Em `build_client_offer`
   (`crates/evelin-client/src/main.rs`) e `build_server_offer`
   (`crates/evelin-server/src/main.rs`), adicione sua capacidade ao
   `Capabilities` que cada lado oferece quando `max_protocol_version >= 2`.
   Use `set_flag`, `set_u8` ou `set` — cada um retorna um `Result` que você
   deve tratar (é `#[must_use]`).

7. **Adicione chaves de config** (se controláveis pelo operador). Adicione
   campos às structs de config em `crates/evelin-config/src/lib.rs` com um
   default de `serde`, e valide-os na inicialização junto com as verificações
   existentes (`validate_protocol_settings` no cliente, `run_check` no
   servidor) para que entrada ruim seja rejeitada antes de qualquer conexão —
   sem arredondamento silencioso.

8. **Consuma o resultado no transporte.** Depois do handshake, leia seu
   `out.negotiated.<field>` e aplique-o (como o transporte aplica
   `max_frame_bytes()` via `set_max_frame_len`). Lembre-se de que ele é
   `Default` em conexões v1.

9. **Teste em ambas as camadas.** Adicione testes unitários em
   `evelin-negotiation` (roundtrip de encode/decode, a redução, rejeição de
   formato malformado) e testes de handshake/integração em `evelin-handshake`
   (um handshake v2 que negocia sua capacidade; um byte-flip ou remoção que
   aborta). Mantenha o caminho v1 idêntico byte a byte — há testes de fixação
   existentes que falham se ele for perturbado.

Duas coisas que você **não** precisa tocar: os rótulos de transcript (seu
bloco de capacidades já está dentro do corpo v2 assinado sob os rótulos
`evelin/2/*` existentes), e o enquadramento da mensagem (o bloco prefixado por
comprimento já carrega um conjunto `Capabilities` canônico arbitrário).

## Não há carregamento dinâmico de plugins — e por quê

O Evelin não carrega código de extensão em tempo de execução. Não há `dlopen`
de objetos de plugin, não há `libloading`, não há caminho de busca de plugins,
não há macro de registro, não há hook de scripting no transporte. (A API C
`libevelin` em `crates/evelin-capi` é construída como um `cdylib` para que
*outros* programas possam linkar o Evelin como biblioteca; isso é o Evelin
sendo embutido, não o Evelin carregando plugins de terceiros. O carregamento
de módulo PKCS#11 nos testes de HSM é andaime de teste para o SoftHSM2, não um
sistema de plugins de transporte.)

Extensões são **compiladas dentro do binário e negociadas por conexão**. Para
um túnel crítico em segurança isto é uma escolha de design deliberada, não um
recurso faltante:

- **Superfície de cadeia de suprimentos.** Toda capacidade negociável é Rust
  na árvore que passa pela mesma revisão, o mesmo `#![forbid(unsafe_code)]`, o
  mesmo gate `-D warnings` e o mesmo build reproduzível que o resto do
  transporte. Um Evelin em execução nunca carrega código com o qual não foi
  construído, então um atacante que consiga soltar um arquivo em disco não
  pode introduzir um novo recurso de túnel ou caminho de código. Não há ABI de
  plugin para manter compatível e não há extensão de terceiros para avaliar.
- **Superfície de auditoria.** O conjunto completo de coisas que dois pares
  podem negociar é o registro `cap` — uma lista curta e "greppável" em um único
  arquivo — e a lógica que decide o que ativa é uma única função pura
  (`negotiate`) com um decodificador limitado e fuzzado. Um auditor pode
  enumerar todo o comportamento de extensão lendo
  `crates/evelin-negotiation/src/lib.rs`, em vez de raciocinar sobre código
  arbitrário que algum deployment possa carregar. O que é negociável é fixado
  em tempo de build e idêntico em cada cópia daquele build.
- **Determinismo.** Como a negociação é uma redução pura e comutativa sobre
  entradas vinculadas ao transcript, o resultado é reproduzível e o mesmo em
  ambos os pares. Uma camada de plugin dinâmica faria o conjunto de recursos
  ativos depender de estado de runtime fora do handshake assinado —
  exatamente o tipo de entrada não autenticada que ataques de downgrade
  exploram.

## Onde ler o código-fonte

| Assunto | Arquivo |
|---|---|
| Tipo de capacidade, registro, codec, `negotiate` | `crates/evelin-negotiation/src/lib.rs` |
| Bloco de capacidades nas mensagens Hello / enquadramento | `crates/evelin-handshake/src/messages.rs` |
| Construção da oferta, vinculação ao transcript (cliente) | `crates/evelin-handshake/src/client.rs` |
| Construção da oferta, vinculação ao transcript (servidor) | `crates/evelin-handshake/src/server.rs` |
| Rótulos de transcript, versões de protocolo, constantes de frame | `crates/evelin-core/src/protocol.rs` |
| Chaves de config `max_protocol_version`, `max_frame_kib` | `crates/evelin-config/src/lib.rs` |
| Oferta ativa + aplicação do resultado | `crates/evelin-client/src/main.rs`, `crates/evelin-server/src/main.rs` |
| Campo de bits legado `EVLN-EXT-1.5` + texto claro do ticket | `crates/evelin-ext/src/extensions.rs`, `crates/evelin-ext/src/ticket.rs` |

## Limitações honestas e não-afirmações

- **O contador de métricas não rastreia capacidades v2.** A série Prometheus
  `evelin_extension_negotiated_total` (labels `resume`, `big_frame`,
  `pipeline`) em `crates/evelin-metrics/src/lib.rs` refere-se aos bits legados
  `EVLN-EXT-1.5`. Esses bits nunca são negociados, e os contadores subjacentes
  são declarados e emitidos mas nunca incrementados em lugar nenhum na árvore —
  então a série sempre lê zero. Ela não é uma medição da negociação de
  capacidades do protocolo-v2.
- **Os modelos formais do v2 são AFIRMADOS, não verificados por máquina.** Os
  modelos Tamarin e ProVerif da negociação v2 são afirmados no repositório mas
  não são rodados até o fim por nenhum prover neste ambiente de build. Não os
  cite como provas verificadas por máquina.
- **`docs/PROTOCOL.md` documenta apenas o protocolo de rede v1.** Esse
  documento corresponde à versão de protocolo de rede `0x01` e não descreve o
  bloco de capacidades do v2. A descrição autoritativa do formato de rede v2 é
  o código-fonte listado acima.
- **A vazão não muda com a negociação.** Negociar um `MAX_FRAME_LOG2` maior
  muda o que a camada de record vai aceitar, não o teto de vazão medido em
  single-core.

## Versão do canal de exportação fixa

A versão 4.4.0 adiciona `fixed-export-v2@evelin.securityops.co`, um canal de
aplicação com codecs próprios versionados de abertura/resultado/commit. O `v2`
no nome é independente de `max_protocol_version` do handshake. Ele não adiciona
um ID de capacidade ao `evelin-negotiation`; a autorização ocorre pela política
dedicada `[fixed_export]`. Veja [exportações fixas](fixed-export.md).
