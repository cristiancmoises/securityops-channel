# Documentação do Evelin 4.4.0

Esta é a documentação em português brasileiro. Em caso de divergência, a
[versão em inglês](../README.md) prevalece.

| Para | Leia |
|---|---|
| Conhecer a versão e instalar os binários | [README em português](../../README.pt-BR.md) |
| Configurar o servidor e conectar pela primeira vez | [Primeiros passos](getting-started.md) |
| Usar os comandos do cliente | [Exemplos](examples.md) |
| Receber exportações PostgreSQL/Forgejo no Linux | [Exportações fixas](fixed-export.md) |
| Escolher plataforma e reproduzir o build | [Builds por plataforma](PLATFORM_BUILDS.md) |
| Entender crates e ciclo de conexão | [Arquitetura](architecture.md) |
| Entender negociação de capacidades | [Extensões](extensions.md) |
| Resolver dúvidas frequentes | [FAQ](faq.md) |
| Contribuir | [Contribuições](CONTRIBUTING.md) e [Código de conduta](CODE_OF_CONDUCT.md) |
| Entender o projeto | [Governança](GOVERNANCE.md) e [Roadmap](ROADMAP.md) |
| Consultar o histórico completo | [CHANGELOG em inglês](../../CHANGELOG.md) |

Guias técnicos adicionais de operação, protocolo e verificação estão no
[índice geral](../README.md).
