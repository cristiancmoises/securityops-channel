# Extensions and capability negotiation

This page describes Evelin's extension architecture exactly as it exists in
the v4.4.0 source tree. Two separate things in the codebase have, at
different times, been called "extensions"; this document keeps them
distinct because they are wired very differently:

1. **Protocol-v2 capability negotiation** (`crates/evelin-negotiation`) —
   the real, live, transcript-bound mechanism by which two peers agree on
   optional features per connection. This is the extension mechanism that
   actually runs today.
2. **The `EVLN-EXT-1.5` extension bitfield** (`crates/evelin-ext`) — an
   older, *provided-but-never-wired* primitive. It is compiled and unit
   tested, but it is never sent or parsed on the wire. The v3.4 release
   corrected earlier documentation that had claimed otherwise; that
   correction is described below.

Up front, the single most important architectural fact: **Evelin has no
dynamic runtime plugin system.** There is no `dlopen`, no `libloading`, no
plugin directory, no registration macro. Every capability is compiled into
the binary and negotiated per connection. The "why" is in
[There is no dynamic plugin loading](#there-is-no-dynamic-plugin-loading--and-why).

## The short version

- An "extension" you can turn on today is a **protocol-v2 capability**: a
  small `(id, value)` entry carried inside the signed handshake body.
- Capability negotiation is **opt-in**. Default deployments speak protocol
  v1 and are byte-identical on the wire to older releases. You enable v2 by
  setting `max_protocol_version = 2` on **both** ends.
- What gets activated is the **intersection** of what both peers offer,
  reduced by a pure function. Neither peer can unilaterally enable a
  feature.
- The negotiated bytes live in the **signed** transcript, so stripping or
  altering them breaks the ML-DSA-87 signature and the handshake aborts.
  That is what makes negotiation downgrade-resistant.
- Exactly two capabilities are defined in the registry today:
  `MAX_FRAME_LOG2` (live; controls record frame size) and `REKEY`
  (negotiated and exposed, but reserved — not yet wired to any behaviour).

## What an extension is on the wire

The live mechanism is defined in `crates/evelin-negotiation/src/lib.rs` and
carried by the handshake messages in
`crates/evelin-handshake/src/messages.rs`.

A **capability** is an `(id, value)` pair:

- `id` is a `u16` from a fixed registry (the `cap` module — see below).
- `value` is 0–256 bytes; its meaning is defined per id. Presence-only
  flags carry an empty value.

A **capability block** is the canonical encoding of a set of capabilities:

```text
CapabilityBlock :=
    u16  count                 (number of capabilities, big-endian)
    Capability * count         (strictly ascending by id, no duplicates)

Capability :=
    u16  id                    (big-endian)
    u16  value_len             (big-endian, <= 256)
    u8   value[value_len]
```

The encoding is **canonical**: ids strictly ascending, no duplicates,
minimal lengths. Because the byte block is a deterministic function of the
capability set, both peers hash identical bytes and equality is
unambiguous. The empty set encodes to exactly the two bytes `00 00`.

On the handshake wire the block is **length-prefixed** so it is
self-delimiting inside the stream:

```text
u16  caps_len || caps_bytes
```

This framed block is appended to the **body** of `HelloClient` and
`HelloServer` in protocol v2. The client's block sits after its
`kem_pk || id_pk || nonce`; the server's sits after its
`id_pk || kem_ct || nonce` and before the trailing ML-DSA-87 signature.
`Finish` carries no capability block.

Hard bounds enforced by the decoder (constants in
`crates/evelin-negotiation/src/lib.rs`):

| Constant | Value | Purpose |
|---|---|---|
| `MAX_CAPABILITIES` | 64 | Maximum entries in a block. |
| `MAX_VALUE_LEN` | 256 | Maximum bytes in one capability value. |
| `MAX_ENCODED_LEN` | 16 642 | Largest possible canonical block (`2 + 64 × 260`); an oversized block is rejected before it is read off the stream. |

`Capabilities::decode` is canonical-only: unordered or duplicate ids,
trailing bytes, oversize values, or an oversize count are all rejected.
Rejecting non-canonical input is deliberate — it removes any wiggle room a
tamperer could use to make two peers compute different capability sets from
"equivalent" bytes. The decoder is fuzzed (a seeded LCG drives hundreds of
thousands of inputs through it in CI) for never-panic and roundtrip
guarantees.

## How negotiation decides what is active

### Opt-in by protocol version

Negotiation only happens on **protocol v2**, and v2 is strictly opt-in.
The switch is the `max_protocol_version` config key (`crates/evelin-config`,
default `1`):

- With `max_protocol_version = 1` (the default, on either the client or the
  server config), no capability block is sent. The wire is byte-identical
  to pre-v4.0 protocol v1.
- With `max_protocol_version = 2` on **both** ends, each side builds a
  capability offer and the connection negotiates v2.
- A v2-capable server still accepts v1 clients (the v1 handshake is
  unchanged), so the supported migration order is servers first, then
  clients. A v2 client against a v1-only server is rejected.
- Values other than `1` or `2` are rejected at startup (client:
  `validate_protocol_settings`; server: `run_check`).

The version field lives in the message **header**
(`magic || version || msg_type || reserved`). The header is a **parse hint
only** — it is not fed into the transcript hash. Authentication of what was
negotiated comes entirely from the capability block being in the signed
*body*, not from the version field.

### Both peers offer; a pure function decides

Each side constructs a `Capabilities` offer and puts it in its Hello. After
the handshake authenticates both offers, each side independently computes
the outcome with `negotiate(client, server)` in
`crates/evelin-negotiation/src/lib.rs`:

- The reduction over each shared capability is **commutative and
  associative** (minimum for `MAX_FRAME_LOG2`, logical AND for `REKEY`), so
  `negotiate(c, s)` and `negotiate(s, c)` agree on shared fields. Both
  peers reach the same `Negotiated` result **without an extra round trip**.
- A capability only takes effect if **both** peers offered it. Neither peer
  can unilaterally enable a feature.
- The result is returned as a `Negotiated` struct on `HandshakeOutput`.
  Transport code reads it (for example `out.negotiated.max_frame_bytes()`)
  and applies it.

### Downgrade resistance by construction

The capability block is embedded in the message **body**, which is covered
by the transcript hash that each side signs with ML-DSA-87. Protocol v2
uses distinct domain-separation labels — `evelin/2/hello-client`,
`evelin/2/hello-server`, `evelin/2/finish` (see
`crates/evelin-core/src/protocol.rs`), versus the `evelin/1/*` labels for
v1. Consequences:

- Stripping, altering, or injecting the capability block changes the
  transcript the originating peer produced, so the signature no longer
  verifies and the handshake aborts.
- Rewriting the header version field does not help an attacker: a v2 client
  requires a v2 `HelloServer` and vice versa (`client.rs` rejects a version
  mismatch with `Error::Wire("protocol version mismatch")`), and a v1
  transcript can never collide with a v2 one because the labels differ.

This is the entire basis of downgrade resistance here: the negotiated
result is authenticated because its inputs are transcript-bound.

### Strict offer validation (v4.1)

`negotiate` returns a `Result`. It rejects, on either offer:

- `MAX_FRAME_LOG2` below `MIN_MAX_FRAME_LOG2` = 14 (2^14 = 16 KiB, the v1
  base frame size every implementation must accept). The record layer
  clamps *up* to 16 KiB, so a smaller advertisement cannot be honoured, and
  silently clamping would make the sender exceed what the peer said it
  accepts. It aborts instead.
- A **known** capability with the wrong value shape: `MAX_FRAME_LOG2` must
  be exactly one byte; `REKEY` must be empty. Unknown ids stay opaque —
  strictness applies only where semantics are defined.

Both peers run the identical `negotiate` over the identical
transcript-bound inputs, so a malformed offer produces the same error on
both ends and the two sides abort coherently. In the transport this surfaces
as `Error::Wire("invalid capability offer")`.

## Extensions that exist today

Two capability ids are defined in the `cap` module of
`crates/evelin-negotiation/src/lib.rs`. Ids are never reused or renumbered.

| Id | Name | Value | Negotiation rule | Status |
|---|---|---|---|---|
| `0x0001` | `MAX_FRAME_LOG2` | 1 byte (base-2 log of max frame in bytes) | minimum of the two advertisements | **Live** — gates the record layer. |
| `0x0002` | `REKEY` | empty (presence flag) | logical AND | Negotiated and exposed, but **reserved** — not wired to any behaviour. |

### `MAX_FRAME_LOG2` (live)

This is the largest record frame a side is willing to receive, as a base-2
logarithm. The negotiated value is `min(client, server)`, and both ends
apply it: on v2 the transport calls `set_max_frame_len` on the
`RecordSender` and `RecordReceiver` (see `set_max_frame_len` uses in the
client and server `main.rs`), which clamps into the record layer's
supported range `[16 KiB, 1 MiB]` (`MAX_FRAME_LEN` .. `MAX_FRAME_LEN_BIG`
in `crates/evelin-core/src/protocol.rs`).

Operators control the advertised value through the `max_frame_kib` config
key: a power of two in `[16, 1024]` KiB (default `1024`), validated at
startup with no silent rounding. `evelin_negotiation::log2_for_kib` maps
KiB to the on-wire exponent (`[14, 20]`); anything outside the supported set
returns `None` and is rejected. `max_frame_kib` is only meaningful with
`max_protocol_version = 2`; it is ignored on v1 connections.

On a **v1** connection nothing is negotiated and `set_max_frame_len` is not
called, so the record layer keeps its build-time default of
`MAX_FRAME_LEN_BIG` (1 MiB) — see the v3.4 note below on why large frames
work without negotiation.

### `REKEY` (reserved)

`REKEY` is a presence-only flag negotiated as a logical AND. When both peers
advertise it, `out.negotiated.rekey` is `true`. It is deliberately **not
wired** to any behaviour: it was reserved for a future rekey ceremony, and
gating the always-on symmetric record-layer ratchet on
it would be pointless ceremony. It is kept in the registry so the id is
fixed for when that protocol lands.

## The `EVLN-EXT-1.5` bitfield and the v3.4 correction

`crates/evelin-ext` predates the v4 negotiation crate. It holds two
pure-data wire primitives with no I/O and no crypto, split into their own
crate so the fuzz harness and formal-model tooling can depend on them
without pulling in `evelin-server`:

- `TicketPlaintext` — the 97-byte session-resumption ticket plaintext (its
  sealing/opening lives in `crates/evelin-ticket` and
  `crates/evelin-server/src/resume.rs`; the plaintext format is *not* an
  extension mechanism, it just shares this crate).
- `Extensions` — a `u16` bitfield with `agree()` combination logic. Defined
  bits: `EXT_RESUME` (bit 0), `EXT_BIG_FRAME` (bit 1), `EXT_PIPELINE`
  (bit 2), with `EXT_KNOWN_BITS` masking the rest. `agree()` computes
  `self AND peer` masked to known bits — the same intersection principle the
  v4 negotiator uses.

**This bitfield is never exchanged on the wire.** The v3.4 release corrected
earlier documentation that had described `EVLN-EXT-1.5` as an active,
on-wire, transcript-bound, formally-proven negotiation. Verified against the
implementation at that time:

- No extension flight existed on the wire; the shipping client and server
  ran the handshake and then built the record layer at fixed build-time
  defaults.
- The `Extensions` type was used only by tests (this crate's own tests and
  the server's CVE-regression tests). It still is.
- The v1 transcript contained no extension bits — only the
  `HELLO_CLIENT` / `HELLO_SERVER` / `FINISH` labels, with nothing exchanged.

The v3.4 finding was classified as an **honesty defect, not a live
vulnerability**: a downgrade attack strips a negotiated option on the wire,
and there was no on-wire negotiation to strip. Large frames worked anyway
because since v2.5 the record layer defaults both ends to
`MAX_FRAME_LEN_BIG` (1 MiB) unconditionally, so the `BIG_FRAME` bit was
never needed to unlock them.

The module doc in `crates/evelin-ext/src/extensions.rs` also records the
**required property for any future implementer**: if that bitfield is ever
put on the wire, both peers' advertised bytes must be folded into the signed
transcript. The v4 `evelin-negotiation` crate is the constructive
resolution of the v3.4 finding — it does exactly that, in the signed body,
from the start.

If you are adding a feature today, add a **protocol-v2 capability**
(`evelin-negotiation`). Do not extend the `EVLN-EXT-1.5` bitfield; it is
legacy and unwired.

## Adding a new capability in-tree

Walked from the actual source. A capability is added by editing compiled
Rust — there is no config file or plugin manifest that introduces one. The
following steps take you from registry to live behaviour.

1. **Reserve an id.** In the `cap` module of
   `crates/evelin-negotiation/src/lib.rs`, add a new `pub const` `u16`. Pick
   the next unused id; never reuse or renumber an existing one. Document its
   value shape and its negotiation rule in the doc comment.

2. **Add the outcome field.** Add a field to the `Negotiated` struct in the
   same file to hold the agreed result (for example `Option<u8>` for a
   value, `bool` for a presence flag). `Negotiated` derives `Default`; make
   sure the default means "not negotiated" (that is what v1 and
   one-side-absent produce).

3. **Validate the shape** (only if your id has defined semantics). In
   `validate_offer`, add a check that a *known* capability carries a
   well-formed value, returning `NegotiationError::MalformedValue(id)` (or a
   more specific variant you add) otherwise. Unknown ids must stay opaque —
   validate only where you have defined the meaning.

4. **Reduce in `negotiate`.** Add the reduction that combines the two
   offers' values into your `Negotiated` field. It **must** be commutative
   and associative (minimum, maximum, logical AND, set intersection, …) so
   both peers compute the same result regardless of argument order. This is
   a correctness requirement, not a style preference — the whole
   no-extra-round-trip design depends on it.

5. **Expose a byte view if needed.** If callers need a derived value (as
   `MAX_FRAME_LOG2` exposes `Negotiated::max_frame_bytes()`), add an
   accessor on `Negotiated`.

6. **Build the offer from config.** In `build_client_offer`
   (`crates/evelin-client/src/main.rs`) and `build_server_offer`
   (`crates/evelin-server/src/main.rs`), add your capability to the
   `Capabilities` that each side offers when `max_protocol_version >= 2`.
   Use `set_flag`, `set_u8`, or `set` — each returns a `Result` you must
   handle (it is `#[must_use]`).

7. **Add config keys** (if operator-controllable). Add fields to the config
   structs in `crates/evelin-config/src/lib.rs` with a `serde` default, and
   validate them at startup alongside the existing checks
   (`validate_protocol_settings` on the client, `run_check` on the server)
   so bad input is rejected before any connection — no silent rounding.

8. **Consume the outcome in the transport.** After the handshake, read your
   `out.negotiated.<field>` and apply it (as the transport applies
   `max_frame_bytes()` via `set_max_frame_len`). Remember it is `Default`
   on v1 connections.

9. **Test at both layers.** Add unit tests in `evelin-negotiation`
   (encode/decode roundtrip, the reduction, malformed-shape rejection) and
   handshake/integration tests in `evelin-handshake` (a v2 handshake that
   negotiates your capability; a byte-flip or strip that aborts). Keep the
   v1 path byte-identical — there are existing pinning tests that fail if it
   is perturbed.

Two things you do **not** need to touch: the transcript labels (your
capability block is already inside the signed v2 body under the existing
`evelin/2/*` labels), and the message framing (the length-prefixed block
already carries an arbitrary canonical `Capabilities` set).

## There is no dynamic plugin loading — and why

Evelin does not load extension code at runtime. There is no `dlopen` of
plugin objects, no `libloading`, no plugin search path, no registration
macro, no scripting hook in the transport. (The `libevelin` C API in
`crates/evelin-capi` is built as a `cdylib` so *other* programs can link
Evelin as a library; that is Evelin being embedded, not Evelin loading
third-party plugins. The PKCS#11 module loading in the HSM tests is test
scaffolding for SoftHSM2, not a transport plugin system.)

Extensions are **compiled into the binary and negotiated per connection**.
For a security-critical tunnel this is a deliberate design choice, not a
missing feature:

- **Supply-chain surface.** Every negotiable capability is in-tree Rust that
  goes through the same review, the same `#![forbid(unsafe_code)]`, the same
  `-D warnings` gate, and the same reproducible build as the rest of the
  transport. A running Evelin never loads code it was not built with, so an
  attacker who can drop a file on disk cannot introduce a new tunnel feature
  or code path. There is no plugin ABI to keep compatible and no third-party
  extension to vet.
- **Audit surface.** The complete set of things two peers can negotiate is
  the `cap` registry — a short, greppable list in one file — and the logic
  that decides what activates is a single pure function (`negotiate`) with a
  bounded, fuzzed decoder. An auditor can enumerate the entire extension
  behaviour by reading `crates/evelin-negotiation/src/lib.rs`, rather than
  reasoning about arbitrary code that some deployment might load. What is
  negotiable is fixed at build time and identical across every copy of that
  build.
- **Determinism.** Because negotiation is a pure, commutative reduction over
  transcript-bound inputs, the outcome is reproducible and the same on both
  peers. A dynamic plugin layer would make the active feature set depend on
  runtime state outside the signed handshake — exactly the kind of
  unauthenticated input that downgrade attacks exploit.

## Where to read the source

| Concern | File |
|---|---|
| Capability type, registry, codec, `negotiate` | `crates/evelin-negotiation/src/lib.rs` |
| Capability block in the Hello messages / framing | `crates/evelin-handshake/src/messages.rs` |
| Offer construction, transcript binding (client) | `crates/evelin-handshake/src/client.rs` |
| Offer construction, transcript binding (server) | `crates/evelin-handshake/src/server.rs` |
| Transcript labels, protocol versions, frame constants | `crates/evelin-core/src/protocol.rs` |
| Config keys `max_protocol_version`, `max_frame_kib` | `crates/evelin-config/src/lib.rs` |
| Live offer + applying the outcome | `crates/evelin-client/src/main.rs`, `crates/evelin-server/src/main.rs` |
| Legacy `EVLN-EXT-1.5` bitfield + ticket plaintext | `crates/evelin-ext/src/extensions.rs`, `crates/evelin-ext/src/ticket.rs` |

## Honest limitations and non-claims

- **The metrics counter does not track v2 capabilities.** The Prometheus
  series `evelin_extension_negotiated_total` (labels `resume`, `big_frame`,
  `pipeline`) in `crates/evelin-metrics/src/lib.rs` refers to the legacy
  `EVLN-EXT-1.5` bits. Those bits are never negotiated, and the underlying
  counters are declared and emitted but never incremented anywhere in the
  tree — so the series always reads zero. It is not a measurement of
  protocol-v2 capability negotiation.
- **The v2 formal models are STATED, not machine-checked.** The Tamarin and
  ProVerif models of the v2 negotiation are stated in the repository but not
  run to completion by any prover in this build environment. Do not cite
  them as machine-verified proofs.
- **`docs/PROTOCOL.md` documents wire-protocol v1 only.** That document
  corresponds to wire-protocol version `0x01` and does not describe the v2
  capability block. The authoritative description of the v2 wire format is
  the source listed above.
- **Throughput is unchanged by negotiation.** Negotiating a larger
  `MAX_FRAME_LOG2` changes what the record layer will accept, not the
  measured single-core throughput ceiling.

## Fixed-export channel version

Version 4.4.0 adds `fixed-export-v2@evelin.securityops.co`, an application channel
with its own versioned open/result/commit codecs. The `v2` in this channel name
is independent of the handshake's `max_protocol_version` setting. It does not
add a capability ID to `evelin-negotiation`; authorization is through the
server's dedicated `[fixed_export]` policy. See [fixed exports](fixed-export.md).
