> Tradução para pt-BR de `ROADMAP.md`. Em caso de divergência, a versão em inglês prevalece.

# Roadmap

Este roadmap é direcional, mantido pelo mantenedor, e os itens só são lançados quando passam pela disciplina de auditoria do projeto — nada é entregue antes de seus testes, de seus portões clippy/audit/deny e de um rótulo honesto DECLARADO-vs-PROVADO.

Ele **não traz datas nem promessas de número de versão**. Cada item abaixo está fundamentado em uma declaração explícita já presente neste repositório, e a fundamentação é citada ao lado dele. Se você quiser conferir um item, leia o arquivo citado — ele é a fonte da verdade, não esta página. Itens sem tal declaração não aparecem aqui, conforme a política de afirmações do projeto (veja `CONTRIBUTING.md`: nunca declare o que não foi verificado).

## Curto prazo

### Verificar por máquina os modelos formais DECLARADOS

`verification/VERIFICATION_STATUS.md` é a única fonte da verdade para o status dos modelos formais. Ele registra 5 lemas Tamarin e 8 consultas ProVerif verificados por máquina na cerimônia v0.1, e os seguintes como **DECLARADO, não PROVADO** (escritos e válidos sintaticamente, mas nunca executados por um provador até a conclusão no CI deste repositório):

- 3 lemas Tamarin + 2 consultas ProVerif no modelo primário de handshake (sigilo futuro do ratchet, vinculação de agente, integridade de conteúdo do filecopy), adicionados na v0.2.1;
- 4 lemas Tamarin + 3 consultas ProVerif modelando a negociação de capacidades v2 já entregue (`evelin-v2-negotiation.spthy`, `evelin-v2-negotiation.pv`), adicionados na v4.0.

O caminho já está nomeado no repositório: `verification/VERIFICATION_STATUS.md` designa `.forgejo/workflows/formal-models.yaml` (que existe na árvore) como "o local pretendido para transformar lemas DECLARADOS em PROVADOS", e o changelog afirma que a promoção "precisa que `tamarin-prover`/`proverif` sejam executados até a conclusão em uma cerimônia de release", com logs de execução referenciados e o teste de manifesto mantendo as contagens honestas. Até que isso aconteça, o projeto recusa a expressão "verificado formalmente" para essas propriedades.

### Uma medição real de vazão em massa multi-core / dois hosts

Os números de vazão publicados são de loopback single-core. As limitações do GA v4.0 no changelog afirmam claramente: "o tráfego em massa é limitado por contenção de núcleo em um único núcleo" e "um benchmark real multi-core/dois hosts ainda está pendente de hardware"; a nota de escopo da v3.8 lista "um número real de vazão ponta a ponta (precisa de multi-core/dois hosts)" como trabalho que exige recursos fora do ambiente de build. O `README.md` leva a mesma limitação para o GA. Este item é a medição em si — um número honesto vindo de hardware em que cliente e servidor não compartilham um núcleo — antes que qualquer afirmação de otimização seja feita sobre ele.

## Médio prazo

### Conectar a capacidade REKEY negociada a uma rechaveação assimétrica ML-KEM

O protocolo v2 negocia uma capacidade `REKEY` que está deliberadamente **reservada, não conectada**. `README.md`: "`REKEY` é negociada/exposta mas reservada para uma futura rechaveação assimétrica ML-KEM (não conectada ao ratchet sempre-ativo — isso seria cerimônia)." O changelog documenta a mesma decisão e observa que "`out.negotiated.rekey` está disponível para quando esse protocolo chegar." Este item é essa chegada: uma real reencapsulação assimétrica ML-KEM condicionada pela flag já negociada. O ratchet simétrico incondicional existente permanece como está (veja os não-objetivos abaixo).

### Uma auditoria criptográfica paga de terceiros

`SECURITY.md`: "Não houve nenhuma auditoria criptográfica paga de terceiros. O autor recebe bem a revisão da comunidade e pretende encomendar uma auditoria paga depois de acumular experiência operacional." O `docs/THREAT-MODEL.md` pontua "Independent third-party audit" em 0, "Not yet performed", e o `COMPARISON.md` lista a auditoria de terceiros como "none completed" entre as linhas em que o OpenSSH vence. Encomendar essa auditoria — e publicar seus resultados sob os termos de embargo e crédito existentes — está neste roadmap porque o repositório afirma isso em três lugares.

### Reduzir cópias de memória por chunk no caminho em massa

`docs/BENCHMARKS.md`: "O verdadeiro gargalo do caminho em massa são as cópias de memória por chunk (`send_data` → `ChannelMsg::encode` → `Aead::seal`), rastreado para um sprint futuro." Esta é a próxima alavanca de desempenho nomeada, depois do trabalho de seal in-place (que já está provado por teste). Qualquer ganho alegado aqui deve vir acompanhado de um benchmark reproduzível, conforme a disciplina de medição do mesmo arquivo.

### Um benchmark comparativo no mesmo host contra o OpenSSH

O `COMPARISON.md` deliberadamente **não faz afirmações comparativas de desempenho**, porque nenhuma foi medida no mesmo host; o `docs/BENCHMARKS.md` traz uma seção "Not yet measured" para um benchmark comparativo contra o `chacha20-poly1305@openssh.com` do OpenSSH no mesmo loopback "para quantificar o overhead pós-quântico". Executar esse benchmark e substituir a expectativa por uma medição permitiria que o documento de comparação declarasse fatos de desempenho em ambas as direções.

## Longo prazo

### Portes para plataformas não-Linux através de `evelin-platform`

O `docs/PLATFORM_BUILDS.md` registra macOS, Windows, FreeBSD, OpenBSD e NetBSD como **não suportados**, com uma única causa raiz: syscalls específicas do Linux (Landlock, seccomp-bpf, `openat2` com `RESOLVE_BENEATH`, IPC de agente por socket de domínio Unix) sem alternativas condicionais por plataforma. O mesmo documento delimita o caminho a seguir por plataforma (macOS App Sandbox, FreeBSD Capsicum, OpenBSD pledge/unveil, Windows named pipes), explicitamente para que um contribuidor disposto a fazer o trabalho de porte tenha o escopo em mãos. O crate `crates/evelin-platform` já entrega a superfície de traits (`Sandbox`, `IpcSocket`/`IpcStream`, `OpenBeneath`, `JobControl`) com uma implementação Linux completa como referência de auditoria e arquivos de plataforma não-Linux que ainda não impõem o sandbox — um esqueleto Windows que compila mais stubs macOS/FreeBSD/OpenBSD cujas chamadas retornam `Unimplemented`. O próprio contrato do crate é que uma nova plataforma deve alcançar "garantias de segurança funcionalmente equivalentes, não necessariamente caminhos de syscall idênticos." O trabalho de porte é preencher esses stubs sem enfraquecer as garantias de sandbox que o build Linux impõe. Nenhum compromisso quanto à ordem ou a qual plataforma chega primeiro.

### Perfil io_uring no caminho de accept — estritamente condicional

`[runtime].io_uring_profile` existe na configuração como um botão **reservado**: o `docs/OPERATOR_RUNBOOK.md` documenta que qualquer valor diferente de `"off"` é um erro de inicialização. O changelog registra a avaliação e a decisão: "NO-GO irrestrito, botão de configuração RESERVED", com o perfil restrito `safe-accept-only` a ser implementado "apenas se a telemetria de campo mostrar o problema de taxa de accept". Essa condição faz parte do item: se a telemetria nunca mostrar o problema, isto nunca é lançado, e esse resultado é aceitável.

## Não-objetivos explícitos

Estes foram deliberadamente rejeitados no repositório, com a decisão e seu raciocínio registrados por escrito. Eles são listados para que ninguém leia sua ausência acima como um descuido.

- **Compatibilidade de fio com SSH.** `README.md`: "O protocolo de fio **não** é compatível com SSH e nunca será." O formato da toolchain voltada ao usuário permanece deliberadamente parecido com o OpenSSH; o fio não.
- **Uma troca de chaves híbrida clássica+PQ.** O `verification/VERIFICATION_STATUS.md` afirma que o design do projeto "descarta explicitamente" um KEX X25519 híbrido — o KEX é puramente pós-quântico. O `COMPARISON.md` expõe o trade-off sem rodeios: não ter uma salvaguarda clássica é "uma posição de design deliberada … um verdadeiro trade-off de ponto único de falha, não uma vitória incondicional."
- **Um mecanismo genérico de 0-RTT.** O `docs/THREAT_MODEL_0RTT.md` registra a análise completa e a decisão: "Não somos a entidade certa para entregar um mecanismo genérico de 0-RTT para um caso de uso futuro desconhecido." Seu encerramento nomeia exatamente três condições sob as quais a decisão "será reaberta": um caso de uso específico de protocolo de aplicação que atenda a todos os oito critérios do modelo de ameaças do documento, um auditor terceiro recomendando um design de 0-RTT mais rígido que o projeto tenha deixado passar, ou um protocolo par (TLS 1.3, QUIC) entregando um design de 0-RTT que resolva o replay entre reinícios de uma forma que o Evelin possa adotar. Na ausência de um desses, permanece fechado.
- **Condicionar o ratchet simétrico sempre-ativo à flag REKEY.** O changelog: "Condicionar um ratchet sempre-ativo a uma flag seria cerimônia." O ratchet permanece incondicional; a capacidade `REKEY` reservada é apenas para a futura rechaveação assimétrica (veja o médio prazo).
- **io_uring irrestrito.** A decisão registrada é "NO-GO irrestrito" — apenas o perfil restrito, condicionado à telemetria, acima está sequer em consideração.
- **Modelos formais à frente do código entregue.** A v3.8 deletou os arquivos de modelo aspiracionais de extensão/híbrido porque eles modelavam um protocolo que o Evelin não entrega; o `verification/VERIFICATION_STATUS.md` preserva a regra: novos modelos são adicionados quando o código que eles descrevem está implementado e alcançável na rede, "não carregado à frente dele". Um teste (`formal_status_manifest_matches_model_files`) garante que os arquivos deletados permaneçam ausentes e que as contagens permaneçam honestas.
