> Tradução para pt-BR de `CONTRIBUTING.md`. Em caso de divergência, a versão em inglês prevalece.

# Contribuindo com o Evelin

O Evelin é um túnel seguro pós-quântico (ML-KEM-1024 + ML-DSA-87 +
ChaCha20-Poly1305) escrito em Rust. Contribuições são bem-vindas, com duas
ressalvas de antemão: o projeto tem uma política de afirmações rigorosa (veja
abaixo), e toda alteração passa pelos mesmos portões de CI — não há atalho, nem
mesmo para o mantenedor (veja "What we will not do" em `SECURITY.md`).

Ao participar, você concorda com o [Código de Conduta](CODE_OF_CONDUCT.md).

## Ambiente de desenvolvimento

Use Rust 1.93.0. O repositório fixa a toolchain em
`rust-toolchain.toml` (canal `1.93.0`, componentes `rustfmt` e `clippy`,
perfil mínimo), então um `rustup` de fábrica escolhe a coisa certa
automaticamente quando você compila dentro do repositório. A versão mínima
suportada do Rust é 1.85 (`rust-version` no `Cargo.toml` do workspace).

Para a execução completa dos portões localmente, você também precisa de:

```sh
rustup target add x86_64-unknown-linux-musl
sudo apt-get install musl-tools          # or your distro's equivalent
cargo install cargo-audit --locked
cargo install cargo-deny  --locked       # optional but recommended
```

O `Cargo.lock` versionado fixa a resolução de dependências dos lançamentos.
Use `--locked` na validação e atualize o lockfile deliberadamente junto com
mudanças nas dependências.

## Compilando e testando

```sh
cargo build --workspace
cargo test  --workspace --release
```

O CI roda a suíte de testes em modo release; rode-a da mesma forma localmente
para que você veja o que o CI vê. `docs/AUDIT-CHECKLIST.md` mapeia propriedades
de segurança para testes específicos, caso você queira rodar um subconjunto
focado.

## Portões que sua alteração deve passar

O CI (`.forgejo/workflows/ci.yml`) roda a cada push e pull request com
`RUSTFLAGS="-D warnings"` definido para todos os jobs. Rode os mesmos portões
localmente antes de submeter:

```sh
# 1. Formatting — no diffs allowed
cargo fmt --all -- --check

# 2. Clippy — warnings are errors
RUSTFLAGS="-D warnings" cargo clippy --workspace --all-targets -- -D warnings

# 3. Tests — release mode, whole workspace
RUSTFLAGS="-D warnings" cargo test --workspace --release

# 4. Release build on the musl target (produces the shipped binaries)
RUSTFLAGS="-D warnings" cargo build --release --workspace --target x86_64-unknown-linux-musl

# 5. Dependency advisories — fails on any unresolved RUSTSEC advisory
scripts/cargo-audit-blocking.sh
```

Um PR que falhar em qualquer um destes não será mesclado. Como o `RUSTFLAGS`
transforma todos os avisos do rustc em erros graves no CI, um aviso "comum" que
escapa do fmt e do clippy ainda faz a compilação falhar.

## A política de afirmações

Toda declaração factual neste repositório — docs, comentários, mensagens de
commit, números de benchmark — está sujeita a uma política de afirmações (veja
`CHANGELOG.md` e `COMPARISON.md`): números precisam ser medidos ou derivados de
constantes, afirmações comparativas de desempenho exigem um benchmark no mesmo
host, e fraquezas conhecidas são declaradas de forma clara em vez de omitidas.
Concretamente, para suas contribuições:

- Não escreva "faster", "hardened", "secure against X", ou qualquer número que
  você não tenha medido ou derivado por conta própria. Se você o mediu, diga
  como (host, flags de build, número de execuções).
- Mensagens de commit descrevem o que a alteração faz, verificado contra o
  código no commit — não o que você espera que ela faça.
- Se sua alteração tem uma propriedade relevante para segurança, adicione ou
  referencie o teste que a demonstra em `docs/AUDIT-CHECKLIST.md`. Se não houver
  teste, liste-o ali como uma lacuna em vez de afirmá-lo.

## Padrões de código

- **Restrinja `unsafe` a fronteiras explícitas do sistema.** Módulos de
  protocolo/codec usam `#![forbid(unsafe_code)]`. A ABI C e operações Linux
  específicas de processos, descritores e auxiliares de backend precisam de
  blocos unsafe revisados. Mantenha cada bloco pequeno, documente suas
  invariantes de segurança e use wrappers seguros quando disponíveis; não
  afirme que o workspace inteiro está livre de unsafe.
- **Zeroize de segredos.** Chaves privadas, segredos compartilhados, chaves de
  sessão e segredos de ticket devem ser apagados quando descartados. Siga os
  padrões `zeroize` existentes em `crates/evelin-crypto`, `crates/evelin-keys`
  e `crates/evelin-ticket`.
- **Tempo constante.** Comparações envolvendo material secreto ou digests não
  devem ramificar sobre dados secretos. Veja `crates/evelin-keys/src/ct_match.rs`
  e `constant_time_eq_32` em `crates/evelin-session/src/filecopy.rs` para o
  estilo da casa; `docs/AUDIT-CHECKLIST.md` (seção E) registra o que é imposto e
  o que é delegado aos upstreams do RustCrypto.
- **Novas dependências precisam de justificativa.** A política de dependências
  é o `deny.toml`: licenças devem estar na lista de permitidas (MIT, Apache-2.0,
  BSD, ISC, MPL-2.0 e licenças permissivas similares), crates devem vir do
  crates.io (registries desconhecidos e fontes git são negados), e `md-5`,
  `sha1`, `rust-crypto`, `openssl` e `openssl-sys` são banidos por completo.
  Rode `cargo deny check` antes de propor uma mudança de dependência, e diga no
  PR o que a dependência traz que a árvore existente não traz.
  Ignores de advisory em `deny.toml` e `scripts/cargo-audit-blocking.sh`
  exigem uma justificativa por escrito.
- **Cabeçalhos SPDX.** Novos arquivos de código-fonte começam com
  `// SPDX-License-Identifier: AGPL-3.0-or-later OR LicenseRef-Evelin-Commercial`
  (sintaxe de comentário conforme apropriado para o tipo de arquivo).

## Como enviar alterações

O repositório principal fica em uma instância privada do Forgejo
(`git.securityops.co`); um mirror público está em
`https://github.com/cristiancmoises/evelin`. Não há rastreador de issues público
(veja `SECURITY.md`).

1. **Converse antes para qualquer coisa não-trivial.** Envie um e-mail para
   `sac@securityops.co` com uma breve descrição antes de escrever uma
   funcionalidade. Isso evita trabalho desperdiçado em alterações que conflitam
   com o design do protocolo ou com o escopo do projeto. Correções de typo e
   patches pequenos e obviamente corretos podem pular esta etapa.
2. **Envie a alteração** como um pull request contra o mirror do GitHub, ou como
   um patch (`git format-patch`) por e-mail para o mesmo endereço.
3. **No PR ou e-mail, declare**: o que a alteração faz, como você a testou
   (quais dos portões acima você rodou) e — para mudanças de comportamento —
   quais docs você atualizou.

Mantenha as alterações focadas: uma alteração lógica por PR. Refatorações e
mudanças de comportamento vão em commits separados.

## Developer Certificate of Origin

Todo commit deve ter sign-off:

```sh
git commit -s
```

O trailer `Signed-off-by: Your Name <you@example.com>` certifica que você
escreveu a alteração ou que de outra forma tem o direito de submetê-la sob a
licença do projeto, conforme o Developer Certificate of Origin 1.1
(<https://developercertificate.org>). Use um nome real e um endereço de e-mail
acessível. Commits sem sign-off precisarão ser refeitos.

## Licenciamento de contribuições

O Evelin tem licença dupla: AGPL-3.0-or-later por padrão, com uma licença
comercial disponível junto ao detentor dos direitos autorais. Leia o `NOTICE`
antes de contribuir — ele é a declaração autoritativa.

O sign-off do DCO comprova que você tem o direito de submeter a alteração sob a
licença open-source indicada pelo projeto. Ele não transfere seus direitos
autorais e, por si só, não concede à Security Ops o direito de oferecer sua
contribuição sob contrato comercial proprietário. Até que o projeto e o
contribuidor assinem um contrato separado com autorização adequada para
relicenciamento comercial, a contribuição deve ser tratada como somente AGPL
na contabilização da opção comercial. Os mantenedores precisam registrar essa
fronteira e não podem apresentar direitos de terceiros não concedidos como
licenciados comercialmente.

Se você deseja que uma contribuição seja considerada para as duas opções,
entre em contato com `sac@securityops.co` antes do envio para combinar termos
explícitos por escrito. Uma contribuição AGPL ainda pode ser considerada sem
essa concessão, mas não pode entrar em uma build comercialmente licenciada sem
resolver os direitos separadamente.

## Reportando problemas de segurança

Não abra um PR público para uma vulnerabilidade. Envie um e-mail para
`sac@securityops.co` com o prefixo de assunto `[SECURITY]` e siga o `SECURITY.md`
— ele define a janela de divulgação, o que está dentro e fora de escopo, e o
processo de CVE.
