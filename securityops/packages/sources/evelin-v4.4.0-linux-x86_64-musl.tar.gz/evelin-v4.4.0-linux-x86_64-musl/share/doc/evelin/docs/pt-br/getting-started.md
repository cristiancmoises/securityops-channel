> Tradução para pt-BR de `docs/en/getting-started.md`. Em caso de divergência, a versão em inglês prevalece.

# Primeiros passos com o Evelin

O Evelin é um túnel seguro pós-quântico: um serviço auto-hospedado, no
estilo do SSH, que transporta comandos, shells e cópias de arquivos por
uma conexão criptografada. Todo handshake usa **ML-KEM-1024** para a
troca de chaves e **ML-DSA-87** para autenticação mútua — ambos
primitivos pós-quânticos de nível 5 do NIST — com **ChaCha20-Poly1305**
como cifra de transporte.

Esta página leva você de uma instalação nova até sua primeira conexão
autenticada: gerar uma chave de identidade, configurar um servidor,
autorizar um cliente, verificar a fingerprint do servidor e, então,
executar um comando, abrir um shell e copiar um arquivo.

Se você quiser um passo a passo conceitual mais completo, leia
[`docs/QUICKSTART.md`](../QUICKSTART.md). Para uma implantação de
produção com Docker + Forgejo, leia [`INSTALL.md`](../../INSTALL.md).

## As peças

Este guia usa três dos binários do Evelin:

- **`evelin-server`** — o daemon que escuta por conexões.
- **`evelin-client`** — a ferramenta que você usa para se conectar.
- **`evelin-keygen`** — gera chaves de identidade (execute uma vez por
  máquina).

E quatro arquivos que você vai criar:

- Uma **chave de identidade** para o servidor (`server.key`) e uma por
  cliente (`id.evelin`). Um par de chaves ML-DSA-87 de vida longa,
  mantido privado, usado para provar quem você é em todo handshake.
- Uma **fingerprint** para cada identidade — o SHA-256 da sua metade
  pública, impresso como 64 caracteres hexadecimais. Curta o suficiente
  para ler em voz alta ou colar em um chat.
- O arquivo **`authorized_keys`** do servidor — a lista de fingerprints
  de clientes que ele vai aceitar. Como o `~/.ssh/authorized_keys`.
- O pin **`server_fingerprint`** do cliente no `client.toml` — a única
  identidade de servidor em que aquele cliente vai confiar. Como uma
  entrada em `~/.ssh/known_hosts`, mas fixada explicitamente antes da
  primeira conexão. Não há confiança-no-primeiro-uso.

## Instalação

### Opção A — compilar a partir do código-fonte

Você precisa de uma toolchain Rust (instale a partir de
<https://rustup.rs>). A partir de um checkout do repositório:

```bash
cargo build --release \
    --bin evelin-server \
    --bin evelin-client \
    --bin evelin-keygen
```

Isso produz os três binários em `target/release/`. Copie-os para algum
lugar no seu `PATH` (por exemplo, `/usr/local/bin` ou `~/.local/bin`).
Para um binário Linux totalmente estático, sem dependência de glibc,
adicione `--target x86_64-unknown-linux-musl`.

### Opção B — arquivos de release pré-compilados

Baixe o arquivo correspondente no
[lançamento v4.4.0](https://github.com/cristiancmoises/evelin-mirror/releases/tag/v4.4.0).
A lista de artefatos informa quais plataformas e formatos foram compilados.
Verifique o download contra seu manifesto SHA-256 publicado, extraia-o e
adicione os binários ao `PATH`. Builds Linux musl evitam dependência da glibc e
podem ser instalados por usuário em `~/.local/bin` no GNU Guix. Um artefato de
compilação cruzada não comprova execução testada nem suporte igual ao sandbox.

### Opção C — Docker / Forgejo

Para uma implantação baseada em contêineres dirigida por Forgejo Actions
(build, release e uma imagem Docker publicada), siga o
[`INSTALL.md`](../../INSTALL.md) de ponta a ponta.

## Passo 1 — Gerar a identidade do servidor

Escolha um diretório que o processo do servidor possa ler, mas nada mais
possa. Em uma configuração pessoal, `~/.config/evelin/` serve; para um
serviço de sistema, use um `/etc/evelin/` de propriedade do root.

```bash
evelin-keygen --out /etc/evelin/server.key
```

O `evelin-keygen` imprime onde gravou a chave e a fingerprint da
identidade:

```
wrote identity to /etc/evelin/server.key (unencrypted)
fingerprint: 7f494dead0d59a99c2f8b1e74c2a3c4f1e2d3a4b5c6d7e8f9012345678901234
```

**Anote essa fingerprint.** É o valor que cada cliente fixa como seu
`server_fingerprint` (Passo 5). Você também pode recuperá-la depois a
partir do log de inicialização do servidor (Passo 4).

Os arquivos de chave de identidade devem ter modo `0600` — o carregador
se recusa a ler qualquer coisa mais ampla:

```bash
chmod 600 /etc/evelin/server.key
```

O `evelin-keygen` se recusa a sobrescrever um arquivo existente, então
ele não vai substituir silenciosamente uma chave que você já tenha.

### Opcional: proteger a chave com senha

Para envolver o arquivo de chave com Argon2id + ChaCha20-Poly1305,
forneça uma senha por meio de uma variável de ambiente:

```bash
EVELIN_PASS='…' evelin-keygen --out /etc/evelin/server.key \
    --passphrase-from-env EVELIN_PASS
```

Você também pode ler a senha de um descritor de arquivo com
`--passphrase-from-fd 0` (stdin). Os parâmetros de custo do Argon2id têm
como padrão memória `--argon2-m 65536` (64 MiB), iterações
`--argon2-t 3` e paralelismo `--argon2-p 1`; passe essas flags para
alterá-los. Se você envolver a chave, a mesma senha deve estar disponível
para o `evelin-server` quando ele iniciar.

## Passo 2 — Escrever uma configuração mínima de servidor

O servidor lê um arquivo TOML. Uma configuração mínima precisa de um
endereço de bind, um caminho para a chave de identidade e um caminho para
o arquivo de chaves autorizadas:

```toml
# /etc/evelin/server.toml
bind            = "0.0.0.0:2200"
identity_key    = "/etc/evelin/server.key"
authorized_keys = "/etc/evelin/authorized_keys"

log_format      = "text"   # "json" for production / log aggregators
log_level       = "info"
```

`identity_key` e `authorized_keys` são obrigatórios; `bind` é opcional e
tem como padrão `0.0.0.0:2200`. Faça o bind em `127.0.0.1` para um
servidor apenas local, ou `0.0.0.0` para todas as interfaces. A
configuração é analisada de forma estrita — uma chave desconhecida faz a
inicialização falhar em vez de ampliar a política silenciosamente.

> **Os caminhos são literais.** O parser TOML não expande `~` nem
> `$HOME`. Sempre escreva caminhos absolutos, por exemplo,
> `/home/you/.config/evelin/server.key`, e não `~/.config/...`.

## Passo 3 — Autorizar uma chave de cliente

Primeiro, gere uma identidade de cliente na máquina cliente, exatamente
como no Passo 1:

```bash
evelin-keygen --out ~/.config/evelin/id.evelin
```

```
wrote identity to /home/alice/.config/evelin/id.evelin (unencrypted)
fingerprint: 57a616ad35e8779f7a5d7fc374858131d812f3387b3cf48c8182d156fb6ced62
```

```bash
chmod 600 ~/.config/evelin/id.evelin
```

Envie essa fingerprint de cliente para quem administra o servidor. No
servidor, liste-a no arquivo `authorized_keys`. O formato é exato:

```
# evelin-authorized-keys v1
57a616ad35e8779f7a5d7fc374858131d812f3387b3cf48c8182d156fb6ced62  alice@laptop
```

- A primeira linha não vazia e sem comentário **deve** ser o cabeçalho
  literal `# evelin-authorized-keys v1`.
- Cada linha seguinte é um peer: uma fingerprint de 64 caracteres
  hexadecimais, seguida de um comentário opcional. Os comentários são
  informativos — ajudam humanos a auditar o arquivo e não são usados para
  a correspondência.
- O arquivo deve ter modo `0600`.

```bash
chmod 600 /etc/evelin/authorized_keys
```

## Passo 4 — Iniciar o servidor

```bash
evelin-server --config /etc/evelin/server.toml
```

Você verá uma linha de inicialização informando o endereço de bind e a
própria fingerprint do servidor:

```
INFO evelin server listening bind=0.0.0.0:2200 server_fingerprint=7f494dead0d59a99…
```

Essa `server_fingerprint` é o valor que os clientes fixam no Passo 5 —
este é um segundo lugar para lê-la, caso você não a tenha anotado durante
o Passo 1.

O servidor roda em primeiro plano; pare-o com `Ctrl-C`. Duas flags ajudam
antes e durante a inicialização:

- `evelin-server --config … --check` valida a configuração e sai sem
  fazer bind ou escutar — ele analisa o TOML, verifica o caminho da chave
  de identidade, o endereço de bind e se o `authorized_keys` carrega. O
  código de saída `0` significa válido. Bom para uma verificação rápida
  depois de editar a configuração.
- `evelin-server --config … --init` gera uma nova chave de identidade no
  caminho `identity_key` configurado, caso o arquivo ainda não exista.

Se o log avisar que o arquivo de chaves autorizadas está vazio ou
ausente, nenhum cliente será aceito — revisite o Passo 3.

## Passo 5 — Configurar o cliente e fixar a fingerprint do servidor

Na máquina cliente, escreva o `client.toml`:

```toml
# ~/.config/evelin/client.toml
server_addr        = "server.example.com:2200"
identity_key       = "/home/alice/.config/evelin/id.evelin"

# The server's fingerprint from Step 1 / Step 4, pinned here.
server_fingerprint = "7f494dead0d59a99c2f8b1e74c2a3c4f1e2d3a4b5c6d7e8f9012345678901234"

log_format         = "text"
log_level          = "info"
```

O `server_fingerprint` é o passo de verificação da chave do host. Em toda
conexão, o cliente compara a identidade que o servidor apresenta com esse
valor fixado. Se elas diferirem, o cliente recusa a conexão e aborta o
handshake com `authorization denied` — isso significa que você fixou a
fingerprint errada, ou que algo está se passando pelo servidor. Não há
confiança-no-primeiro-uso; você obtém a fingerprint fora de banda (a
partir do Passo 1 ou do log do Passo 4, por um canal em que você confia)
e a fixa antes de se conectar.

Como no servidor, `identity_key` deve ser um caminho absoluto, e o
arquivo de chave deve ter modo `0600`.

## Passo 6 — Primeira conexão: executar um comando

O `evelin-client` conecta e executa um subcomando sobre a mesma sessão
autenticada de forma pós-quântica. O mais simples é o `exec`, que executa
um comando no servidor, transmite sua saída de volta e sai com o código
de saída do processo remoto:

```bash
evelin-client --config ~/.config/evelin/client.toml exec uptime
```

Para isso funcionar, o comando deve estar na lista de permissão de exec
do servidor. Adicione uma seção `[exec]` ao `server.toml` e reinicie o
servidor:

```toml
[exec]
allow = ["uptime"]
```

Uma lista de permissão vazia ou ausente nega o exec por completo — esse é
o padrão seguro. A lista de permissão faz a correspondência com o `argv0`
do comando.

Por padrão o cliente é silencioso, como o `ssh`: uma conexão
bem-sucedida imprime apenas a saída do próprio comando, nada sobre o
handshake. Para ver o ciclo de vida da conexão, adicione `-v`
(repetível):

```bash
evelin-client -v --config ~/.config/evelin/client.toml exec uptime
# stderr: ... INFO evelin_client: handshake complete endpoint=... server_fingerprint=...
```

`-v` é INFO, `-vv` é DEBUG, `-vvv` é TRACE; `-q` mostra apenas erros.
Todos os logs vão para o **stderr**, então o stdout do comando fica
limpo para encadeamento (pipe). Um `RUST_LOG` não vazio sobrepõe isso.

Mais duas flags do cliente são úteis aqui:

- `--addr host:port` sobrepõe o `server_addr` da configuração para uma
  única execução.
- `--connect-timeout <seconds>` define o tempo limite da conexão.

Se a chave do cliente não estiver no `authorized_keys` do servidor, o
servidor fecha a conexão durante o handshake — o cliente reporta uma
falha de handshake (um `wire encoding error`) e o servidor registra a
rejeição (Passo 3). Se o cliente registrar `connection refused`, o
servidor não está rodando ou um firewall está no caminho.

## Abrir um shell interativo

```bash
evelin-client --config ~/.config/evelin/client.toml shell
```

Isso inicia um shell dentro de um PTY no servidor e faz a ponte do seu
terminal com ele. O lado do servidor deve ser **compilado com a feature
`pty-shell`** e deve habilitar sessões de shell no `server.toml`:

```toml
[shell]
enable  = true
command = "/bin/sh"
```

O `command` tem como padrão `/bin/sh`. O subcomando `shell` também aceita
`--term`, `--cols` e `--rows` para definir o tipo e o tamanho inicial do
terminal. Use `exit` ou `Ctrl-D` para fechar a sessão.

## Copiar um arquivo

O subcomando `cp` copia um arquivo em qualquer direção. Um lado da cópia
deve ser um caminho `remote:` (um caminho absoluto no servidor); o outro
é um caminho local.

```bash
# Upload: local → server
evelin-client --config ~/.config/evelin/client.toml \
    cp ./local-file.txt remote:/srv/uploads/local-file.txt

# Download: server → local
evelin-client --config ~/.config/evelin/client.toml \
    cp remote:/srv/data/report.pdf ./report.pdf
```

Habilite a cópia de arquivos no servidor listando as raízes sob as quais
os caminhos remotos devem cair, e permitindo a(s) direção(ões) que você
precisa:

```toml
[filecopy]
roots          = ["/srv/uploads", "/srv/data"]
allow_upload   = true
allow_download = true
```

Uma lista `roots` vazia nega a cópia de arquivos por completo. Tanto
`allow_upload` quanto `allow_download` têm como padrão desligado, então
você deve habilitar cada direção explicitamente.

## Quando não conecta

Leia a mensagem de erro do cliente; a maioria das falhas de primeira vez
corresponde a uma destas:

| O cliente diz | Causa | Correção |
|---|---|---|
| `connection refused` | Servidor não está rodando, ou um firewall bloqueia a porta | Confirme que o `evelin-server` está no ar; verifique o firewall do host |
| `authorization denied` | O `server_fingerprint` fixado não corresponde à identidade que o servidor apresentou | Releia a fingerprint do servidor (Passo 1 / Passo 4) e corrija o `client.toml` |
| `wire encoding error` no meio do handshake | A fingerprint do cliente não está no `authorized_keys` do servidor, então o servidor fechou a conexão | Adicione-a e reinicie (Passo 3); o log do servidor registra a rejeição |
| `cryptographic verification failed` | A assinatura de handshake do servidor não verificou — adulteração em trânsito, ou uma chave de servidor corrompida | Investigue o caminho de rede; obtenha novamente a identidade do servidor |
| `insecure mode …; expected 0o600` | O arquivo de chave de identidade está mais amplo que `0600` | Aplique `chmod 600` ao arquivo de chave |

Para um rastro detalhado do handshake, defina `log_level = "debug"` no
`client.toml` (não há flag `--log-level`; a verbosidade do cliente vem do
`log_level` na sua configuração).

## Para onde ir em seguida

- [`docs/QUICKSTART.md`](../QUICKSTART.md) — o mesmo caminho com mais
  profundidade, além de uma unit do systemd para rodar o servidor como um
  serviço e uma tabela de resolução de problemas mais completa.
- [`INSTALL.md`](../../INSTALL.md) — implantação com Docker e Forgejo
  Actions.

Para o conjunto exato de flags e diretivas, as páginas de manual são
autoritativas: `evelin-keygen(1)`, `evelin-client(1)`,
`evelin-server(8)` e `evelin.conf(5)`.

## Exportações fixas (v4.4.0, Linux)

Para receber dump PostgreSQL custom ou arquivo restrito de dados Forgejo
predefinido pelo servidor, siga [exportações fixas](fixed-export.md). São
necessários servidor dedicado separado, autorização explícita do exportador,
Landlock totalmente aplicado antes do runtime e destino privado. Não habilite
o recurso na instância de uso geral configurada acima. O novo canal não muda
a configuração de chave/confiança de exec, shell e cópia de arquivos comuns.
