/*
 * evelin.h — libevelin v1 C ABI
 *
 * SPDX-License-Identifier: AGPL-3.0-or-later OR LicenseRef-Evelin-Commercial
 *
 * Stable C ABI for the evelin post-quantum secure communication
 * library. This header is the foundation that every language SDK
 * (Rust, C, Python, Go, Node, Ruby, Java, Swift, .NET, Elixir,
 * OCaml, Guile) binds to.
 *
 * ABI versioning: the v1 ABI is stable for the lifetime of any
 * libevelin.so.1 / libevelin.1.dylib / evelin-1.dll. Within v1
 * we may ADD symbols and ADD enum variants at the end, but
 * never remove, reorder, or repurpose. Breaking changes go to
 * v2 with a soname bump.
 *
 * Threading: handles are Send (movable across threads) but not
 * Sync (one thread at a time). Internal state is protected by
 * a per-handle mutex. evln_cancel() is thread-safe and may be
 * invoked concurrently with any other call on the same handle.
 *
 * Memory ownership: the caller never owns memory returned from
 * libevelin via opaque handles -- libevelin owns it, free with
 * the matching evln_*_free(). For byte buffers, the caller
 * always provides a buffer with a length, and libevelin writes
 * up to that length and reports how much it wrote.
 *
 * Errors: every function that can fail returns an evln_status_t.
 * 0 (EVLN_OK) is success. Out-parameters are written only on
 * success. evln_strerror() turns a status into a stable string.
 *
 * Init: call evln_init() exactly once at process start. Call
 * evln_shutdown() once before exit. Both are idempotent and
 * thread-safe.
 */

#ifndef EVELIN_H
#define EVELIN_H 1

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ------------------------------------------------------------------
 *  ABI version
 * ------------------------------------------------------------------ */

#define EVELIN_ABI_MAJOR 1u
#define EVELIN_ABI_MINOR 0u

/* Returns ((major << 16) | minor) of the ABI compiled into the
 * library. SDKs should call this at load time and refuse to
 * proceed if the major does not match what they were compiled
 * against. */
uint32_t evln_abi_version(void);

/* Returns a stable, NUL-terminated, statically-allocated
 * version string of the form "1.4.0". Never NULL. */
const char* evln_version_string(void);

/* ------------------------------------------------------------------
 *  Status codes
 * ------------------------------------------------------------------ */

typedef int32_t evln_status_t;

#define EVLN_OK              0  /* success */
#define EVLN_E_INVAL         1  /* invalid argument */
#define EVLN_E_NOMEM         2  /* allocation failed */
#define EVLN_E_IO            3  /* underlying I/O error */
#define EVLN_E_AUTH          4  /* authentication / authorization failure */
#define EVLN_E_PROTO         5  /* protocol violation observed */
#define EVLN_E_TIMEOUT       6  /* timed out */
#define EVLN_E_CANCELLED     7  /* cancelled via evln_cancel */
#define EVLN_E_VERIFY        8  /* integrity / signature verification failed */
#define EVLN_E_AGAIN         9  /* would-block / retry */
#define EVLN_E_CLOSED       10  /* peer closed cleanly; no more data */
#define EVLN_E_NOT_INIT     11  /* evln_init() was not called */
#define EVLN_E_BUSY         12  /* concurrent op already in flight on handle */
#define EVLN_E_TOO_LARGE    13  /* input exceeded a protocol limit */
#define EVLN_E_NOT_FOUND    14  /* lookup found nothing */
#define EVLN_E_INTERNAL    255  /* unexpected internal error; report a bug */

/* Returns a stable, NUL-terminated description of `s`. Never
 * NULL, even for unknown codes. Statically allocated; do not
 * free. */
const char* evln_strerror(evln_status_t s);

/* ------------------------------------------------------------------
 *  Process init / shutdown
 * ------------------------------------------------------------------ */

/* Initializes the global runtime (Tokio multi_thread). Idempotent.
 * Returns EVLN_OK or EVLN_E_INTERNAL. */
evln_status_t evln_init(void);

/* Tears down the global runtime. After this, no other API call
 * is valid until the next evln_init(). Idempotent. */
void evln_shutdown(void);

/* ------------------------------------------------------------------
 *  Opaque handle types
 * ------------------------------------------------------------------ */

typedef struct evln_client  evln_client_t;
typedef struct evln_session evln_session_t;
typedef struct evln_channel evln_channel_t;

/* ------------------------------------------------------------------
 *  Client construction & configuration
 * ------------------------------------------------------------------ */

/* Construct a new client. *out is set on success; the caller
 * owns it and must free with evln_client_free().
 * Returns EVLN_OK on success, EVLN_E_NOT_INIT, or EVLN_E_NOMEM. */
evln_status_t evln_client_new(evln_client_t** out);

/* Free a client handle. NULL-safe. After this the pointer is
 * invalid. Does not affect any sessions previously opened from
 * this client; sessions own their own state. */
void evln_client_free(evln_client_t* c);

/* Load an identity key from a file path (UTF-8, NUL-terminated).
 * Replaces any previously loaded identity. Returns EVLN_OK or
 * EVLN_E_IO / EVLN_E_INVAL / EVLN_E_VERIFY. */
evln_status_t evln_client_load_identity(evln_client_t* c, const char* path);

/* Load an identity from raw bytes already in memory. Useful
 * when the application has its own keystore. Caller retains
 * ownership of `bytes`. */
evln_status_t evln_client_load_identity_bytes(
    evln_client_t* c, const uint8_t* bytes, size_t len);

/* Configure the path of the known-hosts file (analogous to
 * SSH known_hosts). Optional; if unset, host pinning is
 * "trust on first use" disabled and the connection will fail
 * if no pin is found. */
evln_status_t evln_client_known_hosts(evln_client_t* c, const char* path);

/* ------------------------------------------------------------------
 *  Connect & session lifecycle
 * ------------------------------------------------------------------ */

/* Connect to host:port and complete a post-quantum handshake.
 * timeout_ms == 0 means "no timeout".  *out is set on success.
 * Returns EVLN_OK, or one of: EVLN_E_IO, EVLN_E_TIMEOUT,
 * EVLN_E_AUTH, EVLN_E_PROTO, EVLN_E_CANCELLED, EVLN_E_VERIFY. */
evln_status_t evln_connect(
    evln_client_t* c,
    const char* host,
    uint16_t    port,
    uint32_t    timeout_ms,
    evln_session_t** out);

/* Disconnect cleanly and free the session handle. NULL-safe. */
void evln_session_free(evln_session_t* s);

/* Cancel any in-flight operation on this session from another
 * thread. Thread-safe. The cancelled call returns EVLN_E_CANCELLED. */
void evln_cancel(evln_session_t* s);

/* Returns the session's peer-identity fingerprint (32 bytes).
 * `buf` must be >= 32 bytes; *written is set to 32 on success. */
evln_status_t evln_session_peer_fingerprint(
    evln_session_t* s, uint8_t* buf, size_t cap, size_t* written);

/* ------------------------------------------------------------------
 *  Channels (exec, raw)
 * ------------------------------------------------------------------ */

/* Open an exec channel: run `cmd` on the remote side. *out is
 * set on success. */
evln_status_t evln_session_open_exec(
    evln_session_t* s, const char* cmd, evln_channel_t** out);

/* Read up to `cap` bytes from the channel into `buf`. Blocks
 * until at least one byte is available or the channel closes.
 * On clean close returns EVLN_OK with *written = 0 -- callers
 * loop until that condition. Returns EVLN_E_AGAIN if the
 * channel was set non-blocking and no data is ready (reserved;
 * v1.4 always blocks). */
evln_status_t evln_channel_read(
    evln_channel_t* ch, uint8_t* buf, size_t cap, size_t* written);

/* Write up to `len` bytes; *written reports how many were
 * actually queued. Short writes are normal under back-pressure. */
evln_status_t evln_channel_write(
    evln_channel_t* ch, const uint8_t* buf, size_t len, size_t* written);

/* Close the channel and wait for the remote-side exit code.
 * If the channel was already closed, returns EVLN_OK with the
 * cached exit code. */
evln_status_t evln_channel_close(evln_channel_t* ch, int32_t* exit_code_out);

/* Free a channel handle. NULL-safe. If the channel is still
 * open, this drops it without waiting for an exit code. */
void evln_channel_free(evln_channel_t* ch);

/* ------------------------------------------------------------------
 *  Convenience: exec-and-collect (used by hello-evelin)
 * ------------------------------------------------------------------ */

/* Run `cmd` on the remote, collect stdout into a caller-supplied
 * buffer up to `cap`, return how much was actually captured in
 * *written, and the remote exit code in *exit_code_out.
 * Output beyond `cap` is silently truncated; *written may equal
 * cap with more data still on the wire. */
evln_status_t evln_session_run(
    evln_session_t* s,
    const char* cmd,
    uint8_t* stdout_buf,
    size_t   cap,
    size_t*  written,
    int32_t* exit_code_out);

#ifdef __cplusplus
}  /* extern "C" */
#endif

#endif  /* EVELIN_H */
